# DART Form Mockup & Rule Studio 🎨
### Enterprise Intake Form Visual Studio, Rule Simulator & Sprint Versioning Ledger

A lightweight, zero-framework visual form builder, interactive rule simulator, and multi-sprint version control platform built specifically for Cisco DART (Demand Acceleration Request Tracking) intake forms.

It runs **100% offline** with **pure HTML5, CSS3, and Vanilla JavaScript (ES6)**—requiring no Node.js runtime, build pipeline, or external web servers. Business Analysts (BA), Marketing Operations (MOPs) teams, stakeholders, and developers can open and run it simply by double-clicking `htmlprototype/index.html` in Google Chrome or Microsoft Edge.

---

## 📑 Table of Contents

1. [Where Are Form & Version Files Stored?](#-where-are-form--version-files-stored)
2. [Quick Start & Key Capabilities](#-quick-start--key-capabilities)
3. [Complete Directory & Architecture Specification](#-complete-directory--architecture-specification)
4. [Saving Forms & Sprint Version Control Specifications](#-saving-forms--sprint-version-control-specifications)
5. [The 15 Pre-Seeded Cisco DART Intake Forms](#-the-15-pre-seeded-cisco-dart-intake-forms)
6. [Field Types & Workfront Custom Mapping Specs](#-field-types--workfront-custom-mapping-specs)
7. [Advanced Logic Studio (Rule Engine Specs)](#-advanced-logic-studio-rule-engine-specs)
8. [Export & Handover Workflows](#-export--handover-workflows)
9. [Keyboard Shortcuts & Quick Reference](#-keyboard-shortcuts--quick-reference)

---

## 💾 Where Are Form & Version Files Stored? (Architecture & Data Flow)

DART Form Studio uses a **Folder-Native Persistence Architecture** paired with a **Dual-Mode Execution Flow**. This ensures you can run the studio with real-time local disk persistence (via the local Node server) **or** 100% offline via direct double-click in any browser.

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                     FOLDER-NATIVE REPOSITORY ARCHITECTURE                                    │
├──────────────────────────────────────────────────────┬──────────────────────────────────────────────────────┤
│ 1. Individual Form Subdirectories (forms/<form-id>/) │ 2. Master Repository Manifests (forms/)              │
│    • form.json: Active working draft schema          │    • forms-manifest.json: Full compiled JSON catalog │
│    • manifest.json: Form metadata & version ledger   │    • forms-manifest.js: Browser window bundle (offline│
│    • versions/vX.X.json: Immutable sprint snapshots  │    • server.js: Local folder server (port 3000)      │
└──────────────────────────────────────────────────────┴──────────────────────────────────────────────────────┘
```

---

### 📄 What is `form.json` and What is Stored There?

Each form has its own folder under `htmlprototype/forms/<form-id>/` containing a **`form.json`** file (e.g. `forms/audience/form.json`, `forms/webinar/form.json`).

* **Role**: **The Working Draft Schema**. This is the active, live form definition currently being designed on the canvas.
* **What is stored inside**:
  ```json
  {
    "title": "Audience Intake Form",
    "description": "Define and document the target audience for a marketing campaign...",
    "sections": [
      {
        "id": "aud_s1",
        "title": "Project Details",
        "collapsed": false,
        "fields": [
          {
            "id": "aud_f1",
            "wfId": "61df5582003a92b049cafa45f74e87ac",
            "wfFieldName": "contentTitle",
            "wfLabel": "Project / Audience Name",
            "label": "",
            "type": "text",
            "col": "col-lg-6",
            "required": true,
            "placeholder": "e.g. SMB Security Buyers EMEA Q3",
            "tooltip": "Enter the project title",
            "formData": "contentTitle",
            "baNotes": "Mandatory Workfront field",
            "options": [],
            "condition": null,
            "resets": []
          }
        ]
      }
    ]
  }
  ```
* **Key Fields in `form.json`**:
  - `title` & `description`: Form name and purpose displayed on canvas header.
  - `sections[]`: Ordered list of visual section cards on the canvas.
  - `fields[]`: Complete array of fields within each section containing:
    - **UI Presentation**: `type` (`text`, `select`, `multiselect_fancy`, `radio`, `date`, etc.), `col` (`col-lg-6`, `col-lg-12`), `placeholder`, `tooltip`.
    - **Data Binding**: `formData` (the DART state key).
    - **Workfront Mapping**: `wfId`, `wfFieldName`, `wfLabel` (custom form mapping attributes).
    - **Picklist Choices**: `options` array (objects with `{ label, value }` or strings).
    - **Business Rules**: `condition` (DNF logic rule tree), `resets` (fields cleared when hidden).
    - **BA Notes**: Business Analyst instructions and requirements.

---

### 📦 What is `forms-manifest.json` and `forms-manifest.js`?

The root of `htmlprototype/forms/` contains two manifest files:

#### 1. `forms-manifest.json` (Master JSON Catalog)
* **Role**: The consolidated database of all 15 intake forms and their full version histories in a single standard JSON file.
* **What is stored inside**:
  ```json
  {
    "repositoryName": "DART Form Mockup & Rule Studio",
    "version": "2.0.0",
    "updatedAt": "2026-10-13T11:43:08.505Z",
    "forms": [
      {
        "id": "audience",
        "label": "Audience",
        "icon": "👥",
        "configFile": "form.audience.config.ts",
        "activeVersionId": "v4.0",
        "activeSprint": "Sprint 24.11",
        "folder": "audience",
        "totalVersions": 4,
        "schema": { /* form.json contents */ },
        "versions": [
          {
            "versionId": "v1.0",
            "versionLabel": "v1.0 (Baseline)",
            "sprint": "Sprint 24.8",
            "timestamp": "2026-09-01T09:58:43.961Z",
            "author": "MOPs Business Ops",
            "status": "Archived",
            "notes": "Initial baseline specification",
            "schema": { /* v1.0 snapshot */ },
            "stats": { "sectionCount": 3, "fieldCount": 8, "rulesCount": 0 }
          }
        ]
      }
    ]
  }
  ```

#### 2. `forms-manifest.js` (Offline Browser Bundle)
* **Role**: Exactly the same content as `forms-manifest.json`, wrapped inside:
  ```javascript
  /** Auto-generated DART Folder Repository Manifest **/
  window.DART_FORMS_REPOSITORY = { /* identical manifest object */ };
  ```
* **Why this file exists**:
  Standard web browsers (Chrome, Edge) enforce the **Same-Origin Policy / CORS restrictions** that block `fetch('forms/forms-manifest.json')` when `index.html` is opened directly from your file explorer using the `file:///` protocol without a web server.
  By loading `forms-manifest.js` via `<script src="forms/forms-manifest.js"></script>`, the entire catalog loads **synchronously with zero CORS errors**, allowing the studio to function 100% offline out-of-the-box!

---

### 🔄 The End-to-End System Flow

Here is how data flows from startup to editing, saving, and code export:

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                       SYSTEM EXECUTION FLOW                                      │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘

 1. BOOT SEQUENCE
    • User opens http://localhost:3000 (or double-clicks index.html).
    • WorkspaceRepo.detectMode() checks for local server at localhost:3000/api/status.
    ├── If SERVER DETECTED (🟢 Folder-Saved Mode):
    │   • Calls GET /api/manifest.
    │   • server.js scans htmlprototype/forms/*, reading form.json, manifest.json & versions/.
    │   • WorkspaceRepo receives fresh disk state and populates App.allForms.
    └── If OFFLINE / FILE PROTOCOL (🟡 Memory Mode):
        • Instantly seeds App.allForms from window.DART_FORMS_REPOSITORY (forms-manifest.js).

 2. CANVAS & DRAWER EDITING
    • User clicks any of the 15 form tabs (e.g., Audience Intake Form).
    • App.switchForm() loads that form's schema into memory and renders the sections/fields.
    • Clicking a field card opens the Right Inspector Drawer:
      - "Settings" tab: Edits labels, placeholder, Workfront IDs, grid width (col).
      - "Options" tab: Edits/adds/deletes picklist choices; canvas updates in real-time.
      - "Rules" tab: Configures dynamic display conditions via the Rule Engine.
      - "BA Notes" tab: Documents field logic and Workfront configuration notes.

 3. SAVING THE WORKING DRAFT (💾 Save Form / Ctrl+S)
    • Flushes active drawer inputs into this.formSchema.
    • Calls WorkspaceRepo.saveForm(activeForm, this.formSchema).
    • In Server Mode:
      - Sends POST /api/forms/save with updated schema.
      - server.js overwrites forms/<form-id>/form.json directly on disk.
      - server.js updates forms/<form-id>/manifest.json timestamp.
      - server.js calls rebuildMasterManifest() to regenerate forms-manifest.json & forms-manifest.js.
    • UI shows "Changes applied ✓" toast and emerald status confirmation.

 4. FREEZING A SPRINT VERSION (🔖 Save Version)
    • User opens Save Sprint Version dialog, enters Sprint ID (e.g. Sprint 24.12) & notes.
    • VersionManager creates an immutable deep-clone snapshot.
    • Calls WorkspaceRepo.saveVersion(activeForm, versionRecord).
    • In Server Mode:
      - Sends POST /api/versions/save.
      - server.js writes forms/<form-id>/versions/vX.X.json on disk.
      - server.js updates versions ledger in forms/<form-id>/manifest.json.
      - server.js rebuilds master manifests.
    • Historical versions appear immediately in the Time-Machine Diff Inspector (⏱️ Versions).

 5. CODE GENERATION & EXPORT (💻 View Config / DART Code)
    • Exporter inspects active formSchema or any selected version snapshot.
    • Compiles a production-grade TypeScript configuration file: form.<id>.config.ts.
    • Surfaced via the DART Config Studio panel with syntax highlighting, copy, and .ts download.
```

## 🚀 Quick Start & Key Capabilities

1. **Launch Studio**: Double-click `htmlprototype/index.html` in Chrome or Edge.
2. **Explore 15 Cisco DART Forms**: Click any tab along the top strip (Webinar, Email, Event, Webpage, etc.) or open the **`📚 Form Gallery`**.
3. **Build & Reorder**:
   - Drag field components from the left palette into any section.
   - Click field width toggles (`½`, `1/1`, `⅓`, `¼`) to dynamically adjust layout columns.
   - Click field cards to edit labels, placeholders, tooltips, and Workfront mapping attributes in the right drawer.
4. **Simulate Business Rules**:
   - Click **`⚡ Logic`** on any field to open the **Advanced Logic Studio** (supports AND/OR logic groups).
   - Click **`👁️ Live Preview`** in the top navbar to test the form interactively with real-time rule evaluation and 3 visual design variations (Modern Studio, DART Cisco Brand, Step Wizard).
5. **Save & Version Control**:
   - Click **`💾 Save Form`** (`Ctrl+S`) to save active canvas changes. A confirmation pop-up displays storage details with a direct JSON download button.
   - Click **`🔖 Save Version`** to freeze a permanent milestone release (e.g., `v2.0 - Sprint 25.2`).
   - Click **`⏱️ Versions`** to open the Time-Machine ledger and visually inspect side-by-side diffs.
6. **Export & Handover**:
   - Click **`📤 Share HTML`** to export a locked, standalone HTML review file for stakeholders.
   - Click **`💻 DART Code`** to generate production-ready Angular TypeScript config (`form.<name>.config.ts`).

---

## 📁 Complete Directory & Architecture Specification

```
htmlprototype/
├── index.html                  # Main Visual Studio SPA (Canvas, Palettes, Tabs, Drawer, Modals)
├── server.js                   # Node.js local folder-persistence HTTP server (port 3000)
├── start.bat                   # 1-click batch launcher for local folder server
├── README.md                   # Full system specifications, user guide & architecture manual
│
├── forms/                      # Physical JSON form specification files on disk
│   ├── forms-manifest.json     # Master compiled catalog of all 15 forms & sprint histories
│   ├── forms-manifest.js       # Offline script bundle setting window.DART_FORMS_REPOSITORY
│   │
│   ├── audience/               # Form directory (e.g. Audience Definition Intake Form)
│   │   ├── form.json           # Active working draft schema (sections, fields, rules)
│   │   ├── manifest.json       # Metadata ledger (id, label, icon, activeVersionId, sprint)
│   │   └── versions/           # Immutable historical milestone snapshots
│   │       ├── v1.0.json       # Baseline snapshot
│   │       ├── v2.0.json       # Sprint 24.9 snapshot
│   │       ├── v3.0.json       # Sprint 24.10 snapshot
│   │       └── v4.0.json       # Sprint 24.11 snapshot
│   │
│   ├── webinar/                # Webinar production intake form directory
│   ├── email/                  # Email campaign intake form directory
│   ├── event/                  # Event & Cisco Live collateral directory
│   └── ... (15 form directories)
│
├── exports/                    # Generated standalone review HTML files for stakeholders
│   └── webpage-request-review.html
│
├── css/
│   └── styles.css              # Cisco UI 2.0 (CUI) Design System, glassmorphism & responsive grid
│
└── js/
    ├── app.js                  # Core controller: State management, canvas render, save popups, tabs
    ├── workspace-repo.js       # Dual-mode persistence engine (Server API vs. offline manifest)
    ├── version-manager.js      # Sprint versioning engine: Semantic tags, snapshots, visual diff, exports
    ├── forms-registry.js       # Enterprise registry: 15 pre-seeded Cisco DART intake form schemas
    ├── presets.js              # Standard Workfront fields, Common Stakeholder & Country section libraries
    ├── rule-engine.js          # Disjunctive Normal Form (DNF) condition evaluator & cascading resets
    ├── drag-drop.js            # Native HTML5 drag-and-drop handler with drop target indicators
    ├── exporter.js             # DART Angular TypeScript generator & standalone review HTML packager
    └── standalone-css.js       # Embedded CSS payload for generating zero-dependency standalone HTML files
```

### Module Responsibilities:

| File | Purpose & Architecture Role |
| :--- | :--- |
| **`index.html`** | Single Page Application shell. Contains the Cisco navigation bar, mode switcher (`Builder` vs `Live Preview`), multi-form horizontal scroll tab strip, palette sidebar, canvas container, field inspector drawer, and modal dialogs (Logic Studio, Version History, Spec Sheet, Export, Save Confirmation Popups). |
| **`js/app.js`** | Master application controller. Manages reactive state (`allForms`, `activeFormId`, `formSchema`), coordinates rendering, dispatches autosave and manual save events, manages drawer inputs, and powers high-visibility toast and modal pop-up notifications. |
| **`js/version-manager.js`** | Enterprise versioning and time-machine engine. Creates immutable deep-clone snapshots of form schemas, computes smart semantic version tags (`v1.0` ➔ `v2.0` / `v2.1`) and sprints (`Sprint 25.1` ➔ `Sprint 25.2`), performs field-by-field AST diffing, and manages version swapping. |
| **`js/forms-registry.js`** | Pre-seeded DART catalog containing 15 production-grade Cisco intake forms with complete section structures, Workfront GUID mappings, picklists, and conditional visibility rules. |
| **`js/rule-engine.js`** | Pure logic engine implementing Disjunctive Normal Form (DNF). Evaluates condition trees across multiple operators (`isSelected`, `equals`, `contains`, `regex`, numeric comparisons), handles multi-select arrays, and performs automatic cascading resets on hidden fields. |
| **`js/exporter.js`** | Generates production Angular TypeScript configuration files (`form.<name>.config.ts`) adhering to Cisco DART's `form_structure = [ ... ]` contract, and compiles standalone locked HTML review files with zero external dependencies. |
| **`js/drag-drop.js`** | Native HTML5 Drag and Drop API implementation. Handles dragging fields from palette to sections, reordering fields within a section, moving fields across sections, and reordering sections on the canvas. |
| **`js/presets.js`** | Standardized Cisco field definitions (Project Name, CEC ID, Campaign Alignment, Activity ID, SLA Notes) and reusable section templates (Common Stakeholder Section, Common Country Selection). |
| **`js/standalone-css.js`** | Self-contained, minified CSS bundle bundled directly into exported review HTML files so they render perfectly offline without external stylesheets. |
| **`css/styles.css`** | Primary stylesheet built upon Cisco UI 2.0 (CUI) tokens, modern glassmorphic accents, CSS custom properties, responsive multi-column layouts, and modal animation transitions. |

---

## 🔖 Saving Forms & Sprint Version Control Specifications

The studio provides a dual-tiered persistence and version control model:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           DUAL-TIERED SAVE WORKFLOW                             │
├───────────────────────────────────────┬─────────────────────────────────────────┤
│ TIER 1: Working Draft Save            │ TIER 2: Sprint Version Snapshot Freeze  │
│ Button: [💾 Save Form] or (Ctrl+S)    │ Button: [🔖 Save Version]               │
│ • Saves current canvas schema         │ • Freezes an immutable milestone tag   │
│ • Syncs with browser LocalStorage     │ • Records Sprint ID, Author, Changelog  │
│ • Displays Save Form pop-up modal     │ • Auto-downloads JSON to forms/ folder  │
│ • Fast, iterative working checkpoint  │ • Opens in Time-Machine Version Diff    │
└───────────────────────────────────────┴─────────────────────────────────────────┘
```

### 1. Tier 1: Saving Working Form State (`💾 Save Form`)
* **Trigger**: Click **`💾 Save Form`** in the top navbar or press **`Ctrl+S`**.
* **What Happens**:
  1. The studio syncs all live canvas DOM inputs into the active form's schema.
  2. Data is written to `localStorage['dart_all_forms']` and `localStorage['dart_active_form_id']`.
  3. The Save Form button flashes **`✓ Saved!`** with emerald highlighting.
  4. The top-center notification banner confirms: `🔔 💾 Form saved to workspace storage!`.
  5. The **`Form Saved Successfully!`** pop-up confirmation modal opens, displaying:
     - Form title and icon.
     - Active version badge (e.g. `v2.1 Active`).
     - Scope summary (`4 Sections • 16 Fields • 3 Rules`).
     - Storage explanation: Confirms data is safely stored in browser `localStorage`.
     - Direct Action Buttons:
       - **`📥 Download Form JSON`**: Triggers immediate download of `<form-name>.json`.
       - **`🔖 Freeze as Sprint Version`**: Promotes working draft into a milestone version.
       - **`✓ Done`**: Closes the dialog.

### 2. Tier 2: Freezing a Sprint Version Snapshot (`🔖 Save Version`)
* **Trigger**: Click **`🔖 Save Version`** (in the top navbar or form tab strip) or select **`Save Sprint Version Snapshot…`** from `⚙️ Form Actions`.
* **The Save Sprint Version Modal**:
  - **Form Title & Current Baseline**: Displays the active form and current tag (`v2.1 - Sprint 25.1`).
  - **Sprint Identifier**: Auto-increments to next sprint (e.g., `Sprint 25.2`). Quick chips allow 1-click selection (`Sprint 25.2`, `Hotfix Release`).
  - **Version Tag**: Auto-calculates next semantic version (e.g., `v2.0` for major releases or `v2.2` for minor revisions). Quick buttons allow `+ Major` or `+ Minor` increments.
  - **Lifecycle Status**: Choose from `🟢 Active (Current Sprint Target)`, `🟡 Sprint Review / Staging`, `⚪ Draft / Proposal`, or `🔵 Approved Production Baseline`.
  - **Author**: Default prefilled (`MOPs Business Team`).
  - **Sprint Changelog / Release Notes**: Detailed business justification describing what changed.
  - **Download JSON Checkbox**:
    > ☑ **Download JSON file upon saving (to keep in htmlprototype/forms/)**
    > Shows live filename preview: `<form-slug>-<version>.json` (e.g. `webinar-v2.0.json`).
* **The Result (Pop Message Modal)**:
  Upon clicking **`💾 Freeze & Save Sprint Version`**:
  1. The version ledger appends a new immutable snapshot with timestamp, author, status, changelog, and stats.
  2. If the download checkbox is checked, the browser immediately downloads the JSON file to your computer.
  3. The **`🎉 Sprint Version Snapshot Saved!`** pop-up confirmation modal opens, detailing:
     - Version Tag (`v2.0`), Sprint (`Sprint 25.2`), Lifecycle (`Active`), and Author.
     - Section, Field, and Rule metrics.
     - The entered Sprint Changelog.
     - Storage explanation clarifying that the version is safely in `localStorage` and guiding the user on storing the downloaded JSON in `htmlprototype/forms/`.
     - Buttons to **`📥 Re-download JSON`**, **`⏱️ View in Version History`**, or **`✓ Done`**.

### 3. Version History & Time-Machine Inspector (`⏱️ Versions`)
Click **`⏱️ Versions`** in the navbar or tab strip to open the enterprise time-machine inspector:
* **Left Ledger**: Chronological list of all saved sprint versions with status badges (`Active`, `Archived`, `Draft`), dates, authors, and 1-click `Load ↵` buttons.
* **Overview Tab**: Displays sprint release notes, section breakdown chips, and field metrics.
* **Visual Diff Tab**: Live comparison engine comparing any historical snapshot against your currently active canvas:
  - 🟢 **Added in Current Active**: Fields added in the new sprint.
  - 🔴 **Only in Snapshot (Removed in Active)**: Deprecated or removed fields.
  - 🟡 **Modified Fields**: Property-level diff showing exact changes (e.g., `col: col-lg-6 ➔ col-lg-12`, `required: false ➔ true`, options changed).
  - ⚪ **Identical Fields**: Confirmed unchanged configurations.
* **JSON Tab**: Syntax-highlighted view of the snapshot schema with **`📋 Copy JSON`** and **`📥 Download JSON`** buttons.
* **Version Actions**:
  - **`Restoring / Swapping`**: Swap active working copy to any past snapshot.
  - **`Branch / Fork`**: Fork an older snapshot into an entirely new intake form tab.
  - **`Export All Sprints (.json)`**: Exports the entire multi-sprint history ledger as a single JSON package.

---

## 📋 The 15 Pre-Seeded Cisco DART Intake Forms

The studio includes 15 fully configured, production-representative intake forms:

| # | Form Tab | Icon | Angular Config Target | Description & Scope |
| :-: | :--- | :---: | :--- | :--- |
| **1** | **Webinar** | 🎙️ | `form.webinar.config.ts` | Production & promotion requests for Live, Simu-Live, and On-Demand webinars with Campaign alignment and ON24/Webex integration. |
| **2** | **Email Marketing** | ✉️ | `form.email.config.ts` | Marketo/Eloqua batch email blasts, automated nurture streams, dynamic segmentation, and A/B test specifications. |
| **3** | **Event / Cisco Live** | 🎪 | `form.event.config.ts` | Tier 1-3 trade shows, booth activations, signage, registration pages, and Cisco Live breakout sessions. |
| **4** | **Customer Web Page** | 🌐 | `form.webpage.config.ts` | Corporate Cisco.com customer web pages, collateral downloads, campaign asset landing pages, and SEO metadata. |
| **5** | **Paid Media / Ads** | 📢 | `form.paidmedia.config.ts` | Paid search (SEM), programmatic display banners, LinkedIn Sponsored Content, and publisher media buys. |
| **6** | **Social Media** | 📱 | `form.social.config.ts` | Organic social campaigns across LinkedIn, X/Twitter, and YouTube with asset specifications and copy decks. |
| **7** | **Content Syndication**| 📰 | `form.contentsyndication.config.ts`| Third-party publisher lead generation campaigns, whitepaper syndication, and CPL lead delivery specs. |
| **8** | **Video Production** | 🎬 | `form.video.config.ts` | Product demos, executive keynotes, customer testimonial videos, motion graphics, and localization. |
| **9** | **Collateral / PDF** | 📑 | `form.collateral.config.ts` | Solution overviews, technical whitepapers, infographics, case studies, and corporate presentation decks. |
| **10**| **Direct Mail / Gift** | 🎁 | `form.directmail.config.ts` | High-touch dimensional mailers, VIP executive gifting, and automated Sendoso/Postal.io pipeline campaigns. |
| **11**| **Partner Co-Op** | 🤝 | `form.partner.config.ts` | Joint Cisco partner co-branded demand generation campaigns, MDF funding requests, and partner portal assets. |
| **12**| **Executive Comm** | 👔 | `form.execcomm.config.ts` | C-Suite internal broadcasts, all-hands meetings, leadership blogs, and executive briefing center presentations. |
| **13**| **Internal Comm** | 📣 | `form.internalcomm.config.ts` | Sales enablement updates, global marketing newsletters, Cisco TV intranet announcements, and training materials. |
| **14**| **Brand & Creative** | 🎨 | `form.brandcreative.config.ts` | Cisco brand identity guidance, custom icon design, logo approvals, typography licensing, and master visual assets. |
| **15**| **Operations / MOPs** | ⚙️ | `form.operations.config.ts` | Custom Workfront custom form modifications, reporting dashboard builds, tracking pixel setup, and MarTech integrations. |

---

## 🎛️ Field Types & Workfront Custom Mapping Specs

Every field in the studio strictly adheres to Cisco DART's frontend framework:

### 1. Supported Field Types

| Field Type Key | UI Display Name | Description & Capabilities |
| :--- | :--- | :--- |
| `text` | **Single Line Text** | Standard text input for short strings (titles, IDs, names). |
| `select` | **Dropdown Picklist** | Single-select dropdown supporting custom options with labels and values. |
| `multiselect_fancy` | **Multi-Select Fancy** | Multi-select input with interactive token badges/pills and filter search. |
| `textarea` | **Textarea / Notes** | Multi-line text input for descriptions, copy decks, and notes. |
| `number` | **Number Input** | Numeric input with optional step, minimum, and maximum constraints. |
| `date` | **Date Picker** | Native calendar date picker for deadlines, launch dates, and SLAs. |
| `radio` | **Radio Choice** | Single-choice radio button group for mutually exclusive options. |
| `checkbox` | **Checkbox** | Single boolean toggle for legal confirmations and acknowledgments. |
| `file` | **File Upload** | Attachment placeholder for creative briefs, spreadsheets, and assets. |

### 2. Grid Width System
Fields can be sized across standard Bootstrap/CUI grid column classes:
* **`col-lg-6` (50% - 2 Columns)**: Recommended for standard form inputs side-by-side.
* **`col-lg-12` (100% - Full Width)**: Recommended for textareas, titles, and legal disclaimers.
* **`col-lg-4` (33% - 3 Columns)**: Recommended for compact inputs (dates, numbers, codes).
* **`col-lg-3` (25% - 4 Columns)**: Recommended for short codes and status flags.

### 3. Workfront Custom Field Integration
In the Field Inspector Drawer, every field can be mapped directly to Adobe Workfront custom parameters:
* **Workfront Field ID (`wfId`)**: 32-character hexadecimal GUID matching the Workfront custom parameter (e.g. `61df5582003a92b049cafa45f74e87ac`).
* **Workfront Field Name (`wfFieldName`)**: camelCase property identifier used in DART payload API requests (e.g. `campaignAlignment`, `activityId`).
* **Workfront Label (`wfLabel`)**: The official business question label shown in Workfront reports.

---

## ⚡ Advanced Logic Studio (Rule Engine Specs)

The Advanced Logic Studio allows Business Analysts to define complex enterprise conditional logic without writing code:

### 1. Disjunctive Normal Form (DNF)
Logic is evaluated using standard DNF rules:
$$\text{Condition} = (\text{Rule}_A \land \text{Rule}_B) \lor (\text{Rule}_C \land \text{Rule}_D)$$
* **AND Groups**: Criteria within a vertical connector rail must **all** evaluate to true.
* **OR Connectors**: Multiple groups can be added. If **any** group evaluates to true, the action executes.

### 2. Supported Trigger Operators
* `isSelected`: Triggered when a picklist or radio has a specific selection.
* `isNotSelected`: Triggered when a specific option is NOT selected.
* `equals`: Exact string equality match.
* `notEquals`: Not equal to target value.
* `contains`: Substring presence check.
* `isEmpty`: Field is null, blank, or has an empty array.
* `isNotEmpty`: Field contains any user input.
* `regex`: Regular expression pattern matching.
* Numeric comparisons: `>`, `<`, `>=`, `<=`.

### 3. Action Capabilities:
* **Display Tab**: Controls conditional visibility (Show / Hide).
* **Automatic Cascading Resets**: When a parent field changes and causes dependent child fields to hide, the rule engine automatically resets the child fields to default/empty values to prevent submitting phantom data.
* **Skip Tab**: Configures section branching and conditional section jumps.
* **Default Value Tab**: Dynamically calculates and populates default values when criteria match.
* **Validation Tab**: Configures `Required-If` rules that make fields mandatory only under specific conditions.
* **Formatting & Editability Tabs**: Conditionally applies alert warning banners or locks fields into read-only mode.

---

## 📤 Export & Handover Workflows

### 1. Locked Standalone Review HTML (`exports/`)
For sharing interactive prototypes with stakeholders without allowing accidental editing:
1. Click **`📤 Share HTML`** in the navbar or review banner.
2. The studio generates a zero-dependency standalone HTML file (e.g., `webpage-request-review.html`).
3. Send this file via email, Microsoft Teams, or SharePoint.
4. When stakeholders open the file:
   - **All editing controls, drag-and-drop, and drawers are completely removed.**
   - Stakeholders can select picklists, enter test inputs, and watch dependent fields appear/disappear according to your business logic.
   - Stakeholders can toggle between **3 Visual Variations**:
     1. *Variation 1: Modern Studio* (Interactive glassmorphic review).
     2. *Variation 2: DART Cisco Brand* (Official flat Cisco enterprise portal layout).
     3. *Variation 3: Step Wizard* (Multi-step guided wizard layout).

### 2. Developer Angular TypeScript Export (`form.<name>.config.ts`)
When business specifications are approved:
1. Click **`💻 DART Code`** in the tab strip or **`Export DART Config`** from the dropdown.
2. The studio outputs clean, typed Angular TypeScript code:
   ```typescript
   import { FormStructure } from './types.config';

   export const FORM_STRUCTURE: FormStructure = [
     {
       sectionId: 'sec_stakeholder',
       sectionTitle: 'Stakeholder / Requestor',
       fields: [
         {
           id: '61df5582003a92b049cafa45f74e87ac',
           name: 'contentTitle',
           label: 'Project Name',
           type: 'text',
           col: 'col-lg-6',
           required: true,
           placeholder: 'e.g. Cisco Live 2025 Series'
         }
       ]
     }
   ];
   ```
3. Developers can copy and paste this code directly into `src/app/config/form.<name>.config.ts` within the Angular repository.

---

## ⌨️ Keyboard Shortcuts & Quick Reference

| Shortcut | Action Description |
| :--- | :--- |
| **`Ctrl` + `S`** | **Save Active Form**: Saves live canvas to browser `localStorage` and opens the Save confirmation pop-up. |
| **`Alt` + `1`** | **Builder Mode**: Switches to visual canvas builder and editing mode. |
| **`Alt` + `2`** | **Live Preview Mode**: Switches to interactive rule simulation mode. |
| **`Alt` + `G`** | **Form Gallery**: Opens the full 15-form visual browser modal. |
| **`Alt` + `N`** | **New Form Tab**: Creates a new blank intake form tab. |
| **`Esc`** | **Close**: Closes any active modal, pop-up confirmation, or field drawer. |
| **`Mouse Wheel`** | **Scroll Tab Strip**: Position mouse over the horizontal form tab strip and wheel to scroll across all 15 forms. |

---

*Cisco DART Form Mockup & Rule Studio — Built for Marketing Operations (MOPs) and Business Analysis Teams.*
