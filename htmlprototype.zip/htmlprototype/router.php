<?php
/**
 * PHP Built-in Server Router
 * Forces no-cache headers on all static files so browsers always load fresh CSS/JS.
 * Usage: php -S localhost:3000 router.php
 */

$uri = $_SERVER['REQUEST_URI'];
$path = __DIR__ . parse_url($uri, PHP_URL_PATH);

// Normalize: strip query string, resolve to real path
$filePath = realpath($path);

// Security: must be inside this directory
if ($filePath === false || strpos($filePath, __DIR__) !== 0) {
    // Let PHP handle it (404 or directory listing)
    return false;
}

// Route .php files through PHP normally
if (is_file($filePath) && pathinfo($filePath, PATHINFO_EXTENSION) === 'php') {
    // Let the built-in server handle PHP files natively
    return false;
}

// For static files (HTML, CSS, JS, JSON, images, etc.)
if (is_file($filePath)) {
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    $mimeTypes = [
        'html' => 'text/html; charset=UTF-8',
        'css'  => 'text/css; charset=UTF-8',
        'js'   => 'application/javascript; charset=UTF-8',
        'json' => 'application/json; charset=UTF-8',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif'  => 'image/gif',
        'svg'  => 'image/svg+xml',
        'ico'  => 'image/x-icon',
        'woff' => 'font/woff',
        'woff2'=> 'font/woff2',
        'ttf'  => 'font/ttf',
        'pdf'  => 'application/pdf',
        'map'  => 'application/json',
    ];

    $mime = isset($mimeTypes[$ext]) ? $mimeTypes[$ext] : 'application/octet-stream';

    // Force no-cache on HTML, CSS, JS so browser always fetches fresh
    if (in_array($ext, ['html', 'css', 'js', 'json'])) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit;
}

// Directory index: serve index.html or index.php
if (is_dir($filePath)) {
    if (is_file($filePath . '/index.html')) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Content-Type: text/html; charset=UTF-8');
        readfile($filePath . '/index.html');
        exit;
    }
}

// Fall through to PHP built-in server default handling
return false;
