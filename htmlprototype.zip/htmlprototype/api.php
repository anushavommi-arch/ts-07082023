<?php
/**
 * DART Form Studio  PHP Persistence API
 * Drop-in replacement for server.js / server.ps1
 * Requires PHP 7.0+  no extensions beyond standard file I/O needed.
 *
 * Endpoints (query param ?action=...):
 *   GET  ?action=status           health check
 *   GET  ?action=manifest         rebuild & return forms-manifest.json
 *   POST ?action=save             save/create a form
 *   POST ?action=delete           delete a form folder
 *   POST ?action=version          save a sprint version snapshot
 *   POST ?action=sprint           save sprint metadata
 */

// ---------------------------------------------------------------------------
// CORS  allow requests from same origin or any origin (adjust if needed)
// ---------------------------------------------------------------------------
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

$reqMethod = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
if ($reqMethod === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------
define('ROOT_DIR',  __DIR__);
define('FORMS_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'forms');

$action = isset($_GET['action']) ? trim($_GET['action']) : '';

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
switch ($action) {
    case 'status':
        echo json_encode([
            'ok'          => true,
            'mode'        => 'php-folder-native',
            'php'         => PHP_VERSION,
            'workspaceDir'=> ROOT_DIR,
            'formsDir'    => FORMS_DIR,
            'timestamp'   => date('c'),
        ]);
        break;

    case 'manifest':
        $manifest = rebuildMasterManifest();
        echo json_encode($manifest);
        break;

    case 'save':
        handleSaveForm();
        break;

    case 'delete':
        handleDeleteForm();
        break;

    case 'version':
        handleSaveVersion();
        break;

    case 'sprint':
        handleSaveSprint();
        break;

    case 'libraries':
        handleLibraries();
        break;

    case 'user':
        handleGetUser();
        break;

    case 'rename-form':
        handleRenameForm();
        break;

    case 'rename-sprint':
        handleRenameSprint();
        break;

    case 'rename-version':
        handleRenameVersion();
        break;

    case 'delete-version':
        handleDeleteVersion();
        break;

    case 'save-version-title':
        handleSaveVersionTitle();
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action. Use ?action=status|manifest|save|delete|version|sprint|libraries|user|rename-form|rename-sprint|rename-version']);
        break;
}

// ===========================================================================
// REBUILD MASTER MANIFEST
// ===========================================================================
function rebuildMasterManifest() {
    $formsDir = FORMS_DIR;
    if (!is_dir($formsDir)) {
        mkdir($formsDir, 0755, true);
    }

    $manifest = [
        'repositoryName' => 'MOPs Form Mockup & Rule Studio',
        'version'        => '2.0.0',
        'updatedAt'      => date('c'),
        'forms'          => [],
    ];

    $entries = scandir($formsDir);
    foreach ($entries as $name) {
        if ($name === '.' || $name === '..' || $name === 'forms_backup_pre_sprints') continue;
        $fDir = $formsDir . DIRECTORY_SEPARATOR . $name;
        if (!is_dir($fDir)) continue;

        $formJsonPath    = $fDir . DIRECTORY_SEPARATOR . 'form.json';
        $manifestJsonPath= $fDir . DIRECTORY_SEPARATOR . 'manifest.json';
        $sprintsDir      = $fDir . DIRECTORY_SEPARATOR . 'sprints';
        $versDir         = $fDir . DIRECTORY_SEPARATOR . 'versions';

        if (!file_exists($formJsonPath)) continue;

        $schema   = readJsonSafe($formJsonPath) ?? (object)[];
        $formMeta = file_exists($manifestJsonPath) ? (readJsonSafe($manifestJsonPath) ?? (object)[]) : (object)[];

        $sprints  = [];
        $versions = [];

        // Scan sprints/
        if (is_dir($sprintsDir)) {
            $sprintDirs = scandir($sprintsDir);
            foreach ($sprintDirs as $sName) {
                if ($sName === '.' || $sName === '..') continue;
                $sDir         = $sprintsDir . DIRECTORY_SEPARATOR . $sName;
                if (!is_dir($sDir)) continue;
                $sprintFile   = $sDir . DIRECTORY_SEPARATOR . 'sprint.json';
                $sVersDir     = $sDir . DIRECTORY_SEPARATOR . 'versions';
                $sMeta        = file_exists($sprintFile) ? (readJsonSafe($sprintFile) ?? (object)[]) : (object)[];
                $sVersions    = [];

                if (is_dir($sVersDir)) {
                    $vFiles = glob($sVersDir . DIRECTORY_SEPARATOR . '*.json');
                    foreach ($vFiles as $vFile) {
                        $vData = readJsonSafe($vFile);
                        if ($vData && isset($vData->versionId)) {
                            $sVersions[] = $vData;
                            $versions[]  = $vData;
                        }
                    }
                }
                usort($sVersions, function($a, $b) {
                    $ta = isset($a->timestamp) ? $a->timestamp : '';
                    $tb = isset($b->timestamp) ? $b->timestamp : '';
                    return strcmp($ta, $tb);
                });

                $sprints[] = [
                    'sprintId'          => $sMeta->sprintId   ?? $sName,
                    'sprintLabel'       => $sMeta->sprintLabel ?? $sName,
                    'startDate'         => $sMeta->startDate   ?? '',
                    'endDate'           => $sMeta->endDate     ?? '',
                    'status'            => $sMeta->status      ?? 'Active',
                    'publishedVersionId'=> $sMeta->publishedVersionId ?? (end($sVersions)->versionId ?? 'v1.0'),
                    'versions'          => $sVersions,
                ];
            }
        } elseif (is_dir($versDir)) {
            $vFiles = glob($versDir . DIRECTORY_SEPARATOR . '*.json');
            foreach ($vFiles as $vFile) {
                $vData = readJsonSafe($vFile);
                if ($vData && isset($vData->versionId)) {
                    $versions[] = $vData;
                }
            }
        }

        usort($versions, function($a, $b) {
            $ta = isset($a->timestamp) ? $a->timestamp : '';
            $tb = isset($b->timestamp) ? $b->timestamp : '';
            return strcmp($ta, $tb);
        });
        $activeVer = end($versions) ?: null;

        $manifest['forms'][] = [
            'id'              => $formMeta->id              ?? $name,
            'label'           => $formMeta->label           ?? ($schema->title ?? $name),
            'icon'            => $formMeta->icon            ?? '',
            'configFile'      => $formMeta->configFile      ?? "form.{$name}.config.ts",
            'activeVersionId' => $formMeta->activeVersionId ?? ($activeVer->versionId ?? 'v1.0'),
            'activeSprint'    => $formMeta->activeSprint    ?? ($activeVer->sprint ?? 'sprint-25.1'),
            'createdAt'       => $formMeta->createdAt       ?? ($schema->createdAt ?? null),
            'createdBy'       => $formMeta->createdBy       ?? ($schema->createdBy ?? null),
            'updatedAt'       => $formMeta->updatedAt       ?? ($schema->updatedAt ?? date('c')),
            'updatedBy'       => $formMeta->updatedBy       ?? ($schema->updatedBy ?? null),
            'folder'          => $name,
            'totalVersions'   => count($versions),
            'schema'          => $schema,
            'sprints'         => $sprints,
            'versions'        => $versions,
        ];
    }

    // Write forms-manifest.json
    file_put_contents(
        $formsDir . DIRECTORY_SEPARATOR . 'forms-manifest.json',
        json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );

    // Write forms-manifest.js (for offline file:/// fallback)
    $js = "/** Auto-generated DART Folder Repository Manifest (PHP) **/\n"
        . 'window.DART_FORMS_REPOSITORY = '
        . json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        . ";\n";
    file_put_contents($formsDir . DIRECTORY_SEPARATOR . 'forms-manifest.js', $js);

    return $manifest;
}

// ===========================================================================
// SAVE FORM
// ===========================================================================
function handleSaveForm() {
    $data   = jsonBody();
    $formId = $data->formId ?? slugify($data->label ?? 'form');
    $formDir= FORMS_DIR . DIRECTORY_SEPARATOR . $formId;

    if (!is_dir($formDir)) mkdir($formDir, 0755, true);

    // Write form.json
    writeJson($formDir . DIRECTORY_SEPARATOR . 'form.json', $data->schema ?? (object)[]);

    // Update manifest.json
    $manifestPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    $formMeta = file_exists($manifestPath) ? (readJsonSafe($manifestPath) ?? (object)[]) : (object)[];
    $formMeta->id        = $formId;
    if (!empty($data->label))           $formMeta->label           = $data->label;
    if (!empty($data->icon))            $formMeta->icon            = $data->icon;
    if (!empty($data->configFile))      $formMeta->configFile      = $data->configFile;
    if (!empty($data->activeSprint))    $formMeta->activeSprint    = $data->activeSprint;
    if (!empty($data->activeVersionId)) $formMeta->activeVersionId = $data->activeVersionId;

    // Form Audit Tracking
    if (empty($formMeta->createdAt)) {
        $formMeta->createdAt = !empty($data->createdAt) ? $data->createdAt : date('c');
    }
    if (empty($formMeta->createdBy)) {
        $formMeta->createdBy = !empty($data->createdBy) ? $data->createdBy : (!empty($data->updatedBy) ? $data->updatedBy : 'Cisco User');
    }
    $formMeta->updatedAt = date('c');
    $formMeta->updatedBy = !empty($data->updatedBy) ? $data->updatedBy : (!empty($data->createdBy) ? $data->createdBy : 'Cisco User');

    writeJson($manifestPath, $formMeta);

    rebuildMasterManifest();

    echo json_encode([
        'ok'       => true,
        'message'  => "Saved form to forms/{$formId}/form.json",
        'formId'   => $formId,
        'filePath' => "forms/{$formId}/form.json",
    ]);
}

// ===========================================================================
// DELETE FORM
// ===========================================================================
function handleDeleteForm() {
    $data   = jsonBody();
    $formId = $data->formId ?? '';
    if (!$formId) { http_response_code(400); echo json_encode(['error' => 'Missing formId']); return; }

    $formDir = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    if (is_dir($formDir)) {
        deleteDir($formDir);
    }

    rebuildMasterManifest();
    echo json_encode(['ok' => true, 'message' => "Deleted forms/{$formId}", 'formId' => $formId]);
}

// ===========================================================================
// DELETE VERSION SNAPSHOT
// ===========================================================================
function handleDeleteVersion() {
    $data      = jsonBody();
    $formId    = $data->formId ?? '';
    $versionId = strtolower($data->versionId ?? '');
    if (!$formId || !$versionId) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing formId or versionId']);
        return;
    }

    $formDir = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    $deletedFiles = [];

    // 1. Delete from flat versions: forms/{formId}/versions/{versionId}.json
    $flatFile = $formDir . DIRECTORY_SEPARATOR . 'versions' . DIRECTORY_SEPARATOR . "{$versionId}.json";
    if (file_exists($flatFile)) {
        unlink($flatFile);
        $deletedFiles[] = $flatFile;
    }

    // 2. Delete from sprint versions: forms/{formId}/sprints/*/versions/{versionId}.json
    $sprintsDir = $formDir . DIRECTORY_SEPARATOR . 'sprints';
    if (is_dir($sprintsDir)) {
        $sprints = array_diff(scandir($sprintsDir), ['.', '..']);
        foreach ($sprints as $sp) {
            $spVer = $sprintsDir . DIRECTORY_SEPARATOR . $sp . DIRECTORY_SEPARATOR . 'versions' . DIRECTORY_SEPARATOR . "{$versionId}.json";
            if (file_exists($spVer)) {
                unlink($spVer);
                $deletedFiles[] = $spVer;
            }
        }
    }

    // 3. Update form manifest.json if deleted version was activeVersionId
    $manifestPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    if (file_exists($manifestPath)) {
        $fMeta = readJsonSafe($manifestPath);
        if ($fMeta && isset($fMeta->activeVersionId) && strtolower($fMeta->activeVersionId) === $versionId) {
            // Find latest remaining version across sprints or flat versions
            $remaining = [];
            if (is_dir($sprintsDir)) {
                foreach (array_diff(scandir($sprintsDir), ['.', '..']) as $sp) {
                    $vDir = $sprintsDir . DIRECTORY_SEPARATOR . $sp . DIRECTORY_SEPARATOR . 'versions';
                    if (is_dir($vDir)) {
                        foreach (glob($vDir . DIRECTORY_SEPARATOR . '*.json') as $vf) {
                            $remaining[] = basename($vf, '.json');
                        }
                    }
                }
            }
            sort($remaining);
            $fMeta->activeVersionId = count($remaining) > 0 ? end($remaining) : 'v1.0';
            $fMeta->updatedAt = date('c');
            writeJson($manifestPath, $fMeta);
        }
    }

    rebuildMasterManifest();
    echo json_encode([
        'ok'           => true,
        'message'      => "Deleted version {$versionId}",
        'formId'       => $formId,
        'versionId'    => $versionId,
        'deletedFiles' => $deletedFiles
    ]);
}

// ===========================================================================
// SAVE VERSION SNAPSHOT
// ===========================================================================
function handleSaveVersion() {
    $data   = jsonBody();
    $formId = $data->formId ?? '';
    if (!$formId) { http_response_code(400); echo json_encode(['error' => 'Missing formId']); return; }

    $formDir  = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    $versDir  = $formDir . DIRECTORY_SEPARATOR . 'versions';
    if (!is_dir($versDir)) mkdir($versDir, 0755, true);

    $versionId   = strtolower($data->versionId ?? 'v1.0');
    $versionFile = $versDir . DIRECTORY_SEPARATOR . "{$versionId}.json";

    $record = [
        'versionId'    => $versionId,
        'versionLabel' => "{$versionId} (" . ($data->sprint ?? 'Sprint') . ')',
        'sprint'       => $data->sprint  ?? 'Current Sprint',
        'timestamp'    => date('c'),
        'author'       => $data->author  ?? 'MOPs Team',
        'status'       => $data->status  ?? 'Active',
        'notes'        => $data->notes   ?? '',
        'schema'       => $data->schema  ?? (object)[],
        'stats'        => $data->stats   ?? (object)[],
    ];
    writeJson($versionFile, $record);

    if (($data->status ?? '') === 'Active') {
        writeJson($formDir . DIRECTORY_SEPARATOR . 'form.json', $data->schema ?? (object)[]);
    }

    // Update manifest.json
    $manifestPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    $formMeta = file_exists($manifestPath) ? (readJsonSafe($manifestPath) ?? (object)[]) : (object)[];
    $formMeta->id              = $formId;
    $formMeta->activeVersionId = $versionId;
    $formMeta->activeSprint    = $data->sprint ?? 'Current Sprint';
    $formMeta->updatedAt       = date('c');
    if (!empty($data->author)) {
        $formMeta->updatedBy   = $data->author;
    }
    writeJson($manifestPath, $formMeta);

    rebuildMasterManifest();

    echo json_encode([
        'ok'       => true,
        'message'  => "Version saved to forms/{$formId}/versions/{$versionId}.json",
        'formId'   => $formId,
        'versionId'=> $versionId,
        'filePath' => "forms/{$formId}/versions/{$versionId}.json",
    ]);
}

// ===========================================================================
// SAVE SPRINT
// ===========================================================================
function handleSaveSprint() {
    $data    = jsonBody();
    $formId  = $data->formId ?? '';
    $sprintId= strtolower(preg_replace('/[^a-z0-9.]/i', '-', $data->sprintId ?? 'sprint-25.3'));
    if (!$formId) { http_response_code(400); echo json_encode(['error' => 'Missing formId']); return; }

    $formDir   = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    $sprintDir = $formDir . DIRECTORY_SEPARATOR . 'sprints' . DIRECTORY_SEPARATOR . $sprintId;
    $versDir   = $sprintDir . DIRECTORY_SEPARATOR . 'versions';
    if (!is_dir($versDir)) mkdir($versDir, 0755, true);

    $sprintRecord = [
        'sprintId'          => $sprintId,
        'sprintLabel'       => $data->sprintLabel        ?? $sprintId,
        'startDate'         => $data->startDate          ?? date('Y-m-d'),
        'endDate'           => $data->endDate            ?? '',
        'status'            => $data->status             ?? 'Active',
        'publishedVersionId'=> $data->publishedVersionId ?? 'v1.0',
        'versions'          => [],
    ];
    if (!empty($data->versions)) {
        foreach ($data->versions as $v) {
            $sprintRecord['versions'][] = [
                'versionId' => $v->versionId ?? 'v1.0',
                'timestamp' => $v->timestamp ?? date('c'),
                'author'    => $v->author    ?? 'MOPs Business Team',
                'notes'     => $v->notes     ?? '',
                'status'    => $v->status    ?? 'Active',
            ];
            if (!empty($v->versionId)) {
                $vFile = $versDir . DIRECTORY_SEPARATOR . strtolower($v->versionId) . '.json';
                if (!file_exists($vFile)) writeJson($vFile, $v);
            }
        }
    }
    writeJson($sprintDir . DIRECTORY_SEPARATOR . 'sprint.json', $sprintRecord);

    // Update form manifest
    $manifestPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    $formMeta = file_exists($manifestPath) ? (readJsonSafe($manifestPath) ?? (object)[]) : (object)[];
    $formMeta->id = $formId;
    if (($data->status ?? '') === 'Active') {
        $formMeta->activeSprint = $sprintId;
        if (!empty($data->publishedVersionId)) $formMeta->activeVersionId = $data->publishedVersionId;
    }
    $formMeta->updatedAt = date('c');
    writeJson($manifestPath, $formMeta);

    rebuildMasterManifest();

    echo json_encode([
        'ok'       => true,
        'message'  => "Sprint saved to forms/{$formId}/sprints/{$sprintId}/sprint.json",
        'formId'   => $formId,
        'sprintId' => $sprintId,
        'filePath' => "forms/{$formId}/sprints/{$sprintId}/sprint.json",
    ]);
}

// ===========================================================================
// RENAME FORM
// ===========================================================================
function handleRenameForm() {
    $data = jsonBody();
    $formId = $data->formId ?? '';
    $newLabel = trim($data->newLabel ?? '');
    if (!$formId || !$newLabel) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing formId or newLabel']);
        return;
    }

    // Check duplicate form name across all forms in FORMS_DIR
    $formsDir = FORMS_DIR;
    if (is_dir($formsDir)) {
        $entries = scandir($formsDir);
        foreach ($entries as $name) {
            if ($name === '.' || $name === '..' || $name === 'forms_backup_pre_sprints' || $name === $formId) continue;
            $fDir = $formsDir . DIRECTORY_SEPARATOR . $name;
            if (!is_dir($fDir)) continue;
            $mPath = $fDir . DIRECTORY_SEPARATOR . 'manifest.json';
            if (file_exists($mPath)) {
                $meta = readJsonSafe($mPath);
                if ($meta && isset($meta->label) && strcasecmp(trim($meta->label), $newLabel) === 0) {
                    echo json_encode(['ok' => false, 'duplicate' => true, 'error' => "A form named '{$newLabel}' already exists."]);
                    return;
                }
            }
        }
    }

    $formDir = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    if (!is_dir($formDir)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Form directory not found']);
        return;
    }

    $mPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    $meta = file_exists($mPath) ? (readJsonSafe($mPath) ?? (object)[]) : (object)[];
    $meta->label = $newLabel;
    $meta->updatedAt = date('c');
    writeJson($mPath, $meta);

    $fPath = $formDir . DIRECTORY_SEPARATOR . 'form.json';
    if (file_exists($fPath)) {
        $schema = readJsonSafe($fPath) ?? (object)[];
        $schema->title = $newLabel;
        $schema->updatedAt = date('c');
        writeJson($fPath, $schema);
    }

    rebuildMasterManifest();
    echo json_encode(['ok' => true, 'formId' => $formId, 'label' => $newLabel]);
}

// ===========================================================================
// RENAME SPRINT
// ===========================================================================
function handleRenameSprint() {
    $data = jsonBody();
    $formId = $data->formId ?? '';
    $oldSprintId = $data->oldSprintId ?? '';
    $newSprintLabel = trim($data->newSprintLabel ?? '');
    $newSprintId = trim($data->newSprintId ?? '');
    if (!$newSprintId && $newSprintLabel) {
        $newSprintId = strtolower(preg_replace('/[^a-z0-9.]/i', '-', $newSprintLabel));
    }
    if (!$formId || !$oldSprintId || !$newSprintLabel) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing formId, oldSprintId, or newSprintLabel']);
        return;
    }

    $formDir = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    $sprintsDir = $formDir . DIRECTORY_SEPARATOR . 'sprints';
    if (!is_dir($sprintsDir)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Sprints directory not found']);
        return;
    }

    // Check duplicate sprint name/id in this form
    $sprintEntries = scandir($sprintsDir);
    foreach ($sprintEntries as $sName) {
        if ($sName === '.' || $sName === '..' || strcasecmp($sName, $oldSprintId) === 0) continue;
        $sDir = $sprintsDir . DIRECTORY_SEPARATOR . $sName;
        if (!is_dir($sDir)) continue;
        if (strcasecmp($sName, $newSprintId) === 0) {
            echo json_encode(['ok' => false, 'duplicate' => true, 'error' => "A sprint with ID '{$newSprintId}' already exists in this form."]);
            return;
        }
        $spJson = $sDir . DIRECTORY_SEPARATOR . 'sprint.json';
        if (file_exists($spJson)) {
            $spData = readJsonSafe($spJson);
            if ($spData && isset($spData->sprintLabel) && strcasecmp(trim($spData->sprintLabel), $newSprintLabel) === 0) {
                echo json_encode(['ok' => false, 'duplicate' => true, 'error' => "A sprint named '{$newSprintLabel}' already exists in this form."]);
                return;
            }
        }
    }

    $oldDir = $sprintsDir . DIRECTORY_SEPARATOR . $oldSprintId;
    $targetDir = $sprintsDir . DIRECTORY_SEPARATOR . $newSprintId;
    if ($oldSprintId !== $newSprintId && is_dir($oldDir)) {
        rename($oldDir, $targetDir);
    } else {
        $targetDir = $oldDir;
    }

    $spJson = $targetDir . DIRECTORY_SEPARATOR . 'sprint.json';
    $spData = file_exists($spJson) ? (readJsonSafe($spJson) ?? (object)[]) : (object)[];
    $spData->sprintId = $newSprintId;
    $spData->sprintLabel = $newSprintLabel;
    writeJson($spJson, $spData);

    // Update activeSprint in manifest.json if matched
    $mPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    if (file_exists($mPath)) {
        $meta = readJsonSafe($mPath) ?? (object)[];
        if (isset($meta->activeSprint) && (strcasecmp($meta->activeSprint, $oldSprintId) === 0 || strcasecmp($meta->activeSprint, $newSprintId) === 0)) {
            $meta->activeSprint = $newSprintId;
            $meta->updatedAt = date('c');
            writeJson($mPath, $meta);
        }
    }

    rebuildMasterManifest();
    echo json_encode(['ok' => true, 'formId' => $formId, 'sprintId' => $newSprintId, 'sprintLabel' => $newSprintLabel]);
}

// ===========================================================================
// RENAME VERSION
// ===========================================================================
function handleRenameVersion() {
    $data = jsonBody();
    $formId = $data->formId ?? '';
    $oldVersionId = trim($data->oldVersionId ?? '');
    $newVersionId = trim($data->newVersionId ?? '');
    if (!$formId || !$oldVersionId || !$newVersionId) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing formId, oldVersionId, or newVersionId']);
        return;
    }

    $formDir = FORMS_DIR . DIRECTORY_SEPARATOR . $formId;
    if (!is_dir($formDir)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Form directory not found']);
        return;
    }

    // Check duplicate version tag in this form (across all sprints or versions/)
    $sprintsDir = $formDir . DIRECTORY_SEPARATOR . 'sprints';
    $existingVersions = [];
    if (is_dir($sprintsDir)) {
        foreach (scandir($sprintsDir) as $sName) {
            if ($sName === '.' || $sName === '..') continue;
            $vDir = $sprintsDir . DIRECTORY_SEPARATOR . $sName . DIRECTORY_SEPARATOR . 'versions';
            if (is_dir($vDir)) {
                foreach (glob($vDir . DIRECTORY_SEPARATOR . '*.json') as $vFile) {
                    $base = basename($vFile, '.json');
                    if (strcasecmp($base, $oldVersionId) !== 0) {
                        $existingVersions[] = strtolower($base);
                    }
                }
            }
        }
    }
    $versDir = $formDir . DIRECTORY_SEPARATOR . 'versions';
    if (is_dir($versDir)) {
        foreach (glob($versDir . DIRECTORY_SEPARATOR . '*.json') as $vFile) {
            $base = basename($vFile, '.json');
            if (strcasecmp($base, $oldVersionId) !== 0) {
                $existingVersions[] = strtolower($base);
            }
        }
    }

    if (in_array(strtolower($newVersionId), $existingVersions)) {
        echo json_encode(['ok' => false, 'duplicate' => true, 'error' => "Version tag '{$newVersionId}' already exists in this form."]);
        return;
    }

    // Locate and rename the version file
    $found = false;
    if (is_dir($sprintsDir)) {
        foreach (scandir($sprintsDir) as $sName) {
            if ($sName === '.' || $sName === '..') continue;
            $vDir = $sprintsDir . DIRECTORY_SEPARATOR . $sName . DIRECTORY_SEPARATOR . 'versions';
            $oldFile = $vDir . DIRECTORY_SEPARATOR . strtolower($oldVersionId) . '.json';
            $newFile = $vDir . DIRECTORY_SEPARATOR . strtolower($newVersionId) . '.json';
            if (file_exists($oldFile)) {
                $vData = readJsonSafe($oldFile) ?? (object)[];
                $vData->versionId = $newVersionId;
                if (isset($vData->versionLabel)) {
                    $vData->versionLabel = preg_replace('/^' . preg_quote($oldVersionId, '/') . '/', $newVersionId, $vData->versionLabel);
                }
                writeJson($newFile, $vData);
                if (strtolower($oldVersionId) !== strtolower($newVersionId)) {
                    unlink($oldFile);
                }
                $found = true;

                // Also update sprint.json if referenced
                $spJson = $sprintsDir . DIRECTORY_SEPARATOR . $sName . DIRECTORY_SEPARATOR . 'sprint.json';
                if (file_exists($spJson)) {
                    $spData = readJsonSafe($spJson);
                    if ($spData && isset($spData->publishedVersionId) && strcasecmp($spData->publishedVersionId, $oldVersionId) === 0) {
                        $spData->publishedVersionId = $newVersionId;
                        writeJson($spJson, $spData);
                    }
                }
            }
        }
    }

    if (is_dir($versDir)) {
        $oldFile = $versDir . DIRECTORY_SEPARATOR . strtolower($oldVersionId) . '.json';
        $newFile = $versDir . DIRECTORY_SEPARATOR . strtolower($newVersionId) . '.json';
        if (file_exists($oldFile)) {
            $vData = readJsonSafe($oldFile) ?? (object)[];
            $vData->versionId = $newVersionId;
            writeJson($newFile, $vData);
            if (strtolower($oldVersionId) !== strtolower($newVersionId)) {
                unlink($oldFile);
            }
            $found = true;
        }
    }

    // Update activeVersionId in manifest.json if matched
    $mPath = $formDir . DIRECTORY_SEPARATOR . 'manifest.json';
    if (file_exists($mPath)) {
        $meta = readJsonSafe($mPath) ?? (object)[];
        if (isset($meta->activeVersionId) && strcasecmp($meta->activeVersionId, $oldVersionId) === 0) {
            $meta->activeVersionId = $newVersionId;
            $meta->updatedAt = date('c');
            writeJson($mPath, $meta);
        }
    }

    rebuildMasterManifest();
    echo json_encode(['ok' => true, 'formId' => $formId, 'oldVersionId' => $oldVersionId, 'newVersionId' => $newVersionId]);
}

// ===========================================================================
// HELPERS
// ===========================================================================
function jsonBody() {
    $raw = file_get_contents('php://input');
    return $raw ? json_decode($raw) : (object)[];
}

function readJsonSafe($path) {
    if (!file_exists($path)) return null;
    $content = file_get_contents($path);
    // Strip UTF-8 BOM if present
    $content = ltrim($content, "\xEF\xBB\xBF");
    $decoded = json_decode($content);
    return (json_last_error() === JSON_ERROR_NONE) ? $decoded : null;
}

function writeJson($path, $data) {
    $dir = dirname($path);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function slugify($str) {
    return preg_replace('/[^a-z0-9]+/', '-', strtolower(trim($str)));
}

function deleteDir($dir) {
    if (!is_dir($dir)) return;
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        is_dir($path) ? deleteDir($path) : unlink($path);
    }
    rmdir($dir);
}

// ===========================================================================
// HANDLE SAVE VERSION TITLE (updates schema.title and title in the version JSON only)
// ===========================================================================
function handleSaveVersionTitle() {
    $body      = json_decode(file_get_contents('php://input'), true) ?? [];
    $formId    = trim($body['formId']    ?? '');
    $sprintId  = trim($body['sprintId']  ?? '');
    $versionId = trim($body['versionId'] ?? '');
    $newTitle  = trim($body['newTitle']  ?? '');

    if (!$formId || !$versionId || $newTitle === '') {
        http_response_code(400);
        echo json_encode(['error' => 'formId, versionId and newTitle are required']);
        return;
    }

    $formsDir = FORMS_DIR;

    // Locate the version file  check sprint sub-folder first, then legacy versions/
    $versionFile = null;
    if ($sprintId) {
        $candidate = $formsDir . DIRECTORY_SEPARATOR . $formId
                   . DIRECTORY_SEPARATOR . 'sprints'
                   . DIRECTORY_SEPARATOR . $sprintId
                   . DIRECTORY_SEPARATOR . 'versions'
                   . DIRECTORY_SEPARATOR . $versionId . '.json';
        if (file_exists($candidate)) $versionFile = $candidate;
    }
    if (!$versionFile) {
        // Search all sprints of this form
        $sprintsDir = $formsDir . DIRECTORY_SEPARATOR . $formId . DIRECTORY_SEPARATOR . 'sprints';
        if (is_dir($sprintsDir)) {
            $sEntries = scandir($sprintsDir);
            foreach ($sEntries as $sName) {
                if ($sName === '.' || $sName === '..') continue;
                $candidate = $sprintsDir . DIRECTORY_SEPARATOR . $sName
                           . DIRECTORY_SEPARATOR . 'versions'
                           . DIRECTORY_SEPARATOR . $versionId . '.json';
                if (file_exists($candidate)) {
                    $versionFile = $candidate;
                    break;
                }
            }
        }
    }
    if (!$versionFile) {
        $candidate = $formsDir . DIRECTORY_SEPARATOR . $formId
                   . DIRECTORY_SEPARATOR . 'versions'
                   . DIRECTORY_SEPARATOR . $versionId . '.json';
        if (file_exists($candidate)) $versionFile = $candidate;
    }

    if (!$versionFile) {
        http_response_code(404);
        echo json_encode(['error' => "Version file not found for formId=$formId versionId=$versionId"]);
        return;
    }

    // Read as associative array
    $raw = file_get_contents($versionFile);
    $raw = ltrim($raw, "\xEF\xBB\xBF");
    $data = json_decode($raw, true) ?? [];

    $data['title'] = $newTitle;
    $data['formTitle'] = $newTitle;
    if (isset($data['schema']) && is_array($data['schema'])) {
        $data['schema']['title'] = $newTitle;
    } else {
        $data['schema'] = ['title' => $newTitle];
    }

    file_put_contents($versionFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    // Rebuild manifest so manifest cache is up to date
    rebuildMasterManifest();

    echo json_encode(['ok' => true, 'formId' => $formId, 'versionId' => $versionId, 'newTitle' => $newTitle]);
}

// ===========================================================================
// HANDLE LIBRARIES (Reusable Fields & Sections)
// ===========================================================================
function handleLibraries() {
    $libFile = ROOT_DIR . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'libraries.json';
    $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';

    if ($method === 'POST') {
        $body = readJsonBody();
        if (!$body) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid JSON body']);
            return;
        }
        $reusableFields = isset($body['reusableFields']) && is_array($body['reusableFields']) ? $body['reusableFields'] : [];
        // Server-side duplicate WF API Name validation within Workfront Object namespace
        $seenApiKeys = [];
        foreach ($reusableFields as $fld) {
            $dataObj = isset($fld['data']) && is_array($fld['data']) ? $fld['data'] : [];
            $apiRaw = isset($dataObj['formData']) ? $dataObj['formData'] : '';
            $apiNorm = strtolower(preg_replace('/\s+/', '', trim($apiRaw)));
            if ($apiNorm === '') continue;
            $wfObj = strtolower(trim(isset($fld['wfObject']) ? $fld['wfObject'] : (isset($dataObj['wfObject']) ? $dataObj['wfObject'] : 'project')));
            $nsKey = $wfObj . '::' . $apiNorm;
            $globalKey = 'global::' . $apiNorm;
            if (isset($seenApiKeys[$nsKey]) || ($wfObj !== 'global' && isset($seenApiKeys[$globalKey]))) {
                http_response_code(409);
                echo json_encode([
                    'error' => 'An existing Workfront field with API name "' . $apiRaw . '" already exists in the WF Field Library (' . $wfObj . ').',
                    'duplicateApiName' => $apiRaw,
                    'wfObject' => $wfObj
                ]);
                return;
            }
            $seenApiKeys[$nsKey] = true;
        }
        $data = [
            'updatedAt'        => date('c'),
            'reusableSections' => isset($body['reusableSections']) ? $body['reusableSections'] : [],
            'reusableFields'   => $reusableFields
        ];
        writeJson($libFile, $data);
        echo json_encode(['ok' => true, 'updatedAt' => $data['updatedAt']]);
        return;
    }

    // GET
    if (file_exists($libFile)) {
        $data = readJsonSafe($libFile);
        if ($data) {
            echo json_encode($data);
            return;
        }
    }
    echo json_encode(['reusableSections' => [], 'reusableFields' => []]);
}

// ===========================================================================
// HANDLE GET USER INFORMATION (Cisco SSO Session & users.config.php)
// ===========================================================================
function handleGetUser() {
    // 1. Check or initialize PHP session (Cisco SSO sets $_SESSION)
    if (session_status() === PHP_SESSION_NONE) {
        @session_start();
    }

    // 2. Attempt to include DART's shared/dbid.inc.php if available (Cisco session handler)
    $dbidPaths = [
        ROOT_DIR . '/../shared/dbid.inc.php',
        ROOT_DIR . '/../src/shared/dbid.inc.php',
    ];
    foreach ($dbidPaths as $p) {
        if (file_exists($p)) {
            try {
                @include_once $p;
            } catch (\Throwable $t) {
                // Silently ignore if MySQL host (cdc-prd-003) is unreachable (e.g. offline/local)
            }
            break;
        }
    }

    // 3. Search for users.config.php across DART directory structures
    global $config_users;
    $config_users = null;

    $configPaths = [
        ROOT_DIR . '/../assets/server/config/users.config.php',
        ROOT_DIR . '/../src/assets/server/config/users.config.php',
        ROOT_DIR . '/users.config.php',
    ];
    if (isset($_SERVER['DOCUMENT_ROOT'])) {
        $configPaths[] = $_SERVER['DOCUMENT_ROOT'] . '/orderingtool/assets/server/config/users.config.php';
        $configPaths[] = $_SERVER['DOCUMENT_ROOT'] . '/dev/orderingtool/assets/server/config/users.config.php';
    }

    foreach ($configPaths as $path) {
        if (file_exists($path)) {
            @include_once $path;
            break;
        }
    }

    $mapping = isset($config_users->mapping) && is_array($config_users->mapping)
        ? $config_users->mapping
        : [
            'cecId'     => 'userLogin',
            'firstName' => 'userFirstName',
            'lastName'  => 'userLastName',
            'email'     => 'userEmail',
            'phone'     => 'userPhone',
            'country'   => 'userCountry',
            'homepage'  => 'userHomePage'
        ];

    $cecKey = isset($mapping['cecId']) ? $mapping['cecId'] : 'userLogin';
    $isAuth = isset($_SESSION[$cecKey]) && !empty($_SESSION[$cecKey]);

    if ($isAuth) {
        // Authenticated Cisco SSO Session
        $cecId     = isset($_SESSION[$mapping['cecId']])     ? $_SESSION[$mapping['cecId']]     : '';
        $firstName = isset($_SESSION[$mapping['firstName']]) ? $_SESSION[$mapping['firstName']] : '';
        $lastName  = isset($_SESSION[$mapping['lastName']])  ? $_SESSION[$mapping['lastName']]  : '';
        $email     = isset($_SESSION[$mapping['email']])     ? $_SESSION[$mapping['email']]     : ($cecId ? $cecId . '@cisco.com' : '');
        $country   = isset($_SESSION[$mapping['country']])   ? $_SESSION[$mapping['country']]   : '';
        $phone     = isset($_SESSION[$mapping['phone']])     ? $_SESSION[$mapping['phone']]     : '';
        $source    = 'cisco-sso';
    } else {
        // Fallback to default user configured in users.config.php (for local development or pre-SSO)
        $def = isset($config_users->default) && is_array($config_users->default)
            ? $config_users->default
            : [
                'cecId'     => 'vevommi',
                'firstName' => 'VenkataRamaKrishna',
                'lastName'  => 'Vommi',
                'email'     => 'vevommi@cisco.com',
                'country'   => 'INDIA',
                'phone'     => ''
            ];

        $cecId     = isset($def['cecId'])     ? $def['cecId']     : 'guest';
        $firstName = isset($def['firstName']) ? $def['firstName'] : '';
        $lastName  = isset($def['lastName'])  ? $def['lastName']  : '';
        $email     = isset($def['email'])     ? $def['email']     : '';
        $country   = isset($def['country'])   ? $def['country']   : '';
        $phone     = isset($def['phone'])     ? $def['phone']     : '';
        $source    = 'users.config.default';
    }

    $fullName = trim($firstName . ' ' . $lastName);
    if (empty($fullName)) {
        $fullName = $cecId;
    }

    // 2-letter Avatar Initials (e.g. "VV" for Venkata Vommi)
    $initials = '';
    if (!empty($firstName)) $initials .= strtoupper(substr($firstName, 0, 1));
    if (!empty($lastName))  $initials .= strtoupper(substr(trim($lastName), 0, 1));
    if (empty($initials) && !empty($cecId)) {
        $initials = strtoupper(substr($cecId, 0, 2));
    }

    echo json_encode([
        'ok'            => true,
        'authenticated' => $isAuth,
        'cecId'         => $cecId,
        'firstName'     => $firstName,
        'lastName'      => $lastName,
        'fullName'      => $fullName,
        'email'         => $email,
        'country'       => $country,
        'phone'         => $phone,
        'initials'      => $initials,
        'source'        => $source,
    ]);
}
