/**
 * Cisco MOPs FORM Studio - Advanced Logic Studio (Visual Condition Tree & JS Expression Engine)
 * Domain: Enterprise visual rule builder for field visibility, requirement, editability, and validation conditions
 * File: js/modules/08-advanced-logic.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
advLogicState: {
    fieldLoc: null,
    draft: null,
    activeTab: 'display',
    editingRule: null
  },

  openAdvancedLogicForSelectedField() {
    if (!this.selectedFieldLoc) return;
    this.openAdvancedLogicModal(this.selectedFieldLoc.sectionIndex, this.selectedFieldLoc.fieldIndex);
  },

  openAdvancedLogicModal(sIdx, fIdx) {
    const sec = this.formSchema.sections?.[sIdx];
    const field = sec?.fields?.[fIdx];
    if (!field) return;

    this.advLogicState.fieldLoc = { sectionIndex: sIdx, fieldIndex: fIdx };
    this.advLogicState.activeTab = 'display';
    this.advLogicState.editingRule = null;

    // Initialize or clone advancedLogic
    if (field.advancedLogic) {
      this.advLogicState.draft = JSON.parse(JSON.stringify(field.advancedLogic));
    } else {
      // Migrate legacy condition if present
      let initialGroups = [];
      if (field.condition && field.condition !== true) {
        const rules = Array.isArray(field.condition) ? field.condition : [field.condition];
        initialGroups = [{
          operator: field.conditionType || 'AND',
          rules: rules.map(r => ({
            field: r.field || '',
            comparison: r.comparison || 'isSelected',
            value: r.value || ''
          }))
        }];
      } else {
        // Find other fields to provide a default rule
        const otherFields = this.getOtherFields(field.formData);
        const firstTarget = otherFields[0]?.formData || '';
        initialGroups = [{
          operator: 'AND',
          rules: [{ field: firstTarget, comparison: 'isSelected', value: '' }]
        }];
      }

      this.advLogicState.draft = {
        display: {
          operator: 'OR',
          groups: initialGroups
        },
        skip: {
          action: 'none',
          targetSection: ''
        },
        defaultValue: {
          rules: []
        },
        validation: {
          requiredIf: {
            enabled: false,
            operator: 'AND',
            groups: []
          }
        },
        formatting: {
          bannerType: 'none',
          bannerText: ''
        },
        editability: {
          disabledIf: {
            enabled: false,
            operator: 'AND',
            groups: []
          }
        }
      };
    }

    // Set Top Header Bar Metadata
    const typeMap = {
      'text': 'Single-line text',
      'select': 'Single-select dropdown',
      'multi_select_fancy': 'Multi-select dropdown',
      'textarea': 'Textarea / paragraph',
      'radio': 'Radio button group',
      'checkbox': 'Checkbox toggle',
      'date': 'Date picker',
      'file': 'File attachment upload',
      'text_number': 'Numeric input'
    };

    const typeEl = document.getElementById('advLogicFieldType');
    const nameEl = document.getElementById('advLogicFieldName');
    const labelEl = document.getElementById('advLogicFieldLabel');
    const scopeEl = document.getElementById('advLogicFormContext');
    const scopeNameEl = document.getElementById('advScopeFormName');
    if (typeEl) typeEl.textContent = typeMap[field.type] || field.type || 'Single-select dropdown';
    if (nameEl) nameEl.textContent = field.formData || 'untitledField';
    if (labelEl) labelEl.textContent = field.label || field.wfLabel || field.formData || 'Untitled Field';
    if (scopeEl) scopeEl.textContent = this.formSchema.title || 'Current Form';
    if (scopeNameEl) scopeNameEl.textContent = `"${this.formSchema.title || 'this form'}"`;

    // Initialize Plain JS Editor content
    const jsTextarea = document.getElementById('advLogicCustomJsTextarea');
    if (jsTextarea) {
      jsTextarea.value = this.advLogicState.draft.display.customJs || '';
    }
    const currentMode = this.advLogicState.draft.display.mode || 'visual';
    this.setAdvDisplayMode(currentMode);
    this.validateCurrentJsCode();
    const liveRes = document.getElementById('jsLiveTestResult');
    if (liveRes) liveRes.textContent = '';

    // Switch to 'display' tab by default
    this.switchAdvLogicTab('display');

    // Open Modal
    document.getElementById('modalAdvancedLogic')?.classList.add('open');
  },

  closeAdvancedLogicModal() {
    document.getElementById('modalAdvancedLogic')?.classList.remove('open');
    this.advLogicState.fieldLoc = null;
    this.advLogicState.draft = null;
  },

  setAdvDisplayMode(mode) {
    if (!this.advLogicState.draft) return;
    this.advLogicState.draft.display.mode = mode;

    const btnVisual = document.getElementById('btnModeVisualLogic');
    const btnJs = document.getElementById('btnModeJsLogic');
    const visualWrap = document.getElementById('advVisualLogicWrap');
    const jsWrap = document.getElementById('advJsLogicWrap');
    const hint = document.getElementById('logicModeHint');

    if (mode === 'javascript') {
      btnVisual?.classList.remove('active');
      btnJs?.classList.add('active');
      if (visualWrap) visualWrap.style.display = 'none';
      if (jsWrap) jsWrap.style.display = 'block';
      if (hint) hint.textContent = ' Direct Plain JavaScript code mode active. Evaluates ES6 return expression in real time.';

      // Pre-generate starting JS expression from visual groups if editor is currently empty
      const textarea = document.getElementById('advLogicCustomJsTextarea');
      if (textarea && !textarea.value.trim()) {
        const generated = this.generateJsFromVisualGroups();
        if (generated) {
          textarea.value = generated;
          this.advLogicState.draft.display.customJs = generated;
        }
      }
      this.validateCurrentJsCode();
    } else {
      btnJs?.classList.remove('active');
      btnVisual?.classList.add('active');
      if (jsWrap) jsWrap.style.display = 'none';
      if (visualWrap) visualWrap.style.display = 'block';
      if (hint) hint.textContent = ' Visual Rule Builder active. Evaluates AND/OR condition block tree.';
    }
  },

  insertJsSnippet(type) {
    const textarea = document.getElementById('advLogicCustomJsTextarea');
    if (!textarea) return;

    const { sectionIndex, fieldIndex } = this.advLogicState.fieldLoc || {};
    const currField = this.formSchema.sections?.[sectionIndex]?.fields?.[fieldIndex];
    const otherFields = this.getOtherFields(currField?.formData);
    const sampleField = otherFields[0]?.formData || 'fieldName';

    let snippet = '';
    switch (type) {
      case 'equality':
        snippet = `return data.${sampleField} === 'ExpectedValue';`;
        break;
      case 'and_or':
        const secondField = otherFields[1]?.formData || 'otherField';
        snippet = `return (data.${sampleField} === 'Yes' && data.${secondField} === 'Active') || data.priority === 'High';`;
        break;
      case 'includes':
        snippet = `return ['Option A', 'Option B'].includes(data.${sampleField});`;
        break;
      case 'not_empty':
        snippet = `return Boolean(data.${sampleField} && String(data.${sampleField}).trim() !== '');`;
        break;
      case 'regex':
        snippet = `return /^PRJ-[0-9]{4}$/i.test(data.${sampleField} || '');`;
        break;
      default:
        snippet = `return true;`;
    }

    if (!textarea.value.trim() || textarea.value.trim().startsWith('//')) {
      textarea.value = snippet;
    } else {
      textarea.value += '\n' + snippet;
    }
    this.advLogicState.draft.display.customJs = textarea.value;
    this.validateCurrentJsCode();
  },

  validateCurrentJsCode() {
    const textarea = document.getElementById('advLogicCustomJsTextarea');
    const badge = document.getElementById('jsSyntaxStatusBadge');
    if (!textarea || !badge) return true;

    const code = textarea.value.trim();
    if (!code) {
      badge.className = 'js-syntax-badge valid';
      badge.textContent = ' Empty (Always Visible by Default)';
      return true;
    }

    try {
      const wrapped = code.includes('return') ? code : `return (${code});`;
      new Function('data', 'formValues', wrapped);
      badge.className = 'js-syntax-badge valid';
      badge.textContent = 'OK Valid JavaScript Expression';
      return true;
    } catch (e) {
      badge.className = 'js-syntax-badge error';
      badge.textContent = ' Syntax Error: ' + e.message;
      return false;
    }
  },

  testCurrentJsLogic() {
    const textarea = document.getElementById('advLogicCustomJsTextarea');
    const resEl = document.getElementById('jsLiveTestResult');
    if (!textarea || !resEl) return;

    const code = textarea.value.trim();
    if (!code) {
      resEl.className = 'js-test-result visible';
      resEl.textContent = 'Result: VISIBLE (Empty rule)';
      return;
    }

    try {
      const wrapped = code.includes('return') ? code : `return (${code});`;
      const fn = new Function('data', 'formValues', wrapped);
      const liveData = Object.assign({}, this.formValues || {});
      document.querySelectorAll('#canvasSectionsRoot [data-field]').forEach(inp => {
        const key = inp.getAttribute('data-field');
        if (inp.type === 'checkbox') {
          liveData[key] = inp.checked;
        } else if (inp.value) {
          liveData[key] = inp.value;
        }
      });

      const res = Boolean(fn(liveData, liveData));
      if (res) {
        resEl.className = 'js-test-result visible';
        resEl.textContent = 'OK Result: VISIBLE (true)';
      } else {
        resEl.className = 'js-test-result hidden';
        resEl.textContent = ' Result: HIDDEN (false)';
      }
    } catch (e) {
      resEl.className = 'js-test-result hidden';
      resEl.textContent = 'Error: ' + e.message;
    }
  },

  generateJsFromVisualGroups() {
    const groups = this.advLogicState.draft?.display?.groups;
    if (!groups || groups.length === 0) return '';
    const cleanGroups = groups.filter(g => g.rules && g.rules.length > 0 && g.rules[0].field);
    if (cleanGroups.length === 0) return '';

    const groupExpressions = cleanGroups.map(g => {
      const innerOp = (g.operator || 'AND') === 'AND' ? ' && ' : ' || ';
      const ruleExprs = g.rules.filter(r => r.field).map(r => {
        const comp = (r.comparison || 'isSelected').toLowerCase().replace(/\s+/g, '');
        const val = (r.value || '').replace(/'/g, "\\'");
        if (comp === 'isselected' || comp === 'selected' || comp === '==' || comp === 'equals') {
          return `data.${r.field} === '${val}'`;
        } else if (comp === 'isnotselected' || comp === 'notselected' || comp === '!=' || comp === 'notequals') {
          return `data.${r.field} !== '${val}'`;
        } else if (comp === 'contains') {
          return `String(data.${r.field} || '').includes('${val}')`;
        } else if (comp === 'doesnotcontain' || comp === 'not') {
          return `!String(data.${r.field} || '').includes('${val}')`;
        } else if (comp === 'notempty' || comp === 'isnotempty') {
          return `Boolean(data.${r.field})`;
        } else if (comp === 'empty' || comp === 'isempty') {
          return `!data.${r.field}`;
        } else {
          return `data.${r.field} === '${val}'`;
        }
      });
      if (ruleExprs.length === 0) return 'true';
      return ruleExprs.length === 1 ? ruleExprs[0] : `(${ruleExprs.join(innerOp)})`;
    });

    return `return ${groupExpressions.join(' || ')};`;
  },

  applyAdvancedLogic() {
    if (!this.advLogicState.fieldLoc || !this.advLogicState.draft) return;
    const { sectionIndex, fieldIndex } = this.advLogicState.fieldLoc;
    const field = this.formSchema.sections?.[sectionIndex]?.fields?.[fieldIndex];
    if (!field) return;

    // Persist Custom JS from textarea
    const jsTextarea = document.getElementById('advLogicCustomJsTextarea');
    if (jsTextarea) {
      this.advLogicState.draft.display.customJs = jsTextarea.value;
    }

    // Filter out completely empty rules from visual groups
    const cleanGroups = (this.advLogicState.draft.display.groups || []).map(g => {
      return {
        operator: g.operator || 'AND',
        rules: (g.rules || []).filter(r => r.field && r.field.trim() !== '')
      };
    }).filter(g => g.rules.length > 0);

    this.advLogicState.draft.display.groups = cleanGroups;
    field.advancedLogic = JSON.parse(JSON.stringify(this.advLogicState.draft));

    // Synchronize with legacy field.condition for backward compatibility
    if (cleanGroups.length === 0) {
      field.condition = null;
      field.conditionType = null;
    } else if (cleanGroups.length === 1) {
      field.condition = cleanGroups[0].rules;
      field.conditionType = cleanGroups[0].operator || 'AND';
    } else {
      field.condition = cleanGroups[0].rules;
      field.conditionType = 'OR';
    }

    this.saveFormToStorage();
    this.render();
    if (this.selectedFieldLoc && this.selectedFieldLoc.sectionIndex === sectionIndex && this.selectedFieldLoc.fieldIndex === fieldIndex) {
      this.renderDrawerRules(field);
    }
    this.closeAdvancedLogicModal();
  },

  switchAdvLogicTab(tabKey) {
    this.advLogicState.activeTab = tabKey;

    // Update sidebar tab buttons
    document.querySelectorAll('.adv-sidebar-tab').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabKey);
    });

    // Toggle content panes
    document.querySelectorAll('.adv-logic-content .adv-tab-pane').forEach(pane => {
      pane.style.display = 'none';
      pane.classList.remove('active');
    });

    const activePane = document.getElementById(`advPane_${tabKey}`);
    if (activePane) {
      activePane.style.display = 'block';
      activePane.classList.add('active');
    }

    // Render tab content
    switch (tabKey) {
      case 'display':
        this.renderAdvDisplayGroups();
        break;
      case 'skip':
        this.renderAdvSkipTab();
        break;
      case 'default_value':
        this.renderAdvDefaultsTab();
        break;
      case 'validation':
        this.renderAdvValidationTab();
        break;
      case 'formatting':
        this.renderAdvFormattingTab();
        break;
      case 'editability':
        this.renderAdvEditabilityTab();
        break;
    }
  },

  getOtherFields(currentFieldKey) {
    const others = [];
    (this.formSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => {
        if (f.formData !== currentFieldKey) others.push(f);
      });
    });
    return others;
  },

  renderAdvDisplayGroups() {
    const container = document.getElementById('advDisplayGroupsContainer');
    if (!container || !this.advLogicState.draft) return;
    container.innerHTML = '';

    const currentField = this.formSchema.sections[this.advLogicState.fieldLoc.sectionIndex].fields[this.advLogicState.fieldLoc.fieldIndex];
    const otherFields = this.getOtherFields(currentField.formData);
    const groups = this.advLogicState.draft.display.groups || [];

    if (groups.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 24px; background: #ffffff; border: 1px dashed #cbd5e1; border-radius: 8px; color: #64748b;">
          <div>OK <strong>No display conditions currently configured.</strong></div>
          <div style="font-size: 12px; margin-top: 4px;">This field will always be visible on the form.</div>
          <button type="button" class="btn btn-outline btn-sm" style="margin-top: 10px;" onclick="App.addAdvDisplayGroup()">+ Add First Rule Group</button>
        </div>
      `;
      return;
    }

    groups.forEach((group, gIdx) => {
      // If not first group, render the 'Or' connector pill (maroon pill from screenshot!)
      if (gIdx > 0) {
        const orDiv = document.createElement('div');
        orDiv.className = 'adv-or-connector';
        orDiv.innerHTML = `<span class="adv-badge-or">Or</span>`;
        container.appendChild(orDiv);
      }

      // Group Card
      const card = document.createElement('div');
      card.className = 'adv-group-card';

      // Left rail + rules
      const groupBody = document.createElement('div');
      groupBody.className = 'adv-group-body';

      // Left vertical rail with AND badge (indigo badge from screenshot!)
      const rail = document.createElement('div');
      rail.className = 'adv-group-rail';
      rail.innerHTML = `
        <div class="adv-group-rail-line"></div>
        <span class="adv-badge-and">And</span>
      `;
      groupBody.appendChild(rail);

      // Right list of rules
      const rulesList = document.createElement('div');
      rulesList.className = 'adv-group-rules-list';

      (group.rules || []).forEach((rule, rIdx) => {
        const row = document.createElement('div');
        row.className = 'adv-rule-row';

        const isEditing = this.advLogicState.editingRule &&
          this.advLogicState.editingRule.gIdx === gIdx &&
          this.advLogicState.editingRule.rIdx === rIdx;

        // Check if rule is incomplete or references a field missing in this form context
        const targetFieldObj = otherFields.find(f => f.formData === rule.field);
        const isIncomplete = !rule.field || rule.field.trim() === '';
        const isFieldMissingInThisForm = Boolean(rule.field && !targetFieldObj);

        if (isFieldMissingInThisForm && !isEditing) {
          // Orphaned field from another form context or deleted field ( icon!)
          row.innerHTML = `
            <div class="adv-rule-warning" style="cursor: pointer;" onclick="App.editAdvRule(${gIdx}, ${rIdx})">
              <span class="adv-warn-icon"></span>
              <span>Referenced field "<strong>${rule.field}</strong>" does not exist in this form. Click to select a valid field.</span>
            </div>
            <button type="button" class="adv-btn-remove-rule" title="Remove condition" onclick="event.stopPropagation(); App.removeRuleFromAdvGroup(${gIdx}, ${rIdx})"></button>
          `;
        } else if (isIncomplete && !isEditing) {
          // Warning state matching screenshot Row 2 of Group 2 ( icon!)
          row.innerHTML = `
            <div class="adv-rule-warning" style="cursor: pointer;" onclick="App.editAdvRule(${gIdx}, ${rIdx})">
              <span class="adv-warn-icon"></span>
              <span>Rule incomplete: click to choose target field and condition criteria</span>
            </div>
            <button type="button" class="adv-btn-remove-rule" title="Remove condition" onclick="event.stopPropagation(); App.removeRuleFromAdvGroup(${gIdx}, ${rIdx})"></button>
          `;
        } else if (!isEditing && rule.field) {
          // Summary chip row (matching screenshot: "uap DG Motion   Acquire   is Selected   ")
          const fieldLabel = targetFieldObj ? (targetFieldObj.label || targetFieldObj.formData) : rule.field;

          const opLabels = {
            'isselected': 'is Selected',
            'isnotselected': 'is Not Selected',
            '==': 'equals',
            '!=': 'does not equal',
            'contains': 'contains',
            'doesnotcontain': 'does not contain',
            'startswith': 'starts with',
            'endswith': 'ends with',
            'notempty': 'is Not Empty',
            'empty': 'is Empty',
            '>': 'is greater than',
            '<': 'is less than',
            'regex': 'matches regex'
          };
          const compClean = (rule.comparison || 'isselected').toLowerCase().replace(/\s+/g, '');
          const opDisplay = opLabels[compClean] || rule.comparison || 'is Selected';

          const isNoVal = compClean === 'empty' || compClean === 'notempty';

          row.innerHTML = `
            <div class="adv-rule-content" style="cursor: pointer;" onclick="App.editAdvRule(${gIdx}, ${rIdx})">
              <span class="adv-chip-field">${fieldLabel}</span>
              ${!isNoVal ? `<span class="adv-chip-val">${rule.value || 'Any'}</span>` : ''}
              <span class="adv-chip-op">${opDisplay}</span>
            </div>
            <button type="button" class="adv-btn-remove-rule" title="Remove condition" onclick="event.stopPropagation(); App.removeRuleFromAdvGroup(${gIdx}, ${rIdx})"></button>
          `;
        } else {
          // Active inline editing row (matching screenshot Row 3: 3 smart dropdowns!)
          const targetFieldObj = otherFields.find(f => f.formData === rule.field);
          const hasOptions = targetFieldObj && Array.isArray(targetFieldObj.options) && targetFieldObj.options.length > 0;

          const compClean = (rule.comparison || 'isselected').toLowerCase().replace(/\s+/g, '');
          const isNoVal = compClean === 'empty' || compClean === 'notempty';

          // Options for field select
          const fieldSelectHtml = `
            <select class="mops-select adv-select-field" onchange="App.onAdvRuleFieldChange(${gIdx}, ${rIdx}, this.value)">
              <option value=""> Select Target Field </option>
              ${otherFields.map(f => `<option value="${f.formData}" ${f.formData === rule.field ? 'selected' : ''}>${f.label || f.formData} (${f.formData})</option>`).join('')}
            </select>
          `;

          // Value input or dropdown
          let valInputHtml = '';
          if (isNoVal) {
            valInputHtml = '';
          } else if (hasOptions) {
            valInputHtml = `
              <select class="mops-select adv-select-val" onchange="App.onAdvRuleValChange(${gIdx}, ${rIdx}, this.value)">
                <option value=""> Select Option </option>
                ${targetFieldObj.options.map(opt => {
              const optVal = typeof opt === 'object' ? (opt.value || opt.label) : opt;
              const optLabel = typeof opt === 'object' ? (opt.label || opt.value) : opt;
              return `<option value="${optVal}" ${String(optVal) === String(rule.value) ? 'selected' : ''}>${optLabel}</option>`;
            }).join('')}
              </select>
            `;
          } else {
            valInputHtml = `
              <input type="text" class="mops-input adv-input-val" value="${rule.value || ''}" placeholder="Trigger value" oninput="App.onAdvRuleValChange(${gIdx}, ${rIdx}, this.value)">
            `;
          }

          // Operator dropdown
          const operators = [
            { value: 'isSelected', label: 'Selected' },
            { value: 'isNotSelected', label: 'Not Selected' },
            { value: '==', label: 'Equals (==)' },
            { value: '!=', label: 'Does Not Equal (!=)' },
            { value: 'contains', label: 'Contains' },
            { value: 'doesNotContain', label: 'Does Not Contain' },
            { value: 'startsWith', label: 'Starts With' },
            { value: 'endsWith', label: 'Ends With' },
            { value: 'notempty', label: 'Not Empty' },
            { value: 'empty', label: 'Empty' },
            { value: '>', label: 'Greater Than (>)' },
            { value: '<', label: 'Less Than (<)' },
            { value: 'regex', label: 'Regex Pattern' }
          ];

          const compSelectHtml = `
            <select class="mops-select adv-select-op" onchange="App.onAdvRuleCompChange(${gIdx}, ${rIdx}, this.value)">
              ${operators.map(op => `<option value="${op.value}" ${compClean === op.value.toLowerCase().replace(/\s+/g, '') ? 'selected' : ''}>${op.label}</option>`).join('')}
            </select>
          `;

          row.innerHTML = `
            <div class="adv-rule-inputs">
              ${fieldSelectHtml}
              ${valInputHtml}
              <span class="adv-is-connector">is</span>
              ${compSelectHtml}
            </div>
            <button type="button" class="adv-btn-remove-rule" title="Remove condition" onclick="event.stopPropagation(); App.removeRuleFromAdvGroup(${gIdx}, ${rIdx})"></button>
          `;
        }

        rulesList.appendChild(row);
      });

      groupBody.appendChild(rulesList);
      card.appendChild(groupBody);

      // Group Footer (+ Add Rule button & delete group)
      const footer = document.createElement('div');
      footer.className = 'adv-group-footer';
      footer.innerHTML = `
        <button type="button" class="adv-btn-add-rule" onclick="App.addRuleToAdvGroup(${gIdx})">
          <span style="font-size: 14px;">+</span> Add Rule
        </button>
        ${groups.length > 1 ? `<button type="button" class="adv-btn-delete-group" onclick="App.removeAdvGroup(${gIdx})">x Delete Group</button>` : ''}
      `;
      card.appendChild(footer);

      container.appendChild(card);
    });
  },

  editAdvRule(gIdx, rIdx) {
    this.advLogicState.editingRule = { gIdx, rIdx };
    this.renderAdvDisplayGroups();
  },

  onAdvRuleFieldChange(gIdx, rIdx, newField) {
    const rule = this.advLogicState.draft?.display?.groups?.[gIdx]?.rules?.[rIdx];
    if (!rule) return;
    rule.field = newField;
    rule.value = '';
    this.renderAdvDisplayGroups();
  },

  onAdvRuleValChange(gIdx, rIdx, newVal) {
    const rule = this.advLogicState.draft?.display?.groups?.[gIdx]?.rules?.[rIdx];
    if (!rule) return;
    rule.value = newVal;
  },

  onAdvRuleCompChange(gIdx, rIdx, newComp) {
    const rule = this.advLogicState.draft?.display?.groups?.[gIdx]?.rules?.[rIdx];
    if (!rule) return;
    rule.comparison = newComp;
    this.renderAdvDisplayGroups();
  },

  addRuleToAdvGroup(gIdx) {
    const group = this.advLogicState.draft?.display?.groups?.[gIdx];
    if (!group) return;
    const currentField = this.formSchema.sections[this.advLogicState.fieldLoc.sectionIndex].fields[this.advLogicState.fieldLoc.fieldIndex];
    const otherFields = this.getOtherFields(currentField.formData);
    const firstTarget = otherFields[0]?.formData || '';

    group.rules.push({
      field: firstTarget,
      comparison: 'isSelected',
      value: ''
    });

    this.advLogicState.editingRule = { gIdx, rIdx: group.rules.length - 1 };
    this.renderAdvDisplayGroups();
  },

  removeRuleFromAdvGroup(gIdx, rIdx) {
    const group = this.advLogicState.draft?.display?.groups?.[gIdx];
    if (!group) return;
    group.rules.splice(rIdx, 1);

    if (group.rules.length === 0 && (this.advLogicState.draft.display.groups.length > 1)) {
      this.advLogicState.draft.display.groups.splice(gIdx, 1);
    }
    this.advLogicState.editingRule = null;
    this.renderAdvDisplayGroups();
  },

  addAdvDisplayGroup() {
    if (!this.advLogicState.draft) return;
    if (!Array.isArray(this.advLogicState.draft.display.groups)) {
      this.advLogicState.draft.display.groups = [];
    }
    const currentField = this.formSchema.sections[this.advLogicState.fieldLoc.sectionIndex].fields[this.advLogicState.fieldLoc.fieldIndex];
    const otherFields = this.getOtherFields(currentField.formData);
    const firstTarget = otherFields[0]?.formData || '';

    const newGroupIdx = this.advLogicState.draft.display.groups.length;
    this.advLogicState.draft.display.groups.push({
      operator: 'AND',
      rules: [{
        field: firstTarget,
        comparison: 'isSelected',
        value: ''
      }]
    });

    this.advLogicState.editingRule = { gIdx: newGroupIdx, rIdx: 0 };
    this.renderAdvDisplayGroups();
  },

  removeAdvGroup(gIdx) {
    if (!this.advLogicState.draft?.display?.groups) return;
    this.advLogicState.draft.display.groups.splice(gIdx, 1);
    this.advLogicState.editingRule = null;
    this.renderAdvDisplayGroups();
  },

  // Skip Logic Tab
  renderAdvSkipTab() {
    const draft = this.advLogicState.draft?.skip;
    const actionSelect = document.getElementById('advSkipActionSelect');
    const targetGroup = document.getElementById('advSkipTargetSectionGroup');
    const targetSelect = document.getElementById('advSkipTargetSectionSelect');

    if (actionSelect && draft) {
      actionSelect.value = draft.action || 'none';
    }

    if (targetSelect) {
      targetSelect.innerHTML = (this.formSchema.sections || []).map((sec, idx) =>
        `<option value="${sec.id || idx}" ${draft?.targetSection === (sec.id || idx) ? 'selected' : ''}>${sec.title || 'Section ' + (idx + 1)}</option>`
      ).join('');
    }

    if (targetGroup) {
      targetGroup.style.display = draft?.action === 'jumpToSection' ? 'block' : 'none';
    }
  },

  handleSkipActionChange() {
    const actionSelect = document.getElementById('advSkipActionSelect');
    const targetGroup = document.getElementById('advSkipTargetSectionGroup');
    if (!this.advLogicState.draft) return;
    if (!this.advLogicState.draft.skip) this.advLogicState.draft.skip = {};
    this.advLogicState.draft.skip.action = actionSelect.value;
    if (targetGroup) {
      targetGroup.style.display = actionSelect.value === 'jumpToSection' ? 'block' : 'none';
    }
  },

  // Dynamic Defaults Tab
  renderAdvDefaultsTab() {
    const list = document.getElementById('advDefaultsList');
    if (!list || !this.advLogicState.draft) return;
    list.innerHTML = '';
    const rules = this.advLogicState.draft.defaultValue?.rules || [];
    if (rules.length === 0) {
      list.innerHTML = `<div style="font-size: 12.5px; color: #64748b; font-style: italic;">No dynamic default value rules configured.</div>`;
      return;
    }
    const currentField = this.formSchema.sections[this.advLogicState.fieldLoc.sectionIndex].fields[this.advLogicState.fieldLoc.fieldIndex];
    const otherFields = this.getOtherFields(currentField.formData);

    rules.forEach((r, idx) => {
      const row = document.createElement('div');
      row.style.cssText = 'display: flex; align-items: center; gap: 8px; margin-bottom: 8px; padding: 6px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px;';
      row.innerHTML = `
        <span style="font-size: 12px; font-weight: 600;">If</span>
        <select class="mops-select" style="min-width: 140px; height: 30px; font-size: 12px;" onchange="App.advLogicState.draft.defaultValue.rules[${idx}].condition.field = this.value">
          ${otherFields.map(f => `<option value="${f.formData}" ${f.formData === r.condition?.field ? 'selected' : ''}>${f.label || f.formData}</option>`).join('')}
        </select>
        <span style="font-size: 12px;">==</span>
        <input type="text" class="mops-input" style="min-width: 120px; height: 30px; font-size: 12px;" value="${r.condition?.value || ''}" placeholder="Trigger value" oninput="App.advLogicState.draft.defaultValue.rules[${idx}].condition.value = this.value">
        <span style="font-size: 12px; font-weight: 600;">Set To:</span>
        <input type="text" class="mops-input" style="min-width: 120px; height: 30px; font-size: 12px;" value="${r.value || ''}" placeholder="Default value" oninput="App.advLogicState.draft.defaultValue.rules[${idx}].value = this.value">
        <button type="button" class="btn btn-danger btn-sm btn-icon-only" onclick="App.advLogicState.draft.defaultValue.rules.splice(${idx}, 1); App.renderAdvDefaultsTab();"></button>
      `;
      list.appendChild(row);
    });
  },

  addAdvDefaultRule() {
    if (!this.advLogicState.draft) return;
    if (!this.advLogicState.draft.defaultValue) this.advLogicState.draft.defaultValue = { rules: [] };
    const currentField = this.formSchema.sections[this.advLogicState.fieldLoc.sectionIndex].fields[this.advLogicState.fieldLoc.fieldIndex];
    const otherFields = this.getOtherFields(currentField.formData);
    this.advLogicState.draft.defaultValue.rules.push({
      condition: { field: otherFields[0]?.formData || '', comparison: '==', value: '' },
      value: ''
    });
    this.renderAdvDefaultsTab();
  },

  // Validation Tab
  renderAdvValidationTab() {
    const toggle = document.getElementById('advToggleRequiredIf');
    const container = document.getElementById('advRequiredIfContainer');
    const reqIf = this.advLogicState.draft?.validation?.requiredIf;
    if (toggle) toggle.checked = Boolean(reqIf?.enabled);
    if (container) container.style.display = reqIf?.enabled ? 'block' : 'none';
  },

  toggleAdvRequiredIf() {
    const toggle = document.getElementById('advToggleRequiredIf');
    if (!this.advLogicState.draft) return;
    if (!this.advLogicState.draft.validation) this.advLogicState.draft.validation = { requiredIf: {} };
    this.advLogicState.draft.validation.requiredIf.enabled = toggle.checked;
    this.renderAdvValidationTab();
  },

  // Formatting Tab
  renderAdvFormattingTab() {
    const bannerSelect = document.getElementById('advFormatBannerType');
    const bannerInput = document.getElementById('advFormatBannerText');
    const fmt = this.advLogicState.draft?.formatting;
    if (bannerSelect && fmt) bannerSelect.value = fmt.bannerType || 'none';
    if (bannerInput && fmt) bannerInput.value = fmt.bannerText || '';

    bannerSelect?.addEventListener('change', (e) => {
      if (this.advLogicState.draft?.formatting) this.advLogicState.draft.formatting.bannerType = e.target.value;
    });
    bannerInput?.addEventListener('input', (e) => {
      if (this.advLogicState.draft?.formatting) this.advLogicState.draft.formatting.bannerText = e.target.value;
    });
  },

  // Editability Tab
  renderAdvEditabilityTab() {
    const toggle = document.getElementById('advToggleReadOnlyIf');
    const container = document.getElementById('advReadOnlyIfContainer');
    const disIf = this.advLogicState.draft?.editability?.disabledIf;
    if (toggle) toggle.checked = Boolean(disIf?.enabled);
    if (container) container.style.display = disIf?.enabled ? 'block' : 'none';
  },

  toggleAdvReadOnlyIf() {
    const toggle = document.getElementById('advToggleReadOnlyIf');
    if (!this.advLogicState.draft) return;
    if (!this.advLogicState.draft.editability) this.advLogicState.draft.editability = { disabledIf: {} };
    this.advLogicState.draft.editability.disabledIf.enabled = toggle.checked;
    this.renderAdvEditabilityTab();
  }
});
