/**
 * Cisco MOPs FORM Studio - Where-Used Field Dependency Tracker & Shared Field Impact Guard
 * Domain: Cross-form usage scanner, dependency visualizer, and cascade impact protection when editing library fields
 * File: js/modules/13-where-used-tracker.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
getFieldWhereUsed(fieldIdentifier) {
    if (!fieldIdentifier) return [];
    const query = String(fieldIdentifier).trim().toLowerCase();
    const results = [];
    const formsToScan = [];

    // Combine loaded allForms with live current formSchema and registry sample forms
    const knownIds = new Set();
    if (this.currentFormId && this.formSchema && Array.isArray(this.formSchema.sections)) {
      const activeMeta = (this.allForms || []).find(f => f.id === this.currentFormId);
      formsToScan.push({
        id: this.currentFormId,
        label: activeMeta?.label || this.formSchema.title || this.currentFormId,
        icon: activeMeta?.icon || '',
        version: activeMeta?.activeVersionId || this.formSchema.version || 'v1.0',
        sprint: activeMeta?.activeSprint || '',
        schema: this.formSchema
      });
      knownIds.add(this.currentFormId);
    }
    (this.allForms || []).forEach(f => {
      if (!knownIds.has(f.id)) {
        formsToScan.push({
          id: f.id,
          label: f.label,
          icon: f.icon || '',
          version: f.activeVersionId || f.schema?.version || 'v1.0',
          sprint: f.activeSprint || '',
          schema: f.schema
        });
        knownIds.add(f.id);
      }
    });
    if (window.SAMPLE_FORMS && Array.isArray(window.SAMPLE_FORMS)) {
      window.SAMPLE_FORMS.forEach(sf => {
        if (!knownIds.has(sf.id)) {
          formsToScan.push({
            id: sf.id,
            label: sf.label,
            icon: sf.icon || '',
            version: sf.activeVersionId || sf.schema?.version || 'v1.0',
            sprint: sf.activeSprint || '',
            schema: sf.schema
          });
          knownIds.add(sf.id);
        }
      });
    }

    formsToScan.forEach(form => {
      if (!form.schema || !Array.isArray(form.schema.sections)) return;
      form.schema.sections.forEach(sec => {
        (sec.fields || []).forEach(fld => {
          const matchKey = (fld.formData || '').toLowerCase() === query;
          const matchId = (fld.id || '').toLowerCase() === query;
          const matchLib = (fld.wfLibraryFieldId || '').toLowerCase() === query;
          const matchWf = (fld.wfFieldName || '').toLowerCase() === query;
          const matchLbl = (fld.label || '').trim().toLowerCase() === query;
          const matchWfL = (fld.wfLabel || '').trim().toLowerCase() === query;

          if (matchKey || matchId || matchLib || matchWf || matchLbl || matchWfL) {
            results.push({
              formId: form.id,
              formLabel: form.label || form.schema.title || form.id,
              formIcon: form.icon || '',
              formVersion: form.version || 'v1.0',
              formSprint: form.sprint || '',
              sectionTitle: sec.title || 'Section',
              field: fld,
              instanceId: fld.instanceId || '—',
              dateAdded: fld.dateAdded || fld._createdAt || null,
              optionsCount: Array.isArray(fld.options) ? fld.options.length : 0,
              required: Boolean(fld.required),
              condition: fld.condition
            });
          }
        });
      });
    });

    return results;
  },

  updateSavedFieldWhereUsedBanner(savedField) {
    const textEl = document.getElementById('savedFieldWhereUsedText');
    if (!textEl || !savedField) return;
    const key = savedField.data?.formData || savedField.label;
    const usages = this.getFieldWhereUsed(key);
    this._currentEditingSavedFieldKey = key;
    if (usages.length === 0) {
      textEl.innerHTML = '<span style="color:#64748b;">Not used in any active form yet.</span>';
    } else {
      const formNames = usages.map(u => u.formLabel).slice(0, 3).join(', ');
      const extra = usages.length > 3 ? ` +${usages.length - 3} more` : '';
      textEl.innerHTML = `<strong style="color:#1d4ed8;">Used in ${usages.length} Intake form(s)</strong> (${formNames}${extra})`;
    }
  },

  openWhereUsedFromSavedField() {
    if (this._currentEditingSavedFieldKey) {
      this.openFieldWhereUsedModal(this._currentEditingSavedFieldKey);
    }
  },

  openFieldWhereUsedModal(fieldIdentifier) {
    const modal = document.getElementById('modalFieldWhereUsed');
    if (!modal) return;

    const usages = this.getFieldWhereUsed(fieldIdentifier);
    const titleEl = document.getElementById('whereUsedModalTitle');
    const subEl = document.getElementById('whereUsedModalSubtitle');
    const bannerEl = document.getElementById('whereUsedSummaryBanner');
    const tbody = document.getElementById('whereUsedTableBody');

    if (titleEl) titleEl.textContent = `Where-Used Audit: ${fieldIdentifier}`;
    if (subEl) subEl.textContent = `Field key: ${fieldIdentifier}  tracked across all intake forms in workspace`;

    if (bannerEl) {
      if (usages.length === 0) {
        bannerEl.innerHTML = `<strong> Not in Active Use:</strong> This field is not currently embedded in any form. You can safely edit or delete its picklist options without affecting live forms.`;
        bannerEl.style.background = '#f8fafc';
        bannerEl.style.borderColor = '#e2e8f0';
        bannerEl.style.color = '#64748b';
      } else {
        bannerEl.innerHTML = `<strong> Active Across ${usages.length} Form${usages.length > 1 ? 's' : ''}:</strong> Any changes to this field definition or picklist options will impact the forms listed below.`;
        bannerEl.style.background = '#eff6ff';
        bannerEl.style.borderColor = '#bfdbfe';
        bannerEl.style.color = '#1e40af';
      }
    }

    if (tbody) {
      if (usages.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:24px; color:#94a3b8;">No form usages found for "${fieldIdentifier}".</td></tr>`;
      } else {
        tbody.innerHTML = usages.map(u => {
          const reqBadge = u.required ? '<span style="color:#dc2626; font-weight:700;">* Required</span>' : '<span style="color:#64748b;">Optional</span>';
          const optsText = u.optionsCount > 0 ? `${u.optionsCount} options` : 'Text / Input';
          const condText = u.condition ? '<span style="background:#fef3c7; color:#92400e; padding:1px 5px; border-radius:3px; font-size:10px;">Rule</span>' : '';

          const dateStr = u.dateAdded ? new Date(u.dateAdded).toLocaleDateString() : '—';
          const verBadge = u.formVersion ? `<span style="font-size:10px; background:#e0f2fe; color:#0369a1; border-radius:4px; padding:1px 5px; font-weight:600; margin-left:4px;">${u.formVersion}</span>` : '';

          return `
            <tr>
              <td>
                <div style="display:flex; align-items:center; gap:8px;">
                  <span style="font-size:16px;">${u.formIcon}</span>
                  <div>
                    <strong style="color:#0f172a;">${u.formLabel}</strong>${verBadge}
                    <div style="font-size:10.5px; color:#64748b; font-family:monospace;">${u.formId}</div>
                  </div>
                </div>
              </td>
              <td><span style="color:#334155; font-weight:600;">${u.sectionTitle}</span></td>
              <td>
                <div>${u.field.label || u.field.wfLabel || u.field.formData || ''}</div>
                <div style="font-size:10.5px; color:#64748b; font-family:monospace;">API: ${u.field.formData || ''} · Inst: ${u.instanceId}</div>
              </td>
              <td>
                <div style="font-size:11px; color:#334155;">Added: ${dateStr}</div>
                <div style="font-size:10.5px;">${optsText} · ${reqBadge} ${condText}</div>
              </td>
              <td style="text-align: right;">
                <button type="button" class="btn btn-outline btn-sm" onclick="App.navigateToFormFromWhereUsed('${u.formId}', '${u.field.formData || u.field.id}')" style="font-size:11px; padding:3px 9px; font-weight:600; color:#005fb8; border-color:#005fb8;">
                  Open Form 
                </button>
              </td>
            </tr>
          `;
        }).join('');
      }
    }

    modal.classList.add('open');
  },

  closeFieldWhereUsedModal() {
    document.getElementById('modalFieldWhereUsed')?.classList.remove('open');
  },

  navigateToFormFromWhereUsed(formId, fieldKey) {
    this.closeFieldWhereUsedModal();
    this.closeEditSavedFieldModal();
    this.switchActiveForm(formId);
    setTimeout(() => {
      this._showToast(`Switched to form "${formId}"`);
    }, 300);
  },

  // Shared Field Impact Modal
  openSharedFieldImpactModal(fieldIdentifier, usages, removed, added) {
    const modal = document.getElementById('modalSharedFieldImpactWarning');
    if (!modal) return;

    const nameEl = document.getElementById('impactWarningFieldName');
    if (nameEl) nameEl.textContent = fieldIdentifier;

    const detailsEl = document.getElementById('impactWarningDetails');
    if (detailsEl) {
      const formsList = usages.map(u => `<strong>${u.formLabel}</strong>`).join(', ');
      let changeHtml = '';
      if (removed.length > 0) {
        changeHtml += `<div style="margin-top:6px;">Error <strong>Removed picklist option(s):</strong> <del style="color:#b91c1c; background:#fee2e2; padding:1px 6px; border-radius:3px;">${removed.join('", "')}</del></div>`;
      }
      if (added.length > 0) {
        changeHtml += `<div style="margin-top:4px;"> <strong>Added picklist option(s):</strong> <ins style="color:#15803d; background:#dcfce7; padding:1px 6px; border-radius:3px; text-decoration:none;">${added.join('", "')}</ins></div>`;
      }

      detailsEl.innerHTML = `
        <div> This field is shared across <strong>${usages.length} active forms</strong>: ${formsList}.</div>
        ${changeHtml}
        <div style="margin-top:6px; font-size:11px; color:#78350f;">Notice: Removing options may break downstream conditional routing or Workfront reporting if those forms depend on them.</div>
      `;
    }

    modal.classList.add('open');
  },

  closeSharedFieldImpactModal() {
    document.getElementById('modalSharedFieldImpactWarning')?.classList.remove('open');
    this._pendingFieldImpactSave = null;
  },

  confirmSharedFieldImpactAction() {
    const choice = document.querySelector('input[name="radioImpactChoice"]:checked')?.value || 'decouple';
    const pending = this._pendingFieldImpactSave;
    this.closeSharedFieldImpactModal();

    if (!pending) return;

    if (choice === 'global') {
      // Apply globally
      this.saveCurrentSavedFieldChanges('global');
      this._showToast(`Applied changes globally across all ${pending.usages.length} forms!`);
    } else {
      // Decouple for current form only
      this.saveCurrentSavedFieldChanges('decouple');
      this._showToast(`Saved options for this form only. Other forms remain protected!`);
    }
  },

  syncFieldOptionsGlobally(fieldIdentifier, newOptions) {
    const query = String(fieldIdentifier).trim().toLowerCase();
    (this.allForms || []).forEach(form => {
      if (!form.schema || !Array.isArray(form.schema.sections)) return;
      form.schema.sections.forEach(sec => {
        (sec.fields || []).forEach(fld => {
          if ((fld.formData || '').toLowerCase() === query || (fld.id || '').toLowerCase() === query) {
            fld.options = [...newOptions];
          }
        });
      });
    });
    this.saveFormToStorage();
  }
});
