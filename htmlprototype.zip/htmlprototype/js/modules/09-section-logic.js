/**
 * Cisco MOPs FORM Studio - Section-Level Display Logic Studio
 * Domain: Show/hide entire form sections dynamically based on field value conditions with AND/OR group logic
 * File: js/modules/09-section-logic.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
secLogicState: {
    sIdx: null,
    draftConditionType: 'AND',
    draftRules: []
  },

  openSectionLogicModal(sIdx) {
    const sec = this.formSchema?.sections?.[sIdx];
    if (!sec) return;
    this.secLogicState.sIdx = sIdx;

    const titleEl = document.getElementById('secLogicTargetTitle');
    if (titleEl) titleEl.textContent = sec.title || `Section ${sIdx + 1}`;
    const idEl = document.getElementById('secLogicTargetId');
    if (idEl) idEl.textContent = sec.id || `Section_${sIdx + 1}`;

    let condList = [];
    if (sec.condition && sec.condition !== true) {
      condList = Array.isArray(sec.condition) ? JSON.parse(JSON.stringify(sec.condition)) : [JSON.parse(JSON.stringify(sec.condition))];
    }
    this.secLogicState.draftRules = condList.map(r => ({
      field: r.field || '',
      comparison: r.comparison || '==',
      value: r.value !== undefined ? r.value : ''
    }));
    this.secLogicState.draftConditionType = (sec.conditionType || 'AND').toUpperCase();

    this.syncSecLogicTypeToggle();
    this.renderSectionLogicModalRules();

    document.getElementById('modalSectionLogic')?.classList.add('open');
  },

  closeSectionLogicModal() {
    document.getElementById('modalSectionLogic')?.classList.remove('open');
    this.secLogicState.sIdx = null;
    this.secLogicState.draftRules = [];
  },

  setSecLogicType(type) {
    this.secLogicState.draftConditionType = type;
    this.syncSecLogicTypeToggle();
    this.renderSectionLogicModalRules();
  },

  syncSecLogicTypeToggle() {
    const isAnd = this.secLogicState.draftConditionType === 'AND';
    const btnAnd = document.getElementById('secLogicBtnAnd');
    const btnOr = document.getElementById('secLogicBtnOr');
    if (btnAnd) btnAnd.classList.toggle('active', isAnd);
    if (btnOr) btnOr.classList.toggle('active', !isAnd);
  },

  getAvailableFieldsForSection(sIdx) {
    const list = [];
    (this.formSchema?.sections || []).forEach((s, idx) => {
      (s.fields || []).forEach(f => {
        const fieldId = f.formData || f.wfFieldName || f.id || '';
        if (fieldId) {
          list.push({
            id: fieldId,
            label: (f.label && f.label.trim()) || (f.wfLabel && f.wfLabel.trim()) || fieldId,
            sectionTitle: s.title || `Section ${idx + 1}`,
            type: f.type || 'text',
            options: f.options || [],
            categories: f.categories || []
          });
        }
      });
    });
    return list;
  },

  renderSectionLogicModalRules() {
    const container = document.getElementById('secLogicRulesContainer');
    if (!container) return;
    container.innerHTML = '';

    const rules = this.secLogicState.draftRules;
    const availableFields = this.getAvailableFieldsForSection(this.secLogicState.sIdx);

    if (rules.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 28px 16px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px;">
          <div style="font-size: 24px; margin-bottom: 6px;"></div>
          <div style="font-size: 13.5px; font-weight: 700; color: #334155;">Section is Always Visible</div>
          <div style="font-size: 12px; color: #64748b; margin-top: 4px;">No conditions have been set. Click below to add your first conditional display rule.</div>
          <button type="button" class="btn btn-primary btn-sm" onclick="App.addSectionLogicRule()" style="margin-top: 12px;">
            + Add First Condition Rule
          </button>
        </div>
      `;
      return;
    }

    rules.forEach((rule, rIdx) => {
      if (rIdx > 0) {
        const conn = document.createElement('div');
        conn.className = 'sec-rule-connector';
        conn.textContent = this.secLogicState.draftConditionType;
        container.appendChild(conn);
      }

      const card = document.createElement('div');
      card.className = 'sec-rule-card';

      const fieldOptionsHtml = availableFields.map(f => {
        const sel = f.id === rule.field ? 'selected' : '';
        return `<option value="${f.id}" ${sel}>${f.label} (${f.sectionTitle})</option>`;
      }).join('');

      const comp = rule.comparison || '==';
      const ops = [
        { val: '==', label: 'Equals (==)' },
        { val: '!=', label: 'Does Not Equal (!=)' },
        { val: 'contains', label: 'Contains' },
        { val: 'not_contains', label: 'Does Not Contain' },
        { val: 'isEmpty', label: 'Is Empty' },
        { val: 'isNotEmpty', label: 'Is Not Empty' },
        { val: 'isSelected', label: 'Is Selected' }
      ];
      const opOptionsHtml = ops.map(o => `<option value="${o.val}" ${o.val === comp ? 'selected' : ''}>${o.label}</option>`).join('');

      const currentTrigger = availableFields.find(f => f.id === rule.field);
      let valueInputHtml = '';
      let choiceList = [];
      if (currentTrigger) {
        if (Array.isArray(currentTrigger.options) && currentTrigger.options.length) {
          choiceList = currentTrigger.options.map(o => typeof o === 'object' && o !== null ? (o.value || o.label) : o);
        } else if (Array.isArray(currentTrigger.categories) && currentTrigger.categories.length) {
          currentTrigger.categories.forEach(c => {
            (c.options || []).forEach(o => {
              choiceList.push(typeof o === 'object' && o !== null ? (o.value || o.label) : o);
            });
          });
        }
      }

      if (comp === 'isEmpty' || comp === 'isNotEmpty') {
        valueInputHtml = `<input type="text" class="sec-rule-input" disabled value="(No value needed)" style="background:#f1f5f9; color:#94a3b8;">`;
      } else if (choiceList.length > 0) {
        const valOpts = choiceList.map(v => `<option value="${v}" ${String(v) === String(rule.value) ? 'selected' : ''}>${v}</option>`).join('');
        valueInputHtml = `
          <select class="sec-rule-select sec-val-sel" data-rule-idx="${rIdx}">
            <option value="">-- Choose Option --</option>
            ${valOpts}
          </select>
        `;
      } else {
        valueInputHtml = `<input type="text" class="sec-rule-input sec-val-inp" data-rule-idx="${rIdx}" placeholder="Target value..." value="${(rule.value !== undefined ? String(rule.value) : '').replace(/"/g, '&quot;')}">`;
      }

      card.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
          <span style="font-size: 11px; font-weight: 700; color: #005fb8; text-transform: uppercase;">Rule #${rIdx + 1}</span>
          <button type="button" class="btn btn-ghost btn-xs" onclick="App.removeSectionLogicRule(${rIdx})" title="Delete this rule" style="color: #ef4444; padding: 2px 6px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
          </button>
        </div>
        <div class="sec-rule-grid">
          <div>
            <label style="display:block; font-size:10px; font-weight:600; color:#64748b; margin-bottom:3px; text-transform:uppercase;">Trigger Field</label>
            <select class="sec-rule-select sec-field-sel" data-rule-idx="${rIdx}">
              <option value="">-- Select Field --</option>
              ${fieldOptionsHtml}
            </select>
          </div>
          <div>
            <label style="display:block; font-size:10px; font-weight:600; color:#64748b; margin-bottom:3px; text-transform:uppercase;">Condition</label>
            <select class="sec-rule-select sec-op-sel" data-rule-idx="${rIdx}">
              ${opOptionsHtml}
            </select>
          </div>
          <div style="grid-column: span 2;">
            <label style="display:block; font-size:10px; font-weight:600; color:#64748b; margin-bottom:3px; text-transform:uppercase;">Expected Value</label>
            ${valueInputHtml}
          </div>
        </div>
      `;

      container.appendChild(card);
    });

    container.querySelectorAll('.sec-field-sel').forEach(sel => {
      sel.addEventListener('change', (e) => {
        const idx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
        this.secLogicState.draftRules[idx].field = e.target.value;
        this.renderSectionLogicModalRules();
      });
    });

    container.querySelectorAll('.sec-op-sel').forEach(sel => {
      sel.addEventListener('change', (e) => {
        const idx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
        this.secLogicState.draftRules[idx].comparison = e.target.value;
        this.renderSectionLogicModalRules();
      });
    });

    container.querySelectorAll('.sec-val-sel, .sec-val-inp').forEach(input => {
      input.addEventListener('change', (e) => {
        const idx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
        this.secLogicState.draftRules[idx].value = e.target.value;
      });
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
        this.secLogicState.draftRules[idx].value = e.target.value;
      });
    });
  },

  addSectionLogicRule() {
    const fields = this.getAvailableFieldsForSection(this.secLogicState.sIdx);
    const defaultField = fields[0]?.id || '';
    this.secLogicState.draftRules.push({
      field: defaultField,
      comparison: '==',
      value: ''
    });
    this.renderSectionLogicModalRules();
  },

  removeSectionLogicRule(rIdx) {
    this.secLogicState.draftRules.splice(rIdx, 1);
    this.renderSectionLogicModalRules();
  },

  clearSectionLogicRules() {
    if (confirm('Reset this section to always visible (remove all conditions)?')) {
      this.secLogicState.draftRules = [];
      this.renderSectionLogicModalRules();
    }
  },

  saveSectionLogic() {
    const sIdx = this.secLogicState.sIdx;
    if (sIdx === null || sIdx === undefined) return;
    const sec = this.formSchema?.sections?.[sIdx];
    if (!sec) return;

    const validRules = (this.secLogicState.draftRules || []).filter(r => r.field && r.field.trim() !== '');

    if (validRules.length === 0) {
      sec.condition = null;
      sec.conditionType = null;
      this._showToast(`"${sec.title || 'Section'}" is now Always Visible`);
    } else {
      sec.condition = validRules;
      sec.conditionType = this.secLogicState.draftConditionType || 'AND';
      this._showToast(`Saved display logic for "${sec.title || 'Section'}" (${validRules.length} rule${validRules.length > 1 ? 's' : ''})`);
    }

    this.saveFormToStorage();
    this.closeSectionLogicModal();
    this.render();
  }
});
