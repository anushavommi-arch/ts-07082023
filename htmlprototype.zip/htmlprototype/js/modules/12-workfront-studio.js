/**
 * Cisco MOPs FORM Studio - Workfront Routing Rules & Dynamic Field Mapping Hub
 * Domain: Rule-based template and custom form routing, bidirectional field parameter mapping, and live API JSON payload generator
 * File: js/modules/12-workfront-studio.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
openWorkfrontRoutingModal() {
    const modal = document.getElementById('modalWorkfrontRouting');
    if (!modal) return;

    if (!this.formSchema.workfrontRouting) {
      this.formSchema.workfrontRouting = {
        defaultTemplateId: 'TEMPLATE_DART_WEB_PAGE',
        defaultTemplateLabel: 'Standard Web Page Template',
        customFormId: 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS',
        customFormLabel: 'Global Project Details Form',
        defaultCategoryIds: ['CATEGORY_DART_GLOBAL_PROJECT_DETAILS'],
        templateRules: [],
        categoryRules: []
      };
    }

    this._modalRoutingCopy = JSON.parse(JSON.stringify(this.formSchema.workfrontRouting));
    this._modalRoutingTargetVersion = null;
    this._modalRoutingTargetFormId = null;

    // Normalize static Custom Form fields (1 custom form per form, static attachment)
    const cfId = this._modalRoutingCopy.customFormId || (Array.isArray(this._modalRoutingCopy.defaultCategoryIds) && this._modalRoutingCopy.defaultCategoryIds[0]) || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const cfLabel = this._modalRoutingCopy.customFormLabel || 'Global Project Details Form';
    this._modalRoutingCopy.customFormId = cfId;
    this._modalRoutingCopy.customFormLabel = cfLabel;
    this._modalRoutingCopy.defaultCategoryIds = [cfId];
    this._modalRoutingCopy.categoryRules = [];

    const badge = document.getElementById('routingModalFormBadge');
    if (badge) {
      const activeSprint = this.getSprintForVersion ? this.getSprintForVersion(this.getActiveForm(), this.getActiveForm()?.activeVersionId) : null;
      const verText = this.getActiveForm()?.activeVersionId || 'v1.0';
      badge.textContent = `${this.formSchema.title || 'Form'} (${activeSprint ? activeSprint + '  ' : ''}${verText})`;
    }

    // Populate Part 1: Attach Custom Form (Category)
    const cfIdInput = document.getElementById('inputRoutingCustomFormId');
    if (cfIdInput) {
      cfIdInput.value = cfId;
      cfIdInput.oninput = () => {
        const val = cfIdInput.value.trim();
        this._modalRoutingCopy.customFormId = val;
        this._modalRoutingCopy.defaultCategoryIds = val ? [val] : [];
        this._refreshRoutingModalPreview();
      };
    }

    const cfLabelInput = document.getElementById('inputRoutingCustomFormLabel');
    if (cfLabelInput) {
      cfLabelInput.value = cfLabel;
      cfLabelInput.oninput = () => {
        this._modalRoutingCopy.customFormLabel = cfLabelInput.value.trim();
        this._refreshRoutingModalPreview();
      };
    }

    // Populate Part 2: Default Template Fallback
    const defTpl = document.getElementById('inputRoutingDefaultTemplateId');
    if (defTpl) {
      defTpl.value = this._modalRoutingCopy.defaultTemplateId || 'TEMPLATE_DART_WEB_PAGE';
      defTpl.oninput = () => {
        this._modalRoutingCopy.defaultTemplateId = defTpl.value.trim();
        this._refreshRoutingModalPreview();
      };
    }

    const defTplLabel = document.getElementById('inputRoutingDefaultTemplateLabel');
    if (defTplLabel) {
      defTplLabel.value = this._modalRoutingCopy.defaultTemplateLabel || 'Standard Web Page Template';
      defTplLabel.oninput = () => {
        this._modalRoutingCopy.defaultTemplateLabel = defTplLabel.value.trim();
        this._refreshRoutingModalPreview();
      };
    }

    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();

    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  },

  closeWorkfrontRoutingModal() {
    const modal = document.getElementById('modalWorkfrontRouting');
    if (modal) modal.classList.remove('open');
    document.body.style.overflow = '';
  },

  /**
   * Helper: Gather all fields across all sections of active form schema
   */
  getAllAvailableFormFields() {
    const list = [];
    (this.formSchema?.sections || []).forEach((s, idx) => {
      (s.fields || []).forEach(f => {
        const fieldId = f.formData || f.wfFieldName || f.id || '';
        if (fieldId) {
          list.push({
            id: fieldId,
            label: (f.label && f.label.trim()) || (f.wfLabel && f.wfLabel.trim()) || fieldId,
            sectionTitle: s.title || `Section ${idx + 1}`,
            type: f.type || 'text',
            options: f.options || [],
            categories: f.categories || []
          });
        }
      });
    });
    return list;
  },

  /**
   * Render dynamic interactive cards for Workfront Routing Rules (NO prompt() dialogs)
   */
  renderRoutingModalRules() {
    const tplList = document.getElementById('routingTemplateRulesList');
    if (!tplList || !this._modalRoutingCopy) return;

    const availableFields = this.getAllAvailableFormFields();
    const ops = [
      { val: '==', label: 'Equals (==)' },
      { val: '!=', label: 'Does Not Equal (!=)' },
      { val: 'contains', label: 'Contains' },
      { val: 'not_contains', label: 'Does Not Contain' },
      { val: 'isNotEmpty', label: 'Is Not Empty' },
      { val: 'isEmpty', label: 'Is Empty' }
    ];

    // Helper: Build HTML for a single condition row
    const renderConditionRow = (cond, cIdx, rIdx, totalConds) => {
      const comp = cond.comparison || '==';
      const currentField = availableFields.find(f => f.id === cond.field);

      const fieldOpts = availableFields.map(f => {
        const sel = f.id === cond.field ? 'selected' : '';
        return `<option value="${f.id}" ${sel}>${f.label} (${f.id})</option>`;
      }).join('');

      let choiceList = [];
      if (currentField) {
        if (Array.isArray(currentField.options) && currentField.options.length) {
          choiceList = currentField.options.map(o => typeof o === 'object' && o !== null ? (o.value || o.label) : o);
        } else if (Array.isArray(currentField.categories) && currentField.categories.length) {
          currentField.categories.forEach(c => {
            (c.options || []).forEach(o => {
              choiceList.push(typeof o === 'object' && o !== null ? (o.value || o.label) : o);
            });
          });
        }
      }

      let valControlHtml = '';
      if (comp === 'isEmpty' || comp === 'isNotEmpty') {
        valControlHtml = `<input type="text" class="sec-rule-input" disabled value="(Not applicable)" style="background:#f1f5f9; color:#94a3b8; font-size:12px;">`;
      } else if (choiceList.length > 0) {
        const valOpts = choiceList.map(v => `<option value="${v}" ${String(v) === String(cond.value) ? 'selected' : ''}>${v}</option>`).join('');
        valControlHtml = `
          <select class="sec-rule-select wf-cond-val-sel" data-rule-idx="${rIdx}" data-cond-idx="${cIdx}">
            <option value="">-- Choose Option --</option>
            ${valOpts}
          </select>
        `;
      } else {
        valControlHtml = `
          <input type="text" class="sec-rule-input wf-cond-val-inp" data-rule-idx="${rIdx}" data-cond-idx="${cIdx}" placeholder="Value to match" value="${(cond.value !== undefined ? String(cond.value) : '').replace(/"/g, '&quot;')}">
        `;
      }

      return `
        <div style="display:grid; grid-template-columns: 2fr 1.3fr 2fr ${totalConds > 1 ? '30px' : '0px'}; gap:8px; align-items:center; margin-bottom:6px;">
          <div>
            <select class="sec-rule-select wf-cond-field-sel" data-rule-idx="${rIdx}" data-cond-idx="${cIdx}">
              <option value="">-- Select Field --</option>
              ${fieldOpts}
            </select>
          </div>
          <div>
            <select class="sec-rule-select wf-cond-comp-sel" data-rule-idx="${rIdx}" data-cond-idx="${cIdx}">
              ${ops.map(o => `<option value="${o.val}" ${o.val === comp ? 'selected' : ''}>${o.label}</option>`).join('')}
            </select>
          </div>
          <div>
            ${valControlHtml}
          </div>
          ${totalConds > 1 ? `
            <button type="button" class="btn btn-ghost btn-xs wf-btn-del-cond" data-rule-idx="${rIdx}" data-cond-idx="${cIdx}" title="Remove this condition" style="color:#ef4444; padding:2px; font-weight:700;"></button>
          ` : ''}
        </div>
      `;
    };

    // Render Template Rules
    const tplRules = this._modalRoutingCopy.templateRules || [];
    if (tplRules.length === 0) {
      tplList.innerHTML = `
        <div style="font-size:12px; color:#94a3b8; font-style:italic; padding:16px 20px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:6px; text-align:center;">
          No conditional template rules configured. Submissions will always route to the default Template ID above.
          <div style="margin-top:8px;">
            <button type="button" class="btn btn-outline btn-xs" onclick="App.addRoutingTemplateRule()" style="border-color:#005fb8; color:#005fb8; font-weight:600;">+ Add First Template Rule</button>
          </div>
        </div>
      `;
    } else {
      tplList.innerHTML = tplRules.map((rule, rIdx) => {
        const conds = rule.conditions || [];
        const conditionsHtml = conds.map((c, cIdx) => renderConditionRow(c, cIdx, rIdx, conds.length)).join('');
        return `
          <div class="wf-routing-rule-card" style="background:#ffffff; border:1px solid #cbd5e1; border-left:4px solid #005fb8; border-radius:8px; padding:12px 14px; margin-bottom:12px; box-shadow:0 1px 3px rgba(0,0,0,0.04);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; gap:10px; flex-wrap:wrap;">
              <div style="display:flex; align-items:center; gap:8px; flex:1; min-width:240px;">
                <span style="background:#005fb8; color:#fff; font-size:11px; font-weight:700; width:22px; height:22px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0;">${rIdx + 1}</span>
                <input type="text" class="sec-rule-input wf-rule-label-inp" data-rule-idx="${rIdx}" value="${this._escHtml(rule.label || `Template Rule ${rIdx + 1}`)}" placeholder="Rule Label" style="font-weight:700; max-width:320px;" title="Rule Label">
                <span style="font-size:11px; color:#64748b; font-weight:600;">(First Match Wins)</span>
              </div>
              <div style="display:flex; align-items:center; gap:4px;">
                ${rIdx > 0 ? `<button type="button" class="btn btn-outline btn-xs" onclick="App.moveRoutingTemplateRule(${rIdx}, -1)" title="Move up (Higher priority)" style="padding:2px 7px;"></button>` : ''}
                ${rIdx < tplRules.length - 1 ? `<button type="button" class="btn btn-outline btn-xs" onclick="App.moveRoutingTemplateRule(${rIdx}, 1)" title="Move down (Lower priority)" style="padding:2px 7px;"></button>` : ''}
                <button type="button" class="btn btn-outline btn-xs" onclick="App.deleteRoutingTemplateRule(${rIdx})" title="Delete rule" style="color:#ef4444; border-color:#fca5a5; padding:2px 8px;"> Delete</button>
              </div>
            </div>

            <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:6px; padding:8px 12px; margin-bottom:10px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
              <span style="font-size:11.5px; font-weight:700; color:#1e40af;"> Target Workfront Template ID:</span>
              <input type="text" class="sec-rule-input wf-rule-target-inp" data-rule-idx="${rIdx}" value="${this._escHtml(rule.templateId || '')}" placeholder="e.g. TEMPLATE_DART_EXPEDITED" style="font-family:monospace; font-weight:700; color:#1e40af; background:#fff; flex:1; min-width:240px; max-width:380px;">
              <span style="font-size:11px; color:#64748b;">(Assigned if condition matches)</span>
            </div>

            <div style="border-top:1px dashed #e2e8f0; padding-top:8px;">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                <span style="font-size:11px; font-weight:700; color:#475569; text-transform:uppercase;">Condition:</span>
                ${conds.length > 1 ? `
                  <div style="display:flex; align-items:center; gap:4px; font-size:11px;">
                    <span style="color:#64748b;">Match:</span>
                    <select class="sec-rule-select wf-rule-andor-sel" data-rule-idx="${rIdx}" style="width:auto; padding:2px 6px; font-size:11px; font-weight:600;">
                      <option value="AND" ${rule.conditionOperator === 'AND' ? 'selected' : ''}>ALL Conditions (AND)</option>
                      <option value="OR" ${rule.conditionOperator === 'OR' ? 'selected' : ''}>ANY Condition (OR)</option>
                    </select>
                  </div>
                ` : ''}
              </div>

              <div style="display:grid; grid-template-columns: 2fr 1.3fr 2fr ${conds.length > 1 ? '30px' : '0px'}; gap:8px; margin-bottom:4px; font-size:10px; font-weight:700; color:#64748b; text-transform:uppercase;">
                <span>Field</span>
                <span>Operator</span>
                <span>Expected Value</span>
                <span></span>
              </div>

              ${conditionsHtml}

              <div style="margin-top:6px;">
                <button type="button" class="btn btn-ghost btn-xs" onclick="App.addRoutingRuleCondition('template', ${rIdx})" style="color:#005fb8; padding:2px 6px; font-size:11px; font-weight:600;">
                  + Add Condition
                </button>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }

    // Attach Live Event Listeners to Inputs
    const bindRuleInput = (selector, handler) => {
      document.querySelectorAll(selector).forEach(el => {
        el.addEventListener('input', handler);
        el.addEventListener('change', handler);
      });
    };

    // Label input change
    bindRuleInput('.wf-rule-label-inp', (e) => {
      const rIdx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
      const list = this._modalRoutingCopy.templateRules;
      if (list && list[rIdx]) {
        list[rIdx].label = e.target.value;
        this._refreshRoutingModalPreview();
      }
    });

    // Target Template ID change
    bindRuleInput('.wf-rule-target-inp', (e) => {
      const rIdx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
      const list = this._modalRoutingCopy.templateRules;
      if (list && list[rIdx]) {
        list[rIdx].templateId = e.target.value.trim();
        this._refreshRoutingModalPreview();
      }
    });

    // AND/OR operator change
    bindRuleInput('.wf-rule-andor-sel', (e) => {
      const rIdx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
      const list = this._modalRoutingCopy.templateRules;
      if (list && list[rIdx]) {
        list[rIdx].conditionOperator = e.target.value;
        this._refreshRoutingModalPreview();
      }
    });

    // Condition Field change -> resets value and re-renders
    bindRuleInput('.wf-cond-field-sel', (e) => {
      const rIdx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
      const cIdx = parseInt(e.target.getAttribute('data-cond-idx'), 10);
      const list = this._modalRoutingCopy.templateRules;
      if (list && list[rIdx] && list[rIdx].conditions && list[rIdx].conditions[cIdx]) {
        list[rIdx].conditions[cIdx].field = e.target.value;
        const fObj = availableFields.find(f => f.id === e.target.value);
        if (fObj && fObj.options && fObj.options.length) {
          list[rIdx].conditions[cIdx].value = typeof fObj.options[0] === 'object' ? (fObj.options[0].value || fObj.options[0].label) : fObj.options[0];
        } else {
          list[rIdx].conditions[cIdx].value = '';
        }
        this.renderRoutingModalRules();
        this._refreshRoutingModalPreview();
      }
    });

    // Condition Comparison operator change
    bindRuleInput('.wf-cond-comp-sel', (e) => {
      const rIdx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
      const cIdx = parseInt(e.target.getAttribute('data-cond-idx'), 10);
      const list = this._modalRoutingCopy.templateRules;
      if (list && list[rIdx] && list[rIdx].conditions && list[rIdx].conditions[cIdx]) {
        list[rIdx].conditions[cIdx].comparison = e.target.value;
        this.renderRoutingModalRules();
        this._refreshRoutingModalPreview();
      }
    });

    // Condition Value change
    bindRuleInput('.wf-cond-val-sel, .wf-cond-val-inp', (e) => {
      const rIdx = parseInt(e.target.getAttribute('data-rule-idx'), 10);
      const cIdx = parseInt(e.target.getAttribute('data-cond-idx'), 10);
      const list = this._modalRoutingCopy.templateRules;
      if (list && list[rIdx] && list[rIdx].conditions && list[rIdx].conditions[cIdx]) {
        list[rIdx].conditions[cIdx].value = e.target.value;
        this._refreshRoutingModalPreview();
      }
    });

    // Condition Remove button
    document.querySelectorAll('.wf-btn-del-cond').forEach(btn => {
      btn.addEventListener('click', () => {
        const rIdx = parseInt(btn.getAttribute('data-rule-idx'), 10);
        const cIdx = parseInt(btn.getAttribute('data-cond-idx'), 10);
        this.removeRoutingRuleCondition('template', rIdx, cIdx);
      });
    });
  },

  _refreshRoutingModalPreview() {
    if (!this._modalRoutingCopy || !window.WorkfrontRoutingEngine) return;

    const vals = Object.assign({}, this.formValues || {});
    const result = window.WorkfrontRoutingEngine.resolveAll({ workfrontRouting: this._modalRoutingCopy }, vals);

    const tplEl = document.getElementById('routingModalPreviewTemplate');
    const catEl = document.getElementById('routingModalPreviewCategories');
    const countEl = document.getElementById('routingModalRuleMatchCount');

    if (tplEl) {
      tplEl.textContent = result.templateId + (result.matchedRule ? ` (Rule ${result.matchedRule.priority}: ${result.templateLabel})` : ' (Default Fallback)');
    }
    if (catEl) {
      const cfId = this._modalRoutingCopy.customFormId || result.customFormId || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
      const cfLabel = this._modalRoutingCopy.customFormLabel ? `  ${this._modalRoutingCopy.customFormLabel}` : '';
      catEl.textContent = `${cfId}${cfLabel} (Fixed  100% of Submissions)`;
    }
    if (countEl) {
      countEl.textContent = result.matchedRule
        ? `Rule ${result.matchedRule.priority} Matched ("${result.templateLabel}")`
        : `0 Rules Matched (Using Default Template)`;
    }
  },

  /**
   * Add a Template Rule inline (NO browser prompt() popups)
   */
  addRoutingTemplateRule() {
    if (!this._modalRoutingCopy) return;
    this._modalRoutingCopy.templateRules = this._modalRoutingCopy.templateRules || [];

    const fields = this.getAllAvailableFormFields();
    const defaultField = fields[0]?.id || 'submitterType';
    const fieldObj = fields.find(f => f.id === defaultField);
    let defaultVal = 'Agency';
    if (fieldObj && fieldObj.options && fieldObj.options.length) {
      defaultVal = typeof fieldObj.options[0] === 'object' ? (fieldObj.options[0].value || fieldObj.options[0].label) : fieldObj.options[0];
    }

    const newIdx = this._modalRoutingCopy.templateRules.length + 1;
    this._modalRoutingCopy.templateRules.push({
      priority: newIdx,
      label: `Template Rule ${newIdx}`,
      conditions: [{ field: defaultField, comparison: '==', value: defaultVal }],
      conditionOperator: 'AND',
      templateId: 'TEMPLATE_DART_CUSTOM'
    });

    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();
  },

  deleteRoutingTemplateRule(idx) {
    if (!this._modalRoutingCopy?.templateRules) return;
    this._modalRoutingCopy.templateRules.splice(idx, 1);
    this._modalRoutingCopy.templateRules.forEach((r, i) => r.priority = i + 1);
    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();
  },

  moveRoutingTemplateRule(idx, dir) {
    if (!this._modalRoutingCopy?.templateRules) return;
    const rules = this._modalRoutingCopy.templateRules;
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= rules.length) return;
    const temp = rules[idx];
    rules[idx] = rules[targetIdx];
    rules[targetIdx] = temp;
    rules.forEach((r, i) => r.priority = i + 1);
    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();
  },

  addRoutingRuleCondition(ruleType, rIdx) {
    const list = this._modalRoutingCopy?.templateRules;
    if (!list || !list[rIdx]) return;
    list[rIdx].conditions = list[rIdx].conditions || [];
    const fields = this.getAllAvailableFormFields();
    const defaultField = fields[0]?.id || 'submitterType';
    const fieldObj = fields.find(f => f.id === defaultField);
    let defaultVal = 'Agency';
    if (fieldObj && fieldObj.options && fieldObj.options.length) {
      defaultVal = typeof fieldObj.options[0] === 'object' ? (fieldObj.options[0].value || fieldObj.options[0].label) : fieldObj.options[0];
    }
    list[rIdx].conditions.push({ field: defaultField, comparison: '==', value: defaultVal });
    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();
  },

  removeRoutingRuleCondition(ruleType, rIdx, cIdx) {
    const list = this._modalRoutingCopy?.templateRules;
    if (!list || !list[rIdx] || !list[rIdx].conditions) return;
    list[rIdx].conditions.splice(cIdx, 1);
    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();
  },

  openRoutingForVersion(formId, versionId) {
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) return;

    let targetVer = (form.versions || []).find(v => v.versionId === versionId);
    if (!targetVer && form.sprints) {
      for (const sp of form.sprints) {
        targetVer = (sp.versions || []).find(v => v.versionId === versionId);
        if (targetVer) break;
      }
    }

    const schema = targetVer?.schema || (form.id === this.activeFormId ? this.formSchema : null);
    if (!schema) return;

    if (!schema.workfrontRouting) {
      schema.workfrontRouting = {
        defaultTemplateId: 'TEMPLATE_DART_WEB_PAGE',
        defaultTemplateLabel: 'Standard Web Page Template',
        customFormId: 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS',
        customFormLabel: 'Global Project Details Form',
        defaultCategoryIds: ['CATEGORY_DART_GLOBAL_PROJECT_DETAILS'],
        templateRules: [],
        categoryRules: []
      };
    }

    this._modalRoutingCopy = JSON.parse(JSON.stringify(schema.workfrontRouting));
    this._modalRoutingTargetVersion = versionId;
    this._modalRoutingTargetFormId = formId;

    const cfId = this._modalRoutingCopy.customFormId || (Array.isArray(this._modalRoutingCopy.defaultCategoryIds) && this._modalRoutingCopy.defaultCategoryIds[0]) || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const cfLabel = this._modalRoutingCopy.customFormLabel || 'Global Project Details Form';
    this._modalRoutingCopy.customFormId = cfId;
    this._modalRoutingCopy.customFormLabel = cfLabel;
    this._modalRoutingCopy.defaultCategoryIds = [cfId];
    this._modalRoutingCopy.categoryRules = [];

    const modal = document.getElementById('modalWorkfrontRouting');
    if (!modal) return;

    const badge = document.getElementById('routingModalFormBadge');
    if (badge) {
      const spId = this.getSprintForVersion ? this.getSprintForVersion(form, versionId) : null;
      badge.textContent = `${form.label || form.id} (${spId ? spId + '  ' : ''}${versionId})`;
    }

    const cfIdInput = document.getElementById('inputRoutingCustomFormId');
    if (cfIdInput) {
      cfIdInput.value = cfId;
      cfIdInput.oninput = () => {
        const val = cfIdInput.value.trim();
        this._modalRoutingCopy.customFormId = val;
        this._modalRoutingCopy.defaultCategoryIds = val ? [val] : [];
        this._refreshRoutingModalPreview();
      };
    }

    const cfLabelInput = document.getElementById('inputRoutingCustomFormLabel');
    if (cfLabelInput) {
      cfLabelInput.value = cfLabel;
      cfLabelInput.oninput = () => {
        this._modalRoutingCopy.customFormLabel = cfLabelInput.value.trim();
        this._refreshRoutingModalPreview();
      };
    }

    const defTpl = document.getElementById('inputRoutingDefaultTemplateId');
    if (defTpl) {
      defTpl.value = this._modalRoutingCopy.defaultTemplateId || 'TEMPLATE_DART_WEB_PAGE';
      defTpl.oninput = () => {
        this._modalRoutingCopy.defaultTemplateId = defTpl.value.trim();
        this._refreshRoutingModalPreview();
      };
    }

    const defTplLabel = document.getElementById('inputRoutingDefaultTemplateLabel');
    if (defTplLabel) {
      defTplLabel.value = this._modalRoutingCopy.defaultTemplateLabel || 'Standard Web Page Template';
      defTplLabel.oninput = () => {
        this._modalRoutingCopy.defaultTemplateLabel = defTplLabel.value.trim();
        this._refreshRoutingModalPreview();
      };
    }

    this.renderRoutingModalRules();
    this._refreshRoutingModalPreview();

    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  },

  saveWorkfrontRoutingFromModal() {
    if (!this._modalRoutingCopy) return;

    const cfId = document.getElementById('inputRoutingCustomFormId')?.value.trim() || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const cfLabel = document.getElementById('inputRoutingCustomFormLabel')?.value.trim() || 'Global Project Details Form';
    const defTpl = document.getElementById('inputRoutingDefaultTemplateId')?.value.trim() || 'TEMPLATE_DART_WEB_PAGE';
    const defTplLabel = document.getElementById('inputRoutingDefaultTemplateLabel')?.value.trim() || 'Standard Web Page Template';

    this._modalRoutingCopy.customFormId = cfId;
    this._modalRoutingCopy.customFormLabel = cfLabel;
    this._modalRoutingCopy.defaultCategoryIds = [cfId];
    this._modalRoutingCopy.defaultTemplateId = defTpl;
    this._modalRoutingCopy.defaultTemplateLabel = defTplLabel;
    this._modalRoutingCopy.categoryRules = [];

    // If targeted at a specific version in tree, update that version's schema
    if (this._modalRoutingTargetFormId && this._modalRoutingTargetVersion) {
      const form = (this.allForms || []).find(f => f.id === this._modalRoutingTargetFormId);
      if (form) {
        let targetVer = (form.versions || []).find(v => v.versionId === this._modalRoutingTargetVersion);
        if (!targetVer && form.sprints) {
          for (const sp of form.sprints) {
            targetVer = (sp.versions || []).find(v => v.versionId === this._modalRoutingTargetVersion);
            if (targetVer) break;
          }
        }
        if (targetVer && targetVer.schema) {
          targetVer.schema.workfrontRouting = JSON.parse(JSON.stringify(this._modalRoutingCopy));
        }
      }
    }

    // Always update current working formSchema if it's the active form
    if (!this._modalRoutingTargetFormId || this._modalRoutingTargetFormId === this.activeFormId) {
      this.formSchema.workfrontRouting = JSON.parse(JSON.stringify(this._modalRoutingCopy));
      this.saveFormToStorage();
      this.renderCiscoBuilderMode();
    }

    this.closeWorkfrontRoutingModal();
    this.syncTopNavFormHeader();
    this._showToast('Workfront Routing configuration saved successfully!');
  },

  // 
  // Workfront API Custom Field Mapping Studio
  // 

  getAvailableIntakeFormFields() {
    const list = [];
    (this.formSchema?.sections || []).forEach((s, sIdx) => {
      (s.fields || []).forEach((f, fIdx) => {
        const id = f.formData || f.id || `field_${sIdx}_${fIdx}`;
        const label = (f.label && f.label.trim()) || (f.wfLabel && f.wfLabel.trim()) || id;
        list.push({
          id,
          label,
          type: f.type || 'text',
          sectionTitle: s.title || `Section ${sIdx + 1}`,
          fieldRef: f
        });
      });
    });
    return list;
  },

  getAvailableWorkfrontParameters() {
    const standard = [
      'DE:Project Name',
      'DE:Campaign Alignment',
      'DE:Submitter Type',
      'DE:Stakeholder Cisco Email',
      'DE:Agency Partner Name',
      'DE:Deliverable Format',
      'DE:Target Launch Date',
      'DE:Estimated Budget',
      'DE:Cost Center',
      'DE:Target Audience Region',
      'DE:Executive Sponsor',
      'DE:uap Budget Approval',
      'DE:Legal / Compliance Review Status',
      'DE:Digital Asset Management ID',
      'DE:Localization Required',
      'DE:Project Priority Tier',
      'DE:Business Unit',
      'DE:Business Justification',
      'DE:Asset Distribution Channel',
      'DE:Security Review Complete'
    ];
    const set = new Set(standard);
    (this.formSchema?.sections || []).forEach(s => {
      (s.fields || []).forEach(f => {
        if (f.wfApiParameter) {
          set.add(f.wfApiParameter.startsWith('DE:') ? f.wfApiParameter : `DE:${f.wfApiParameter}`);
        }
        if (f.wfFieldName) {
          set.add(f.wfFieldName.startsWith('DE:') ? f.wfFieldName : `DE:${f.wfFieldName}`);
        }
      });
    });
    return Array.from(set).sort();
  },

  openWorkfrontFieldMappingModal() {
    const modal = document.getElementById('modalWorkfrontFieldMapping');
    if (!modal) return;

    const active = this.getActiveForm();
    const ver = active?.activeVersionId || this.formSchema?.version || 'v1.0';
    const sprint = (this.getSprintForVersion && this.getSprintForVersion(active, ver)) || active?.activeSprint;
    const badge = document.getElementById('wfMappingFormBadge');
    if (badge) {
      badge.textContent = `${this.formSchema?.title || active?.label || 'Form'}  ${sprint ? sprint + '  ' : ''}${ver}`;
    }

    // Category / Custom Form info
    const routing = this.formSchema?.workfrontRouting || {};
    const catId = routing.customFormId || routing.defaultCategoryIds?.[0] || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const catLabel = routing.customFormLabel || 'Global Project Details Form';
    const catEl = document.getElementById('wfMappingAttachedCategory');
    const catLabelEl = document.getElementById('wfMappingCategoryLabel');
    if (catEl) catEl.textContent = catId;
    if (catLabelEl) catLabelEl.textContent = catLabel;

    const searchInput = document.getElementById('wfMappingSearchInput');
    if (searchInput) {
      searchInput.value = '';
      searchInput.oninput = () => this.renderWorkfrontFieldMappingTable();
    }

    // Close slide-over drawer initially
    this.toggleWfPayloadPreviewDrawer(false);

    // Initialize mapping rows
    const intakeFields = this.getAvailableIntakeFormFields();
    const wfParams = this.getAvailableWorkfrontParameters();

    if (this.formSchema?.workfrontMappings && Array.isArray(this.formSchema.workfrontMappings) && this.formSchema.workfrontMappings.length > 0) {
      this._modalMappingRows = JSON.parse(JSON.stringify(this.formSchema.workfrontMappings));
    } else {
      // Auto-seed from intake fields
      this._modalMappingRows = intakeFields.map(f => {
        let targetParam = f.fieldRef?.wfApiParameter;
        if (!targetParam && f.fieldRef?.wfFieldName) {
          targetParam = f.fieldRef.wfFieldName.startsWith('DE:') ? f.fieldRef.wfFieldName : `DE:${f.fieldRef.wfFieldName}`;
        }
        if (!targetParam) {
          const cleanLabel = f.label.replace(/^DE:/i, '').trim().toLowerCase();
          const match = wfParams.find(p => p.replace(/^DE:/i, '').trim().toLowerCase() === cleanLabel);
          targetParam = match || `DE:${f.label.replace(/^DE:/i, '').trim()}`;
        }
        const isCustom = !wfParams.includes(targetParam);
        return {
          intakeFieldId: f.id,
          wfParameter: targetParam,
          isCustom: isCustom
        };
      });
    }

    this.renderWorkfrontFieldMappingTable();
    this._refreshWfPayloadPreview();

    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  },

  closeWorkfrontFieldMappingModal() {
    const modal = document.getElementById('modalWorkfrontFieldMapping');
    if (modal) modal.classList.remove('open');
    this.toggleWfPayloadPreviewDrawer(false);
    document.body.style.overflow = '';
  },

  renderWorkfrontFieldMappingTable() {
    const tbody = document.getElementById('wfMappingTableBody');
    if (!tbody) return;

    const searchTerm = (document.getElementById('wfMappingSearchInput')?.value || '').trim().toLowerCase();
    const intakeFields = this.getAvailableIntakeFormFields();
    const wfParams = this.getAvailableWorkfrontParameters();

    if (!this._modalMappingRows) {
      this._modalMappingRows = [];
    }

    // Filter rows based on search
    const filteredRows = [];
    this._modalMappingRows.forEach((row, originalIdx) => {
      const intakeField = intakeFields.find(f => f.id === row.intakeFieldId);
      const intakeLabel = intakeField ? intakeField.label : row.intakeFieldId;
      const paramName = row.wfParameter || '';

      if (searchTerm) {
        const match = intakeLabel.toLowerCase().includes(searchTerm) ||
          (row.intakeFieldId || '').toLowerCase().includes(searchTerm) ||
          paramName.toLowerCase().includes(searchTerm) ||
          (intakeField?.sectionTitle || '').toLowerCase().includes(searchTerm);
        if (!match) return;
      }
      filteredRows.push({ row, originalIdx, intakeField });
    });

    let rowsHtml = '';
    filteredRows.forEach((item, displayIdx) => {
      const { row, originalIdx, intakeField } = item;
      const rowNum = displayIdx + 1;

      // Intake Form Field Select Dropdown
      const intakeOptionsHtml = intakeFields.map(inf => {
        const isSel = row.intakeFieldId === inf.id ? 'selected' : '';
        return `<option value="${this._escHtml(inf.id)}" ${isSel}>${this._escHtml(inf.label)} (${this._escHtml(inf.id)})</option>`;
      }).join('');

      const intakeFieldDetail = intakeField ? `
        <div style="display:flex; align-items:center; gap:6px; margin-top:4px; font-size:11px; color:#64748b;">
          <code style="background:#f1f5f9; padding:1px 5px; border-radius:3px; color:#334155; font-weight:600;">${this._escHtml(intakeField.id)}</code>
          <span>&bull;</span>
          <span style="background:#e0f2fe; color:#0369a1; padding:1px 6px; border-radius:4px; font-weight:600;">${this._escHtml(intakeField.type)}</span>
          <span>&bull;</span>
          <span style="color:#64748b;">${this._escHtml(intakeField.sectionTitle)}</span>
        </div>
      ` : `
        <div style="font-size:11px; color:#94a3b8; margin-top:4px; font-style:italic;">Select an intake form field to map</div>
      `;

      // Workfront API Parameter Select Dropdown or Custom Input
      let wfParamHtml = '';
      if (row.isCustom) {
        wfParamHtml = `
          <div style="display:flex; align-items:center; gap:6px;">
            <input type="text" class="wf-map-custom-inp mops-input" data-row-idx="${originalIdx}"
              value="${this._escHtml(row.wfParameter || 'DE:')}"
              placeholder="e.g. DE:Custom Field Name"
              style="font-family:monospace; font-size:12px; font-weight:700; color:#0369a1; background:#fff; border:1px solid #bae6fd; flex:1;">
            <button type="button" class="btn btn-outline btn-xs" onclick="App.revertWorkfrontCustomRow(${originalIdx})"
              style="border-color:#cbd5e1; color:#475569; font-size:10.5px; padding:3px 8px;" title="Switch back to standard dropdown list">
               List
            </button>
          </div>
          <div style="font-size:10px; color:#94a3b8; margin-top:2px;">Format: <code>DE:&lt;Workfront Parameter&gt;</code></div>
        `;
      } else {
        const wfOptionsHtml = wfParams.map(p => {
          const isSel = row.wfParameter === p ? 'selected' : '';
          return `<option value="${this._escHtml(p)}" ${isSel}>${this._escHtml(p)}</option>`;
        }).join('');

        wfParamHtml = `
          <select class="mops-select wf-map-param-select" data-row-idx="${originalIdx}"
            style="font-family:monospace; font-size:12px; font-weight:700; color:#0369a1; padding:6px 10px; width:100%; border:1px solid #bae6fd; border-radius:4px; background:#f0f9ff;">
            <option value="">-- Select Workfront API Parameter --</option>
            <optgroup label="Workfront Custom Field Parameters (POST /attask/v14.0/PROJ)">
              ${wfOptionsHtml}
            </optgroup>
            <option value="__CUSTOM__">+ Enter Custom Parameter Name</option>
          </select>
          <div style="font-size:10px; color:#94a3b8; margin-top:2px;">Workfront API Custom Field parameter (POST /attask/v14.0/PROJ)</div>
        `;
      }


      rowsHtml += `
        <tr style="border-bottom: 1px solid #e2e8f0; background: ${rowNum % 2 === 0 ? '#fafafa' : '#ffffff'};">
          <td style="padding: 10px 12px; text-align: center; color: #64748b; font-weight: 700; border-right: 1px solid #e2e8f0;">${rowNum}</td>
          <td style="padding: 10px 14px; border-right: 1px solid #e2e8f0;">
            <select class="mops-select wf-map-intake-select" data-row-idx="${originalIdx}"
              style="font-size:12px; font-weight:600; color:#0f172a; padding:6px 10px; width:100%; border:1px solid #cbd5e1; border-radius:4px; background:#fff;">
              <option value="">-- Select Intake Form Field --</option>
              ${intakeOptionsHtml}
            </select>
            ${intakeFieldDetail}
          </td>
          <td style="padding: 10px 8px; text-align: center; color: #0284c7; font-weight: 800; font-size: 14px; border-right: 1px solid #e2e8f0;"></td>
          <td style="padding: 8px 14px; border-right: 1px solid #e2e8f0;">
            ${wfParamHtml}
          </td>
          <td style="padding: 10px 10px; text-align: center;">
            <button type="button" class="btn btn-ghost btn-xs" onclick="App.removeWorkfrontMappingRow(${originalIdx})"
              style="color:#ef4444; font-size:14px; font-weight:bold; padding:3px 7px; border-radius:4px;" title="Remove this mapping row"></button>
          </td>
        </tr>
      `;
    });

    if (this._modalMappingRows.length === 0 || filteredRows.length === 0) {
      rowsHtml = `
        <tr>
          <td colspan="5" style="padding: 28px; text-align: center; color: #94a3b8; font-style: italic;">
            ${searchTerm ? 'No field mappings match your search filter.' : 'No field mappings configured yet. Click "+ Add Field Mapping" or " Auto-Map All Fields" above.'}
          </td>
        </tr>
      `;
    }

    tbody.innerHTML = rowsHtml;

    // Update Metrics
    const totalMappings = this._modalMappingRows.length;
    const configuredCount = this._modalMappingRows.filter(r => r.intakeFieldId && r.wfParameter).length;
    const totalIntakeCount = intakeFields.length;
    const covPct = totalIntakeCount > 0 ? Math.round((configuredCount / totalIntakeCount) * 100) : 100;

    const totalEl = document.getElementById('wfMappingTotalFields');
    const mappedEl = document.getElementById('wfMappingMappedCount');
    const covEl = document.getElementById('wfMappingCoverage');
    if (totalEl) totalEl.textContent = totalMappings;
    if (mappedEl) mappedEl.textContent = configuredCount;
    if (covEl) covEl.textContent = `${covPct}%`;

    // Attach Event Listeners
    tbody.querySelectorAll('.wf-map-intake-select').forEach(sel => {
      sel.addEventListener('change', (e) => {
        const rIdx = parseInt(e.target.getAttribute('data-row-idx'), 10);
        const newIntakeId = e.target.value;
        if (this._modalMappingRows[rIdx]) {
          this._modalMappingRows[rIdx].intakeFieldId = newIntakeId;
          // If no wfParameter yet, auto-guess from field label
          if (!this._modalMappingRows[rIdx].wfParameter && newIntakeId) {
            const fld = intakeFields.find(f => f.id === newIntakeId);
            if (fld) {
              const cleanLabel = fld.label.replace(/^DE:/i, '').trim().toLowerCase();
              const match = wfParams.find(p => p.replace(/^DE:/i, '').trim().toLowerCase() === cleanLabel);
              this._modalMappingRows[rIdx].wfParameter = match || `DE:${fld.label.replace(/^DE:/i, '').trim()}`;
            }
          }
          this.renderWorkfrontFieldMappingTable();
          this._refreshWfPayloadPreview();
        }
      });
    });

    tbody.querySelectorAll('.wf-map-param-select').forEach(sel => {
      sel.addEventListener('change', (e) => {
        const rIdx = parseInt(e.target.getAttribute('data-row-idx'), 10);
        const val = e.target.value;
        if (this._modalMappingRows[rIdx]) {
          if (val === '__CUSTOM__') {
            this._modalMappingRows[rIdx].isCustom = true;
            if (!this._modalMappingRows[rIdx].wfParameter || !this._modalMappingRows[rIdx].wfParameter.startsWith('DE:')) {
              this._modalMappingRows[rIdx].wfParameter = 'DE:';
            }
          } else {
            this._modalMappingRows[rIdx].wfParameter = val;
            this._modalMappingRows[rIdx].isCustom = false;
          }
          this.renderWorkfrontFieldMappingTable();
          this._refreshWfPayloadPreview();
        }
      });
    });

    tbody.querySelectorAll('.wf-map-custom-inp').forEach(inp => {
      inp.addEventListener('input', (e) => {
        const rIdx = parseInt(e.target.getAttribute('data-row-idx'), 10);
        if (this._modalMappingRows[rIdx]) {
          this._modalMappingRows[rIdx].wfParameter = e.target.value.trim();
          this._refreshWfPayloadPreview();
        }
      });
    });
  },

  addWorkfrontMappingRow() {
    if (!this._modalMappingRows) this._modalMappingRows = [];
    this._modalMappingRows.push({
      intakeFieldId: '',
      wfParameter: '',
      isCustom: false
    });
    this.renderWorkfrontFieldMappingTable();
    this._refreshWfPayloadPreview();
  },

  removeWorkfrontMappingRow(originalIdx) {
    if (!this._modalMappingRows || !this._modalMappingRows[originalIdx]) return;
    this._modalMappingRows.splice(originalIdx, 1);
    this.renderWorkfrontFieldMappingTable();
    this._refreshWfPayloadPreview();
  },

  revertWorkfrontCustomRow(originalIdx) {
    if (!this._modalMappingRows || !this._modalMappingRows[originalIdx]) return;
    this._modalMappingRows[originalIdx].isCustom = false;
    this.renderWorkfrontFieldMappingTable();
    this._refreshWfPayloadPreview();
  },

  autoSuggestWorkfrontMappings() {
    const intakeFields = this.getAvailableIntakeFormFields();
    const wfParams = this.getAvailableWorkfrontParameters();

    this._modalMappingRows = intakeFields.map(f => {
      let targetParam = f.fieldRef?.wfApiParameter;
      if (!targetParam && f.fieldRef?.wfFieldName) {
        targetParam = f.fieldRef.wfFieldName.startsWith('DE:') ? f.fieldRef.wfFieldName : `DE:${f.fieldRef.wfFieldName}`;
      }
      if (!targetParam) {
        const cleanLabel = f.label.replace(/^DE:/i, '').trim().toLowerCase();
        const match = wfParams.find(p => p.replace(/^DE:/i, '').trim().toLowerCase() === cleanLabel);
        targetParam = match || `DE:${f.label.replace(/^DE:/i, '').trim()}`;
      }
      const isCustom = !wfParams.includes(targetParam);
      return {
        intakeFieldId: f.id,
        wfParameter: targetParam,
        isCustom: isCustom
      };
    });

    this.renderWorkfrontFieldMappingTable();
    this._refreshWfPayloadPreview();
    this._showToast(`Auto-mapped all ${this._modalMappingRows.length} intake field(s) to Workfront parameters!`);
  },

  toggleWfPayloadPreviewDrawer(force) {
    const drawer = document.getElementById('wfMappingPayloadDrawer');
    if (!drawer) return;
    const isCurrentlyOpen = drawer.style.display === 'flex' || drawer.classList.contains('open');
    const open = force !== undefined ? !!force : !isCurrentlyOpen;
    if (open) {
      drawer.style.display = 'flex';
      drawer.classList.add('open');
      this._refreshWfPayloadPreview();
    } else {
      drawer.style.display = 'none';
      drawer.classList.remove('open');
    }
  },

  _refreshWfPayloadPreview() {
    const pre = document.getElementById('wfMappingPayloadJson');
    if (!pre) return;

    const routing = this.formSchema?.workfrontRouting || {};
    const catId = routing.customFormId || routing.defaultCategoryIds?.[0] || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const tplId = routing.defaultTemplateId || 'TEMPLATE_DART_WEB_PAGE';

    const paramValues = {};
    const sampleValues = this.formValues || {};
    const intakeFields = this.getAvailableIntakeFormFields();

    (this._modalMappingRows || []).forEach(row => {
      if (!row.intakeFieldId || !row.wfParameter) return;
      const fld = intakeFields.find(f => f.id === row.intakeFieldId);
      let sampleVal = sampleValues[row.intakeFieldId];
      if (sampleVal === undefined) {
        if (fld?.fieldRef?.options && fld.fieldRef.options.length > 0) {
          const firstOpt = fld.fieldRef.options[0];
          sampleVal = typeof firstOpt === 'object' ? (firstOpt.value || firstOpt.label) : firstOpt;
        } else if (fld?.type === 'email') {
          sampleVal = 'submitter@cisco.com';
        } else if (fld?.type === 'date') {
          sampleVal = new Date().toISOString().split('T')[0];
        } else if (fld?.type === 'number') {
          sampleVal = 50000;
        } else {
          sampleVal = fld?.fieldRef?.placeholder || fld?.label || 'Sample Data';
        }
      }
      const pKey = row.wfParameter.startsWith('DE:') ? row.wfParameter : `DE:${row.wfParameter}`;
      paramValues[pKey] = sampleVal;
    });

    const payload = {
      name: sampleValues.projectName || this.formSchema?.title || 'FY27 Cisco Marketing Initiative',
      templateID: tplId,
      categoryID: catId,
      status: 'PLN',
      parameterValues: paramValues
    };

    pre.textContent = JSON.stringify(payload, null, 2);
  },

  copyWfMappingPayloadToClipboard() {
    const pre = document.getElementById('wfMappingPayloadJson');
    if (!pre) return;
    navigator.clipboard.writeText(pre.textContent).then(() => {
      this._showToast('Live Workfront API payload JSON copied to clipboard!');
    }).catch(() => {
      this._showToast('Could not copy to clipboard.');
    });
  },

  saveWorkfrontFieldMappings() {
    if (!this.formSchema) return;
    this.formSchema.workfrontMappings = this._modalMappingRows || [];

    // Sync back to fields in formSchema so each field knows its API parameter
    (this.formSchema.sections || []).forEach(s => {
      (s.fields || []).forEach(f => {
        const fId = f.formData || f.id;
        const mapping = (this._modalMappingRows || []).find(m => m.intakeFieldId === fId);
        if (mapping && mapping.wfParameter) {
          f.wfApiParameter = mapping.wfParameter;
          f.wfIncludeInPayload = true;
        }
      });
    });

    this.saveFormToStorage();
    this.closeWorkfrontFieldMappingModal();
    this.renderCiscoBuilderMode();
    this._showToast('Workfront API custom field mappings saved successfully!');
  }
});
