/**
 * Cisco MOPs FORM Studio - BA-Friendly Cascading Dropdown Studio
 * Domain: Excel-like grid, 3-column Miller columns flow, paste-from-clipboard parser, and live 3-tier cascade drilldown simulator
 * File: js/modules/14-cascading-studio.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
openMappingHubModal(targetTableId = null) {
    const modal = document.getElementById('modalMappingHub');
    if (!modal) return;

    this.activeMappingTableId = targetTableId || this.activeMappingTableId || 'region_country_lang';
    this.mappingHubView = this.mappingHubView || 'excel';

    // Populate dropdown with all tables
    this.populateMappingTableSelector();

    // Reset miller selections
    this.colSelectedLvl1Id = null;
    this.colSelectedLvl2Id = null;

    // Render active view
    this.setMappingHubView(this.mappingHubView);

    modal.style.cssText = 'display:flex!important;opacity:1!important;pointer-events:auto!important;position:fixed;inset:0;background:rgba(0,14,52,0.7);align-items:center;justify-content:center;z-index:9999;';
    modal.classList.add('open');
  },

  closeMappingHubModal() {
    const modal = document.getElementById('modalMappingHub');
    if (modal) {
      modal.classList.remove('open');
      modal.style.cssText = 'display:none;opacity:0;pointer-events:none;';
    }
  },

  populateMappingTableSelector() {
    const sel = document.getElementById('selectMappingTable');
    if (!sel || !window.MappingManager) return;
    const tables = window.MappingManager.getTables();
    sel.innerHTML = tables.map(t => `<option value="${t.id}">${t.title}</option>`).join('');
    sel.value = this.activeMappingTableId;
  },

  onMappingTableSelectChange(tableId) {
    this.activeMappingTableId = tableId;
    this.colSelectedLvl1Id = null;
    this.colSelectedLvl2Id = null;
    this.renderCurrentMappingView();
  },

  setMappingHubView(viewName) {
    this.mappingHubView = viewName;
    const views = ['excel', 'columns', 'paste', 'simulator'];

    // Update active tab button
    views.forEach(v => {
      let btnId = 'tabMapBtn' + v.charAt(0).toUpperCase() + v.slice(1);
      if (v === 'simulator') btnId = 'tabMapBtnSim';
      const btn = document.getElementById(btnId);
      if (btn) {
        if (v === viewName) btn.classList.add('active');
        else btn.classList.remove('active');
      }
      const container = document.getElementById(`mapViewContainer_${v}`);
      if (container) {
        container.style.display = (v === viewName) ? 'block' : 'none';
      }
    });

    this.renderCurrentMappingView();
  },

  renderCurrentMappingView() {
    const q = (document.getElementById('inputSearchMappingHub')?.value || '').trim();
    if (this.mappingHubView === 'excel') {
      this.renderMappingExcelTable(q);
    } else if (this.mappingHubView === 'columns') {
      this.renderMappingColumns(q);
    } else if (this.mappingHubView === 'paste') {
      // Paste view ready
    } else if (this.mappingHubView === 'simulator') {
      this.initDrilldownSimulator();
    }
    this.updateMappingBreadcrumbs();
  },

  onMappingSearchInput(query) {
    this.renderCurrentMappingView();
  },

  updateMappingBreadcrumbs() {
    const table = window.MappingManager ? window.MappingManager.getTable(this.activeMappingTableId) : null;
    if (!table) return;

    const statsEl = document.getElementById('mapBreadcrumbStats');
    const textEl = document.getElementById('mapBreadcrumbText');
    const rows = window.MappingManager.flattenToRows(this.activeMappingTableId);

    if (statsEl) statsEl.textContent = `${rows.length} total combinations (${(table.nodes || []).length} root ${table.levelLabels[0] || 'items'})`;

    if (textEl) {
      if (this.colSelectedLvl1Id && this.mappingHubView === 'columns') {
        const lvl1 = (table.nodes || []).find(n => n.id === this.colSelectedLvl1Id);
        const lvl2 = (lvl1?.children || []).find(n => n.id === this.colSelectedLvl2Id);
        let pathStr = lvl1?.label || 'All';
        if (lvl2) pathStr += `  ${lvl2.label}`;
        textEl.textContent = pathStr;
      } else {
        textEl.textContent = `${table.title} (${table.levelLabels.join('  ')})`;
      }
    }
  },

  // ------------------------------------------------------------------------
  // VIEW 1: Excel Grid View
  // ------------------------------------------------------------------------
  renderMappingExcelTable(filterQuery = '') {
    const wrapper = document.getElementById('mapExcelTableWrapper');
    if (!wrapper || !window.MappingManager) return;

    const table = window.MappingManager.getTable(this.activeMappingTableId);
    if (!table) return;

    const levels = table.levelLabels || ['Category', 'Sub-Category', 'Option'];
    const rows = window.MappingManager.flattenToRows(this.activeMappingTableId);
    const q = (filterQuery || '').toLowerCase();

    // Update placeholders in the Quick Add Row
    const inLvl1 = document.getElementById('inputGridNewLvl1');
    const inLvl2 = document.getElementById('inputGridNewLvl2');
    const inLvl3 = document.getElementById('inputGridNewLvl3');
    if (inLvl1) inLvl1.placeholder = levels[0] || 'Level 1';
    if (inLvl2) inLvl2.placeholder = levels[1] || 'Level 2';
    if (inLvl3) {
      inLvl3.placeholder = levels[2] || 'Level 3';
      inLvl3.style.display = levels.length >= 3 ? 'inline-block' : 'none';
    }

    const filteredRows = rows.filter(r => {
      if (!q) return true;
      const combined = (r.levels.join(' ') + ' ' + (r.code || '') + ' ' + (r.region || '') + ' ' + (r.tag || '')).toLowerCase();
      return combined.includes(q);
    });

    if (filteredRows.length === 0) {
      wrapper.innerHTML = `
        <div style="padding: 36px 20px; text-align: center; color: #64748b;">
          <div style="font-size: 28px; margin-bottom: 8px;"></div>
          <div style="font-size: 13px; font-weight: 700; color: #0f172a;">${q ? 'No matching rows found' : 'No rows in this table yet'}</div>
          <div style="font-size: 12px; margin-top: 4px;">Use the Quick Add bar above, or switch to <strong>"Paste from Excel"</strong> to import rows.</div>
        </div>
      `;
      return;
    }

    const ths = levels.map((l, i) => `<th>Step ${i + 1}: ${l}</th>`).join('') +
      `<th>Code / Value</th><th>Tag / Extra</th><th style="width: 80px; text-align: center;">Actions</th>`;

    const trs = filteredRows.map(r => {
      const levelTds = levels.map((l, lvlIdx) => {
        const val = r.levels[lvlIdx] || '';
        return `<td><strong>${val}</strong></td>`;
      }).join('');

      const codeBadge = r.code ? `<code style="background:#eff6ff; color:#0369a1; padding:2px 6px; border-radius:4px; font-weight:600;">${r.code}</code>` : '<span style="color:#94a3b8;"></span>';
      const tagBadge = (r.region || r.tag) ? `<span class="map-tag-badge">${r.region || r.tag}</span>` : '<span style="color:#94a3b8;"></span>';

      return `
        <tr>
          ${levelTds}
          <td>${codeBadge}</td>
          <td>${tagBadge}</td>
          <td style="text-align: center; white-space: nowrap;">
            <button type="button" class="map-miller-btn del" onclick="App.deleteMappingGridRow('${r.leafId}', '${(r.levels[r.levels.length - 1] || 'item').replace(/'/g, "\\'")}')" title="Delete this combination">
              
            </button>
          </td>
        </tr>
      `;
    }).join('');

    wrapper.innerHTML = `
      <table class="map-excel-table">
        <thead>
          <tr>${ths}</tr>
        </thead>
        <tbody>
          ${trs}
        </tbody>
      </table>
    `;
  },

  addMappingGridRow() {
    const table = window.MappingManager ? window.MappingManager.getTable(this.activeMappingTableId) : null;
    if (!table) return;

    const inLvl1 = document.getElementById('inputGridNewLvl1');
    const inLvl2 = document.getElementById('inputGridNewLvl2');
    const inLvl3 = document.getElementById('inputGridNewLvl3');
    const inCode = document.getElementById('inputGridNewCode');

    const l1 = (inLvl1?.value || '').trim();
    const l2 = (inLvl2?.value || '').trim();
    const l3 = (inLvl3?.value || '').trim();
    const code = (inCode?.value || '').trim().toUpperCase();

    if (!l1 || !l2) {
      this._showToast(`Please fill in at least ${table.levelLabels[0] || 'Level 1'} and ${table.levelLabels[1] || 'Level 2'}.`);
      return;
    }

    const levels = [l1, l2];
    if (l3) levels.push(l3);

    window.MappingManager.importRows(this.activeMappingTableId, [{ levels, code }]);

    if (inLvl2) inLvl2.value = '';
    if (inLvl3) inLvl3.value = '';
    if (inCode) inCode.value = '';
    if (inLvl2) inLvl2.focus();

    this._showToast(`Added combination: "${l1}  ${l2}${l3 ? '  ' + l3 : ''}"`);
    this.renderCurrentMappingView();
    this.renderSidebarMappingsList();
  },

  deleteMappingGridRow(leafId, label) {
    if (confirm(`Remove "${label}" combination from this table?`)) {
      window.MappingManager.deleteNode(this.activeMappingTableId, leafId);
      this._showToast(`Removed "${label}"`);
      this.renderCurrentMappingView();
      this.renderSidebarMappingsList();
    }
  },

  // ------------------------------------------------------------------------
  // VIEW 2: 3-Column Miller Flow
  // ------------------------------------------------------------------------
  renderMappingColumns(filterQuery = '') {
    const grid = document.getElementById('mapMillerGridRoot');
    if (!grid || !window.MappingManager) return;

    const table = window.MappingManager.getTable(this.activeMappingTableId);
    if (!table) return;

    const levels = table.levelLabels || ['Category', 'Sub-Category', 'Option'];
    const nodes = table.nodes || [];

    // Ensure selection defaults
    if (!this.colSelectedLvl1Id && nodes.length > 0) {
      this.colSelectedLvl1Id = nodes[0].id;
    }

    const selectedLvl1Node = nodes.find(n => n.id === this.colSelectedLvl1Id);
    const lvl2Nodes = selectedLvl1Node?.children || [];

    if (!this.colSelectedLvl2Id && lvl2Nodes.length > 0) {
      this.colSelectedLvl2Id = lvl2Nodes[0].id;
    }

    const selectedLvl2Node = lvl2Nodes.find(n => n.id === this.colSelectedLvl2Id);
    const lvl3Nodes = selectedLvl2Node?.children || [];

    // Column 1
    const col1Html = `
      <div class="map-miller-col">
        <div class="map-miller-header">
          <span class="map-miller-title">
            <span class="map-col-badge">1</span> ${levels[0] || 'Level 1'}
          </span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${nodes.length} items</span>
        </div>
        <div class="map-miller-list">
          ${nodes.map(n => {
      const isActive = n.id === this.colSelectedLvl1Id;
      const childCount = (n.children || []).length;
      return `
              <div class="map-miller-item ${isActive ? 'active' : ''}" onclick="App.selectMillerItem(1, '${n.id}')">
                <span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${n.label}</span>
                <span style="font-size:11px; color:#64748b; margin-right:4px;">${childCount} </span>
                <div class="map-miller-actions" onclick="event.stopPropagation();">
                  <button type="button" class="map-miller-btn del" onclick="App.deleteMillerItem(1, '${n.id}', '${n.label.replace(/'/g, "\\'")}')" title="Delete"></button>
                </div>
              </div>
            `;
    }).join('')}
        </div>
        <div class="map-miller-footer">
          <input type="text" id="inputColNewLvl1" class="mops-input" placeholder="+ Add ${levels[0]}..." style="height:28px; font-size:11.5px; flex:1;" onkeydown="if(event.key==='Enter') App.addMillerItem(1, null)">
          <button type="button" class="btn btn-outline btn-sm" onclick="App.addMillerItem(1, null)" style="height:28px; padding:0 8px;">+</button>
        </div>
      </div>
    `;

    // Column 2
    const col2Html = `
      <div class="map-miller-col">
        <div class="map-miller-header">
          <span class="map-miller-title">
            <span class="map-col-badge">2</span> ${levels[1] || 'Level 2'}
          </span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${lvl2Nodes.length} items</span>
        </div>
        <div class="map-miller-list">
          ${lvl2Nodes.length === 0 ? `<div style="padding:24px; text-align:center; color:#94a3b8; font-size:12px;">No items under selected ${levels[0]}. Use box below to add one.</div>` : ''}
          ${lvl2Nodes.map(n => {
      const isActive = n.id === this.colSelectedLvl2Id;
      const childCount = (n.children || []).length;
      const badge = n.code ? `<span class="map-code-badge" style="font-size:10px; padding:0 4px;">${n.code}</span>` : '';
      return `
              <div class="map-miller-item ${isActive ? 'active' : ''}" onclick="App.selectMillerItem(2, '${n.id}')">
                <span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${n.label} ${badge}</span>
                <span style="font-size:11px; color:#64748b; margin-right:4px;">${childCount} </span>
                <div class="map-miller-actions" onclick="event.stopPropagation();">
                  <button type="button" class="map-miller-btn del" onclick="App.deleteMillerItem(2, '${n.id}', '${n.label.replace(/'/g, "\\'")}')" title="Delete"></button>
                </div>
              </div>
            `;
    }).join('')}
        </div>
        <div class="map-miller-footer">
          <input type="text" id="inputColNewLvl2" class="mops-input" placeholder="+ Add ${levels[1]} under selected..." style="height:28px; font-size:11.5px; flex:1;" onkeydown="if(event.key==='Enter') App.addMillerItem(2, '${this.colSelectedLvl1Id || ''}')" ${!this.colSelectedLvl1Id ? 'disabled' : ''}>
          <button type="button" class="btn btn-outline btn-sm" onclick="App.addMillerItem(2, '${this.colSelectedLvl1Id || ''}')" style="height:28px; padding:0 8px;" ${!this.colSelectedLvl1Id ? 'disabled' : ''}>+</button>
        </div>
      </div>
    `;

    // Column 3
    const col3Html = `
      <div class="map-miller-col">
        <div class="map-miller-header">
          <span class="map-miller-title">
            <span class="map-col-badge">3</span> ${levels[2] || 'Level 3'}
          </span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${lvl3Nodes.length} items</span>
        </div>
        <div class="map-miller-list">
          ${lvl3Nodes.length === 0 ? `<div style="padding:24px; text-align:center; color:#94a3b8; font-size:12px;">No options under selected ${levels[1]}. Use box below to add one.</div>` : ''}
          ${lvl3Nodes.map(n => {
      const badge = n.code ? `<span class="map-code-badge">${n.code}</span>` : '';
      const tag = n.tag ? `<span class="map-tag-badge">${n.tag}</span>` : '';
      return `
              <div class="map-miller-item">
                <div style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                  <span>${n.label}</span>
                  ${badge}
                  ${tag}
                </div>
                <div class="map-miller-actions" onclick="event.stopPropagation();">
                  <button type="button" class="map-miller-btn del" onclick="App.deleteMillerItem(3, '${n.id}', '${n.label.replace(/'/g, "\\'")}')" title="Delete"></button>
                </div>
              </div>
            `;
    }).join('')}
        </div>
        <div class="map-miller-footer" style="flex-direction:column; gap:4px;">
          <div style="display:flex; gap:4px;">
            <input type="text" id="inputColNewLvl3" class="mops-input" placeholder="+ Add ${levels[2]}..." style="height:28px; font-size:11.5px; flex:1;" onkeydown="if(event.key==='Enter') App.addMillerItem(3, '${this.colSelectedLvl2Id || ''}')" ${!this.colSelectedLvl2Id ? 'disabled' : ''}>
            <input type="text" id="inputColNewCode" class="mops-input" placeholder="Code" style="height:28px; font-size:11.5px; width:70px;" ${!this.colSelectedLvl2Id ? 'disabled' : ''}>
            <button type="button" class="btn btn-outline btn-sm" onclick="App.addMillerItem(3, '${this.colSelectedLvl2Id || ''}')" style="height:28px; padding:0 8px;" ${!this.colSelectedLvl2Id ? 'disabled' : ''}>+</button>
          </div>
        </div>
      </div>
    `;

    grid.innerHTML = col1Html + col2Html + col3Html;
  },

  selectMillerItem(level, id) {
    if (level === 1) {
      this.colSelectedLvl1Id = id;
      this.colSelectedLvl2Id = null;
    } else if (level === 2) {
      this.colSelectedLvl2Id = id;
    }
    this.renderMappingColumns();
    this.updateMappingBreadcrumbs();
  },

  addMillerItem(level, parentId) {
    const table = window.MappingManager ? window.MappingManager.getTable(this.activeMappingTableId) : null;
    if (!table) return;

    if (level === 1) {
      const input = document.getElementById('inputColNewLvl1');
      const val = (input?.value || '').trim();
      if (!val) return;
      const newNode = {
        id: 'node_' + Math.random().toString(36).substr(2, 9),
        label: val,
        code: '',
        children: []
      };
      window.MappingManager.addNode(this.activeMappingTableId, [], newNode);
      this.colSelectedLvl1Id = newNode.id;
      this._showToast(`Added "${val}" to ${table.levelLabels[0]}`);
    } else if (level === 2) {
      if (!parentId) { this._showToast(`Please select a ${table.levelLabels[0]} first.`); return; }
      const input = document.getElementById('inputColNewLvl2');
      const val = (input?.value || '').trim();
      if (!val) return;
      const newNode = {
        id: 'node_' + Math.random().toString(36).substr(2, 9),
        label: val,
        code: '',
        children: []
      };
      window.MappingManager.addNode(this.activeMappingTableId, [parentId], newNode);
      this.colSelectedLvl2Id = newNode.id;
      this._showToast(`Added "${val}" to ${table.levelLabels[1]}`);
    } else if (level === 3) {
      if (!parentId) { this._showToast(`Please select a ${table.levelLabels[1]} first.`); return; }
      const input = document.getElementById('inputColNewLvl3');
      const inCode = document.getElementById('inputColNewCode');
      const val = (input?.value || '').trim();
      const code = (inCode?.value || '').trim().toUpperCase();
      if (!val) return;
      const newNode = {
        id: 'node_' + Math.random().toString(36).substr(2, 9),
        label: val,
        code: code,
        tag: 'Primary',
        children: []
      };
      window.MappingManager.addNode(this.activeMappingTableId, [this.colSelectedLvl1Id, parentId], newNode);
      this._showToast(`Added "${val}"`);
    }

    this.renderCurrentMappingView();
    this.renderSidebarMappingsList();
  },

  deleteMillerItem(level, nodeId, label) {
    if (confirm(`Delete "${label}" and all its sub-options?`)) {
      window.MappingManager.deleteNode(this.activeMappingTableId, nodeId);
      if (level === 1 && this.colSelectedLvl1Id === nodeId) this.colSelectedLvl1Id = null;
      if (level === 2 && this.colSelectedLvl2Id === nodeId) this.colSelectedLvl2Id = null;
      this._showToast(`Deleted "${label}"`);
      this.renderCurrentMappingView();
      this.renderSidebarMappingsList();
    }
  },

  // ------------------------------------------------------------------------
  // VIEW 3: Paste from Excel / CSV
  // ------------------------------------------------------------------------
  onExcelPasteInput() {
    const text = document.getElementById('textareaExcelPaste')?.value || '';
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    const statusEl = document.getElementById('pasteStatusText');
    const btn = document.getElementById('btnConfirmImportPaste');
    const previewWrap = document.getElementById('pastePreviewWrap');
    const previewTable = document.getElementById('pastePreviewTable');

    if (lines.length === 0) {
      if (statusEl) statusEl.textContent = 'Waiting for input...';
      if (btn) btn.disabled = true;
      if (previewWrap) previewWrap.style.display = 'none';
      return;
    }

    const parsedRows = [];
    for (const line of lines) {
      const parts = line.includes('\t') ? line.split('\t') : line.split(',');
      const cleanParts = parts.map(p => p.trim());
      if (cleanParts.length >= 2) {
        parsedRows.push({
          levels: cleanParts.slice(0, Math.min(cleanParts.length, 3)),
          code: cleanParts[3] || '',
          tag: cleanParts[4] || ''
        });
      }
    }

    if (statusEl) {
      statusEl.innerHTML = `<span style="color:#16a34a; font-weight:700;">OK Detected ${parsedRows.length} valid rows</span> from ${lines.length} lines.`;
    }
    if (btn) btn.disabled = parsedRows.length === 0;

    if (previewTable && previewWrap) {
      if (parsedRows.length > 0) {
        previewWrap.style.display = 'block';
        const head = `<thead><tr><th>Col 1</th><th>Col 2</th><th>Col 3</th><th>Code</th></tr></thead>`;
        const body = parsedRows.slice(0, 15).map(r => `
          <tr>
            <td>${r.levels[0] || ''}</td>
            <td>${r.levels[1] || ''}</td>
            <td>${r.levels[2] || ''}</td>
            <td><code>${r.code || ''}</code></td>
          </tr>
        `).join('');
        previewTable.innerHTML = head + `<tbody>${body}</tbody>`;
      } else {
        previewWrap.style.display = 'none';
      }
    }
  },

  loadExcelPasteSample() {
    const ta = document.getElementById('textareaExcelPaste');
    if (!ta) return;
    ta.value =
      "Americas\tUnited States\tEnglish - United States\tUS_EN\tPrimary\n" +
      "Americas\tCanada\tEnglish - Canada\tCA_EN\tPrimary\n" +
      "Americas\tCanada\tFrench - Canada\tCA_FR\tRegional\n" +
      "Americas\tMexico\tSpanish - Mexico\tMX_ES\tPrimary\n" +
      "EMEA\tUnited Kingdom\tEnglish - United Kingdom\tUK_EN\tPrimary\n" +
      "EMEA\tFrance\tFrench - France\tFR_FR\tPrimary\n" +
      "EMEA\tGermany\tGerman - Germany\tDE_DE\tPrimary\n" +
      "APJC\tAustralia\tEnglish - Australia\tAU_EN\tPrimary\n" +
      "APJC\tJapan\tJapanese - Japan\tJA_JP\tPrimary";
    this.onExcelPasteInput();
  },

  confirmImportExcelData() {
    const text = document.getElementById('textareaExcelPaste')?.value || '';
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    const parsedRows = [];

    for (const line of lines) {
      const parts = line.includes('\t') ? line.split('\t') : line.split(',');
      const cleanParts = parts.map(p => p.trim());
      if (cleanParts.length >= 2) {
        parsedRows.push({
          levels: cleanParts.slice(0, 3),
          code: cleanParts[3] || '',
          tag: cleanParts[4] || ''
        });
      }
    }

    if (parsedRows.length === 0) return;

    const count = window.MappingManager.importRows(this.activeMappingTableId, parsedRows);
    this._showToast(`Successfully imported ${count} items from Excel!`);

    const ta = document.getElementById('textareaExcelPaste');
    if (ta) ta.value = '';
    this.onExcelPasteInput();

    // Switch to Excel view to see results immediately
    this.setMappingHubView('excel');
    this.renderSidebarMappingsList();
  },

  // ------------------------------------------------------------------------
  // Create New Cascade Table Wizard
  // ------------------------------------------------------------------------
  openNewCascadeTableModal() {
    const modal = document.getElementById('modalNewCascadeTable');
    if (!modal) return;
    modal.style.cssText = 'display:flex!important;opacity:1!important;pointer-events:auto!important;position:fixed;inset:0;background:rgba(0,14,52,0.7);align-items:center;justify-content:center;z-index:10000;';
    modal.classList.add('open');

    const inTitle = document.getElementById('inputNewCascadeTitle');
    const inDesc = document.getElementById('inputNewCascadeDesc');
    if (inTitle) inTitle.value = '';
    if (inDesc) inDesc.value = '';
    setTimeout(() => inTitle?.focus(), 100);
  },

  closeNewCascadeTableModal() {
    const modal = document.getElementById('modalNewCascadeTable');
    if (modal) {
      modal.classList.remove('open');
      modal.style.cssText = 'display:none;opacity:0;pointer-events:none;';
    }
  },

  confirmCreateNewCascadeTable() {
    const inTitle = document.getElementById('inputNewCascadeTitle');
    const inDesc = document.getElementById('inputNewCascadeDesc');
    const inLvl1 = document.getElementById('inputNewCascadeLvl1');
    const inLvl2 = document.getElementById('inputNewCascadeLvl2');
    const inLvl3 = document.getElementById('inputNewCascadeLvl3');

    const title = (inTitle?.value || '').trim();
    const desc = (inDesc?.value || '').trim();
    const l1 = (inLvl1?.value || 'Category').trim();
    const l2 = (inLvl2?.value || 'Sub-Category').trim();
    const l3 = (inLvl3?.value || '').trim();

    if (!title) {
      this._showToast('Please enter a name for the new cascade table.');
      return;
    }

    const levels = [l1, l2];
    if (l3) levels.push(l3);

    const newTable = window.MappingManager.createTable(title, desc, levels);
    this.activeMappingTableId = newTable.id;

    this.closeNewCascadeTableModal();
    this.populateMappingTableSelector();
    this.setMappingHubView('excel');
    this.renderSidebarMappingsList();

    // Sync Configuration -> Mapping Tables tab if present
    const cfgSel = document.getElementById('cfgMappingSelector');
    if (cfgSel && typeof this._loadCfgMappings === 'function') {
      this._loadCfgMappings();
      cfgSel.value = newTable.id;
      if (typeof this.onCfgMappingChange === 'function') this.onCfgMappingChange();
    }

    this._showToast(`Created new cascade table "${title}"! You can now add rows or paste from Excel.`);
  },

  // ------------------------------------------------------------------------
  // Export CSV & JSON
  // ------------------------------------------------------------------------
  exportMappingTableCsv() {
    const table = window.MappingManager ? window.MappingManager.getTable(this.activeMappingTableId) : null;
    if (!table) return;

    const rows = window.MappingManager.flattenToRows(this.activeMappingTableId);
    const levels = table.levelLabels || ['Level 1', 'Level 2', 'Level 3'];

    const csvRows = [];
    csvRows.push([...levels, 'Code', 'Tag'].map(h => `"${h}"`).join(','));

    rows.forEach(r => {
      const cells = [
        r.levels[0] || '',
        r.levels[1] || '',
        r.levels[2] || '',
        r.code || '',
        r.region || r.tag || ''
      ].map(c => `"${c.replace(/"/g, '""')}"`);
      csvRows.push(cells.join(','));
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + encodeURIComponent(csvRows.join('\n'));
    this._triggerDownload(csvContent, `${table.id}_export.csv`);
    this._showToast(`Exported ${table.title} to CSV`);
  },

  exportMappingTableJson() {
    const table = window.MappingManager ? window.MappingManager.getTable(this.activeMappingTableId) : null;
    if (!table) return;
    const jsonStr = JSON.stringify(table, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    this._triggerDownload(url, `${table.id}_mapping.json`);
    this._showToast(`Exported ${table.title} to JSON`);
  },

  // ------------------------------------------------------------------------
  // 1-Click Form Integration: Insert Linked Cascading Dropdowns
  // ------------------------------------------------------------------------
  insertCascadeToActiveForm() {
    const table = window.MappingManager ? window.MappingManager.getTable(this.activeMappingTableId) : null;
    if (!table) return;

    if (!this.activeFormId) {
      this._showToast('Please open or create a form first before inserting cascading dropdowns.');
      return;
    }

    const form = this.getActiveForm();
    if (!form || !form.sections || form.sections.length === 0) {
      this._showToast('The current form does not have any sections to place fields into.');
      return;
    }

    const targetSection = form.sections[0];
    const levels = table.levelLabels || ['Level 1', 'Level 2', 'Level 3'];
    const nowIso = new Date().toISOString();
    const userSig = this.getCurrentUserSignature();

    // Create 2 or 3 linked fields
    const createdFields = [];
    let prevFieldKey = null;

    levels.forEach((lvlName, idx) => {
      const autoKey = 'field_' + lvlName.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Math.floor(Math.random() * 1000);
      const isRoot = (idx === 0);

      // Seed root options or dynamic options
      let initialOptions = [];
      if (isRoot) {
        initialOptions = (table.nodes || []).map(n => n.label);
      } else {
        initialOptions = ['(Select parent first)'];
      }

      const newField = {
        label: lvlName,
        formData: autoKey,
        type: 'select',
        col: 'col-lg-6',
        required: true,
        options: initialOptions,
        cascadingConfig: {
          tableId: table.id,
          levelIndex: idx,
          parentKey: prevFieldKey
        },
        _createdAt: nowIso,
        _createdBy: userSig,
        _updatedAt: nowIso,
        _updatedBy: userSig
      };

      targetSection.fields.push(newField);
      createdFields.push(newField);
      prevFieldKey = autoKey;
    });

    this.saveAllForms();
    this.renderCanvas();
    this.closeMappingHubModal();
    this._showToast(`Added ${createdFields.length} linked cascading dropdowns to "${targetSection.title}"!`);
  },

  // Test Simulator Inside Mapping Hub
  initDrilldownSimulator() {
    const table = window.MappingManager.getTable(this.activeMappingTableId);
    if (!table) return;

    const lbl1 = document.getElementById('simLabelLvl1');
    const lbl2 = document.getElementById('simLabelLvl2');
    const lbl3 = document.getElementById('simLabelLvl3');

    if (lbl1) lbl1.textContent = `Level 1: ${table.levelLabels?.[0] || 'Parent'}`;
    if (lbl2) lbl2.textContent = `Level 2: ${table.levelLabels?.[1] || 'Child'}`;
    if (lbl3) lbl3.textContent = `Level 3: ${table.levelLabels?.[2] || 'Sub-item'}`;

    const sel1 = document.getElementById('simSelectLvl1');
    const sel2 = document.getElementById('simSelectLvl2');
    const sel3 = document.getElementById('simSelectLvl3');
    const resEl = document.getElementById('simResolvedCode');

    if (sel1) {
      sel1.innerHTML = `<option value="">Select ${table.levelLabels?.[0] || 'Item'}...</option>` +
        (table.nodes || []).map(n => `<option value="${n.id}">${n.label}</option>`).join('');
      sel1.value = '';
    }
    if (sel2) { sel2.innerHTML = `<option value="">Select...</option>`; sel2.disabled = true; }
    if (sel3) { sel3.innerHTML = `<option value="">Select...</option>`; sel3.disabled = true; }
    if (resEl) { resEl.style.display = 'none'; resEl.textContent = ''; }
  },

  onSimLevel1Change(parentId) {
    const table = window.MappingManager.getTable(this.activeMappingTableId);
    const sel2 = document.getElementById('simSelectLvl2');
    const sel3 = document.getElementById('simSelectLvl3');
    const resEl = document.getElementById('simResolvedCode');

    if (sel3) { sel3.innerHTML = '<option value="">Select...</option>'; sel3.disabled = true; }
    if (resEl) resEl.style.display = 'none';

    if (!parentId || !table) {
      if (sel2) { sel2.innerHTML = '<option value="">Select...</option>'; sel2.disabled = true; }
      return;
    }

    const parentNode = (table.nodes || []).find(n => n.id === parentId);
    const children = parentNode?.children || [];

    if (sel2) {
      sel2.innerHTML = `<option value="">Select ${table.levelLabels?.[1] || 'Child'}...</option>` +
        children.map(c => `<option value="${c.id}">${c.label} (${c.code || c.region || ''})</option>`).join('');
      sel2.disabled = children.length === 0;
    }
  },

  onSimLevel2Change(childId) {
    const table = window.MappingManager.getTable(this.activeMappingTableId);
    const sel1 = document.getElementById('simSelectLvl1');
    const sel3 = document.getElementById('simSelectLvl3');
    const resEl = document.getElementById('simResolvedCode');

    if (!childId || !table) {
      if (sel3) { sel3.innerHTML = '<option value="">Select...</option>'; sel3.disabled = true; }
      if (resEl) resEl.style.display = 'none';
      return;
    }

    const parentNode = (table.nodes || []).find(n => n.id === sel1?.value);
    const childNode = (parentNode?.children || []).find(c => c.id === childId);
    const subChildren = childNode?.children || [];

    if (sel3) {
      sel3.innerHTML = `<option value="">Select ${table.levelLabels?.[2] || 'Sub-item'}...</option>` +
        subChildren.map(s => `<option value="${s.id}" data-code="${s.code || ''}">${s.label} [${s.code || ''}]</option>`).join('');
      sel3.disabled = subChildren.length === 0;
    }
  },

  onSimLevel3Change(subId) {
    const sel3 = document.getElementById('simSelectLvl3');
    const opt = sel3?.options[sel3.selectedIndex];
    const code = opt?.getAttribute('data-code');
    const resEl = document.getElementById('simResolvedCode');
    if (resEl && subId) {
      resEl.style.display = 'block';
      resEl.innerHTML = `OK Resolved Technical Code: <code style="background:#dcfce7; padding:2px 8px; border-radius:4px; font-weight:700;">${code || opt?.text || subId}</code> (Auto-mapped to Workfront &amp; Naming Conventions)`;
    } else if (resEl) {
      resEl.style.display = 'none';
    }
  },

  exportMappingTableJson() {
    const table = window.MappingManager.getTable(this.activeMappingTableId);
    if (!table) return;
    const jsonStr = JSON.stringify(table, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    this._triggerDownload(url, `${table.id}_mapping.json`);
    this._showToast(`Exported ${table.title} JSON`);
  },

  renderSidebarMappingsList() {
    const container = document.getElementById('sidebarMappingsList');
    if (!container || !window.MappingManager) return;

    const tables = window.MappingManager.getTables();
    container.innerHTML = tables.map(t => {
      const topCount = (t.nodes || []).length;
      return `
        <div style="background:#fff; border:1px solid #e2e8f0; border-radius:6px; padding:10px 12px; margin-bottom:8px; box-shadow:0 1px 3px rgba(0,0,0,0.04);">
          <div style="font-weight:700; color:#0f172a; font-size:12px; margin-bottom:2px;">${t.title}</div>
          <div style="font-size:11px; color:#64748b; line-height:1.4; margin-bottom:8px;">${t.description}</div>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:10.5px; font-weight:600; color:#0369a1; background:#e0f2fe; padding:1px 6px; border-radius:4px;">${topCount} Root Branches</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="App.openMappingHubModal('${t.id}')" style="font-size:11px; padding:2px 8px; font-weight:600;">
               Drilldown
            </button>
          </div>
        </div>
      `;
    }).join('');
  }
});
