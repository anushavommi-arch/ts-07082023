/**
 * Cisco MOPs FORM Studio - Canvas Field & Section CRUD Operations
 * Domain: Adding, deleting, moving, cloning fields/sections on canvas, and reusable section/field library management
 * File: js/modules/05-field-operations.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
addSection() {
    const newSec = {
      title: 'New Section',
      id: 'Section_' + (this.formSchema.sections.length + 1),
      condition: null,
      fields: []
    };
    this.formSchema.sections.push(newSec);
    this.saveFormToStorage();
    this.render();
  },

  deleteSection(sIdx) {
    if (confirm(`Are you sure you want to delete "${this.formSchema.sections[sIdx].title}"?`)) {
      this.formSchema.sections.splice(sIdx, 1);
      this.saveFormToStorage();
      this.render();
    }
  },

  reorderSections(fromIdx, toIdx) {
    const moved = this.formSchema.sections.splice(fromIdx, 1)[0];
    this.formSchema.sections.splice(toIdx, 0, moved);
    this.saveFormToStorage();
    this.render();
  },

  addFieldToSection(secIdx, fieldData) {
    if (!this.formSchema.sections[secIdx]) return;
    const cloned = JSON.parse(JSON.stringify(fieldData));

    // Audit tracking & Workfront instance identity
    const now = new Date().toISOString();
    const sig = this.getCurrentUserSignature();
    cloned._createdAt = cloned._createdAt || now;
    cloned._createdBy = cloned._createdBy || sig;
    cloned._updatedAt = now;
    cloned._updatedBy = sig;
    if (cloned.type !== 'empty_field') {
      cloned.instanceId = cloned.instanceId || ('inst_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      cloned.dateAdded = cloned.dateAdded || now;
      cloned.wfLibraryFieldId = cloned.wfLibraryFieldId || cloned.id || cloned.formData;
      cloned.wfFieldName = cloned.wfFieldName || cloned.formData;
    }

    // Ensure unique formData key
    cloned.formData = this.ensureUniqueKey(cloned.formData || 'field');
    this.formSchema.sections[secIdx].fields.push(cloned);
    this.saveFormToStorage();
    this.render();
    this._refreshSidebarPreserveScroll();
  },

  _refreshSidebarPreserveScroll() {
    const listEl = document.getElementById('reusableFieldsList');
    const st = listEl ? listEl.scrollTop : 0;
    if (typeof this.renderSidebar === 'function') this.renderSidebar();
    const listElAfter = document.getElementById('reusableFieldsList');
    if (listElAfter) listElAfter.scrollTop = st;
  },

  insertFieldAt(secIdx, targetFieldIdx, fieldData) {
    this.ensureActiveForm();
    if (!this.formSchema.sections || !this.formSchema.sections[secIdx]) return;
    const cloned = JSON.parse(JSON.stringify(fieldData));

    // Audit tracking & Workfront instance identity
    const now = new Date().toISOString();
    const sig = this.getCurrentUserSignature();
    cloned._createdAt = cloned._createdAt || now;
    cloned._createdBy = cloned._createdBy || sig;
    cloned._updatedAt = now;
    cloned._updatedBy = sig;
    if (cloned.type !== 'empty_field') {
      cloned.instanceId = cloned.instanceId || ('inst_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
      cloned.dateAdded = cloned.dateAdded || now;
      cloned.wfLibraryFieldId = cloned.wfLibraryFieldId || cloned.id || cloned.formData;
      cloned.wfFieldName = cloned.wfFieldName || cloned.formData;
    }

    cloned.formData = this.ensureUniqueKey(cloned.formData || 'field');

    let insertIdx = targetFieldIdx;
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > this.formSchema.sections[secIdx].fields.length) {
      insertIdx = this.formSchema.sections[secIdx].fields.length;
    }

    this.formSchema.sections[secIdx].fields.splice(insertIdx, 0, cloned);
    this.saveFormToStorage();
    this.render();
    this._refreshSidebarPreserveScroll();

    this.selectedFieldLoc = { sectionIndex: secIdx, fieldIndex: insertIdx };

    setTimeout(() => {
      const fieldCards = document.querySelectorAll(`.canvas-section-card[data-section-index="${secIdx}"] .canvas-field-card`);
      const card = fieldCards[insertIdx] || fieldCards[fieldCards.length - 1];
      if (card) {
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        card.classList.add('field-highlight-pulse');
        setTimeout(() => card.classList.remove('field-highlight-pulse'), 1800);
      }
    }, 100);

    const secTitle = this.formSchema.sections[secIdx].title || `Section ${secIdx + 1}`;
    this._showToast(`Placed "${cloned.label || cloned.formData}" at Position ${insertIdx + 1} in ${secTitle}!`);
  },

  reorderFields(fromSecIdx, fromFieldIdx, toSecIdx, toFieldIdx) {
    if (!this.formSchema.sections[fromSecIdx] || !this.formSchema.sections[toSecIdx]) return;
    const movedField = this.formSchema.sections[fromSecIdx].fields.splice(fromFieldIdx, 1)[0];
    if (!movedField) return;

    let adjustedToIdx = toFieldIdx;
    if (fromSecIdx === toSecIdx && fromFieldIdx < toFieldIdx) {
      adjustedToIdx = toFieldIdx - 1;
    }
    if (adjustedToIdx < 0) adjustedToIdx = 0;
    if (adjustedToIdx > this.formSchema.sections[toSecIdx].fields.length) {
      adjustedToIdx = this.formSchema.sections[toSecIdx].fields.length;
    }

    this.formSchema.sections[toSecIdx].fields.splice(adjustedToIdx, 0, movedField);
    this.saveFormToStorage();
    this.render();

    this.selectedFieldLoc = { sectionIndex: toSecIdx, fieldIndex: adjustedToIdx };

    setTimeout(() => {
      const fieldCards = document.querySelectorAll(`.canvas-section-card[data-section-index="${toSecIdx}"] .canvas-field-card`);
      const card = fieldCards[adjustedToIdx];
      if (card) {
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        card.classList.add('field-highlight-pulse');
        setTimeout(() => card.classList.remove('field-highlight-pulse'), 1800);
      }
    }, 100);

    const secTitle = this.formSchema.sections[toSecIdx].title || `Section ${toSecIdx + 1}`;
    this._showToast(`Moved "${movedField.label || movedField.formData}" to Position ${adjustedToIdx + 1} in ${secTitle}!`);
  },

  setFieldWidth(secIdx, fieldIdx, colClass) {
    const field = this.formSchema.sections[secIdx]?.fields[fieldIdx];
    if (field) {
      field.col = colClass;
      this.saveFormToStorage();
      this.render();
      if (this.selectedFieldLoc &&
        this.selectedFieldLoc.sectionIndex === secIdx &&
        this.selectedFieldLoc.fieldIndex === fieldIdx) {
        this.updateWidthPills(colClass);
      }
    }
  },

  deleteField(secIdx, fieldIdx) {
    this.formSchema.sections[secIdx].fields.splice(fieldIdx, 1);
    this.saveFormToStorage();
    this.render();
    this._refreshSidebarPreserveScroll();
  },

  ensureUniqueKey(baseKey) {
    const allKeys = new Set();
    (this.formSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => allKeys.add(f.formData));
    });

    if (!allKeys.has(baseKey)) return baseKey;
    let counter = 1;
    while (allKeys.has(baseKey + counter)) {
      counter++;
    }
    return baseKey + counter;
  },

  // ------------------------------------------------------------------------
  // Reusable Section & Field Library Operations
  // ------------------------------------------------------------------------
  saveSectionAsTemplate(secIdx) {
    const sec = this.formSchema.sections[secIdx];
    if (!sec) return;

    const name = prompt('Enter a name for this reusable section template:', sec.title || 'Custom Section');
    if (!name) return;

    const trimmedName = name.trim();
    const existingIdx = (this.reusableSections || []).findIndex(s =>
      (s.title || '').toLowerCase() === trimmedName.toLowerCase()
    );

    const clonedSec = JSON.parse(JSON.stringify(sec));
    clonedSec.title = trimmedName;

    if (existingIdx >= 0 && confirm(`A reusable section named "${trimmedName}" already exists.\nClick OK to update it, or Cancel to save as a new copy.`)) {
      const existing = this.reusableSections[existingIdx];
      existing.title = trimmedName;
      existing.description = `${clonedSec.fields?.length || 0} fields`;
      existing.data = clonedSec;
      this.saveLibraries();
      this.renderSidebar();
      this._showToast(`Updated reusable section "${trimmedName}"!`);
      return;
    }

    this.reusableSections.push({
      id: 'custom_sec_' + Date.now(),
      title: trimmedName,
      badge: 'Custom',
      icon: '📋',
      description: `${clonedSec.fields?.length || 0} fields`,
      data: clonedSec
    });

    this.saveLibraries();
    this.renderSidebar();
    this._showToast(`Saved "${trimmedName}" to Reusable Sections!`);
  },

  openNewReusableSectionModal() {
    this.editingReusableSectionIdx = -1;
    this._tempReusableSecFields = [];
    this._showReusableSectionModal('Create New Reusable Section', '', 'Custom', '📋', '');
  },

  openEditReusableSectionModal(idx) {
    const sec = (this.reusableSections || [])[idx];
    if (!sec) return;
    this.editingReusableSectionIdx = idx;
    this._tempReusableSecFields = JSON.parse(JSON.stringify(sec.data?.fields || []));
    this._showReusableSectionModal(
      `Edit Reusable Section: ${sec.title || 'Section'}`,
      sec.title || sec.data?.title || '',
      sec.badge || 'Custom',
      sec.icon || '📋',
      sec.description || ''
    );
  },

  _showReusableSectionModal(modalTitle, title, badge, icon, desc) {
    const modal = document.getElementById('modalEditReusableSection');
    if (!modal) return;
    modal.style.cssText = 'display:flex!important;opacity:1!important;pointer-events:auto!important;position:fixed;inset:0;background:rgba(0,14,52,0.7);align-items:center;justify-content:center;z-index:9999;';
    modal.classList.add('open');

    const dialog = modal.querySelector('.mops-modal-dialog');
    if (dialog) {
      dialog.style.cssText = 'display:flex!important;opacity:1!important;visibility:visible!important;transform:scale(1) translateY(0)!important;pointer-events:auto!important;flex-direction:column;background:#ffffff;border-radius:10px;max-width:620px;width:95%;max-height:90vh;box-shadow:0 25px 50px -12px rgba(0,0,0,0.25);overflow:hidden;animation:none!important;';
    }

    const titleHeader = document.getElementById('editReusableSectionModalTitle');
    if (titleHeader) titleHeader.textContent = modalTitle;

    const inpTitle = document.getElementById('inputReusableSecTitle');
    const inpBadge = document.getElementById('inputReusableSecBadge');
    const inpIcon = document.getElementById('inputReusableSecIcon');
    const inpDesc = document.getElementById('inputReusableSecDesc');
    if (inpTitle) inpTitle.value = title;
    if (inpBadge) inpBadge.value = badge;
    if (inpIcon) inpIcon.value = icon;
    if (inpDesc) inpDesc.value = desc;

    const delBtn = document.getElementById('btnDeleteReusableSection');
    if (delBtn) delBtn.style.display = this.editingReusableSectionIdx >= 0 ? 'inline-flex' : 'none';

    const loadBtn = document.getElementById('btnLoadReusableSecToCanvas');
    if (loadBtn) loadBtn.style.display = this.editingReusableSectionIdx >= 0 ? 'inline-flex' : 'none';

    this._renderReusableSectionModalFields();
  },

  _renderReusableSectionModalFields() {
    const listEl = document.getElementById('reusableSecFieldsEditorList');
    const countEl = document.getElementById('reusableSecFieldCount');
    const fields = this._tempReusableSecFields || [];
    if (countEl) countEl.textContent = fields.length;
    if (!listEl) return;

    if (fields.length === 0) {
      listEl.innerHTML = `<div style="font-size:12px;color:#94a3b8;text-align:center;padding:14px;">No fields yet. You can save this empty section or build fields on the canvas and click <strong>Template</strong> on the section header.</div>`;
      return;
    }

    listEl.innerHTML = fields.map((f, fIdx) => `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 8px;background:#fff;border:1px solid #e2e8f0;border-radius:5px;margin-bottom:5px;font-size:12px;">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;flex:1;">
          <span style="color:#64748b;font-size:10px;background:#f1f5f9;padding:1px 5px;border-radius:3px;">${f.type || 'text'}</span>
          <span style="font-weight:600;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${f.label || f.formData || 'Untitled'}</span>
          ${f.required ? '<span style="color:#ef4444;font-weight:700;">*</span>' : ''}
        </div>
        <button type="button" class="btn-saved-action btn-danger-hover" title="Remove field from section" onclick="App.removeFieldFromReusableSectionModal(${fIdx})">×</button>
      </div>
    `).join('');
  },

  removeFieldFromReusableSectionModal(fIdx) {
    if (!Array.isArray(this._tempReusableSecFields)) return;
    this._tempReusableSecFields.splice(fIdx, 1);
    this._renderReusableSectionModalFields();
  },

  loadReusableSectionToCanvasForEdit() {
    const idx = this.editingReusableSectionIdx;
    const sec = (this.reusableSections || [])[idx];
    if (!sec) return;
    this.closeEditReusableSectionModal();
    this.insertReusableSection(sec.data);
    this._showToast(`Loaded "${sec.title}" onto canvas. Edit its fields, then click "Template" on the section header to save updates.`);
  },

  saveReusableSectionModal() {
    const title = (document.getElementById('inputReusableSecTitle')?.value || '').trim();
    if (!title) {
      alert('Please enter a section title.');
      return;
    }
    const badge = (document.getElementById('inputReusableSecBadge')?.value || 'Custom').trim() || 'Custom';
    const icon = (document.getElementById('inputReusableSecIcon')?.value || '📋').trim() || '📋';
    const fields = JSON.parse(JSON.stringify(this._tempReusableSecFields || []));
    const desc = (document.getElementById('inputReusableSecDesc')?.value || '').trim() || `${fields.length} field${fields.length !== 1 ? 's' : ''}`;

    if (this.editingReusableSectionIdx >= 0 && this.reusableSections[this.editingReusableSectionIdx]) {
      const target = this.reusableSections[this.editingReusableSectionIdx];
      target.title = title;
      target.badge = badge;
      target.icon = icon;
      target.description = desc;
      target.data = target.data || {};
      target.data.title = title;
      target.data.fields = fields;
      this._showToast(`Updated reusable section "${title}"!`);
    } else {
      this.reusableSections.push({
        id: 'custom_sec_' + Date.now(),
        title,
        badge,
        icon,
        description: desc,
        data: {
          title,
          id: 'Custom_' + Date.now(),
          condition: null,
          fields
        }
      });
      this._showToast(`Created reusable section "${title}"!`);
    }

    this.saveLibraries();
    this.renderSidebar();
    this.closeEditReusableSectionModal();
  },

  deleteReusableSection(idx, fromModal) {
    const sec = (this.reusableSections || [])[idx];
    if (!sec) return;
    if (!confirm(`Delete reusable section "${sec.title}" from your library?`)) return;
    this.reusableSections.splice(idx, 1);
    this.saveLibraries();
    this.renderSidebar();
    if (fromModal) this.closeEditReusableSectionModal();
    this._showToast(`Deleted reusable section "${sec.title}".`);
  },

  closeEditReusableSectionModal() {
    const modal = document.getElementById('modalEditReusableSection');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
    }
    this.editingReusableSectionIdx = -1;
    this._tempReusableSecFields = [];
  },

  insertReusableSection(secData, targetIdx) {
    this.ensureActiveForm();
    const cloned = JSON.parse(JSON.stringify(secData));
    // If the form has only 1 section and it is completely empty (0 fields), replace it directly!
    if (this.formSchema.sections.length === 1 && (!this.formSchema.sections[0].fields || this.formSchema.sections[0].fields.length === 0)) {
      this.formSchema.sections[0] = cloned;
    } else if (targetIdx !== undefined && targetIdx >= 0) {
      this.formSchema.sections.splice(targetIdx, 0, cloned);
    } else {
      this.formSchema.sections.push(cloned);
    }
    this.saveFormToStorage();
    this.render();
    this._showToast(`Added Section "${cloned.title || 'Section'}" to form!`);
  },

  insertPaletteField(type, targetSecIdx) {
    if (type !== 'empty_field') {
      this.ensureActiveForm();
      if (!this.formSchema.sections || this.formSchema.sections.length === 0) {
        this.addSection();
      }
      let secIdx = 0;
      if (targetSecIdx !== undefined && targetSecIdx >= 0 && targetSecIdx < this.formSchema.sections.length) {
        secIdx = targetSecIdx;
      } else if (this.selectedFieldLoc && this.selectedFieldLoc.sectionIndex !== undefined && this.selectedFieldLoc.sectionIndex < this.formSchema.sections.length) {
        secIdx = this.selectedFieldLoc.sectionIndex;
      }
      this.openCreateLibraryFieldModal(type, { secIdx, fieldIdx: null, col: 'col-lg-6' });
      return;
    }
    this.ensureActiveForm();
    let paletteDef = (window.DEFAULT_PALETTE_ITEMS || []).find(p => p.type === type);
    if (!paletteDef && type === 'empty_field') {
      paletteDef = {
        name: 'Empty Field',
        defaultData: { label: 'Empty Space', formData: 'emptySpace', col: 'col-lg-6', required: false, type: 'empty_field', condition: null }
      };
    }
    if (!paletteDef) return;

    if (!this.formSchema.sections || this.formSchema.sections.length === 0) {
      this.addSection();
    }

    let secIdx = 0;
    if (targetSecIdx !== undefined && targetSecIdx >= 0 && targetSecIdx < this.formSchema.sections.length) {
      secIdx = targetSecIdx;
    } else if (this.selectedFieldLoc && this.selectedFieldLoc.sectionIndex !== undefined && this.selectedFieldLoc.sectionIndex < this.formSchema.sections.length) {
      secIdx = this.selectedFieldLoc.sectionIndex;
    } else {
      secIdx = 0;
    }

    this.addFieldToSection(secIdx, paletteDef.defaultData);

    const targetSec = this.formSchema.sections[secIdx];
    const newFieldIdx = (targetSec?.fields || []).length - 1;
    const fieldName = paletteDef.name || paletteDef.label || 'Field';
    const secTitle = targetSec?.title || `Section ${secIdx + 1}`;

    if (type !== 'empty_field') {
      this.selectedFieldLoc = { sectionIndex: secIdx, fieldIndex: newFieldIdx };
    }

    setTimeout(() => {
      const fieldCards = document.querySelectorAll(`.canvas-section-card[data-section-index="${secIdx}"] .canvas-field-card`);
      const lastCard = fieldCards[newFieldIdx] || fieldCards[fieldCards.length - 1];
      if (lastCard) {
        lastCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        lastCard.classList.add('field-highlight-pulse');
        setTimeout(() => lastCard.classList.remove('field-highlight-pulse'), 1800);
      }
    }, 100);

    this._showToast(`Added "${fieldName}" to ${secTitle}!`);
  },

  populateEmptySectionWithTemplate(secIdx, secData) {
    const cloned = JSON.parse(JSON.stringify(secData));
    this.formSchema.sections[secIdx] = cloned;
    this.saveFormToStorage();
    this.render();
  },

  addQuickField(secIdx, type) {
    const paletteDef = (window.DEFAULT_PALETTE_ITEMS || []).find(p => p.type === type);
    if (paletteDef) {
      this.addFieldToSection(secIdx, paletteDef.defaultData);
    }
  },

  saveSelectedFieldToLibrary() {
    if (!this.selectedFieldLoc) return;
    const { sectionIndex, fieldIndex } = this.selectedFieldLoc;
    const field = this.formSchema.sections[sectionIndex]?.fields[fieldIndex];
    if (!field) return;

    const name = prompt('Enter a name for this saved reusable field:', field.label || field.formData);
    if (!name) return;

    // Field Definition vs Form-Specific Logic:
    // Core attributes (Label, Type, Picklist Options, Placeholder, Tooltip, col, required) are saved to library.
    // Display logic is cleared so that when this field is reused in another form, it has a clean slate for that form's own logic!
    const reusableFieldDef = JSON.parse(JSON.stringify(field));
    reusableFieldDef.condition = null;
    reusableFieldDef.conditionType = null;
    reusableFieldDef.advancedLogic = null;

    this.reusableFields.push({
      label: name,
      badge: 'Custom',
      data: reusableFieldDef
    });

    this.saveLibraries();
    this.renderSidebar();
    alert(`Saved "${name}" to Reusable Fields!\n\nNote: Its core type and options were saved. When reused in another form, you can configure form-specific display logic tailored to that form.`);
  },

  insertReusableField(idx, targetSecIdx, directFieldData) {
    this.ensureActiveForm();
    let fData = directFieldData;
    let fieldLabel = 'Field';
    if (!fData && idx !== null && idx !== undefined && this.reusableFields && this.reusableFields[idx]) {
      const f = this.reusableFields[idx];
      if (f.status === 'inactive') {
        this._showToast(`"${f.label}" is Inactive. Reactivate it in WF Field Library to add to forms.`);
        return;
      }
      fData = JSON.parse(JSON.stringify(f.data));
      fData.wfLibraryFieldId = f.id || fData.id || fData.formData;
      fData.wfObject = f.wfObject || fData.wfObject || 'Project';
      fData.wfFieldName = fData.wfFieldName || fData.formData;
      fData.wfLabel = fData.wfLabel || fData.label;
      if (Array.isArray(f.wfFormIds) && !fData.wfFormIds) fData.wfFormIds = [...f.wfFormIds];
      if (Array.isArray(f.wfFormLabels) && !fData.wfFormLabels) fData.wfFormLabels = [...f.wfFormLabels];
      fieldLabel = f.label || f.data?.label || 'Field';
    }
    if (!fData) return;

    if (!this.formSchema.sections || this.formSchema.sections.length === 0) {
      this.addSection();
    }

    let secIdx = 0;
    if (targetSecIdx !== undefined && targetSecIdx >= 0 && targetSecIdx < this.formSchema.sections.length) {
      secIdx = targetSecIdx;
    } else if (this.selectedFieldLoc && this.selectedFieldLoc.sectionIndex !== undefined && this.selectedFieldLoc.sectionIndex < this.formSchema.sections.length) {
      secIdx = this.selectedFieldLoc.sectionIndex;
    } else {
      secIdx = 0;
    }

    this.addFieldToSection(secIdx, fData);

    const targetSec = this.formSchema.sections[secIdx];
    const newFieldIdx = (targetSec?.fields || []).length - 1;
    const secTitle = targetSec?.title || `Section ${secIdx + 1}`;

    this.selectedFieldLoc = { sectionIndex: secIdx, fieldIndex: newFieldIdx };

    setTimeout(() => {
      const fieldCards = document.querySelectorAll(`.canvas-section-card[data-section-index="${secIdx}"] .canvas-field-card`);
      const lastCard = fieldCards[newFieldIdx] || fieldCards[fieldCards.length - 1];
      if (lastCard) {
        lastCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        lastCard.classList.add('field-highlight-pulse');
        setTimeout(() => lastCard.classList.remove('field-highlight-pulse'), 1800);
      }
    }, 100);

    this._showToast(`Added "${fieldLabel}" to ${secTitle}!`);
  },

  _canDeleteSavedField(f) {
    if (!f) return false;
    const key = f.data?.formData || f.label;
    const usages = typeof this.getFieldWhereUsed === 'function' ? this.getFieldWhereUsed(key) : [];
    const uniqueForms = Array.from(new Map(usages.map(u => [u.formId, u.formLabel || u.formId])).values());
    if (uniqueForms.length >= 1) {
      alert(
        `Cannot permanently delete "${f.label || key}" because it is currently referenced by ${uniqueForms.length} active Intake form(s):\n\n` +
        uniqueForms.map(name => `• ${name}`).join('\n') +
        `\n\nPlease use "Deactivate" instead, or remove this field from all Intake forms before deleting.`
      );
      return false;
    }
    return true;
  },

  toggleSavedFieldStatus(idx) {
    const f = this.reusableFields?.[idx];
    if (!f) return;
    const nextStatus = f.status === 'inactive' ? 'active' : 'inactive';
    if (nextStatus === 'inactive') {
      const key = f.data?.formData || f.label;
      const usages = typeof this.getFieldWhereUsed === 'function' ? this.getFieldWhereUsed(key) : [];
      if (usages.length > 0) {
        const formNames = Array.from(new Set(usages.map(u => u.formLabel))).join(', ');
        if (!confirm(`"${f.label}" is currently used in ${usages.length} Intake form(s) (${formNames}).\n\nDeactivating will hide it from new forms while preserving existing form instances. Continue?`)) {
          return;
        }
      }
    }
    f.status = nextStatus;
    f.updatedAt = new Date().toISOString();
    this.saveLibraries().catch(err => this._showToast(err.message));
    this.renderSidebar();
    this._showToast(`"${f.label}" marked as ${nextStatus === 'active' ? 'Active' : 'Inactive'}.`);
  },

  toggleCurrentSavedFieldStatus() {
    if (this.editingSavedFieldIdx === null || this.editingSavedFieldIdx === undefined) return;
    this.toggleSavedFieldStatus(this.editingSavedFieldIdx);
    this.closeEditSavedFieldModal();
  },

  deleteReusableField(idx) {
    const f = this.reusableFields[idx];
    if (!this._canDeleteSavedField(f)) return;
    if (confirm(`Remove "${f.label}" from your Saved Fields library?`)) {
      this.reusableFields.splice(idx, 1);
      this.saveLibraries();
      this.renderSidebar();
    }
  },

  openCreateLibraryFieldModal(presetType = 'text', pendingDropTarget = null) {
    this.editingSavedFieldIdx = null;
    this._pendingCreateDropTarget = pendingDropTarget || null;
    this._duplicateMatchedIdx = null;
    const modal = document.getElementById('modalEditSavedField');
    if (!modal) return;

    // Force backdrop visible
    modal.style.cssText = 'display:flex!important;opacity:1!important;pointer-events:auto!important;position:fixed;inset:0;background:rgba(0,14,52,0.7);align-items:center;justify-content:center;z-index:9999;';
    modal.classList.add('open');

    // Force dialog visible  inline style wins over ALL CSS rules including animations
    const dialog = modal.querySelector('.mops-modal-dialog');
    if (dialog) {
      dialog.style.cssText = 'display:flex!important;opacity:1!important;visibility:visible!important;transform:scale(1) translateY(0)!important;pointer-events:auto!important;flex-direction:column;background:#ffffff;border-radius:10px;max-width:650px;width:95%;max-height:90vh;box-shadow:0 25px 50px -12px rgba(0,0,0,0.25);overflow:hidden;animation:none!important;';
    }

    const titleEl = document.getElementById('editSavedFieldModalTitle');
    if (titleEl) titleEl.textContent = pendingDropTarget ? 'Create Workfront Field & Add to Form' : 'Create New Workfront Field';

    const dupBanner = document.getElementById('savedFieldDuplicateBanner');
    if (dupBanner) dupBanner.style.display = 'none';
    const safBanner = document.getElementById('savedFieldEditSafeguardBanner');
    if (safBanner) safBanner.style.display = 'none';
    const banner = document.getElementById('savedFieldWhereUsedBanner');
    if (banner) banner.style.display = 'none';

    const btnToggleStatus = document.getElementById('btnToggleSavedFieldStatus');
    if (btnToggleStatus) btnToggleStatus.style.display = 'none';
    const btnDelete = document.getElementById('btnDeleteCurrentSavedField');
    if (btnDelete) btnDelete.style.display = 'none';

    const btnInsert = document.getElementById('btnInsertCurrentSavedField');
    if (btnInsert) btnInsert.style.display = 'none';

    const btnSave = document.getElementById('btnSaveCurrentSavedField');
    if (btnSave) {
      btnSave.innerHTML = `<span class="icon-svg"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg></span> ${pendingDropTarget ? 'Create & Add to Form' : '+ Create Field'}`;
    }

    const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
    setVal('inputSavedFieldLibName', '');
    setVal('inputSavedFieldBadge', 'Custom');
    setVal('inputSavedFieldWfObject', 'Project');
    setVal('inputSavedFieldStatus', 'active');
    setVal('inputSavedFieldLabel', '');
    setVal('inputSavedFieldKey', '');
    setVal('inputSavedFieldType', presetType || 'text');
    setVal('inputSavedFieldWfId', '');
    setVal('inputSavedFieldPlaceholder', '');
    setVal('inputSavedFieldTooltip', '');

    const keyEl = document.getElementById('inputSavedFieldKey');
    const typeEl = document.getElementById('inputSavedFieldType');
    if (keyEl) { keyEl.disabled = false; keyEl.dataset.autoSync = 'true'; }
    if (typeEl) typeEl.disabled = false;
    const lblElReset = document.getElementById('inputSavedFieldLabel');
    if (lblElReset) lblElReset.dataset.autoSync = 'true';

    const chk = document.getElementById('chkSavedFieldRequired');
    if (chk) chk.checked = false;

    // Populate Workfront Custom Form(s) multi-select from registry (blank in new mode)
    App._populateWfSelectorsInFieldModal.call(App, []);

    this.onSavedFieldTypeChange();
    this.renderSavedFieldOptionsList(['Option 1', 'Option 2', 'Option 3']);

    // Live auto-generate key and label + live duplicate detection
    const libInput = document.getElementById('inputSavedFieldLibName');
    if (libInput) {
      libInput.oninput = (e) => {
        const val = e.target.value;
        const keyEl2 = document.getElementById('inputSavedFieldKey');
        const lblEl2 = document.getElementById('inputSavedFieldLabel');
        if (lblEl2 && (!lblEl2.value || lblEl2.dataset.autoSync === 'true')) {
          lblEl2.value = val;
          lblEl2.dataset.autoSync = 'true';
        }
        if (keyEl2 && (!keyEl2.value || keyEl2.dataset.autoSync === 'true')) {
          keyEl2.value = val.toLowerCase().replace(/[^a-z0-9]+(.)/g, (m, chr) => chr.toUpperCase()).replace(/[^a-zA-Z0-9]/g, '');
          keyEl2.dataset.autoSync = 'true';
        }
        this._checkSavedFieldDuplicatesLive();
      };
    }
    if (keyEl) {
      keyEl.oninput = () => {
        keyEl.dataset.autoSync = 'false';
        this._checkSavedFieldDuplicatesLive();
      };
    }
    if (lblElReset) {
      lblElReset.oninput = () => {
        lblElReset.dataset.autoSync = 'false';
        this._checkSavedFieldDuplicatesLive();
      };
    }

    setTimeout(() => { document.getElementById('inputSavedFieldLibName')?.focus(); }, 150);
  },

  findDuplicateWfField(name, apiName, wfObject, wfFormIds, excludeIdx = null) {
    const normName = String(name || '').trim().toLowerCase();
    const normApi = String(apiName || '').trim().replace(/\s+/g, '').toLowerCase();
    const normObj = String(wfObject || 'Project').trim().toLowerCase();
    const formSet = new Set(Array.isArray(wfFormIds) ? wfFormIds.filter(Boolean) : []);

    const list = this.reusableFields || [];
    for (let i = 0; i < list.length; i++) {
      if (excludeIdx !== null && excludeIdx !== undefined && i === excludeIdx) continue;
      const item = list[i];
      const itemApi = String(item.data?.formData || '').trim().replace(/\s+/g, '').toLowerCase();
      const itemName = String(item.label || '').trim().toLowerCase();
      const itemLabel = String(item.data?.label || '').trim().toLowerCase();
      const itemObj = String(item.wfObject || item.data?.wfObject || 'Project').trim().toLowerCase();
      const itemForms = Array.isArray(item.wfFormIds) ? item.wfFormIds : (Array.isArray(item.data?.wfFormIds) ? item.data.wfFormIds : (item.wfFormId || item.data?.wfFormId ? [item.wfFormId || item.data?.wfFormId] : []));

      const sameNamespace = (normObj === 'global' || itemObj === 'global' || normObj === itemObj);
      if (normApi && itemApi && normApi === itemApi && sameNamespace) {
        return { reason: 'api', idx: i, existing: item };
      }

      // Display name scope: check within same object AND overlapping custom form scope (or both unmapped)
      if (normName && (normName === itemName || normName === itemLabel) && sameNamespace) {
        const sharesForm = (formSet.size === 0 && itemForms.length === 0) || itemForms.some(fid => formSet.has(fid));
        if (sharesForm) {
          return { reason: 'name', idx: i, existing: item };
        }
      }
    }
    return null;
  },

  _checkSavedFieldDuplicatesLive() {
    const dupBanner = document.getElementById('savedFieldDuplicateBanner');
    if (!dupBanner) return null;
    const name = document.getElementById('inputSavedFieldLibName')?.value || document.getElementById('inputSavedFieldLabel')?.value || '';
    const apiName = document.getElementById('inputSavedFieldKey')?.value || '';
    const wfObject = document.getElementById('inputSavedFieldWfObject')?.value || 'Project';
    const wfFormIds = Array.from(document.querySelectorAll('#savedFieldWfFormsMultiList .saved-field-wf-form-chk:checked')).map(c => c.value);
    const excludeIdx = (this.editingSavedFieldIdx !== null && this.editingSavedFieldIdx !== undefined) ? this.editingSavedFieldIdx : null;

    const dup = this.findDuplicateWfField(name, apiName, wfObject, wfFormIds, excludeIdx);
    if (!dup) {
      dupBanner.style.display = 'none';
      this._duplicateMatchedIdx = null;
      return null;
    }

    this._duplicateMatchedIdx = dup.idx;
    const ex = dup.existing;
    const msgEl = document.getElementById('savedFieldDuplicateMsg');
    const metaEl = document.getElementById('savedFieldDuplicateMeta');
    if (msgEl) {
      msgEl.textContent = dup.reason === 'api'
        ? 'An existing Workfront field with this API name is already available in the WF Field Library.'
        : 'This field already exists in this Workfront object/custom form scope. Would you like to reuse the existing field?';
    }
    if (metaEl) {
      metaEl.innerHTML = `<strong>${ex.label || ex.data?.label || ''}</strong> · API: <code>${ex.data?.formData || ''}</code> · Type: <strong>${ex.data?.type || 'text'}</strong> · Object: <strong>${ex.wfObject || ex.data?.wfObject || 'Project'}</strong>`;
    }
    dupBanner.style.display = 'block';
    return dup;
  },

  reuseExistingDuplicateField() {
    const idx = this._duplicateMatchedIdx;
    if (idx === null || idx === undefined) return;
    const pending = this._pendingCreateDropTarget;
    this.closeEditSavedFieldModal();
    if (pending && pending.secIdx !== undefined) {
      const f = this.reusableFields?.[idx];
      if (!f) return;
      if (f.status === 'inactive') {
        this._showToast(`"${f.label}" is Inactive. Opening it so you can reactivate it.`);
        this.openEditSavedFieldModal(idx);
        return;
      }
      const fData = JSON.parse(JSON.stringify(f.data));
      fData.wfLibraryFieldId = f.id || fData.id || fData.formData;
      fData.wfObject = f.wfObject || fData.wfObject || 'Project';
      fData.wfFieldName = fData.wfFieldName || fData.formData;
      fData.wfLabel = fData.wfLabel || fData.label;
      if (pending.fieldIdx === null || pending.fieldIdx === undefined) {
        this.addFieldToSection(pending.secIdx, fData);
      } else {
        this.insertFieldAt(pending.secIdx, pending.fieldIdx, fData);
      }
      this._showToast(`Reused existing WF Field "${f.label}"!`);
    } else {
      this.openEditSavedFieldModal(idx);
    }
  },

  openEditSavedFieldModal(idx) {
    const modal = document.getElementById('modalEditSavedField');
    if (!modal) return;
    this._pendingCreateDropTarget = null;
    this._duplicateMatchedIdx = null;

    // Force backdrop visible
    modal.style.cssText = 'display:flex!important;opacity:1!important;pointer-events:auto!important;position:fixed;inset:0;background:rgba(0,14,52,0.7);align-items:center;justify-content:center;z-index:9999;';
    modal.classList.add('open');

    // Force dialog visible  inline style wins over ALL CSS rules including animations
    const dialog = modal.querySelector('.mops-modal-dialog');
    if (dialog) {
      dialog.style.cssText = 'display:flex!important;opacity:1!important;visibility:visible!important;transform:scale(1) translateY(0)!important;pointer-events:auto!important;flex-direction:column;background:#ffffff;border-radius:10px;max-width:650px;width:95%;max-height:90vh;box-shadow:0 25px 50px -12px rgba(0,0,0,0.25);overflow:hidden;animation:none!important;';
    }

    const dupBanner = document.getElementById('savedFieldDuplicateBanner');
    if (dupBanner) dupBanner.style.display = 'none';

    const banner = document.getElementById('savedFieldWhereUsedBanner');
    if (banner) banner.style.display = 'flex';

    const btnDelete = document.getElementById('btnDeleteCurrentSavedField');
    if (btnDelete) btnDelete.style.display = 'inline-flex';

    const btnInsert = document.getElementById('btnInsertCurrentSavedField');
    if (btnInsert) btnInsert.style.display = 'inline-flex';

    const btnSave = document.getElementById('btnSaveCurrentSavedField');
    if (btnSave) {
      btnSave.innerHTML = `<span class="icon-svg"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg></span> Save Changes`;
    }
    this.editingSavedFieldIdx = idx;
    const f = this.reusableFields[idx];
    if (!f || !f.data) return;

    const titleEl = document.getElementById('editSavedFieldModalTitle');
    if (titleEl) titleEl.textContent = `WF Field: ${f.label || f.data.formData || 'Field'}`;

    const libName = document.getElementById('inputSavedFieldLibName');
    if (libName) {
      libName.value = f.label || '';
      libName.oninput = () => this._checkSavedFieldDuplicatesLive();
    }

    const badge = document.getElementById('inputSavedFieldBadge');
    if (badge) badge.value = f.badge || 'Standard';

    const wfObjEl = document.getElementById('inputSavedFieldWfObject');
    if (wfObjEl) wfObjEl.value = f.wfObject || f.data.wfObject || 'Project';

    const statusEl = document.getElementById('inputSavedFieldStatus');
    if (statusEl) statusEl.value = f.status === 'inactive' ? 'inactive' : 'active';

    const btnToggleStatus = document.getElementById('btnToggleSavedFieldStatus');
    if (btnToggleStatus) {
      btnToggleStatus.style.display = 'inline-flex';
      btnToggleStatus.textContent = f.status === 'inactive' ? 'Reactivate' : 'Deactivate';
    }

    const lbl = document.getElementById('inputSavedFieldLabel');
    if (lbl) {
      lbl.value = f.data.label || '';
      lbl.oninput = () => this._checkSavedFieldDuplicatesLive();
    }

    const key = document.getElementById('inputSavedFieldKey');
    if (key) {
      key.value = f.data.formData || '';
      key.oninput = () => this._checkSavedFieldDuplicatesLive();
    }

    const type = document.getElementById('inputSavedFieldType');
    if (type) type.value = f.data.type || 'text';

    const wfId = document.getElementById('inputSavedFieldWfId');
    if (wfId) wfId.value = f.data.id || '';

    const ph = document.getElementById('inputSavedFieldPlaceholder');
    if (ph) ph.value = f.data.placeholder || '';

    const tip = document.getElementById('inputSavedFieldTooltip');
    if (tip) tip.value = f.data.tooltip || '';

    const req = document.getElementById('chkSavedFieldRequired');
    if (req) req.checked = Boolean(f.data.required);

    // Edit safeguard: lock API Name & Field Type if field is used in active Intake Forms
    const usages = typeof this.getFieldWhereUsed === 'function'
      ? this.getFieldWhereUsed(f.data.formData || f.label)
      : [];
    const safBanner = document.getElementById('savedFieldEditSafeguardBanner');
    const safText = document.getElementById('savedFieldEditSafeguardText');
    const unlockBtn = document.getElementById('btnUnlockWfApiFields');
    if (usages.length > 0) {
      if (key) key.disabled = true;
      if (type) type.disabled = true;
      if (safBanner) safBanner.style.display = 'block';
      if (safText) {
        const formNames = Array.from(new Set(usages.map(u => u.formLabel))).slice(0, 3).join(', ');
        safText.textContent = `Used in ${usages.length} Intake form(s) (${formNames}). WF API Name and Field Type are locked to protect integrations.`;
      }
      if (unlockBtn) unlockBtn.style.display = 'inline-flex';
    } else {
      if (key) key.disabled = false;
      if (type) type.disabled = false;
      if (safBanner) safBanner.style.display = 'none';
    }

    this.onSavedFieldTypeChange();
    this.renderSavedFieldOptionsList(f.data.options || []);

    // Populate Workfront Custom Form(s) multi-select from registry and restore selections
    const existingWfFormIds = Array.isArray(f.data.wfFormIds) && f.data.wfFormIds.length
      ? f.data.wfFormIds
      : (Array.isArray(f.wfFormIds) && f.wfFormIds.length ? f.wfFormIds : ((f.data.wfFormId || f.wfFormId) ? [f.data.wfFormId || f.wfFormId] : []));
    App._populateWfSelectorsInFieldModal.call(App, existingWfFormIds);

    this.updateSavedFieldWhereUsedBanner(f);
  },

  unlockSavedFieldProtectedProps() {
    if (!confirm('Changing WF Field API Name or Field Type can break existing Workfront mappings and Intake Forms.\n\nUnlock these fields for editing?')) {
      return;
    }
    const key = document.getElementById('inputSavedFieldKey');
    const type = document.getElementById('inputSavedFieldType');
    if (key) key.disabled = false;
    if (type) type.disabled = false;
    const unlockBtn = document.getElementById('btnUnlockWfApiFields');
    if (unlockBtn) unlockBtn.style.display = 'none';
  },

  closeEditSavedFieldModal() {
    const modal = document.getElementById('modalEditSavedField');
    if (modal) {
      modal.classList.remove('open');
      modal.style.cssText = 'display:none;opacity:0;pointer-events:none;';
      const dialog = modal.querySelector('.mops-modal-dialog');
      if (dialog) dialog.style.cssText = '';
    }
    this.editingSavedFieldIdx = null;
    this._pendingCreateDropTarget = null;
    this._duplicateMatchedIdx = null;
  },

  onSavedFieldTypeChange() {
    const type = document.getElementById('inputSavedFieldType')?.value;
    const container = document.getElementById('savedFieldOptionsContainer');
    if (!container) return;
    const hasOptions = ['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'visual_cards'].includes(type);
    container.style.display = hasOptions ? 'block' : 'none';
  },

  renderSavedFieldOptionsList(options) {
    const list = document.getElementById('savedFieldOptionsList');
    if (!list) return;
    list.innerHTML = '';
    const opts = (Array.isArray(options) && options.length > 0) ? options : ['Option 1', 'Option 2'];
    opts.forEach((opt) => {
      const optVal = typeof opt === 'object' && opt !== null ? (opt.label || opt.value || '') : opt;
      const row = document.createElement('div');
      row.className = 'saved-opt-row';
      row.style.cssText = 'display: flex; gap: 6px; align-items: center;';
      row.innerHTML = `
        <input type="text" class="mops-input saved-opt-val" value="${optVal}">
        <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.saved-opt-row').remove()"></button>
      `;
      list.appendChild(row);
    });
  },

  addSavedFieldOption() {
    const list = document.getElementById('savedFieldOptionsList');
    if (!list) return;
    const count = list.children.length + 1;
    const row = document.createElement('div');
    row.className = 'saved-opt-row';
    row.style.cssText = 'display: flex; gap: 6px; align-items: center;';
    row.innerHTML = `
      <input type="text" class="mops-input saved-opt-val" value="Option ${count}">
      <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.saved-opt-row').remove()"></button>
    `;
    list.appendChild(row);
    row.querySelector('input')?.focus();
  },

  saveCurrentSavedFieldChanges(forceAction = null) {
    const isNew = (this.editingSavedFieldIdx === null || this.editingSavedFieldIdx === undefined);
    const f = isNew ? null : this.reusableFields[this.editingSavedFieldIdx];
    if (!isNew && (!f || !f.data)) return;

    const libName = document.getElementById('inputSavedFieldLibName').value.trim();
    const badge = document.getElementById('inputSavedFieldBadge').value.trim() || 'Custom';
    const wfObject = document.getElementById('inputSavedFieldWfObject')?.value || 'Project';
    const status = document.getElementById('inputSavedFieldStatus')?.value || 'active';
    const label = document.getElementById('inputSavedFieldLabel').value.trim();
    const key = document.getElementById('inputSavedFieldKey').value.trim();
    const type = document.getElementById('inputSavedFieldType').value;
    const wfId = document.getElementById('inputSavedFieldWfId').value.trim();
    const placeholder = document.getElementById('inputSavedFieldPlaceholder').value;
    const tooltip = document.getElementById('inputSavedFieldTooltip').value;
    const required = document.getElementById('chkSavedFieldRequired').checked;
    // Read Workfront Custom Form(s) multi-select checkboxes
    const checkedWfBoxes = Array.from(document.querySelectorAll('#savedFieldWfFormsMultiList .saved-field-wf-form-chk:checked'));
    const wfFormIds = checkedWfBoxes.map(cb => cb.value).filter(Boolean);
    const wfFormLabels = checkedWfBoxes.map(cb => cb.dataset.label || cb.value).filter(Boolean);
    const wfFormId = wfFormIds[0] || '';
    const wfFormLabel = wfFormLabels.join(', ');

    if (isNew && !libName && !label && !key) {
      alert('Please enter a WF Field Name or Workfront Field API Name.');
      return;
    }

    // Duplicate validation (WF Field Name & WF API Name)
    const dup = this._checkSavedFieldDuplicatesLive();
    if (dup) {
      const msg = dup.reason === 'api'
        ? 'An existing Workfront field with this API name is already available in the WF Field Library.'
        : 'This field already exists in this Workfront object/custom form scope. Would you like to reuse the existing field?';
      this._showToast(msg);
      return;
    }

    let newOptions = [];
    if (['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'visual_cards'].includes(type)) {
      const optInputs = document.querySelectorAll('#savedFieldOptionsList .saved-opt-val');
      newOptions = Array.from(optInputs).map(inp => inp.value.trim()).filter(Boolean);
      if (newOptions.length === 0) newOptions = ['Option 1', 'Option 2'];
    }

    if (isNew) {
      // Create and save new reusable field to central WF Field Library
      const autoKey = key || (libName || label).toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/^_+|_+$/g, '') || ('field_' + Date.now());
      const nowIso = new Date().toISOString();
      const userSig = this.getCurrentUserSignature();
      const libId = wfId || ('wf_' + Date.now());
      const newFieldObj = {
        id: libId,
        label: libName || label || autoKey,
        badge: badge || 'Custom',
        wfObject,
        status,
        wfFormId,
        wfFormLabel,
        wfFormIds,
        wfFormLabels,
        createdAt: nowIso,
        createdBy: userSig,
        updatedAt: nowIso,
        updatedBy: userSig,
        data: {
          wfLibraryFieldId: libId,
          wfObject,
          label: label || libName || 'Field',
          wfLabel: label || libName || 'Field',
          formData: autoKey,
          wfFieldName: autoKey,
          type: type || 'text',
          id: wfId || '',
          wfFormId,
          wfFormLabel,
          wfFormIds,
          wfFormLabels,
          placeholder: placeholder || '',
          tooltip: tooltip || '',
          required: Boolean(required),
          col: 'col-lg-6',
          _createdAt: nowIso,
          _createdBy: userSig,
          _updatedAt: nowIso,
          _updatedBy: userSig
        }
      };
      if (['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'visual_cards'].includes(type)) {
        newFieldObj.data.options = newOptions;
      }
      this.reusableFields.unshift(newFieldObj);
      const pendingDrop = this._pendingCreateDropTarget;
      this.saveLibraries().catch(err => {
        this.reusableFields.shift();
        this.renderSidebar();
        alert(err.message);
      });
      this.renderSidebar();
      this.closeEditSavedFieldModal();
      if (pendingDrop && pendingDrop.secIdx !== undefined && status !== 'inactive') {
        const instData = JSON.parse(JSON.stringify(newFieldObj.data));
        if (pendingDrop.fieldIdx === null || pendingDrop.fieldIdx === undefined) {
          this.addFieldToSection(pendingDrop.secIdx, instData);
        } else {
          this.insertFieldAt(pendingDrop.secIdx, pendingDrop.fieldIdx, instData);
        }
        this._showToast(`Created "${newFieldObj.label}" in WF Field Library & added to form!`);
      } else {
        this._showToast(`Registered "${newFieldObj.label}" in WF Field Library!`);
      }
      return;
    }

    const originalOptions = Array.isArray(f.data.options) ? [...f.data.options] : [];
    // Check cross-form usage impact
    const fieldIdentifier = key || f.data.formData || f.label;
    const usages = this.getFieldWhereUsed(fieldIdentifier);

    if (!forceAction && usages.length > 1 && ['select', 'radio', 'multiselect_fancy', 'visual_cards'].includes(type)) {
      const removed = originalOptions.filter(o => !newOptions.includes(o));
      const added = newOptions.filter(o => !originalOptions.includes(o));

      if (removed.length > 0 || added.length > 0) {
        // Trigger Shared Field Impact Alert
        this._pendingFieldImpactSave = {
          idx: this.editingSavedFieldIdx,
          newProps: { libName, badge, label, key, type, wfId, placeholder, tooltip, required, options: newOptions },
          originalOptions,
          removed,
          added,
          usages
        };
        this.openSharedFieldImpactModal(fieldIdentifier, usages, removed, added);
        return;
      }
    }

    const nowIso = new Date().toISOString();
    const userSig = this.getCurrentUserSignature();
    f.updatedAt = nowIso;
    f.updatedBy = userSig;
    if (!f.createdAt) { f.createdAt = nowIso; f.createdBy = userSig; }
    f.data._updatedAt = nowIso;
    f.data._updatedBy = userSig;
    if (!f.data._createdAt) { f.data._createdAt = nowIso; f.data._createdBy = userSig; }

    f.label = libName || label || key || 'Custom Field';
    f.badge = badge;
    f.wfObject = wfObject;
    f.status = status;
    f.wfFormId = wfFormId;
    f.wfFormLabel = wfFormLabel;
    f.wfFormIds = wfFormIds;
    f.wfFormLabels = wfFormLabels;
    f.data.wfObject = wfObject;
    f.data.label = label;
    f.data.wfLabel = label;
    f.data.formData = key || f.data.formData;
    f.data.wfFieldName = f.data.formData;
    f.data.type = type;
    f.data.id = wfId;
    f.data.wfFormId = wfFormId;
    f.data.wfFormLabel = wfFormLabel;
    f.data.wfFormIds = wfFormIds;
    f.data.wfFormLabels = wfFormLabels;
    f.data.placeholder = placeholder;
    f.data.tooltip = tooltip;
    f.data.required = required;
    if (['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'visual_cards'].includes(type)) {
      f.data.options = newOptions;
    }

    // If global action confirmed, sync options to all other form schemas
    if (forceAction === 'global') {
      this.syncFieldOptionsGlobally(fieldIdentifier, newOptions);
    }

    this.saveLibraries().catch(err => alert(err.message));
    this.renderSidebar();
    this.closeEditSavedFieldModal();
  },

  deleteCurrentSavedField() {
    if (this.editingSavedFieldIdx === null || this.editingSavedFieldIdx === undefined) return;
    const idx = this.editingSavedFieldIdx;
    const f = this.reusableFields[idx];
    if (!this._canDeleteSavedField(f)) return;
    if (confirm(`Delete "${f.label}" from Saved Fields library?`)) {
      this.reusableFields.splice(idx, 1);
      this.saveLibraries();
      this.renderSidebar();
      this.closeEditSavedFieldModal();
    }
  },

  insertCurrentSavedFieldToActiveForm() {
    if (this.editingSavedFieldIdx === null || this.editingSavedFieldIdx === undefined) return;
    this.insertReusableField(this.editingSavedFieldIdx);
    this.closeEditSavedFieldModal();
  },

  openQuickWfFieldPicker(event, secIdx, insertIdx) {
    event?.stopPropagation();
    document.getElementById('quickWfFieldPicker')?.remove();

    const rect = event?.currentTarget?.getBoundingClientRect();
    const pop = document.createElement('div');
    pop.id = 'quickWfFieldPicker';
    pop.style.cssText = 'position:fixed; z-index:9998; width:320px; max-height:380px; background:#ffffff; border:1px solid #cbd5e1; border-radius:10px; box-shadow:0 16px 36px rgba(15,23,42,0.18); display:flex; flex-direction:column; overflow:hidden; font-family:Inter,sans-serif;';
    const topPos = rect ? Math.min(window.innerHeight - 395, Math.max(60, rect.top + 8)) : 120;
    const leftPos = rect ? Math.min(window.innerWidth - 335, Math.max(16, rect.left)) : 260;
    pop.style.top = topPos + 'px';
    pop.style.left = leftPos + 'px';

    pop.innerHTML = `
      <div style="padding:10px 12px; background:#f8fafc; border-bottom:1px solid #e2e8f0; display:flex; align-items:center; justify-content:space-between;">
        <span style="font-size:12px; font-weight:700; color:#0f172a;">Add from WF Field Library</span>
        <button type="button" onclick="document.getElementById('quickWfFieldPicker')?.remove()" style="border:none; background:none; cursor:pointer; font-size:15px; color:#64748b; line-height:1;">×</button>
      </div>
      <div style="padding:8px 10px; border-bottom:1px solid #f1f5f9;">
        <input type="text" id="quickWfPickerSearch" class="mops-input" placeholder="Search WF Field Name or API Name..." style="font-size:12px; padding:6px 8px; width:100%; box-sizing:border-box;">
      </div>
      <div id="quickWfPickerList" style="overflow-y:auto; max-height:240px; padding:6px;"></div>
      <div style="padding:8px 10px; background:#f8fafc; border-top:1px solid #e2e8f0;">
        <button type="button" id="quickWfPickerCreateBtn" class="btn btn-primary btn-sm" style="width:100%; justify-content:center; font-size:11.5px; font-weight:700;">+ Create New WF Field</button>
      </div>
    `;
    document.body.appendChild(pop);

    const renderList = (q = '') => {
      const listEl = document.getElementById('quickWfPickerList');
      if (!listEl) return;
      const term = q.trim().toLowerCase();
      const activeFields = (this.reusableFields || []).map((f, idx) => ({ f, idx })).filter(({ f }) => {
        if (f.status === 'inactive') return false;
        if (!term) return true;
        return (f.label || '').toLowerCase().includes(term) || (f.data?.formData || '').toLowerCase().includes(term);
      });
      if (activeFields.length === 0) {
        listEl.innerHTML = `<div style="padding:16px; text-align:center; font-size:11.5px; color:#94a3b8;">No matching active WF fields.</div>`;
        return;
      }
      listEl.innerHTML = activeFields.map(({ f, idx }) => `
        <div class="quick-wf-pick-row" data-idx="${idx}" style="padding:7px 9px; border-radius:6px; cursor:pointer; display:flex; align-items:center; justify-content:space-between; gap:8px;" onmouseover="this.style.background='#eff6ff'" onmouseout="this.style.background='transparent'">
          <div style="min-width:0;">
            <div style="font-size:12px; font-weight:600; color:#0f172a; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${f.label || f.data?.label || ''}</div>
            <div style="font-size:10.5px; color:#64748b; font-family:monospace;">${f.data?.formData || ''} · ${f.data?.type || 'text'}</div>
          </div>
          <span style="font-size:11px; color:#005fb8; font-weight:700; flex-shrink:0;">+ Add</span>
        </div>
      `).join('');

      listEl.querySelectorAll('.quick-wf-pick-row').forEach(row => {
        row.onclick = () => {
          const idx = parseInt(row.getAttribute('data-idx'), 10);
          const f = this.reusableFields?.[idx];
          if (!f) return;
          const cloned = JSON.parse(JSON.stringify(f.data));
          cloned.col = 'col-lg-6';
          cloned.wfLibraryFieldId = f.id || cloned.id || cloned.formData;
          cloned.wfObject = f.wfObject || cloned.wfObject || 'Project';
          cloned.wfFieldName = cloned.wfFieldName || cloned.formData;
          cloned.wfLabel = cloned.wfLabel || cloned.label;
          if (Array.isArray(f.wfFormIds) && !cloned.wfFormIds) cloned.wfFormIds = [...f.wfFormIds];
          if (Array.isArray(f.wfFormLabels) && !cloned.wfFormLabels) cloned.wfFormLabels = [...f.wfFormLabels];
          pop.remove();
          this.insertFieldAt(secIdx, insertIdx, cloned);
        };
      });
    };

    renderList('');
    const searchEl = document.getElementById('quickWfPickerSearch');
    if (searchEl) {
      searchEl.oninput = (e) => renderList(e.target.value);
      setTimeout(() => searchEl.focus(), 30);
    }
    const createBtn = document.getElementById('quickWfPickerCreateBtn');
    if (createBtn) {
      createBtn.onclick = () => {
        pop.remove();
        this.openCreateLibraryFieldModal('text', { secIdx, fieldIdx: insertIdx, col: 'col-lg-6' });
      };
    }

    const onOutside = (e) => {
      if (!pop.contains(e.target)) {
        pop.remove();
        document.removeEventListener('mousedown', onOutside);
      }
    };
    setTimeout(() => document.addEventListener('mousedown', onOutside), 0);
  },

  // ------------------------------------------------------------------------
});
