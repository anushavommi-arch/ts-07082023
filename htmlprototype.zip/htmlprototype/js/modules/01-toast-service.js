/**
 * Cisco MOPs FORM Studio - Toast Notification Service
 * Domain: User feedback, non-blocking toast notifications & status badges
 * File: js/modules/01-toast-service.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
_showToast(msg, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? '&#10003;' : type === 'error' ? '&#9888;' : '&#8505;';
    toast.innerHTML = `<span style="font-weight:700;">${icon}</span> <span>${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }
});
