/**
 * Cisco MOPs FORM Studio - Sprint & Form Versioning Controller
 * Domain: Version creation, sprint workflows, time-machine version switching, lock/unlock, rename, delete, and version history modal
 * File: js/modules/03-sprint-versioning.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
openSaveFormSuccessModal() {
    const active = this.getActiveForm();
    const titleEl = document.getElementById('saveFormSuccessTitle');
    const iconEl = document.getElementById('saveFormSuccessIcon');
    const verEl = document.getElementById('saveFormSuccessActiveVer');
    const statsEl = document.getElementById('saveFormSuccessStats');

    if (active) {
      if (titleEl) titleEl.textContent = this.formSchema.title || active.label || 'Intake Form';
      if (iconEl) iconEl.textContent = active.icon || '';
      if (verEl) verEl.textContent = `${active.activeVersionId || 'v1.0'} Active`;
      const secCount = this.formSchema.sections?.length || 0;
      const fldCount = window.VersionManager ? window.VersionManager.countFields(this.formSchema) : 0;
      const rlsCount = window.VersionManager ? window.VersionManager.countRules(this.formSchema) : 0;
      if (statsEl) {
        statsEl.textContent = ` ${secCount} Section${secCount === 1 ? '' : 's'}  ${fldCount} Field${fldCount === 1 ? '' : 's'}  ${rlsCount} Rule${rlsCount === 1 ? '' : 's'}`;
      }
    }
    document.getElementById('modalSaveFormSuccess')?.classList.add('open');
  },


  // --------------------------------------------------------------------------

  /**
   * Opens the "Save as New Version" modal  a clean, focused modal.
   * Invoked by the navbar "Save as New Version" button.
   */
  openSaveNewVersionModal() {
    const active = this.getActiveForm();
    if (!active) {
      this._showToast('No active form selected.');
      return;
    }

    // Always open the modal first  so it appears even if data population has errors
    const modal = document.getElementById('modalSaveNewVersion');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }

    try {
      window.VersionManager?.ensureFormVersions(active);

      const sug = window.VersionManager?.getNextVersionSuggestions(active) || { defaultVer: 'v2.0', nextMinor: 'v1.1', nextSprint: 'Sprint 25.2' };

      const nameEl = document.getElementById('saveNewVerFormName');
      const iconEl = document.getElementById('saveNewVerFormIcon');
      const tagEl = document.getElementById('saveNewVerCurrentTag');
      const statEl = document.getElementById('saveNewVerStatsPill');
      const verIn = document.getElementById('inputNewVersionTag');
      const spIn = document.getElementById('inputNewVersionSprint');
      const notIn = document.getElementById('textareaNewVersionNotes');
      const chips = document.getElementById('newVersionQuickChips');

      if (nameEl) nameEl.textContent = this.formSchema?.title || active.label || 'Intake Form';
      if (iconEl) iconEl.textContent = active.icon || '';
      if (tagEl) tagEl.textContent = `${active.activeVersionId || 'v1.0'} (${active.activeSprint || 'Sprint 25.1'})`;
      if (verIn) verIn.value = sug.defaultVer;
      if (spIn) spIn.value = sug.nextSprint;
      if (notIn) notIn.value = '';
      const authorIn = document.getElementById('inputNewVersionAuthor');
      if (authorIn) authorIn.value = this.getCurrentUserSignature();

      const secCount = this.formSchema?.sections?.length || 0;
      const fldCount = window.VersionManager?.countFields(this.formSchema) || 0;
      if (statEl) statEl.textContent = `${secCount} Sections  ${fldCount} Fields`;

      if (chips) {
        chips.innerHTML = [
          { label: sug.nextMinor + ' (Minor)', val: sug.nextMinor },
          { label: (sug.nextMajor || 'v2.0') + ' (Major)', val: sug.nextMajor || 'v2.0' }
        ].map(c => `<button type="button" class="quick-chip" onclick="App._setNewVersionTag('${c.val}')">${c.label}</button>`).join('');
      }
    } catch (err) {
      console.error('[MOPs] openSaveNewVersionModal data population error:', err);
    }
  },

  /**
   * Alias: "Save New Sprint Version" button (Version History modal header & sidebar).
   * Opens the standard Save New Version modal  sprints and versions share the same modal.
   */
  openSaveSprintVersionModal() {
    this.openSaveNewVersionModal();
  },

  _setNewVersionTag(val) {
    const inp = document.getElementById('inputNewVersionTag');
    if (inp) inp.value = val;
  },

  _syncNewVersionPreview() {
    // Nothing to sync currently  placeholder for future filename preview
  },

  /**
   * Confirm: create a new version snapshot from the modal form.
   * When _addVersionContext is set (triggered by "+ Version" tree button),
   * clones schema + rules + BA notes from the most recent sprint version.
   */
  confirmSaveNewVersion() {
    // Determine target form  either from clone context or active form
    const ctx = this._addVersionContext;
    const active = ctx
      ? (this.allForms || []).find(f => f.id === ctx.formId)
      : this.getActiveForm();
    if (!active) { this._showToast('No active form selected.'); return; }

    const verTagRaw = (document.getElementById('inputNewVersionTag')?.value || '').trim();
    const sprint = (document.getElementById('inputNewVersionSprint')?.value || '').trim();
    const author = (document.getElementById('inputNewVersionAuthor')?.value || this.getCurrentUserSignature()).trim();
    const notes = (document.getElementById('textareaNewVersionNotes')?.value || '').trim();
    const now = new Date().toISOString();

    if (!verTagRaw) { this._showToast('Please enter a Version Tag.'); return; }
    if (!sprint) { this._showToast('Please enter a Sprint Identifier.'); return; }

    if (!window.VersionManager) {
      this._showToast('Version Manager not loaded.');
      this.closeSaveNewVersionModal();
      return;
    }

    try {
      const verTag = window.VersionManager.normalizeVersionTag(verTagRaw);

      // Duplicate Check: across ALL sprint versions AND flat versions of this form
      const allVersionIds = [];
      (active.sprints || []).forEach(sp => (sp.versions || []).forEach(v => allVersionIds.push(v.versionId)));
      (active.versions || []).forEach(v => allVersionIds.push(v.versionId));
      if (allVersionIds.some(id => id && id.trim().toLowerCase() === verTag.toLowerCase())) {
        this.showValidationError(
          'Duplicate Version Tag',
          `Version "${verTag}" already exists for form "${active.label || active.id}". Duplicate version tags are not allowed for this form.`
        );
        document.getElementById('inputNewVersionTag')?.focus();
        return;
      }

      let newVersion;

      if (ctx) {
        //  CLONE PATH: triggered by "+ Version" tree button 
        const sourceVer = ctx.sourceVer;

        // Deep-clone schema (sections, fields, rules, BA notes) from source
        let baseSchema;
        if (sourceVer?.schema) {
          baseSchema = JSON.parse(JSON.stringify(sourceVer.schema));
        } else {
          baseSchema = JSON.parse(JSON.stringify(active.schema || { sections: [] }));
        }
        // Keep the form title consistent
        baseSchema.title = baseSchema.title || active.formTitle || active.label || active.id;

        newVersion = {
          versionId: verTag,
          versionLabel: `${verTag} (${sprint})`,
          sprint,
          timestamp: now,
          createdAt: now,
          createdBy: author,
          author,
          status: 'Active',
          notes: notes || `Cloned from ${sourceVer?.versionId || 'previous version'}. ${sprint} update.`,
          schema: baseSchema,
          formTitle: baseSchema.title,
          title: baseSchema.title,
          stats: {
            sectionCount: baseSchema.sections?.length || 0,
            fieldCount: window.VersionManager?.countFields(baseSchema) || 0,
            rulesCount: window.VersionManager?.countRules?.(baseSchema) || 0
          }
        };

        // Add to target sprint.versions
        const targetSprint = (active.sprints || []).find(sp => sp.sprintId === ctx.sprintId);
        if (targetSprint) {
          if (!Array.isArray(targetSprint.versions)) targetSprint.versions = [];
          // Archive previous Active versions in this sprint
          targetSprint.versions.forEach(v => { if (v.status === 'Active') v.status = 'Archived'; });
          targetSprint.versions.push(newVersion);
          targetSprint.publishedVersionId = verTag;
        }

        // Also push to flat form.versions
        if (!Array.isArray(active.versions)) active.versions = [];
        active.versions.forEach(v => { if (v.status === 'Active') v.status = 'Archived'; });
        active.versions.push(Object.assign({}, newVersion));

        active.activeVersionId = verTag;
        if (targetSprint) active.activeSprint = targetSprint.sprintLabel || targetSprint.sprintId;

        // Persist to disk (async)
        window.WorkspaceRepo?.saveVersion(active, newVersion)
          .then(r => r?.ok && console.log(`[MOPs]  Clone version on disk: ${r.filePath}`))
          .catch(e => console.warn('[MOPs] Clone version disk save:', e));

        this.saveAllForms();
        this.closeSaveNewVersionModal(); // also clears _addVersionContext
        this.renderFormsTree();
        this.syncCanvasHeader();
        this.renderFormTabs();
        this._showToast(`Version ${verTag} (${sprint}) cloned from ${sourceVer?.versionId || 'previous'}!`);

      } else {
        //  NORMAL PATH: triggered by standard "Save Version" button 
        // Sync live canvas edits into form schema BEFORE snapshotting
        active.schema = JSON.parse(JSON.stringify(this.formSchema || { sections: [] }));

        newVersion = window.VersionManager.saveVersion(active, {
          versionId: verTag,
          sprint,
          status: 'Active',
          author,
          notes: notes || `Sprint ${sprint} specification snapshot.`
        });

        // Persist version snapshot to disk (async)
        window.WorkspaceRepo?.saveVersion(active, newVersion)
          .then(r => r?.ok && console.log(`[MOPs]  Version on disk: ${r.filePath}`))
          .catch(e => console.warn('[MOPs] Version disk save:', e));

        this.formSchema = active.schema;
        this.saveAllForms();
        this.syncCanvasHeader();
        this.renderFormTabs();

        // Close Save New Version modal
        this.closeSaveNewVersionModal();

        // If Version History modal is open, refresh it
        const vhModal = document.getElementById('modalVersionHistory');
        if (vhModal && vhModal.classList.contains('open')) {
          this.vhState.selectedVersionId = verTag;
          this.renderVersionHistoryList();
          this.selectVersionInHistory(verTag);
        }

        // Show success modal
        this._openVersionSavedSuccessModal(newVersion, active);
        this._flashSaveButtonSuccess();
        this._showToast(`Version ${verTag} (${sprint}) created!`);
      }
    } catch (err) {
      console.error('[MOPs] confirmSaveNewVersion error:', err);
      this._showToast('Error creating version: ' + (err.message || 'Unknown error'));
      this.closeSaveNewVersionModal();
    }
  },

  closeSaveNewVersionModal() {
    const modal = document.getElementById('modalSaveNewVersion');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
    }
    // Clear add-version context whenever modal closes
    this._addVersionContext = null;
  },

  /**
   * Open the Save New Version modal pre-filled to clone from the most recent
   * version in the given sprint.  Called by the "+ Version" tree button.
   */
  openAddVersionModal(formId, sprintId) {
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) { this._showToast('Form not found.'); return; }

    // Find the sprint and its versions
    const sprint = (form.sprints || []).find(sp => sp.sprintId === sprintId);
    let spVersions = sprint ? (sprint.versions || []) : [];

    // Fallback: match from flat form.versions if sprint.versions is empty
    if (spVersions.length === 0 && Array.isArray(form.versions) && form.versions.length > 0) {
      const spNorm = sprintId.toLowerCase().replace(/[^a-z0-9]/g, '');
      spVersions = form.versions.filter(v => {
        const vSp = (v.sprint || v.sprintId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        return vSp && spNorm && (vSp === spNorm || vSp.includes(spNorm) || spNorm.includes(vSp));
      });
    }

    // Source = most recent version in this sprint
    const sourceVer = spVersions.length > 0 ? spVersions[spVersions.length - 1] : null;

    // Suggest next version tag
    const sug = window.VersionManager?.getNextVersionSuggestions(form) || { defaultVer: 'v1.1', nextMinor: 'v1.1', nextMajor: 'v2.0' };

    // Store context so confirmSaveNewVersion() knows this is a clone operation
    this._addVersionContext = { formId, sprintId, sourceVer };

    // Reuse existing save-new-version modal
    const modal = document.getElementById('modalSaveNewVersion');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }

    try {
      const nameEl = document.getElementById('saveNewVerFormName');
      const iconEl = document.getElementById('saveNewVerFormIcon');
      const tagEl = document.getElementById('saveNewVerCurrentTag');
      const statEl = document.getElementById('saveNewVerStatsPill');
      const verIn = document.getElementById('inputNewVersionTag');
      const spIn = document.getElementById('inputNewVersionSprint');
      const notIn = document.getElementById('textareaNewVersionNotes');
      const chips = document.getElementById('newVersionQuickChips');
      const authorIn = document.getElementById('inputNewVersionAuthor');

      const formTitle = form.formTitle || form.schema?.title || form.label || form.id;
      if (nameEl) nameEl.textContent = formTitle;
      if (iconEl) iconEl.textContent = form.icon || '';
      if (tagEl) tagEl.textContent = sourceVer ? `Clone of ${sourceVer.versionId}` : 'No previous version';
      if (verIn) verIn.value = sug.nextMinor || sug.defaultVer || 'v1.1';
      if (spIn) spIn.value = sprint?.sprintLabel || sprintId;
      if (notIn) notIn.value = '';
      if (authorIn) authorIn.value = this.getCurrentUserSignature();

      const srcSchema = sourceVer?.schema || form.schema || { sections: [] };
      const secCount = srcSchema.sections?.length || 0;
      const fldCount = window.VersionManager?.countFields(srcSchema) || 0;
      if (statEl) statEl.textContent = `${secCount} Sections  ${fldCount} Fields (cloning from ${sourceVer?.versionId || 'current'})`;

      if (chips) {
        chips.innerHTML = [
          { label: (sug.nextMinor || 'v1.1') + ' (Minor)', val: sug.nextMinor || 'v1.1' },
          { label: (sug.nextMajor || 'v2.0') + ' (Major)', val: sug.nextMajor || 'v2.0' }
        ].map(c => `<button type="button" class="quick-chip" onclick="App._setNewVersionTag('${c.val}')">${c.label}</button>`).join('');
      }
    } catch (err) {
      console.error('[MOPs] openAddVersionModal data population error:', err);
    }
  },

  _openVersionSavedSuccessModal(newVersion, active) {
    const iconEl = document.getElementById('verSuccessIcon');
    const tagEl = document.getElementById('verSuccessTag');
    const sprintEl = document.getElementById('verSuccessSprint');
    const authorEl = document.getElementById('verSuccessAuthor');
    const notesEl = document.getElementById('verSuccessNotes');
    const statsEl = document.getElementById('verSuccessStats');

    if (iconEl) iconEl.textContent = active?.icon || '';
    if (tagEl) tagEl.textContent = newVersion?.versionId || 'v2.0';
    if (sprintEl) sprintEl.textContent = newVersion?.sprint || '';
    if (authorEl) authorEl.textContent = `By ${newVersion?.author || 'MOPs Team'}`;
    if (notesEl) notesEl.textContent = newVersion?.notes || '';
    if (statsEl) {
      const s = newVersion?.stats || {};
      statsEl.textContent = ` ${s.sectionCount || 0} Sections  ${s.fieldCount || 0} Fields  ${s.rulesCount || 0} Rules`;
    }
    document.getElementById('modalVersionSavedSuccess')?.classList.add('open');
  },

  closeVersionSavedSuccessModal() {
    document.getElementById('modalVersionSavedSuccess')?.classList.remove('open');
  },

  // --------------------------------------------------------------------------
  // Create New Form Modal
  // --------------------------------------------------------------------------

  /**
   * Retrieves all unique sprints across all forms in the repository,
   * sorted in descending order (e.g. sprint-25.2, sprint-25.1, sprint-24.11...).
   */
  getAllWorkspaceSprints() {
    const sprintMap = new Map();
    (this.allForms || []).forEach(f => {
      if (f.activeSprint) {
        const sId = f.activeSprint.toLowerCase().replace(/[^a-z0-9.]/g, '-');
        if (!sprintMap.has(sId)) {
          sprintMap.set(sId, { sprintId: sId, sprintLabel: f.activeSprint, status: 'Active', count: 0 });
        }
        sprintMap.get(sId).count++;
      }
      (f.sprints || []).forEach(sp => {
        const sId = (sp.sprintId || sp.sprintLabel || '').toLowerCase().replace(/[^a-z0-9.]/g, '-');
        if (sId) {
          if (!sprintMap.has(sId)) {
            sprintMap.set(sId, {
              sprintId: sp.sprintId || sId,
              sprintLabel: sp.sprintLabel || sp.sprintId || sId,
              startDate: sp.startDate || '',
              endDate: sp.endDate || '',
              status: sp.status || 'Archived',
              count: 0
            });
          }
          sprintMap.get(sId).count++;
        }
      });
    });

    const list = Array.from(sprintMap.values());
    list.sort((a, b) => {
      const ma = (a.sprintId || '').match(/(\d+)\.(\d+)/);
      const mb = (b.sprintId || '').match(/(\d+)\.(\d+)/);
      if (ma && mb) {
        const ya = parseInt(ma[1], 10), na = parseInt(ma[2], 10);
        const yb = parseInt(mb[1], 10), nb = parseInt(mb[2], 10);
        if (ya !== yb) return yb - ya;
        return nb - na;
      }
      return (b.sprintId || '').localeCompare(a.sprintId || '');
    });
    return list;
  },

  /**
   * Computes the next logical sprint identifier based on existing sprints.
   * e.g. sprint-25.2 -> sprint-25.3 / Sprint 25.3
   */
  getSuggestedNextSprint() {
    const list = this.getAllWorkspaceSprints();
    let maxYear = 25;
    let maxNum = 2;
    list.forEach(sp => {
      const m = (sp.sprintId || sp.sprintLabel || '').match(/(\d+)\.(\d+)/);
      if (m) {
        const y = parseInt(m[1], 10);
        const n = parseInt(m[2], 10);
        if (y > maxYear || (y === maxYear && n > maxNum)) {
          maxYear = y;
          maxNum = n;
        }
      }
    });
    const nextNum = maxNum + 1;
    return {
      sprintId: `sprint-${maxYear}.${nextNum}`,
      sprintLabel: `Sprint ${maxYear}.${nextNum}`
    };
  },

  /**
   * Opens the "Create New Form" modal.
   * Simple and clean: Form Name, Icon, Description.
   */
  openCreateNewFormModal() {
    const nameIn = document.getElementById('inputNewFormName');
    const iconIn = document.getElementById('inputNewFormIcon');
    const descIn = document.getElementById('inputNewFormDesc');
    if (nameIn) nameIn.value = '';
    if (iconIn) iconIn.value = '';
    if (descIn) descIn.value = '';
    const modal = document.getElementById('modalCreateNewForm');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }
    setTimeout(() => {
      nameIn?.focus();
      nameIn?.select();
    }, 80);
  },

  closeCreateNewFormModal() {
    const modal = document.getElementById('modalCreateNewForm');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
    }
  },

  /**
   * Confirm: create the new form with initial baseline v1.0.
   */
  confirmCreateNewForm() {
    const nameIn = document.getElementById('inputNewFormName');
    const iconIn = document.getElementById('inputNewFormIcon');
    const descIn = document.getElementById('inputNewFormDesc');

    const trimmed = (nameIn?.value || '').trim();
    if (!trimmed) {
      this.showValidationError('Form Name Required', 'Please enter a name for the new form.');
      nameIn?.focus();
      return;
    }

    // Duplicate Check: Form name must be unique across all forms
    const isDuplicate = (this.allForms || []).some(f =>
      (f.label && f.label.trim().toLowerCase() === trimmed.toLowerCase()) ||
      (f.schema?.title && f.schema.title.trim().toLowerCase() === trimmed.toLowerCase())
    );
    if (isDuplicate) {
      this.showValidationError(
        'Duplicate Form Name',
        `A form named "${trimmed}" already exists. Duplicate form names are not allowed across the workspace.`
      );
      nameIn?.focus();
      nameIn?.select();
      return;
    }

    const icon = (iconIn?.value || '').trim() || '';
    const desc = (descIn?.value || '').trim();
    const newId = trimmed.toLowerCase().replace(/[^a-z0-9]/g, '-') || ('form_' + Date.now());
    const finalId = this.allForms.some(f => f.id === newId) ? `${newId}-${Date.now().toString().slice(-4)}` : newId;

    const defaultSprint = 'sprint-25.2';
    const defaultSprintLabel = 'Sprint 25.2';

    const baselineSchema = {
      title: trimmed,
      description: desc || '',
      sections: [
        {
          id: 'sec_1',
          title: 'General Information',
          collapsed: false,
          fields: []
        }
      ]
    };

    const nowIso = new Date().toISOString();
    const userSig = this.getCurrentUserSignature();

    const newVersionRecord = {
      versionId: 'v1.0',
      versionLabel: `v1.0 (${defaultSprintLabel})`,
      sprint: defaultSprintLabel,
      timestamp: nowIso,
      author: userSig,
      status: 'Active',
      notes: `Initial baseline specification for ${trimmed}.`,
      schema: JSON.parse(JSON.stringify(baselineSchema)),
      stats: { sectionCount: 1, fieldCount: 0, rulesCount: 0 }
    };

    const newSprintRecord = {
      sprintId: defaultSprint,
      sprintLabel: defaultSprintLabel,
      startDate: nowIso.slice(0, 10),
      endDate: '',
      status: 'Active',
      publishedVersionId: 'v1.0',
      versions: [newVersionRecord]
    };

    const newForm = {
      id: finalId,
      label: trimmed.length > 20 ? trimmed.substring(0, 20) + '' : trimmed,
      icon: icon,
      configFile: 'form.' + finalId + '.config.ts',
      activeSprint: defaultSprint,
      activeVersionId: 'v1.0',
      createdAt: nowIso,
      createdBy: userSig,
      updatedAt: nowIso,
      updatedBy: userSig,
      schema: baselineSchema,
      sprints: [newSprintRecord],
      versions: [newVersionRecord]
    };

    // Save to workspace repo / disk immediately
    window.WorkspaceRepo?.saveForm(newForm, newForm.schema);
    window.WorkspaceRepo?.saveVersion(newForm, newVersionRecord);
    window.WorkspaceRepo?.saveSprint?.(newForm, newSprintRecord);

    if (window.MOPS_FORMS_REPOSITORY && window.MOPS_FORMS_REPOSITORY.forms) {
      window.MOPS_FORMS_REPOSITORY.forms.push(newForm);
    }

    this.allForms.push(newForm);

    // Auto-expand tree folders for this new form so it's immediately visible
    const expanded = this._getExpandedTreeNodes();
    expanded.add(`form:${finalId}`);
    expanded.add(`sprints:${finalId}`);
    expanded.add(`sprint:${finalId}:${defaultSprint}`);
    expanded.add(`vers:${finalId}:${defaultSprint}`);

    this.closeCreateNewFormModal();
    this.switchActiveForm(finalId);

    if (this.activeMode === 'review') {
      this.switchMode('builder');
    }

    this.renderFormsGallery?.();
    this.renderFormTabs();
    this._showToast(`Created form "${trimmed}"! Click "+ Sprint" next to the form to add sprints.`);
  },

  /**
   * Clone an entire existing form (schema, sections, fields, BA notes, rules, routing) into a new form.
   */
  promptCloneForm(sourceFormId, event) {
    event?.stopPropagation();
    const sourceForm = (this.allForms || []).find(f => f.id === sourceFormId);
    if (!sourceForm) { this._showToast('Source form not found.'); return; }

    const baseLabel = sourceForm.schema?.title || sourceForm.label || sourceForm.id;
    const rawName = prompt(`Enter a name for the cloned form (copying "${baseLabel}"):`, `${baseLabel} (Copy)`);
    if (rawName === null) return;
    const trimmed = rawName.trim();
    if (!trimmed) { this._showToast('Form name cannot be empty.'); return; }

    // Duplicate check across workspace
    const normNew = trimmed.toLowerCase();
    const dupForm = (this.allForms || []).find(f => {
      const lbl = (f.label || '').trim().toLowerCase();
      const ttl = (f.schema?.title || '').trim().toLowerCase();
      return lbl === normNew || ttl === normNew;
    });
    if (dupForm) {
      this.showValidationError(
        'Duplicate Form Name',
        `A form named "${trimmed}" already exists. Duplicate form names are not allowed across the workspace.`
      );
      return;
    }

    const baseId = trimmed.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || ('form-' + Date.now());
    let finalId = baseId;
    let counter = 2;
    while ((this.allForms || []).some(f => f.id === finalId)) {
      finalId = `${baseId}-${counter++}`;
    }

    // Resolve source schema (use live formSchema if cloning currently active form)
    const srcSchema = (sourceFormId === this.activeFormId && this.formSchema?.sections?.length)
      ? this.formSchema
      : (sourceForm.schema || { sections: [] });
    const clonedSchema = JSON.parse(JSON.stringify(srcSchema));
    clonedSchema.title = trimmed;
    const nowIso = new Date().toISOString();
    const userSig = this.getCurrentUserSignature();

    // Stamp fresh instanceIds on cloned fields while preserving WF Field Library identity
    (clonedSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(fld => {
        if (fld.type !== 'empty_field') {
          fld.instanceId = 'inst_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
          fld.dateAdded = nowIso;
        }
      });
    });

    const activeSp = sourceForm.activeSprint || 'sprint-25.2';
    const defaultSprint = activeSp.toLowerCase().replace(/[^a-z0-9.]/g, '-');
    const defaultSprintLabel = activeSp;

    const newVersionRecord = {
      versionId: 'v1.0',
      versionLabel: `v1.0 (${defaultSprintLabel})`,
      sprint: defaultSprintLabel,
      timestamp: nowIso,
      author: userSig,
      status: 'Active',
      notes: `Cloned from "${baseLabel}" (${sourceForm.activeVersionId || 'v1.0'}).`,
      schema: JSON.parse(JSON.stringify(clonedSchema)),
      formTitle: trimmed,
      title: trimmed,
      stats: {
        sectionCount: clonedSchema.sections?.length || 0,
        fieldCount: window.VersionManager?.countFields(clonedSchema) || 0,
        rulesCount: window.VersionManager?.countRules?.(clonedSchema) || 0
      }
    };

    const newSprintRecord = {
      sprintId: defaultSprint,
      sprintLabel: defaultSprintLabel,
      startDate: nowIso.slice(0, 10),
      endDate: '',
      status: 'Active',
      publishedVersionId: 'v1.0',
      versions: [newVersionRecord]
    };

    const newForm = {
      id: finalId,
      label: trimmed.length > 24 ? trimmed.substring(0, 24) : trimmed,
      icon: sourceForm.icon || '',
      configFile: 'form.' + finalId + '.config.ts',
      activeSprint: defaultSprint,
      activeVersionId: 'v1.0',
      createdAt: nowIso,
      createdBy: userSig,
      updatedAt: nowIso,
      updatedBy: userSig,
      schema: clonedSchema,
      sprints: [newSprintRecord],
      versions: [newVersionRecord]
    };

    window.WorkspaceRepo?.saveForm(newForm, newForm.schema);
    window.WorkspaceRepo?.saveVersion(newForm, newVersionRecord);
    window.WorkspaceRepo?.saveSprint?.(newForm, newSprintRecord);

    if (window.MOPS_FORMS_REPOSITORY && window.MOPS_FORMS_REPOSITORY.forms) {
      window.MOPS_FORMS_REPOSITORY.forms.push(newForm);
    }

    this.allForms.push(newForm);
    this.saveAllForms();

    const expanded = this._getExpandedTreeNodes();
    expanded.add(`form:${finalId}`);
    expanded.add(`sprints:${finalId}`);
    expanded.add(`sprint:${finalId}:${defaultSprint}`);
    expanded.add(`vers:${finalId}:${defaultSprint}`);

    this.renderFormsGallery?.();
    this.openVersionFromTree(finalId, 'v1.0');
    this._refreshSidebarPreserveScroll?.();
    this._showToast(`Cloned "${baseLabel}" into "${trimmed}" (v1.0)!`);
  },

  /**
   * Opens the "Add New Sprint" modal for a specific form.
   * Triggered by clicking the "+ Sprint" button next to any form in the sidebar tree.
   */
  openCreateNewSprintModal(targetFormId = null) {
    const form = (targetFormId && this.allForms?.find(f => f.id === targetFormId)) || this.getActiveForm();
    if (!form) {
      this._showToast('Please select or click "+ Sprint" next to a form.');
      return;
    }

    this._newSprintTargetFormId = form.id;

    const targetNameEl = document.getElementById('newSprintFormTargetName');
    if (targetNameEl) {
      targetNameEl.textContent = form.label || form.id;
    }

    // Calculate next sprint based on this form's existing sprints
    let maxYear = 25;
    let maxNum = 2;
    (form.sprints || []).forEach(sp => {
      const m = (sp.sprintId || sp.sprintLabel || '').match(/(\d+)\.(\d+)/);
      if (m) {
        const y = parseInt(m[1], 10);
        const n = parseInt(m[2], 10);
        if (y > maxYear || (y === maxYear && n > maxNum)) {
          maxYear = y;
          maxNum = n;
        }
      }
    });
    const nextSprintId = `sprint-${maxYear}.${maxNum + 1}`;
    const nextSprintLabel = `Sprint ${maxYear}.${maxNum + 1}`;

    const idIn = document.getElementById('inputNewSprintId');
    const labelIn = document.getElementById('inputNewSprintLabel');
    const verIn = document.getElementById('inputNewSprintVersion');
    const startIn = document.getElementById('inputNewSprintStartDate');
    const endIn = document.getElementById('inputNewSprintEndDate');
    const statusSel = document.getElementById('selectNewSprintStatus');
    const notesIn = document.getElementById('inputNewSprintNotes');

    if (idIn) idIn.value = nextSprintId;
    if (labelIn) labelIn.value = nextSprintLabel;

    const sug = window.VersionManager?.getNextVersionSuggestions(form) || { nextMajor: 'v4.0' };
    if (verIn) verIn.value = sug.nextMajor || 'v2.0';

    const today = new Date();
    const in30Days = new Date(today.getTime() + 30 * 24 * 3600 * 1000);
    if (startIn) startIn.value = today.toISOString().slice(0, 10);
    if (endIn) endIn.value = in30Days.toISOString().slice(0, 10);
    if (statusSel) statusSel.value = 'Active';
    if (notesIn) notesIn.value = '';

    const modal = document.getElementById('modalCreateNewSprint');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }
    setTimeout(() => {
      idIn?.focus();
      idIn?.select();
    }, 80);
  },

  closeCreateNewSprintModal() {
    const modal = document.getElementById('modalCreateNewSprint');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
    }
  },

  /**
   * Confirm: adds the new sprint to the target form.
   */
  confirmCreateNewSprint() {
    const form = (this._newSprintTargetFormId && this.allForms?.find(f => f.id === this._newSprintTargetFormId)) || this.getActiveForm();
    if (!form) {
      this._showToast('No target form found.');
      return;
    }

    const idIn = document.getElementById('inputNewSprintId');
    const labelIn = document.getElementById('inputNewSprintLabel');
    const verIn = document.getElementById('inputNewSprintVersion');
    const startIn = document.getElementById('inputNewSprintStartDate');
    const endIn = document.getElementById('inputNewSprintEndDate');
    const statusSel = document.getElementById('selectNewSprintStatus');
    const notesIn = document.getElementById('inputNewSprintNotes');

    const sprintId = (idIn?.value || '').trim().toLowerCase().replace(/[^a-z0-9.]/g, '-');
    const sprintLabel = (labelIn?.value || sprintId).trim() || sprintId;
    const verTag = (verIn?.value || 'v2.0').trim() || 'v2.0';
    const startDate = startIn?.value || new Date().toISOString().slice(0, 10);
    const endDate = endIn?.value || '';
    const status = statusSel?.value || 'Active';
    const notes = (notesIn?.value || '').trim() || `Sprint milestone ${sprintLabel}.`;

    if (!sprintId) {
      this.showValidationError('Sprint ID Required', 'Please enter a Sprint Identifier (e.g. sprint-25.3).');
      idIn?.focus();
      return;
    }

    if (!form.sprints) form.sprints = [];

    // Duplicate Sprint Check (within this form)
    const isDuplicateSprint = form.sprints.some(sp =>
      (sp.sprintId && sp.sprintId.trim().toLowerCase() === sprintId.toLowerCase()) ||
      (sp.sprintLabel && sp.sprintLabel.trim().toLowerCase() === sprintLabel.toLowerCase())
    );
    if (isDuplicateSprint) {
      this.showValidationError(
        'Duplicate Sprint Name',
        `A sprint named "${sprintLabel}" (${sprintId}) already exists for form "${form.label || form.id}". Sprint names must be unique within a form.`
      );
      idIn?.focus();
      return;
    }

    // Duplicate Version Tag Check (within this form)
    const isDuplicateVersion = (form.versions || []).some(v =>
      v.versionId && v.versionId.trim().toLowerCase() === verTag.toLowerCase()
    );
    if (isDuplicateVersion) {
      this.showValidationError(
        'Duplicate Version Tag',
        `Version tag "${verTag}" already exists for form "${form.label || form.id}". Duplicate version tags are not allowed within a form.`
      );
      verIn?.focus();
      return;
    }

    const newVersionRecord = {
      versionId: verTag,
      versionLabel: `${verTag} (${sprintLabel})`,
      sprint: sprintLabel,
      timestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      createdBy: this.getCurrentUserSignature(),
      author: this.getCurrentUserSignature(),
      status: status,
      notes: notes,
      schema: JSON.parse(JSON.stringify(form.schema || { sections: [] })),
      stats: {
        sectionCount: form.schema?.sections?.length || 0,
        fieldCount: window.VersionManager?.countFields(form.schema) || 0,
        rulesCount: 0
      }
    };

    if (status === 'Active') {
      form.sprints.forEach(sp => { sp.status = 'Archived'; });
    }

    const newSprintRecord = {
      sprintId,
      sprintLabel,
      startDate,
      endDate,
      status,
      createdAt: new Date().toISOString(),
      createdBy: this.getCurrentUserSignature(),
      publishedVersionId: verTag,
      versions: [newVersionRecord]
    };

    form.sprints.push(newSprintRecord);
    if (!form.versions) form.versions = [];
    form.versions.push(newVersionRecord);
    form.activeSprint = sprintId;
    form.activeVersionId = verTag;

    window.WorkspaceRepo?.saveForm(form, form.schema);
    window.WorkspaceRepo?.saveVersion(form, newVersionRecord);
    window.WorkspaceRepo?.saveSprint?.(form, newSprintRecord);

    const expanded = this._getExpandedTreeNodes();
    expanded.add(`form:${form.id}`);
    expanded.add(`sprints:${form.id}`);
    expanded.add(`sprint:${form.id}:${sprintId}`);
    expanded.add(`vers:${form.id}:${sprintId}`);

    this.closeCreateNewSprintModal();
    this.switchActiveForm(form.id);
    this.syncCanvasHeader();
    this.renderFormTabs();
    this.renderFormsTree();
    this._showToast(`Added Sprint "${sprintLabel}" (${verTag}) to ${form.label || form.id}!`);
  },

  // ==========================================================================
  // Validation Error Modal & Item Renaming Handlers
  // ==========================================================================

  showValidationError(title, message, onDismiss) {
    const modal = document.getElementById('modalValidationError');
    const titleEl = document.getElementById('modalValidationErrorTitle');
    const msgEl = document.getElementById('modalValidationErrorMessage');
    if (titleEl) titleEl.textContent = title || 'Validation Error';
    if (msgEl) msgEl.textContent = message || 'Duplicate detected.';
    this._validationDismissCb = onDismiss || null;

    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
      const btn = document.getElementById('btnDismissValidationError');
      setTimeout(() => btn?.focus(), 60);
    } else {
      alert(`${title}\n\n${message}`);
      if (onDismiss) onDismiss();
    }
  },

  closeValidationErrorModal() {
    const modal = document.getElementById('modalValidationError');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
    }
    if (typeof this._validationDismissCb === 'function') {
      const cb = this._validationDismissCb;
      this._validationDismissCb = null;
      cb();
    }
  },

  promptRenameForm(formId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId) || this.getActiveForm();
    if (!form) return;
    this._renameTarget = {
      type: 'form',
      formId: form.id,
      originalValue: form.label || form.id
    };
    const titleEl = document.getElementById('modalRenameTitle');
    const subEl = document.getElementById('modalRenameSubtitle');
    const labelEl = document.getElementById('modalRenameInputLabel');
    const input = document.getElementById('modalRenameInput');
    const helpEl = document.getElementById('modalRenameHelpText');
    const extraWrap = document.getElementById('modalRenameExtraWrap');

    if (titleEl) titleEl.textContent = 'Rename Form';
    if (subEl) subEl.textContent = `Current: "${form.label || form.id}"`;
    if (labelEl) labelEl.textContent = 'New Form Name *';
    if (input) input.value = form.label || form.id;
    if (helpEl) helpEl.textContent = 'Form names must be unique across all forms.';
    if (extraWrap) extraWrap.style.display = 'none';

    const modal = document.getElementById('modalRenameItem');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }
    setTimeout(() => { input?.focus(); input?.select(); }, 80);
  },

  promptRenameSprint(formId, sprintId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId) || this.getActiveForm();
    if (!form) return;
    const sprint = (form.sprints || []).find(sp => sp.sprintId === sprintId);
    const sprintLabel = sprint ? (sprint.sprintLabel || sprint.sprintId) : sprintId;
    this._renameTarget = {
      type: 'sprint',
      formId: form.id,
      oldSprintId: sprintId,
      originalValue: sprintLabel
    };
    const titleEl = document.getElementById('modalRenameTitle');
    const subEl = document.getElementById('modalRenameSubtitle');
    const labelEl = document.getElementById('modalRenameInputLabel');
    const input = document.getElementById('modalRenameInput');
    const helpEl = document.getElementById('modalRenameHelpText');
    const extraWrap = document.getElementById('modalRenameExtraWrap');
    const extraInput = document.getElementById('modalRenameExtraInput');

    if (titleEl) titleEl.textContent = 'Rename Sprint';
    if (subEl) subEl.textContent = `For Form: ${form.label || form.id}`;
    if (labelEl) labelEl.textContent = 'Sprint Display Name *';
    if (input) input.value = sprintLabel;
    if (helpEl) helpEl.textContent = 'Sprint names must be unique within this form.';
    if (extraWrap && extraInput) {
      extraWrap.style.display = 'block';
      extraInput.value = sprintId;
    }

    const modal = document.getElementById('modalRenameItem');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }
    setTimeout(() => { input?.focus(); input?.select(); }, 80);
  },

  promptRenameVersion(formId, versionId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId) || this.getActiveForm();
    if (!form) return;
    this._renameTarget = {
      type: 'version',
      formId: form.id,
      oldVersionId: versionId,
      originalValue: versionId
    };
    const titleEl = document.getElementById('modalRenameTitle');
    const subEl = document.getElementById('modalRenameSubtitle');
    const labelEl = document.getElementById('modalRenameInputLabel');
    const input = document.getElementById('modalRenameInput');
    const helpEl = document.getElementById('modalRenameHelpText');
    const extraWrap = document.getElementById('modalRenameExtraWrap');

    if (titleEl) titleEl.textContent = 'Rename Version';
    if (subEl) subEl.textContent = `For Form: ${form.label || form.id} (Current: ${versionId})`;
    if (labelEl) labelEl.textContent = 'New Version Tag *';
    if (input) input.value = versionId;
    if (helpEl) helpEl.textContent = 'e.g. v3.3. Version tags must be unique within this form.';
    if (extraWrap) extraWrap.style.display = 'none';

    const modal = document.getElementById('modalRenameItem');
    if (modal) {
      modal.style.display = 'flex';
      modal.classList.add('open');
    }
    setTimeout(() => { input?.focus(); input?.select(); }, 80);
  },

  closeRenameModal() {
    const modal = document.getElementById('modalRenameItem');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
    }
    this._renameTarget = null;
  },

  async confirmRenameItem() {
    if (!this._renameTarget) return;
    const input = document.getElementById('modalRenameInput');
    const newVal = (input?.value || '').trim();
    if (!newVal) {
      this.showValidationError('Name Required', 'Please enter a non-empty name.');
      input?.focus();
      return;
    }

    const target = this._renameTarget;
    const form = (this.allForms || []).find(f => f.id === target.formId) || this.getActiveForm();
    if (!form) return;

    if (target.type === 'form') {
      // Check duplicate form name across all other forms
      const isDuplicate = (this.allForms || []).some(f =>
        f.id !== form.id && (
          (f.label && f.label.trim().toLowerCase() === newVal.toLowerCase()) ||
          (f.schema?.title && f.schema.title.trim().toLowerCase() === newVal.toLowerCase())
        )
      );
      if (isDuplicate) {
        this.showValidationError(
          'Duplicate Form Name',
          `A form named "${newVal}" already exists in the workspace. Duplicate form names are not allowed.`
        );
        input?.focus();
        return;
      }

      form.label = newVal;
      if (form.schema) form.schema.title = newVal;
      if (form.id === this.activeFormId) {
        this.formSchema.title = newVal;
        const topTitle = document.getElementById('topNavFormTitle');
        if (topTitle) topTitle.textContent = newVal;
        const ciscoInput = document.querySelector('.cisco-bld-title-edit');
        if (ciscoInput) ciscoInput.value = newVal;
      }
      this.closeRenameModal();
      await window.WorkspaceRepo?.renameForm(form.id, newVal);
      this.renderFormsTree();
      this.renderFormTabs();
      this._showToast(`Form renamed to "${newVal}"`);
    } else if (target.type === 'sprint') {
      // Check duplicate sprint within form
      const extraInput = document.getElementById('modalRenameExtraInput');
      const newSprintId = (extraInput?.value || newVal).trim().toLowerCase().replace(/[^a-z0-9.]/g, '-');
      const isDuplicate = (form.sprints || []).some(sp =>
        sp.sprintId !== target.oldSprintId && (
          (sp.sprintLabel && sp.sprintLabel.trim().toLowerCase() === newVal.toLowerCase()) ||
          (sp.sprintId && sp.sprintId.trim().toLowerCase() === newSprintId.toLowerCase())
        )
      );
      if (isDuplicate) {
        this.showValidationError(
          'Duplicate Sprint Name',
          `A sprint named "${newVal}" (${newSprintId}) already exists for form "${form.label || form.id}". Duplicate sprint names are not allowed.`
        );
        input?.focus();
        return;
      }

      const sprint = (form.sprints || []).find(sp => sp.sprintId === target.oldSprintId);
      if (sprint) {
        sprint.sprintLabel = newVal;
        sprint.sprintId = newSprintId;
        (sprint.versions || []).forEach(v => {
          v.sprint = newVal;
        });
      }
      if (form.activeSprint === target.oldSprintId) {
        form.activeSprint = newSprintId;
      }
      this.closeRenameModal();
      await window.WorkspaceRepo?.renameSprint(form.id, target.oldSprintId, newSprintId, newVal);
      this.renderFormsTree();
      this.syncCanvasHeader();
      this._showToast(`Sprint renamed to "${newVal}"`);
    } else if (target.type === 'version') {
      const normalized = window.VersionManager?.normalizeVersionTag(newVal) || newVal;
      // Check duplicate version tag within form
      const isDuplicate = (form.versions || []).some(v =>
        v.versionId.toLowerCase() !== target.oldVersionId.toLowerCase() &&
        v.versionId.toLowerCase() === normalized.toLowerCase()
      );
      if (isDuplicate) {
        this.showValidationError(
          'Duplicate Version Tag',
          `Version tag "${normalized}" already exists for form "${form.label || form.id}". Duplicate version tags are not allowed.`
        );
        input?.focus();
        return;
      }

      const verObj = (form.versions || []).find(v => v.versionId.toLowerCase() === target.oldVersionId.toLowerCase());
      if (verObj) {
        verObj.versionId = normalized;
        if (verObj.versionLabel) {
          verObj.versionLabel = verObj.versionLabel.replace(target.oldVersionId, normalized);
        }
      }
      (form.sprints || []).forEach(sp => {
        (sp.versions || []).forEach(sv => {
          if (sv.versionId && sv.versionId.toLowerCase() === target.oldVersionId.toLowerCase()) {
            sv.versionId = normalized;
          }
        });
        if (sp.publishedVersionId && sp.publishedVersionId.toLowerCase() === target.oldVersionId.toLowerCase()) {
          sp.publishedVersionId = normalized;
        }
      });
      if (form.activeVersionId && form.activeVersionId.toLowerCase() === target.oldVersionId.toLowerCase()) {
        form.activeVersionId = normalized;
      }
      this.closeRenameModal();
      await window.WorkspaceRepo?.renameVersion(form.id, target.oldVersionId, normalized);
      this.renderFormsTree();
      this.syncCanvasHeader();
      this.renderFormTabs();
      const vhModal = document.getElementById('modalVersionHistory');
      if (vhModal && vhModal.classList.contains('open')) {
        this.openVersionHistoryModal('overview', normalized, form.id);
      }
      this._showToast(`Version renamed to "${normalized}"`);
    }
  },

  // --------------------------------------------------------------------------
  // Navbar Version Selector (select element in navbar)
  // --------------------------------------------------------------------------

  /**
   * Sync the navbar version <select> dropdown with the active form's versions.
   */
  syncVersionSelect() {
    const active = this.getActiveForm();
    const sel = document.getElementById('navVersionSelect');
    if (!sel || !active) return;

    window.VersionManager?.ensureFormVersions(active);
    const versions = active.versions || [];

    sel.innerHTML = '';
    if (versions.length === 0) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'No versions';
      sel.appendChild(opt);
      return;
    }

    // Show newest first
    const reversed = [...versions].reverse();
    reversed.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.versionId;
      opt.textContent = `${v.versionId}  ${v.sprint || ''}`;
      if (v.versionId === active.activeVersionId) opt.selected = true;
      sel.appendChild(opt);
    });
  },

  /**
   * Called when the user picks a version from the navbar <select>.
   * Loads that version's schema into the canvas for editing.
   */
  onVersionSelectChange(selectedVersionId) {
    if (!selectedVersionId) return;
    const active = this.getActiveForm();
    if (!active) return;

    const target = (active.versions || []).find(v => v.versionId === selectedVersionId);
    if (!target) return;

    if (selectedVersionId === active.activeVersionId) return; // already loaded

    if (!confirm(`Load version ${selectedVersionId} (${target.sprint}) into the canvas for editing?\n\nThis will replace the current canvas. Save your work first if needed.`)) {
      // Reset select to current version
      this.syncVersionSelect();
      return;
    }

    // Swap to the selected version
    window.VersionManager.swapToVersion(active, selectedVersionId);
    this.formSchema = active.schema;
    this.saveAllForms();
    this.render();
    this.syncCanvasHeader();
    this.renderFormTabs();
    this._showToast(`Loaded ${selectedVersionId} (${target.sprint})  now editing this version.`);
  },




  /**
 * Toggle a form between Active (live in MOPs) and Inactive (disabled/archived).
 */
  toggleFormActiveStatus(formId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) return;

    // Toggle active status (default is true if undefined)
    const wasActive = form.active !== false;
    form.active = !wasActive;
    if (form.schema) form.schema.active = form.active;

    this.saveAllForms();
    this.renderFormTabs();
    this.renderFormsGallery?.();
    this._showToast(`"${form.schema?.title || form.label}" marked as ${form.active ? 'Active' : 'Inactive'}`);
  },

  /**
   * Toggle a form's read-only (locked) state.
   * When locked, the canvas is view-only  no edits allowed.
   */
  toggleFormReadOnly(formId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) return;

    form.readOnly = !form.readOnly;
    if (form.schema) form.schema.readOnly = form.readOnly;

    this.saveAllForms();
    this.renderFormTabs();

    // If this is the currently open form, re-render canvas immediately
    if (formId === this.activeFormId) {
      this.render();
    }

    const label = form.schema?.title || form.label || formId;
    this._showToast(form.readOnly
      ? `"${label}" is now Read Only  editing disabled`
      : `"${label}" is now Editable`);
  },

  /**
   * Toggle a specific version's read-only state.
   * Displayed on the form link row under each version.
   */
  toggleVersionReadOnly(formId, versionId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) return;

    if (!form.lockedVersions) form.lockedVersions = [];
    const idx = form.lockedVersions.indexOf(versionId);
    let isNowLocked = false;
    if (idx >= 0) {
      form.lockedVersions.splice(idx, 1);
      isNowLocked = false;
    } else {
      form.lockedVersions.push(versionId);
      isNowLocked = true;
    }

    // If currently active version is this one, update active form readOnly flag & re-render canvas
    if (form.id === this.activeFormId && (form.activeVersionId === versionId || !this.activeFormId)) {
      form.readOnly = isNowLocked;
      if (this.formSchema) this.formSchema.readOnly = isNowLocked;
      this.render();
    }

    this.saveAllForms();
    this.renderFormTabs();

    const label = form.label || formId;
    this._showToast(isNowLocked
      ? `"${label}" (${versionId}) marked as Read Only`
      : `"${label}" (${versionId}) is now Editable`);
  },

  /**
   * Permanently delete a form from the workstation workspace.
   */
  deleteForm(formId, event) {
    if (event) event.stopPropagation();
    const idx = (this.allForms || []).findIndex(f => f.id === formId);
    if (idx < 0) return;

    const form = this.allForms[idx];
    const formName = form.schema?.title || form.label || 'form';

    if (!confirm(`Are you sure you want to delete "${formName}"?\n\nThis action cannot be undone. All versions and field configurations for this form will be removed.`)) {
      return;
    }

    this.allForms.splice(idx, 1);

    // Persist deletion to disk and localStorage
    window.WorkspaceRepo?.deleteForm(formId);

    if (this.activeFormId === formId) {
      if (this.allForms.length > 0) {
        this.switchActiveForm(this.allForms[0].id);
      } else {
        this.activeFormId = null;
        this.formSchema = { title: '', description: '', sections: [] };
        this.renderFormTabs();
        this.render();
      }
    } else {
      this.saveAllForms();
      this.renderFormTabs();
    }

    this.renderFormsGallery?.();
    this._showToast(`Deleted form "${formName}"`);
  },

  /**
   * Prompt and permanently delete a version from a form.
   */
  async promptDeleteVersion(formId, versionId, event) {
    if (event) event.stopPropagation();
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) return;

    // Safety check: count total versions
    const allVersions = form.versions || [];
    if (allVersions.length <= 1) {
      this.showValidationError('Cannot Delete Version', `Version "${versionId}" is the only version of "${form.label || form.id}". Forms must have at least one version.`);
      return;
    }

    if (!confirm(`Are you sure you want to delete version "${versionId}" from "${form.label || form.id}"?\n\nThis will remove the version snapshot. This action cannot be undone.`)) {
      return;
    }

    // 1. Remove from flat form.versions
    const vIdx = allVersions.findIndex(v => v.versionId && v.versionId.toLowerCase() === versionId.toLowerCase());
    if (vIdx >= 0) allVersions.splice(vIdx, 1);

    // 2. Remove from sprint.versions
    (form.sprints || []).forEach(sp => {
      if (Array.isArray(sp.versions)) {
        const spIdx = sp.versions.findIndex(v => v.versionId && v.versionId.toLowerCase() === versionId.toLowerCase());
        if (spIdx >= 0) sp.versions.splice(spIdx, 1);
      }
      if (sp.publishedVersionId && sp.publishedVersionId.toLowerCase() === versionId.toLowerCase()) {
        sp.publishedVersionId = (sp.versions && sp.versions[sp.versions.length - 1]?.versionId) || '';
      }
    });

    // 3. If currently active, switch to newest remaining version
    if (form.activeVersionId && form.activeVersionId.toLowerCase() === versionId.toLowerCase()) {
      const remaining = allVersions[allVersions.length - 1];
      if (remaining) {
        form.activeVersionId = remaining.versionId;
        form.activeSprint = remaining.sprint || form.activeSprint;
        if (remaining.schema) {
          form.schema = JSON.parse(JSON.stringify(remaining.schema));
          if (this.activeFormId === formId) {
            this.formSchema = form.schema;
          }
        }
      }
    }

    // 4. Remove from lockedVersions if present
    if (Array.isArray(form.lockedVersions)) {
      form.lockedVersions = form.lockedVersions.filter(id => id.toLowerCase() !== versionId.toLowerCase());
    }

    // 5. Persist to disk via API and save in localStorage
    await window.WorkspaceRepo?.deleteVersion(formId, versionId);
    this.saveAllForms();

    // 6. Refresh UI
    this.renderFormsTree();
    this.syncCanvasHeader();
    this.renderFormTabs();
    if (this.activeFormId === formId) this.render();

    // If Version History modal is open, refresh it
    const vhModal = document.getElementById('modalVersionHistory');
    if (vhModal && vhModal.classList.contains('open')) {
      this.vhState.selectedVersionId = form.activeVersionId;
      this.renderVersionHistoryList();
      this.selectVersionInHistory(form.activeVersionId);
    }

    this._showToast(`Deleted version ${versionId}`);
  },

vhState: {
    selectedVersionId: null,
    activeTab: 'overview'
  },

  getActiveForm() {
    return (this.allForms || []).find(f => f.id === this.activeFormId) || null;
  },

  ensureActiveForm() {
    let active = this.getActiveForm();
    if (active) return active;

    const tf = (this.allForms || []).find(f => f.id === 'test-form') || (this.allForms || [])[0];
    if (tf) {
      const activeVerId = tf.activeVersionId || (tf.versions && tf.versions[tf.versions.length - 1]?.versionId) || 'v3.2';
      this.openVersionFromTree(tf.id, activeVerId);
      return this.getActiveForm();
    }
    return null;
  },

  openDefaultForm() {
    const tf = (this.allForms || []).find(f => f.id === 'test-form') || (this.allForms || [])[0];
    if (tf) {
      const activeVerId = tf.activeVersionId || (tf.versions && tf.versions[tf.versions.length - 1]?.versionId) || 'v3.2';
      this.openVersionFromTree(tf.id, activeVerId);
      this._showToast(`Loaded ${tf.schema?.title || tf.label || 'TestForm'} (${activeVerId})`);
    }
  },

  // --------------------------------------------------------------------------
  // Navbar Quick Version Dropdown
  // --------------------------------------------------------------------------
  toggleNavVersionDropdown(e) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    const dropdown = document.getElementById('navVersionDropdown');
    if (!dropdown) return;
    const isShowing = dropdown.style.display !== 'none';
    if (isShowing) {
      this.closeNavVersionDropdown();
    } else {
      this.renderNavVersionDropdown();
      dropdown.style.display = 'block';
    }
  },

  closeNavVersionDropdown() {
    const dropdown = document.getElementById('navVersionDropdown');
    if (dropdown) dropdown.style.display = 'none';
  },

  renderNavVersionDropdown() {
    const active = this.getActiveForm();
    if (!active || !window.VersionManager) return;
    window.VersionManager.ensureFormVersions(active);

    const listEl = document.getElementById('navVdList');
    const countEl = document.getElementById('navVdCount');
    if (!listEl) return;

    const versions = active.versions || [];
    if (countEl) countEl.textContent = `${versions.length} Version${versions.length === 1 ? '' : 's'}`;

    listEl.innerHTML = '';

    if (versions.length === 0) {
      listEl.innerHTML = '<div style="padding: 12px; text-align: center; color: #64748b; font-size: 12px;">No versions saved yet</div>';
      return;
    }

    // Show newest first (reverse chronological)
    const reversed = [...versions].reverse();
    reversed.forEach(v => {
      const isActiveVer = v.versionId === active.activeVersionId;
      const item = document.createElement('div');
      item.className = `nav-vd-item ${isActiveVer ? 'active' : ''}`;
      item.title = isActiveVer ? 'Currently active working copy' : `Click to switch to ${v.versionId}`;

      const fCount = v.stats?.fieldCount || window.VersionManager.countFields(v.schema) || 0;
      const d = v.timestamp ? new Date(v.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';

      item.innerHTML = `
        <div class="nav-vd-item-left">
          <div class="nav-vd-ver-tag">
            <span>${v.versionId}</span>
            ${isActiveVer ? '<span class="nav-vd-active-pill">* Active</span>' : ''}
          </div>
          <div class="nav-vd-sprint">${v.sprint || 'Sprint'}  ${fCount} fields ${d ? ' ' + d : ''}</div>
        </div>
        <div class="nav-vd-item-right">
          ${isActiveVer
          ? '<span style="font-size: 11px; font-weight: 700; color: #005fb8;">Current</span>'
          : `<button type="button" class="nav-vd-switch-btn" onclick="App.swapFromNavDropdown('${v.versionId}', event)">Switch </button>`
        }
        </div>
      `;

      item.onclick = (e) => {
        if (!isActiveVer) {
          this.swapFromNavDropdown(v.versionId, e);
        }
      };

      listEl.appendChild(item);
    });
  },

  swapFromNavDropdown(versionId, e) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    const active = this.getActiveForm();
    if (!active || !versionId) return;

    window.VersionManager.swapToVersion(active, versionId);
    this.formSchema = active.schema;
    this.saveAllForms();
    this.render();
    this.syncCanvasHeader();
    this.renderFormTabs();
    this.closeNavVersionDropdown();
    this._showToast(`Swapped active form to ${versionId}!`);
  },



  // Version History Modal
  openVersionHistoryModal(initialTab = 'overview', targetVersionId = null, formId = null, baselineVersionId = null) {
    if (formId) {
      this.activeFormId = formId;
      this._userHasOpenedForm = true;
      const f = (this.allForms || []).find(x => x.id === formId);
      if (f && f.schema) this.formSchema = f.schema;
    }
    let active = this.getActiveForm();
    if (!active) {
      const tf = (this.allForms || []).find(f => f.id === 'test-form') || (this.allForms || [])[0];
      if (tf) {
        this.activeFormId = tf.id;
        this._userHasOpenedForm = true;
        if (tf.schema) this.formSchema = tf.schema;
        active = tf;
      } else {
        return;
      }
    }
    window.VersionManager.ensureFormVersions(active);

    const titleEl = document.getElementById('vhModalSubtitle');
    if (titleEl) titleEl.textContent = `${active.schema?.title || active.label} (${active.configFile || ''})`;

    this.vhState.selectedVersionId = targetVersionId || active.activeVersionId || active.versions[active.versions.length - 1]?.versionId;
    this.vhState.baselineVersionId = baselineVersionId || null;
    this.vhState.activeTab = initialTab;

    this.renderVersionHistoryList();
    this.selectVersionInHistory(this.vhState.selectedVersionId, baselineVersionId);
    this.switchVhTab(initialTab);

    document.getElementById('modalVersionHistory')?.classList.add('open');
  },

  /**
   * One-click trigger for Change History from tree or navbar
   * Automatically targets targetVersionId and diffs against its immediately preceding version!
   */
  showVersionChangeHistory(formId = null, targetVersionId = null) {
    const fId = formId || this.activeFormId || 'test-form';
    const form = (this.allForms || []).find(f => f.id === fId);
    if (!form) return;

    if (window.VersionManager) {
      window.VersionManager.ensureFormVersions(form);
    }

    const versions = form.versions || [];
    const sorted = [...versions].sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));

    const targetVer = sorted.find(v => v.versionId === targetVersionId) || sorted[sorted.length - 1];
    const targetIdx = sorted.findIndex(v => v.versionId === targetVer?.versionId);
    const prevVer = targetIdx > 0 ? sorted[targetIdx - 1] : null;

    this.openVersionHistoryModal('diff', targetVer?.versionId, fId, prevVer?.versionId);
  },

  showCurrentFormChangeHistory() {
    const active = this.getActiveForm();
    if (!active) {
      this.showVersionChangeHistory('test-form', 'v1.4');
      return;
    }
    this.showVersionChangeHistory(active.id, active.activeVersionId);
  },

  onVhCompareTargetChange(newTargetId) {
    this.selectVersionInHistory(newTargetId);
  },

  onVhCompareBaselineChange(newBaselineId) {
    const active = this.getActiveForm();
    if (!active) return;
    const targetVer = (active.versions || []).find(v => v.versionId === this.vhState.selectedVersionId);
    if (!targetVer) return;
    this.vhState.baselineVersionId = newBaselineId;
    this.renderVisualDiff(targetVer, newBaselineId);
  },

  highlightChangesOnCanvasFromModal() {
    const active = this.getActiveForm();
    if (!active) return;
    const targetVerId = this.vhState.selectedVersionId || active.activeVersionId;
    const baselineVerId = this.vhState.baselineVersionId;

    // Load target version on canvas
    this.openVersionFromTree(active.id, targetVerId);

    // Set baseline and enable diff
    if (baselineVerId && baselineVerId !== '__canvas__') {
      this.sprintDiffBaselineId = baselineVerId;
    }
    this.toggleSprintDiffMode(true);
    this.closeVersionHistoryModal();
    this._showToast(`Live Sprint Diff Active: Highlighting ${targetVerId} vs ${baselineVerId || 'baseline'} on canvas!`);
  },

  loadVhTargetVersionToCanvas() {
    const active = this.getActiveForm();
    if (!active) return;
    const targetVerId = this.vhState.selectedVersionId || active.activeVersionId;
    this.openVersionFromTree(active.id, targetVerId);
    this.closeVersionHistoryModal();
    this._showToast(`Loaded ${targetVerId} on canvas!`);
  },

  closeVersionHistoryModal() {
    document.getElementById('modalVersionHistory')?.classList.remove('open');
  },

  renderVersionHistoryList() {
    const active = this.getActiveForm();
    if (!active) return;
    const container = document.getElementById('vhVersionListContainer');
    const countBadge = document.getElementById('vhSidebarCount');
    if (!container) return;

    const versions = active.versions || [];
    if (countBadge) countBadge.textContent = `${versions.length} Version${versions.length === 1 ? '' : 's'}`;

    container.innerHTML = '';

    // Render in reverse chronological order (newest first)
    const reversed = [...versions].reverse();
    reversed.forEach(v => {
      const isSelected = v.versionId === this.vhState.selectedVersionId;
      const isActiveVer = v.versionId === active.activeVersionId;
      const card = document.createElement('div');
      card.className = `vh-card ${isSelected ? 'active' : ''}`;
      card.onclick = () => this.selectVersionInHistory(v.versionId);

      const d = v.timestamp ? new Date(v.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';
      const statusClass = (v.status || 'archived').toLowerCase().replace(/[^a-z]/g, '');

      card.innerHTML = `
        <div class="vh-card-header">
          <span class="vh-card-tag">${v.versionId}</span>
          <div style="display:flex; align-items:center; gap:6px;">
            <button type="button" class="vh-card-quick-swap-btn" title="Rename Version ${v.versionId}" onclick="event.stopPropagation(); App.promptRenameVersion('${active.id}', '${v.versionId}', event)"> Rename</button>
            <span class="vh-card-status ${statusClass}">${v.status || 'Archived'}</span>
            ${!isActiveVer ? `<button type="button" class="vh-card-quick-swap-btn" title="Instantly switch working copy to this version" onclick="event.stopPropagation(); App.swapToVhVersionDirect('${v.versionId}')">Load </button>` : ''}
          </div>
        </div>
        <div class="vh-card-sprint">${v.sprint || 'Sprint'}</div>
        <div class="vh-card-date">${d}  by ${v.author || 'Team'}</div>
        <div class="vh-card-stats">
          <span>${v.stats?.sectionCount || 0} Secs</span>
          <span></span>
          <span>${v.stats?.fieldCount || 0} Fields</span>
          ${v.stats?.rulesCount ? `<span>  ${v.stats.rulesCount} Rules</span>` : ''}
          ${isActiveVer ? `<span style="margin-left:auto; color:#15803d; font-weight:700; background:#dcfce7; padding:1px 6px; border-radius:10px; font-size:10px;">* Current Active</span>` : ''}
        </div>
      `;
      container.appendChild(card);
    });
  },

  swapToVhVersionDirect(versionId) {
    this.vhState.selectedVersionId = versionId;
    this.swapToSelectedVhVersion();
  },

  selectVersionInHistory(versionId, explicitBaselineId = null) {
    const active = this.getActiveForm();
    if (!active) return;
    const v = (active.versions || []).find(ver => ver.versionId === versionId);
    if (!v) return;

    this.vhState.selectedVersionId = versionId;

    // Determine baseline (previous version in chronological order)
    const versions = active.versions || [];
    const sorted = [...versions].sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));
    const currIdx = sorted.findIndex(ver => ver.versionId === versionId);

    let baselineVer = null;
    if (explicitBaselineId) {
      if (explicitBaselineId === '__canvas__') {
        baselineVer = { versionId: 'Live Canvas', isCanvas: true, sprint: 'Canvas', schema: this.formSchema };
      } else {
        baselineVer = sorted.find(ver => ver.versionId === explicitBaselineId) || null;
      }
    } else if (currIdx > 0) {
      // Naturally previous version!
      baselineVer = sorted[currIdx - 1];
    }
    this.vhState.baselineVersionId = baselineVer ? baselineVer.versionId : null;

    // Update active highlight in left list
    document.querySelectorAll('.vh-card').forEach(card => {
      const tag = card.querySelector('.vh-card-tag')?.textContent;
      card.classList.toggle('active', tag === versionId);
    });

    // Update top header
    const titleEl = document.getElementById('vhSelectedVersionTitle');
    const sprintEl = document.getElementById('vhSelectedSprintBadge');
    const statusEl = document.getElementById('vhSelectedStatusPill');
    const metaEl = document.getElementById('vhSelectedMeta');

    if (titleEl) titleEl.textContent = v.versionId;
    if (sprintEl) sprintEl.textContent = v.sprint;
    if (statusEl) {
      statusEl.textContent = v.status || 'Archived';
      statusEl.className = 'vh-status-pill ' + (v.status || 'archived').toLowerCase();
    }
    const dStr = v.timestamp ? new Date(v.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Unknown date';
    if (metaEl) metaEl.textContent = `Recorded on ${dStr} by ${v.author || 'MOPs Team'}`;

    // Render Overview Pane
    const notesText = document.getElementById('vhNotesText');
    if (notesText) notesText.textContent = v.notes || 'No sprint changelog recorded.';

    const statSec = document.getElementById('vhStatSections');
    const statFld = document.getElementById('vhStatFields');
    const statRls = document.getElementById('vhStatRules');
    const statAut = document.getElementById('vhStatAuthor');

    if (statSec) statSec.textContent = v.stats?.sectionCount || v.schema?.sections?.length || 0;
    if (statFld) statFld.textContent = v.stats?.fieldCount || window.VersionManager.countFields(v.schema);
    if (statRls) statRls.textContent = v.stats?.rulesCount || window.VersionManager.countRules(v.schema);
    if (statAut) statAut.textContent = v.author || 'Team';

    const secList = document.getElementById('vhSectionsList');
    if (secList) {
      secList.innerHTML = (v.schema?.sections || []).map(s => `
        <span class="vh-section-chip">
          <strong>${s.title}</strong>
          <span style="opacity:0.75; font-size:11px;">(${s.fields?.length || 0} fields)</span>
        </span>
      `).join('') || '<span style="color:#94a3b8; font-style:italic;">No sections defined.</span>';
    }

    // Render Diff Pane: Target Version vs Baseline (Previous Version)
    this.renderVisualDiff(v, baselineVer);

    // Render JSON Pane
    const jsonBlock = document.getElementById('vhJsonCodeBlock');
    if (jsonBlock) {
      jsonBlock.textContent = JSON.stringify(v.schema, null, 2);
    }
  },

  switchVhTab(tabKey) {
    this.vhState.activeTab = tabKey;
    document.querySelectorAll('.vh-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.vh-pane').forEach(p => {
      p.style.display = 'none';
      p.classList.remove('active');
    });

    const activeBtn = document.getElementById('vhTabBtn' + tabKey.charAt(0).toUpperCase() + tabKey.slice(1));
    const activePane = document.getElementById('vhPane_' + tabKey);
    if (activeBtn) activeBtn.classList.add('active');
    if (activePane) {
      activePane.style.display = 'flex';
      activePane.classList.add('active');
    }
  },

  renderVisualDiff(targetVer, baselineVer = null) {
    const summaryCard = document.getElementById('vhDiffSummaryCard');
    const resultsContainer = document.getElementById('vhDiffResults');
    const badgeCount = document.getElementById('vhDiffCountBadge');
    const controlsBar = document.getElementById('vhDiffControlsBar');
    const narrativeCard = document.getElementById('vhDiffNarrativeCard');
    if (!summaryCard || !resultsContainer) return;

    const active = this.getActiveForm();
    if (!active) return;

    // Normalization: if targetVer is a schema instead of version object, wrap it
    if (targetVer && !targetVer.versionId && targetVer.sections) {
      targetVer = {
        versionId: this.vhState.selectedVersionId || active.activeVersionId || 'current',
        sprint: active.activeSprint || 'Current Sprint',
        schema: targetVer,
        notes: ''
      };
    }
    if (!targetVer) return;

    const versions = active.versions || [];
    const sortedVersions = [...versions].sort((a, b) => {
      const tA = a.timestamp || '';
      const tB = b.timestamp || '';
      return tA.localeCompare(tB);
    });

    const targetIdx = sortedVersions.findIndex(v => v.versionId === targetVer.versionId);

    // Auto-resolve baseline if not explicitly provided or if baselineVer is string ID
    if (typeof baselineVer === 'string') {
      if (baselineVer === '__canvas__') {
        baselineVer = { versionId: 'Live Canvas', isCanvas: true, sprint: 'Canvas', schema: this.formSchema };
      } else {
        baselineVer = sortedVersions.find(v => v.versionId === baselineVer) || null;
      }
    } else if (baselineVer === null && targetIdx > 0) {
      // Natural previous version!
      baselineVer = sortedVersions[targetIdx - 1];
    }

    this.vhState.selectedVersionId = targetVer.versionId;
    this.vhState.baselineVersionId = baselineVer ? baselineVer.versionId : null;

    // 1. Render Controls Bar
    if (controlsBar) {
      const targetOptions = sortedVersions.map(v => {
        const isSel = v.versionId === targetVer.versionId;
        return `<option value="${v.versionId}" ${isSel ? 'selected' : ''}>${v.versionId} (${v.sprint || 'Sprint'})</option>`;
      }).reverse().join('');

      const baselineOptions = sortedVersions.map((v, idx) => {
        if (v.versionId === targetVer.versionId) return '';
        const isPrev = (idx === targetIdx - 1);
        const isBase = (idx === 0);
        const tag = isPrev ? ' [Previous Version]' : (isBase ? ' [Baseline]' : '');
        const isSel = baselineVer && v.versionId === baselineVer.versionId;
        return `<option value="${v.versionId}" ${isSel ? 'selected' : ''}>${v.versionId} (${v.sprint || ''})${tag}</option>`;
      }).filter(Boolean).reverse().join('');

      const hasCanvas = Boolean(this.formSchema && this.formSchema.sections && this.formSchema.sections.length > 0);
      const isCanvasSel = baselineVer && baselineVer.isCanvas;

      controlsBar.innerHTML = `
        <div class="vh-diff-select-group">
          <span class="vh-diff-label">Comparing:</span>
          <select id="vhTargetVerSelect" class="vh-diff-select" onchange="App.onVhCompareTargetChange(this.value)">
            ${targetOptions}
          </select>
        </div>
        <span class="vh-diff-arrow">vs</span>
        <div class="vh-diff-select-group">
          <span class="vh-diff-label">Previous / Baseline:</span>
          <select id="vhBaselineVerSelect" class="vh-diff-select" onchange="App.onVhCompareBaselineChange(this.value)">
            ${baselineVer ? baselineOptions : '<option value="">(None - Initial Baseline)</option>' + baselineOptions}
            ${hasCanvas ? `<option value="__canvas__" ${isCanvasSel ? 'selected' : ''}>Active Canvas (Working Copy)</option>` : ''}
          </select>
        </div>
        <div class="vh-diff-quick-actions">
          ${baselineVer ? `
            <button type="button" class="btn btn-outline btn-xs" onclick="App.highlightChangesOnCanvasFromModal()" title="Highlight these differences directly on the form canvas">
               Highlight on Canvas
            </button>
          ` : ''}
          <button type="button" class="btn btn-primary btn-xs" onclick="App.loadVhTargetVersionToCanvas()" title="Open ${targetVer.versionId} into form builder">
             Open Version
          </button>
        </div>
      `;
    }

    // 2. Case: Initial Baseline Version (e.g. v1.0 with no previous version)
    if (!baselineVer) {
      if (badgeCount) {
        badgeCount.style.display = 'inline-block';
        badgeCount.textContent = 'Baseline Release';
      }

      if (narrativeCard) {
        narrativeCard.className = 'vh-diff-narrative-card baseline';
        narrativeCard.innerHTML = `
          <div class="vh-diff-narrative-title">
            <span></span> Initial Baseline Version: <strong>${targetVer.versionId}</strong> (${targetVer.sprint || 'Initial Sprint'})
          </div>
          <div class="vh-diff-narrative-desc">
            ${targetVer.notes || 'Initial baseline release of this form. All initial sections and fields are established here.'}
          </div>
        `;
      }

      const secCount = targetVer.schema?.sections?.length || 0;
      const fldCount = window.VersionManager.countFields(targetVer.schema);

      summaryCard.innerHTML = `
        <span class="diff-badge-pill added"> ${fldCount} Initial Fields</span>
        <span class="diff-badge-pill unchanged"> ${secCount} Sections</span>
        <span class="diff-badge-pill" style="background:#e0f2fe; color:#0369a1;"> Baseline Origin</span>
      `;

      resultsContainer.innerHTML = `
        <div style="text-align: center; padding: 25px; color: #0369a1; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; margin-bottom: 12px;">
          <div style="font-size: 16px; font-weight:700; margin-bottom: 4px;"> Initial Baseline Specification</div>
          <div style="font-size: 12.5px; color: #0284c7;">This is version <strong>${targetVer.versionId}</strong>, the initial release of <strong>${active.label || active.id}</strong>. There is no prior version to compare against.</div>
        </div>
        <div style="font-weight: 700; font-size: 12px; color: #475569; text-transform: uppercase; margin-bottom: 8px;">Baseline Sections & Fields:</div>
      `;

      (targetVer.schema?.sections || []).forEach(sec => {
        const secEl = document.createElement('div');
        secEl.className = 'vh-diff-item';
        secEl.style.borderLeft = '4px solid #0284c7';
        secEl.innerHTML = `
          <div style="font-weight:700; color:#0369a1; margin-bottom:6px;"> Section: ${sec.title} (${sec.fields?.length || 0} fields)</div>
          <div style="display:flex; flex-wrap:wrap; gap:6px;">
            ${(sec.fields || []).map(f => `<span class="vh-section-chip" style="font-size:11px;">${f.label || f.wfLabel || f.formData} <em>(${f.type})</em></span>`).join('')}
          </div>
        `;
        resultsContainer.appendChild(secEl);
      });
      return;
    }

    // 3. Diff baselineVer.schema (Previous) vs targetVer.schema (Current)
    const diff = window.VersionManager.diffVersions(baselineVer.schema, targetVer.schema);

    if (badgeCount) {
      badgeCount.style.display = diff.totalChanges > 0 ? 'inline-block' : 'none';
      badgeCount.textContent = `${diff.totalChanges} change${diff.totalChanges === 1 ? '' : 's'} from ${baselineVer.versionId}`;
    }

    // 4. Narrative Card
    if (narrativeCard) {
      narrativeCard.className = 'vh-diff-narrative-card';
      const sprintLabel = targetVer.sprint ? ` [${targetVer.sprint}]` : '';
      const baseSprintLabel = baselineVer.sprint ? ` [${baselineVer.sprint}]` : '';
      narrativeCard.innerHTML = `
        <div class="vh-diff-narrative-title">
          <span></span> Changes in <strong>${targetVer.versionId}</strong>${sprintLabel} from previous version <strong>${baselineVer.versionId}</strong>${baseSprintLabel}
        </div>
        <div class="vh-diff-narrative-desc">
          ${targetVer.notes ? `Sprint Changelog: <em>"${targetVer.notes}"</em>` : `Comparing changes between releases ${baselineVer.versionId}  ${targetVer.versionId}.`}
        </div>
      `;
    }

    // 5. Summary badges
    summaryCard.innerHTML = `
      <span class="diff-badge-pill added"> +${diff.fieldsAdded.length} Fields Added</span>
      <span class="diff-badge-pill modified"> ${diff.fieldsModified.length} Modified</span>
      <span class="diff-badge-pill removed"> -${diff.fieldsRemoved.length} Removed</span>
      <span class="diff-badge-pill unchanged"> ${diff.fieldsUnchanged} Identical</span>
      ${diff.sectionsAdded.length > 0 ? `<span class="diff-badge-pill" style="background:#dcfce7; color:#15803d; border:1px solid #86efac;"> +${diff.sectionsAdded.length} New Section(s)</span>` : ''}
    `;

    resultsContainer.innerHTML = '';

    if (diff.totalChanges === 0) {
      resultsContainer.innerHTML = `
        <div style="text-align: center; padding: 30px; color: #15803d; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px;">
          <div style="font-size: 18px; font-weight:700; margin-bottom: 4px;">OK Identical Specification</div>
          <div style="font-size: 13px; color: #166534;">Version <strong>${targetVer.versionId}</strong> has the exact same sections, fields, and rule configurations as <strong>${baselineVer.versionId}</strong>.</div>
        </div>
      `;
      return;
    }

    // Render Added Sections
    diff.sectionsAdded.forEach(sec => {
      const el = document.createElement('div');
      el.className = 'vh-diff-item added';
      el.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <strong style="color: #15803d;"> + Added New Section:</strong>
            <span style="font-weight:700; margin-left:6px; font-size:13px;">${sec.title}</span>
            <span style="font-size:11.5px; color:#64748b; margin-left:8px;">(${sec.fields?.length || 0} fields)</span>
          </div>
          <span style="font-size:11.5px; background:#dcfce7; color:#15803d; padding:2px 8px; border-radius:10px; font-weight:700;">New Section in ${targetVer.versionId}</span>
        </div>
      `;
      resultsContainer.appendChild(el);
    });

    // Render Added Fields
    diff.fieldsAdded.forEach(item => {
      const el = document.createElement('div');
      el.className = 'vh-diff-item added';
      const f = item.field;
      el.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <strong style="color: #15803d;"> + Added Field in ${targetVer.versionId}:</strong>
            <span style="font-weight:700; margin-left:6px;">${f.label || f.wfLabel || f.formData}</span>
            <span style="font-size:11.5px; color:#64748b; margin-left:8px;">(${f.type || 'text'}, ${f.col || 'col-lg-6'}${f.required ? ', Required' : ''})</span>
            ${f.placeholder ? `<div style="font-size:11px; color:#475569; margin-top:2px;">Placeholder: <em>"${f.placeholder}"</em></div>` : ''}
            ${f.options ? `<div style="font-size:11px; color:#475569; margin-top:2px;">Options (${f.options.length}): ${f.options.join(', ')}</div>` : ''}
          </div>
          <span style="font-size:11.5px; background:#dcfce7; color:#15803d; padding:2px 8px; border-radius:10px; font-weight:600; white-space:nowrap;">In Section: ${item.section}</span>
        </div>
      `;
      resultsContainer.appendChild(el);
    });

    // Render Modified Fields
    diff.fieldsModified.forEach(item => {
      const el = document.createElement('div');
      el.className = 'vh-diff-item modified';
      const changesHtml = item.changes.map(ch => `
        <div class="diff-change-prop">
          <strong>${ch.prop}:</strong>
          <span class="diff-old-val">${ch.from || '(none)'}</span>
          <span style="margin: 0 4px; color:#92400e; font-weight:bold;"></span>
          <span class="diff-new-val" style="background:#fef08a; color:#854d0e; padding:1px 4px; border-radius:3px; font-weight:600;">${ch.to || '(none)'}</span>
        </div>
      `).join('');

      el.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
          <div>
            <strong style="color: #92400e;">  Modified Field in ${targetVer.versionId}:</strong>
            <span style="font-weight:700; margin-left:6px;">${item.fieldB.label || item.fieldB.wfLabel || item.fieldB.formData}</span>
          </div>
          <span style="font-size:11.5px; background:#fef3c7; color:#92400e; padding:2px 8px; border-radius:10px; font-weight:600; white-space:nowrap;">In Section: ${item.section}</span>
        </div>
        ${changesHtml}
      `;
      resultsContainer.appendChild(el);
    });

    // Render Removed Fields
    diff.fieldsRemoved.forEach(item => {
      const el = document.createElement('div');
      el.className = 'vh-diff-item removed';
      el.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <strong style="color: #991b1b;"> - Removed Field in ${targetVer.versionId}:</strong>
            <span style="font-weight:700; margin-left:6px;">${item.field.label || item.field.wfLabel || item.field.formData}</span>
            <span style="font-size:11.5px; color:#64748b; margin-left:8px;">(${item.field.type})</span>
          </div>
          <span style="font-size:11.5px; background:#fee2e2; color:#991b1b; padding:2px 8px; border-radius:10px; font-weight:600; white-space:nowrap;">Was in Section: ${item.section}</span>
        </div>
      `;
      resultsContainer.appendChild(el);
    });

    // Render Removed Sections
    diff.sectionsRemoved.forEach(sec => {
      const el = document.createElement('div');
      el.className = 'vh-diff-item removed';
      el.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <strong style="color: #991b1b;"> - Removed Entire Section:</strong>
            <span style="font-weight:700; margin-left:6px;">${sec.title}</span>
          </div>
          <span style="font-size:11.5px; background:#fee2e2; color:#991b1b; padding:2px 8px; border-radius:10px; font-weight:700;">Removed in ${targetVer.versionId}</span>
        </div>
      `;
      resultsContainer.appendChild(el);
    });
  },

  swapToSelectedVhVersion() {
    const active = this.getActiveForm();
    if (!active || !this.vhState.selectedVersionId) return;

    const vId = this.vhState.selectedVersionId;
    window.VersionManager.swapToVersion(active, vId);
    this.formSchema = active.schema;
    this.saveAllForms();
    this.render();
    this.syncCanvasHeader();
    this.renderFormTabs();
    this.closeVersionHistoryModal();
    this._showToast(`Swapped active form to ${vId}!`);
  },

  previewSelectedVhSnapshot() {
    const active = this.getActiveForm();
    if (!active || !this.vhState.selectedVersionId) return;

    const vId = this.vhState.selectedVersionId;
    window.VersionManager.previewSnapshot(active, vId);
    this.formSchema = active.schema;
    this.render();
    this.syncCanvasHeader();
    this.closeVersionHistoryModal();
    this._showToast(`Viewing snapshot: ${vId}`);
  },

  restoreCurrentSnapshot() {
    const active = this.getActiveForm();
    if (!active) return;
    const vId = window.VersionManager.snapshotVersionId;
    window.VersionManager.restoreCurrentSnapshot(active);
    this.formSchema = active.schema;
    this.saveAllForms();
    this.render();
    this.syncCanvasHeader();
    this.renderFormTabs();
    this._showToast(`Restored ${vId} as active version!`);
  },

  exitSnapshotView() {
    const active = this.getActiveForm();
    if (!active) return;
    window.VersionManager.exitSnapshot(active);
    this.formSchema = active.schema;
    this.render();
    this.syncCanvasHeader();
    this._showToast('Returned to active form');
  },

  forkCurrentSnapshot() {
    const active = this.getActiveForm();
    if (!active) return;
    const vId = window.VersionManager.snapshotVersionId;
    this.forkVersion(active, vId);
  },

  forkSelectedVhVersion() {
    const active = this.getActiveForm();
    if (!active || !this.vhState.selectedVersionId) return;
    this.forkVersion(active, this.vhState.selectedVersionId);
    this.closeVersionHistoryModal();
  },

  forkVersion(form, versionId) {
    const newTitle = prompt('Enter a name for the new forked form tab:', `${form.schema?.title || form.label} (${versionId} Variant)`);
    if (!newTitle || !newTitle.trim()) return;

    const newForm = window.VersionManager.forkVersionAsNewForm(form, versionId, newTitle.trim());
    if (newForm) {
      this.allForms.push(newForm);
      this.switchActiveForm(newForm.id);
      this.renderFormTabs();
      this._showToast(`Created new form tab from ${versionId}!`);
    }
  },

  exportSelectedVhJson() {
    const active = this.getActiveForm();
    if (!active || !this.vhState.selectedVersionId) return;
    window.VersionManager.exportVersionJson(active, this.vhState.selectedVersionId);
  },

  exportAllVersionsBundle() {
    const active = this.getActiveForm();
    if (!active) return;
    window.VersionManager.exportAllVersionsBundle(active);
  },

  async deleteSelectedVhVersion() {
    const active = this.getActiveForm();
    if (!active || !this.vhState.selectedVersionId) return;
    const vId = this.vhState.selectedVersionId;

    if (confirm(`Delete snapshot "${vId}" from version history? This cannot be undone.`)) {
      const ok = window.VersionManager.deleteVersion(active, vId);
      if (ok) {
        // Remove from sprint.versions
        (active.sprints || []).forEach(sp => {
          if (Array.isArray(sp.versions)) {
            const spIdx = sp.versions.findIndex(v => v.versionId && v.versionId.toLowerCase() === vId.toLowerCase());
            if (spIdx >= 0) sp.versions.splice(spIdx, 1);
          }
          if (sp.publishedVersionId && sp.publishedVersionId.toLowerCase() === vId.toLowerCase()) {
            sp.publishedVersionId = (sp.versions && sp.versions[sp.versions.length - 1]?.versionId) || '';
          }
        });

        // Persist to disk via API
        await window.WorkspaceRepo?.deleteVersion(active.id, vId);
        this.saveAllForms();

        this.vhState.selectedVersionId = active.versions[active.versions.length - 1]?.versionId;
        this.renderVersionHistoryList();
        this.selectVersionInHistory(this.vhState.selectedVersionId);
        this.syncCanvasHeader();
        this.renderFormsTree();
        this._showToast(`Deleted ${vId}`);
      }
    }
  },

  copyVhJson() {
    const jsonBlock = document.getElementById('vhJsonCodeBlock');
    if (!jsonBlock) return;
    navigator.clipboard.writeText(jsonBlock.textContent).then(() => {
      const btn = document.getElementById('btnCopyVhJson');
      if (btn) {
        btn.textContent = 'OK Copied!';
        setTimeout(() => { btn.textContent = ' Copy JSON'; }, 1800);
      }
    });
  }
});
