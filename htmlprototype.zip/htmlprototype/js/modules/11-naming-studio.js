/**
 * Cisco MOPs FORM Studio - Project Naming Convention Studio
 * Domain: Dynamic live project name generation, segment token builder, abbreviation mapping (Angular specialNameBuilder contract)
 * File: js/modules/11-naming-studio.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
ABBR_PROGRAM_MAPPING: {
    'Campaign Alignment 1': 'CA1',
    'Campaign Alignment 2': 'CA2',
    'Demand Generation': 'DG',
    'Brand Awareness': 'BA',
    'Partner Marketing': 'PM',
    'Corporate': 'CORP',
    'Product Launch': 'PL',
    'Field Marketing': 'FM',
    'Executive': 'EXEC',
    'Account Based Marketing': 'ABM',
    'Customer Experience': 'CX',
    'Enablement': 'EN',
  },

  ABBR_CAMPAIGN_MAPPING: {
    'Other': 'OTH',
    'Digital Experience': 'DX',
    'Security': 'SEC',
    'Networking': 'NET',
    'Collaboration': 'COLLAB',
    'Cloud': 'CLD',
    'AI & Analytics': 'AIA',
    'SMB': 'SMB',
    'Enterprise': 'ENT',
    'Service Provider': 'SP',
  },

  /** Return abbreviation from a mapping, or fallback to first 4 chars uppercased */
  _getAbbr(value, mapping) {
    if (!value) return '';
    return mapping[value] || value.toString().replace(/[^A-Za-z0-9]/g, '').substring(0, 4).toUpperCase();
  },

  /**
   * Ensure the current formSchema has a namingConvention object.
   * If not present, build sensible defaults from the form's existing fields.
   */
  ensureNamingConvention() {
    if (this.formSchema.namingConvention) return this.formSchema.namingConvention;

    // Scan fields to detect MOPs standard field IDs / formData keys
    const allFields = [];
    (this.formSchema.sections || []).forEach(s => (s.fields || []).forEach(f => allFields.push(f)));

    const has = (key) => allFields.some(f => f.formData === key || f.wfFieldName === key || f.id === key);

    const segments = [];

    // Segment 1: Program/Campaign alignment with abbreviation
    if (has('programAlign')) {
      segments.push({ id: 's_program', type: 'field_abbr', fieldKey: 'programAlign', label: 'Program Align (Abbr)', sample: 'DG' });
    } else if (has('CampaignAlign')) {
      segments.push({ id: 's_campaign', type: 'field_abbr', fieldKey: 'CampaignAlign', label: 'Campaign Align (Abbr)', sample: 'DX' });
    } else {
      segments.push({ id: 's_campaign', type: 'field_abbr', fieldKey: 'CampaignAlign', label: 'Campaign Align (Abbr)', sample: 'DG' });
    }

    // Segment 2: Content / Project title (user entered text)
    if (has('contentTitle')) {
      segments.push({ id: 's_title', type: 'field_value', fieldKey: 'contentTitle', label: 'Project Title', sample: 'SMB-Security-Buyers-EMEA' });
    }

    // Segment 3: Display type (mapped to Workfront projectType)
    if (has('displayType')) {
      segments.push({ id: 's_type', type: 'field_value', fieldKey: 'displayType', label: 'Asset Type', sample: 'Web Page' });
    }

    // Segment 4: Fiscal quarter from system context
    segments.push({ id: 's_fq', type: 'system', fieldKey: 'fiscalQuarter', label: 'Fiscal Quarter', sample: 'Q1FY26' });

    // Segment 5: Region (array join)
    if (has('regions1') || has('region')) {
      const rKey = has('regions1') ? 'regions1' : 'region';
      segments.push({ id: 's_region', type: 'field_value', fieldKey: rKey, label: 'Region', sample: 'AMER' });
    }

    // Segment 6: Reference number / ID (static label)
    segments.push({ id: 's_ref', type: 'static', fieldKey: '', label: 'Project Reference #', sample: '[ID]' });

    this.formSchema.namingConvention = {
      delimiter: '_',
      segments
    };
    return this.formSchema.namingConvention;
  },

  /**
   * Evaluate the project name given a set of sample/override values.
   * Returns { tokens: string[], evaluated: string }
   * Mirrors the specialNameBuilder logic from form.web-page.config.ts L6187
   */
  evaluateProjectName(customSamples) {
    const nc = this.ensureNamingConvention();
    const delim = nc.delimiter || '_';
    const tokens = [];

    (nc.segments || []).forEach(seg => {
      let val = '';
      if (seg.type === 'static') {
        val = seg.sample || seg.label || '';
      } else if (seg.type === 'system') {
        // System-provided values  use sample in prototype context
        val = (customSamples && customSamples[seg.fieldKey]) || seg.sample || '';
      } else if (seg.type === 'field_abbr') {
        const raw = (customSamples && customSamples[seg.fieldKey]) || seg.sample || '';
        const mapping = seg.fieldKey === 'programAlign' ? this.ABBR_PROGRAM_MAPPING : this.ABBR_CAMPAIGN_MAPPING;
        val = this._getAbbr(raw, mapping);
      } else if (seg.type === 'field_value') {
        val = (customSamples && customSamples[seg.fieldKey]) || seg.sample || '';
        // Arrays (e.g. regions1) joined with comma
        if (Array.isArray(val)) val = val.join(',');
      }
      // Clean whitespace and push non-empty
      val = (val || '').toString().trim();
      if (val) tokens.push(val);
    });

    const evaluated = tokens.join(delim);
    return { tokens, evaluated };
  },

  /**
   * Sync the canvas Naming Rule Bar (#canvasProjectNameLivePreview)
   * Called after render() or whenever the schema changes.
   */
  syncCanvasNamingRuleBar() {
    const bar = document.getElementById('canvasNamingRuleBar');
    const preview = document.getElementById('canvasProjectNameLivePreview');
    if (!preview) return;

    const nc = this.formSchema.namingConvention;
    if (!nc) {
      // Show a subtle hint
      preview.innerHTML = `<span class="cnrb-loading">Configure naming rules  <em> Naming Rules</em></span>`;
      if (bar) bar.style.display = 'flex';
      return;
    }

    const { tokens, evaluated } = this.evaluateProjectName();
    const delim = nc.delimiter || '_';

    if (!tokens.length) {
      preview.innerHTML = `<span class="cnrb-loading">No segments configured</span>`;
      return;
    }

    // Render pills with delimiters between them
    const html = tokens.map((t, i) =>
      `<span class="cnrb-pill">${this._escHtml(t)}</span>${i < tokens.length - 1 ? `<span class="cnrb-delim">${this._escHtml(delim)}</span>` : ''}`
    ).join('');

    preview.innerHTML = html;
    if (bar) bar.style.display = 'flex';
  },

  /** HTML-escape helper */
  _escHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  },

  // 
  // Modal: Open / Close
  // 

  openNamingConventionModal() {
    const modal = document.getElementById('modalNamingStudio');
    if (!modal) return;

    // Ensure naming convention exists
    this.ensureNamingConvention();

    // Populate form badge with active form label
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const badge = document.getElementById('namingModalFormBadge');
    if (badge) badge.textContent = active?.label || this.formSchema.title || 'Form';

    // Set delimiter selector
    const delimSelect = document.getElementById('namingDelimiterSelect');
    if (delimSelect) delimSelect.value = this.formSchema.namingConvention.delimiter || '_';

    // Switch to builder tab by default
    this.switchNamingTab('builder');

    // Render segments list
    this.renderNamingSegments();

    // Refresh live preview
    this._refreshNamingModalPreview();

    // Show modal
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  },

  closeNamingConventionModal() {
    const modal = document.getElementById('modalNamingStudio');
    if (modal) modal.classList.remove('open');
    document.body.style.overflow = '';
  },

  // 
  // Segments Renderer
  // 

  renderNamingSegments() {
    const list = document.getElementById('namingSegmentsList');
    if (!list) return;

    const nc = this.ensureNamingConvention();
    const segments = nc.segments || [];

    if (!segments.length) {
      list.innerHTML = `<div class="naming-empty-state">No segments yet. Click <strong>+ Add Segment</strong> above to begin.</div>`;
      return;
    }

    // Collect all field options from schema for the fieldKey dropdown
    const allFields = [];
    (this.formSchema.sections || []).forEach(s => (s.fields || []).forEach(f => allFields.push(f)));
    const fieldOptions = allFields.map(f =>
      `<option value="${this._escHtml(f.formData || f.id)}">${this._escHtml(f.label || f.wfLabel || f.formData || f.id)}</option>`
    ).join('');
    const systemOptions = `<option value="fiscalQuarter">fiscalQuarter (system)</option><option value="projectType">projectType (enriched)</option>`;

    list.innerHTML = segments.map((seg, idx) => {
      const isFirst = idx === 0;
      const isLast = idx === segments.length - 1;
      const typeSelected = (t) => seg.type === t ? 'selected' : '';
      const fieldVal = this._escHtml(seg.fieldKey || '');
      const sampleVal = this._escHtml(seg.sample || '');
      const labelVal = this._escHtml(seg.label || '');

      return `
        <div class="naming-segment-card" data-idx="${idx}">
          <div class="naming-seg-controls">
            <button type="button" class="naming-seg-move" onclick="App.moveNamingSegment(${idx}, -1)" ${isFirst ? 'disabled' : ''} title="Move up">^</button>
            <span class="naming-seg-num">${idx + 1}</span>
            <button type="button" class="naming-seg-move" onclick="App.moveNamingSegment(${idx}, 1)" ${isLast ? 'disabled' : ''} title="Move down">v</button>
          </div>
          <div class="naming-seg-body">
            <div class="naming-seg-row">
              <label class="naming-seg-label-text">Label</label>
              <input type="text" class="mops-input naming-seg-input" value="${labelVal}"
                onchange="App._updateNamingSegment(${idx}, 'label', this.value)"
                placeholder="Friendly label for this segment" />
            </div>
            <div class="naming-seg-row">
              <label class="naming-seg-label-text">Type</label>
              <select class="mops-select naming-seg-select" onchange="App._updateNamingSegment(${idx}, 'type', this.value)">
                <option value="field_abbr" ${typeSelected('field_abbr')}>Field  Abbreviation (like programAlign)</option>
                <option value="field_value" ${typeSelected('field_value')}>Field  Raw Value (like contentTitle)</option>
                <option value="system" ${typeSelected('system')}>System Context (like fiscalQuarter)</option>
                <option value="static" ${typeSelected('static')}>Static / Constant Text</option>
              </select>
            </div>
            ${seg.type !== 'static' ? `
            <div class="naming-seg-row">
              <label class="naming-seg-label-text">Field Key</label>
              <select class="mops-select naming-seg-select" onchange="App._updateNamingSegment(${idx}, 'fieldKey', this.value)">
                <option value=""> Select field </option>
                ${seg.type === 'system' ? systemOptions : fieldOptions}
              </select>
            </div>` : ''}
            <div class="naming-seg-row">
              <label class="naming-seg-label-text">Sample Value</label>
              <input type="text" class="mops-input naming-seg-input" value="${sampleVal}"
                onchange="App._updateNamingSegment(${idx}, 'sample', this.value); App._refreshNamingModalPreview();"
                placeholder="e.g. DG or Q1FY26" />
              <span class="naming-seg-hint">Used in preview</span>
            </div>
          </div>
          <button type="button" class="naming-seg-delete" onclick="App.deleteNamingSegment(${idx})" title="Remove segment"></button>
        </div>`;
    }).join('');

    // Re-set the fieldKey selects after render (innerHTML doesn't allow selected via string reliably)
    segments.forEach((seg, idx) => {
      const card = list.querySelector(`[data-idx="${idx}"]`);
      if (!card) return;
      const fkSelect = card.querySelectorAll('select')[1];
      if (fkSelect && seg.fieldKey) fkSelect.value = seg.fieldKey;
    });
  },

  /** Update a single property on a naming segment in-place */
  _updateNamingSegment(idx, prop, value) {
    const nc = this.ensureNamingConvention();
    if (!nc.segments[idx]) return;
    nc.segments[idx][prop] = value;
    if (prop === 'type') this.renderNamingSegments(); // Re-render to show/hide fieldKey row
    this._refreshNamingModalPreview();
  },

  addNamingSegment() {
    const nc = this.ensureNamingConvention();
    const newSeg = {
      id: 's_' + Date.now(),
      type: 'field_value',
      fieldKey: '',
      label: 'New Segment',
      sample: 'Value'
    };
    nc.segments.push(newSeg);
    this.renderNamingSegments();
    this._refreshNamingModalPreview();
  },

  moveNamingSegment(idx, dir) {
    const nc = this.ensureNamingConvention();
    const segs = nc.segments;
    const newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= segs.length) return;
    const tmp = segs[idx];
    segs[idx] = segs[newIdx];
    segs[newIdx] = tmp;
    this.renderNamingSegments();
    this._refreshNamingModalPreview();
  },

  deleteNamingSegment(idx) {
    const nc = this.ensureNamingConvention();
    nc.segments.splice(idx, 1);
    this.renderNamingSegments();
    this._refreshNamingModalPreview();
  },

  // 
  // Live Preview inside the Modal
  // 

  _refreshNamingModalPreview() {
    const box = document.getElementById('namingLiveEvaluatedBox');
    const formula = document.getElementById('namingFormulaText');
    if (!box) return;

    const nc = this.formSchema.namingConvention;
    if (!nc) { box.innerHTML = ''; return; }

    const { tokens, evaluated } = this.evaluateProjectName();
    const delim = nc.delimiter || '_';

    if (!tokens.length) {
      box.innerHTML = `<span style="color:#94a3b8; font-style:italic;">Add segments to see the preview</span>`;
      if (formula) formula.textContent = '';
      return;
    }

    // Animated pill display
    box.innerHTML = tokens.map((t, i) =>
      `<span class="naming-preview-pill">${this._escHtml(t)}</span>${i < tokens.length - 1 ? `<span class="naming-preview-delim">${this._escHtml(delim)}</span>` : ''}`
    ).join('');

    // Formula display
    const nc_segs = nc.segments || [];
    if (formula) {
      formula.textContent = ' ' + nc_segs.map(s => `[${s.label || s.fieldKey || s.type}]`).join(` ${delim} `) + ' ';
    }

    // Also update the code tab if visible
    this.renderNamingTsCodePreview();
  },

  // 
  // Tabs
  // 

  switchNamingTab(tabId) {
    ['builder', 'code'].forEach(id => {
      const btn = document.getElementById(`btnNamingTab${id.charAt(0).toUpperCase() + id.slice(1)}`);
      const pane = document.getElementById(`namingPane_${id}`);
      if (btn) btn.classList.toggle('active', id === tabId);
      if (pane) pane.style.display = id === tabId ? 'block' : 'none';
    });
    if (tabId === 'code') this.renderNamingTsCodePreview();
  },

  // 
  // TypeScript Code Generator
  // Produces specialNameBuilder and nameBuilder matching form.web-page.config.ts
  // 

  renderNamingTsCodePreview() {
    const block = document.getElementById('namingTsCodeBlock');
    if (!block) return;

    const nc = this.formSchema.namingConvention;
    if (!nc) { block.textContent = '// No naming convention configured.'; return; }

    const delim = nc.delimiter || '_';
    const segs = nc.segments || [];

    // Build the aux.push lines
    const pushLines = segs.map(seg => {
      if (seg.type === 'static') {
        return `  aux.push('${seg.sample || seg.label || ''}');`;
      } else if (seg.type === 'system') {
        if (seg.fieldKey === 'fiscalQuarter') {
          return `  aux.push(formObject?.fiscalQuarter?.shortYear || '');  // e.g. Q1FY26`;
        } else if (seg.fieldKey === 'projectType') {
          return `  aux.push(enrichedValues[config.uapFields.projectType] || '');`;
        }
        return `  aux.push(formObject?.${seg.fieldKey} || '');`;
      } else if (seg.type === 'field_abbr') {
        const mapName = seg.fieldKey === 'programAlign' ? 'ABBR_PROGRAM_MAPPING' : 'ABBR_CAMPAIGN_MAPPING';
        return `  aux.push(getAbbr(formObject.formData?.${seg.fieldKey}, ${mapName}));  // ${seg.label}`;
      } else {
        // field_value
        return `  aux.push((formObject.formData?.${seg.fieldKey} || '').toString().trim());  // ${seg.label}`;
      }
    });

    // nameBuilder array (field IDs)
    const allFields = [];
    (this.formSchema.sections || []).forEach(s => (s.fields || []).forEach(f => allFields.push(f)));
    const nameBuilderIds = segs
      .filter(s => s.type === 'field_value' || s.type === 'field_abbr')
      .map(s => {
        const f = allFields.find(f => f.formData === s.fieldKey || f.id === s.fieldKey);
        return f ? `  '${f.id || f.wfId}',` : `  /* fieldKey: ${s.fieldKey}  wfId not found */`;
      });

    const formId = this.formSchema.id || (this.activeFormId || 'form').toLowerCase().replace(/[^a-z0-9]/g, '-');
    const configFile = `form.${formId}.config.ts`;

    const code = [
      `// -----------------------------------------------------------------------`,
      `// File: ${configFile}`,
      `// Generated by MOPs FORM Studio  Naming Convention Studio`,
      `// Mirrors MOPs Angular specialNameBuilder / nameBuilder pattern`,
      `// -----------------------------------------------------------------------`,
      ``,
      `import { getAbbr, ABBR_CAMPAIGN_MAPPING, ABBR_PROGRAM_MAPPING } from './form.mops.config';`,
      ``,
      `/** Ordered field IDs / keys that form the Workfront Project Name */`,
      `export const nameBuilder: string[] = [`,
      ...nameBuilderIds,
      `  'fiscalQuarter',`,
      `  'Project Reference Number',`,
      `];`,
      ``,
      `/** Options including the specialNameBuilder factory */`,
      `export const specialOptions = {`,
      `  /**`,
      `   * Constructs the Workfront Project Name from form + enriched values.`,
      `   * Delimiter: '${delim}'  (segments joined after filtering empty values)`,
      `   */`,
      `  specialNameBuilder: (formObject: any, enrichedValues: any): string => {`,
      `    const aux: string[] = [];`,
      ``,
      ...pushLines,
      ``,
      `    // Filter out empty/whitespace tokens, then join with delimiter`,
      `    return aux`,
      `      .filter(v => v && v.toString().trim() !== '')`,
      `      .join('${delim}');`,
      `  }`,
      `};`,
    ].join('\n');

    block.textContent = code;
  },

  // 
  // Save / Reset
  // 

  saveNamingConvention() {
    const nc = this.formSchema.namingConvention;
    if (!nc) return;

    // Persist to storage
    this.saveFormToStorage();

    // Update the canvas bar
    this.syncCanvasNamingRuleBar();

    // Close modal
    this.closeNamingConventionModal();

    // Brief success flash on the canvas bar button
    const btn = document.getElementById('btnOpenNamingStudio');
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = 'OK Saved!';
      btn.style.background = '#16a34a';
      setTimeout(() => {
        btn.innerHTML = orig;
        btn.style.background = '';
      }, 1800);
    }
  },

  resetNamingToDefaults() {
    // Wipe the existing convention so ensureNamingConvention rebuilds from schema
    delete this.formSchema.namingConvention;
    this.ensureNamingConvention();
    this.renderNamingSegments();
    this._refreshNamingModalPreview();

    const delimSelect = document.getElementById('namingDelimiterSelect');
    if (delimSelect) delimSelect.value = '_';
  },

  onNamingDelimiterChange(value) {
    const nc = this.ensureNamingConvention();
    nc.delimiter = value;
    this._refreshNamingModalPreview();
  },

  copyProjectNamePreview() {
    const { evaluated } = this.evaluateProjectName();
    if (!evaluated) return;
    try {
      navigator.clipboard.writeText(evaluated).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = evaluated;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      });
    } catch {
      const ta = document.createElement('textarea');
      ta.value = evaluated;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    const btn = document.querySelector('#modalNamingStudio .naming-hero-controls .btn');
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = 'OK Copied!';
      setTimeout(() => { btn.innerHTML = orig; }, 1600);
    }
  }
});
