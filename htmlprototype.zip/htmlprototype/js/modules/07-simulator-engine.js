/**
 * Cisco MOPs FORM Studio - Runtime Simulator & Interactive Review Engine
 * Domain: Interactive preview mode, live rule evaluation, spec sheet generator, and mock form submission testing
 * File: js/modules/07-simulator-engine.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
toggleReviewSpecSheet() {
    const iframe = document.getElementById('livePreviewIframe');
    if (!iframe || !iframe.contentWindow) return;
    const v = this.livePreviewVariant || 1;
    const win = iframe.contentWindow;
    const isSpec = iframe.dataset.specMode === 'true';
    const labelEl = document.getElementById('btnReviewFullSpecLabel');
    if (isSpec) {
      if (v === 1) win.switchV2Tab?.('form');
      else if (v === 2) win.switchTab?.('form');
      else win.switchWizTab?.('form');
      iframe.dataset.specMode = 'false';
      if (labelEl) labelEl.textContent = 'Full Spec Sheet';
    } else {
      if (v === 1) win.switchV2Tab?.('spec');
      else if (v === 2) win.switchTab?.('spec');
      else win.switchWizTab?.('spec');
      iframe.dataset.specMode = 'true';
      if (labelEl) labelEl.textContent = ' Back to Form';
    }
  },

  switchReviewVariant(variant) {
    this.livePreviewVariant = variant;
    this.builderVariant = variant;

    document.querySelectorAll('#builderVariationSwitcher .rev-var-btn').forEach(btn => {
      const v = parseInt(btn.getAttribute('data-variant'), 10);
      if (v === variant) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    document.querySelectorAll('#reviewVariationSwitcher .rev-var-btn').forEach(btn => {
      const v = parseInt(btn.getAttribute('data-variant'), 10);
      if (v === variant) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    if (this.activeMode !== 'review') {
      this.switchMode('review');
    } else {
      this.render();
    }
  },

renderReviewMode(canvasRoot) {
    const v = this.livePreviewVariant || 1;

    // Sync variation button active states in the reviewModeBanner
    document.querySelectorAll('.rev-var-btn').forEach(btn => {
      const bVar = parseInt(btn.getAttribute('data-variant'), 10);
      if (bVar === v) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    const effectiveSchema = this.formSchema;
    const activeFormMeta = this.getActiveForm();

    // Generate self-contained HTML for the selected variation
    // v=1  MOPs Cisco Brand (flat Cisco enterprise, matches Angular MOPs intake form)
    // v=2  Modern Studio (glassmorphism dark layout)
    // v=3  Step Wizard (multi-step with Next/Back navigation)
    let htmlContent = '';
    if (v === 3) {
      htmlContent = window.Exporter.generateStandaloneReviewHtmlV3(effectiveSchema, activeFormMeta);
    } else if (v === 2) {
      // Modern Studio (glassmorphism)
      const css = window.MOPS_STANDALONE_CSS || window.STANDALONE_REVIEW_CSS || '';
      htmlContent = window.Exporter.generateStandaloneReviewHtml(effectiveSchema, css, activeFormMeta);
    } else {
      // MOPs Cisco Brand  default (flat enterprise, matches Angular intake form)
      htmlContent = window.Exporter.generateStandaloneReviewHtmlV2(effectiveSchema, activeFormMeta);
    }

    // Build iframe viewport container
    const previewContainer = document.createElement('div');
    previewContainer.className = 'live-preview-container';
    previewContainer.innerHTML = `
      <div class="live-preview-viewport">
        <iframe id="livePreviewIframe" class="live-preview-iframe" title="Interactive Form Preview (Variation ${v})"></iframe>
      </div>
    `;

    canvasRoot.appendChild(previewContainer);

    const iframe = previewContainer.querySelector('#livePreviewIframe');
    if (iframe) {
      iframe.srcdoc = htmlContent;

      const updateHeight = () => {
        try {
          const doc = iframe.contentDocument || iframe.contentWindow?.document;
          if (!doc) return;
          const bodyH = doc.body ? doc.body.scrollHeight : 0;
          const docH = doc.documentElement ? doc.documentElement.scrollHeight : 0;
          const h = Math.max(bodyH, docH);
          if (h > 400) {
            iframe.style.height = (h + 30) + 'px';
          }
        } catch (e) { }
      };

      iframe.onload = () => {
        updateHeight();
        try {
          const doc = iframe.contentDocument || iframe.contentWindow?.document;
          if (doc && doc.body) {
            const observer = new MutationObserver(updateHeight);
            observer.observe(doc.body, { childList: true, subtree: true, attributes: true });
            doc.addEventListener('change', () => setTimeout(updateHeight, 50));
            doc.addEventListener('click', () => setTimeout(updateHeight, 50));
            doc.addEventListener('input', () => setTimeout(updateHeight, 50));
          }
        } catch (e) { }
      };
    }
  },


  // ------------------------------------------------------------------------
});
