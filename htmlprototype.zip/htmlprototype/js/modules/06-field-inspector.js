/**
 * Cisco MOPs FORM Studio - Field Property Inspector Drawer
 * Domain: Right slide-out drawer: General attributes, Workfront mapping, options list, date constraints, and display rules
 * File: js/modules/06-field-inspector.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
openFieldSettings(sIdx, fIdx) {
    const field = this.formSchema.sections[sIdx]?.fields[fIdx];
    if (!field) return;
    if (field.type === 'empty_field') {
      // Empty Field is strictly a layout spacer — no settings, rules, or BA notes
      document.getElementById('settingsDrawer')?.classList.remove('open');
      this.selectedFieldLoc = null;
      return;
    }
    this.selectedFieldLoc = { sectionIndex: sIdx, fieldIndex: fIdx };

    const drawer = document.getElementById('settingsDrawer');
    drawer.classList.add('open');

    // Always reset all tabs to the "General / Settings" tab on each new field open.
    // This clears any stale inline borderBottomColor overrides that caused BA Notes
    // to appear selected (blue strip bleed-through from #btnAddOption scrolling behind .drawer-tabs).
    document.querySelectorAll('.drawer-tab-btn').forEach(b => {
      b.classList.remove('active');
      b.style.borderBottomColor = 'transparent';
      b.style.color = '#6b7280';
    });
    document.querySelectorAll('.drawer-tab-pane').forEach(p => p.classList.remove('active'));
    const defaultTabBtn = document.querySelector('.drawer-tab-btn[data-tab="general"]');
    if (defaultTabBtn) {
      defaultTabBtn.classList.add('active');
      defaultTabBtn.style.borderBottomColor = '#005fb8';
      defaultTabBtn.style.color = '#005fb8';
    }
    document.getElementById('drawerTab_general')?.classList.add('active');

    // Update drawer header with field type
    const typeLabels = {
      text: ' Single Line Text', text_suggestion: ' Auto Suggest', autosuggest: ' Auto Suggest', select: ' Dropdown Picklist',
      multiselect_fancy: '[x] Multi-Select Dropdown', checkbox_group: '[x][x] Checkbox Group',
      text_area: ' Textarea', text_number: ' Number Input', date: ' Date Picker',
      radio: ' Radio Choice Group', visual_cards: ' Categorized Visual Cards', checkbox: '[x] Checkbox', file: ' File Upload'
    };
    const typeEl = document.getElementById('drawerFieldTypeLabel');
    const keyHintEl = document.getElementById('drawerFieldKeyHint');
    if (typeEl) typeEl.textContent = typeLabels[field.type] || 'Field Configuration';
    if (keyHintEl) keyHintEl.textContent = field.formData ? `key: ${field.formData}` : '';

    // Populate Fields safely
    const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    setVal('inputFieldType', field.type || 'text');
    setVal('inputWorkfrontId', field.wfId || field.id || '');
    setVal('inputWorkfrontFieldName', field.wfFieldName || field.formData || '');
    setVal('inputWorkfrontLabel', field.wfLabel || field.label || '');
    if (typeof this._renderWfFormsMultiCheckboxes === 'function') {
      const wfIds = Array.isArray(field.wfFormIds) && field.wfFormIds.length
        ? field.wfFormIds
        : (field.wfFormId ? [field.wfFormId] : []);
      this._renderWfFormsMultiCheckboxes('drawerFieldWfFormsMultiList', 'drawerFieldWfFormsCount', wfIds, 'drawer-field-wf-form-chk', 'App._onDrawerWfFormMultiChange()');
    }
    setVal('inputFieldLabel', field.label || '');   // overwrite label (optional)
    setVal('inputFieldKey', field.formData || '');
    setVal('inputFieldPlaceholder', field.placeholder || '');
    setVal('inputFieldTooltip', field.tooltip || '');
    const chkReq = document.getElementById('chkFieldRequired');
    if (chkReq) chkReq.checked = Boolean(field.required);
    const chkDis = document.getElementById('chkFieldDisabled');
    if (chkDis) chkDis.checked = Boolean(field.disabled || field.readonly);
    const chkHid = document.getElementById('chkFieldHidden');
    if (chkHid) chkHid.checked = Boolean(field.hidden);
    setVal('inputFieldBaNotes', field.baNotes || '');
    const baRichEl = document.getElementById('inputFieldBaNotesRich');
    if (baRichEl) {
      baRichEl.innerHTML = this._baNotesToEditorHtml(field.baNotes || '');
    }
    // Sync BA Notes char counter
    const baCountEl = document.getElementById('baNotesCharCount');
    if (baCountEl) baCountEl.textContent = this._getBaNotesPlainText(field.baNotes || '').length + ' chars';

    // --- Audit Trail: stamp _createdAt/_createdBy if missing (fields loaded from JSON lack these) ---
    if (!field._createdAt) {
      field._createdAt = new Date().toISOString();
      field._createdBy = this.getCurrentUserSignature();
    }

    this.updateWidthPills(field.col || 'col-lg-6');
    this._markDrawerDirty(false); // reset dirty state for new field
    this.bindDrawerFieldInputs(sIdx, fIdx);
    this.renderDrawerOptions(field);
    this.renderDrawerRules(field);
    this.renderDrawerDateRules(field);
    this._syncWfRequiredIndicator(); // highlight empty mandatory WF fields

    this.render(); // highlight selected card
  },

  _onDrawerWfFormMultiChange() {
    const listEl = document.getElementById('drawerFieldWfFormsMultiList');
    const cntEl = document.getElementById('drawerFieldWfFormsCount');
    if (listEl && cntEl) {
      const checked = listEl.querySelectorAll('.drawer-field-wf-form-chk:checked').length;
      cntEl.textContent = checked + ' selected';
    }
    this._markDrawerDirty(true);
  },

  closeDrawer() {
    document.getElementById('settingsDrawer')?.classList.remove('open');
    this.selectedFieldLoc = null;
    this.render();
  },

  // --- Rich BA Notes Editor Helpers ----------------------------------------
  _getBaNotesPlainText(htmlOrText) {
    if (!htmlOrText) return '';
    const tmp = document.createElement('div');
    tmp.innerHTML = String(htmlOrText);
    return (tmp.textContent || tmp.innerText || '').replace(/\u00A0/g, ' ');
  },

  _baNotesToEditorHtml(raw) {
    if (!raw) return '';
    const str = String(raw);
    // If already HTML (contains tags), return as-is
    if (/<(div|p|br|ul|ol|li|b|strong|i|em|u|span|code)\b/i.test(str)) {
      return str;
    }
    // Convert plain text lines into clean structured HTML
    const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return str.split(/\r?\n/).map(line => {
      const trimmed = line.trim();
      if (!trimmed) return '<div><br></div>';
      const formatted = esc(trimmed)
        .replace(/^(Field Type|FIELD TYPE)\s*:\s*/i, '<span class="ba-tag ba-tag-type">Field Type</span>&nbsp;')
        .replace(/^(WF Field ID|WF FIELD ID)\s*:\s*/i, '<span class="ba-tag ba-tag-wfid">WF Field ID</span>&nbsp;')
        .replace(/^(WF Field API Name|WF Field Name|WF Field|WF FIELD API NAME|WF FIELD NAME|WF FIELD)\s*:\s*/i, '<span class="ba-tag ba-tag-wf">WF Field API Name</span>&nbsp;')
        .replace(/^(Required when|Mandatory when|REQUIRED WHEN)\s*:\s*/i, '<span class="ba-tag ba-tag-req">Required When</span>&nbsp;')
        .replace(/^(Validation|VALIDATION)\s*:\s*/i, '<span class="ba-tag ba-tag-val">Validation</span>&nbsp;')
        .replace(/^(Drop Down Filter|Dropdown Filter|Dropdown Option|DROPDOWN FILTER)\s*:\s*/i, '<span class="ba-tag ba-tag-filter">Drop Down Filter</span>&nbsp;')
        .replace(/^(Show Only When|Shown Only When|SHOW ONLY WHEN)\s*:\s*/i, '<span class="ba-tag ba-tag-show">Show Only When</span>&nbsp;')
        .replace(/^(Show Only When Not|Show When Not|Hide When|SHOW WHEN NOT)\s*:\s*/i, '<span class="ba-tag ba-tag-hide">Show Only When Not</span>&nbsp;')
        .replace(/^(Action|ACTION)\s*:\s*/i, '<span class="ba-tag ba-tag-action">Action</span>&nbsp;')
        .replace(/^(Dev Note|DEV NOTE)\s*:\s*/i, '<span class="ba-tag ba-tag-dev">Dev Note</span>&nbsp;')
        .replace(/^(General Note|Note|GENERAL NOTE|NOTE)\s*:\s*/i, '<span class="ba-tag ba-tag-note">General Note</span>&nbsp;');
      return `<div class="ba-note-line">${formatted}</div>`;
    }).join('');
  },

  execBaFormat(cmd) {
    const ed = document.getElementById('inputFieldBaNotesRich');
    if (!ed) return;
    ed.focus();
    document.execCommand(cmd, false, null);
    ed.dispatchEvent(new Event('input'));
  },

  insertBaCodeSnippet() {
    const ed = document.getElementById('inputFieldBaNotesRich');
    if (!ed) return;
    ed.focus();
    const sel = window.getSelection();
    const text = sel && sel.toString() ? sel.toString() : 'fieldKey';
    const esc = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    document.execCommand('insertHTML', false, `<code>${esc}</code>&nbsp;`);
    ed.dispatchEvent(new Event('input'));
  },

  insertBaTag(tagType, label) {
    const ed = document.getElementById('inputFieldBaNotesRich');
    if (!ed) return;
    ed.focus();

    const line = document.createElement('div');
    line.className = 'ba-note-line';

    const badge = document.createElement('span');
    badge.className = `ba-tag ba-tag-${tagType}`;
    badge.contentEditable = 'false';
    badge.textContent = label;

    const spaceNode = document.createTextNode('\u00A0');
    line.appendChild(badge);
    line.appendChild(spaceNode);
    ed.appendChild(line);

    // Place cursor right after the badge so BA can type immediately
    const range = document.createRange();
    range.setStartAfter(spaceNode);
    range.collapse(true);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    ed.scrollTop = ed.scrollHeight;
    ed.dispatchEvent(new Event('input'));
  },

  updateWidthPills(colClass) {
    document.querySelectorAll('.width-pill').forEach(pill => {
      pill.classList.toggle('active', pill.getAttribute('data-width') === colClass);
    });
  },

  bindDrawerFieldInputs(sIdx, fIdx) {
    if (!this.formSchema.sections[sIdx]?.fields[fIdx]) return;
    const field = this.formSchema.sections[sIdx].fields[fIdx];
    const markDirty = () => this._markDrawerDirty(true);

    // Sync field audit box
    const createdEl = document.getElementById('fieldAuditCreated');
    const updatedEl = document.getElementById('fieldAuditUpdated');
    const userFallback = this.getCurrentUserSignature();
    const fmt = (dt, by) => dt
      ? `${new Date(dt).toLocaleString()} by ${by || userFallback}`
      : (by ? `by ${by}` : userFallback);
    if (createdEl) createdEl.textContent = fmt(field._createdAt, field._createdBy);
    if (updatedEl) updatedEl.textContent = fmt(field._updatedAt || field._createdAt, field._updatedBy || field._createdBy);

    // Bind the Apply Changes button
    const applyBtn = document.getElementById('btnApplyFieldChanges');
    if (applyBtn) {
      applyBtn.onclick = () => this._applyDrawerChanges();
    }

    // Field Type / Presentation Format selector
    const typeInput = document.getElementById('inputFieldType');
    if (typeInput) {
      typeInput.value = field.type || 'text';
      typeInput.onchange = (e) => {
        const newType = e.target.value;
        field.type = newType;
        // If switching to an option-based type and options is empty, supply default options
        if (['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'visual_cards'].includes(newType)) {
          if (!Array.isArray(field.options) || field.options.length === 0) {
            field.options = ['Americas', 'EMEA', 'APJC', 'Global'];
          }
        }
        const typeLabels = {
          text: ' Single Line Text', select: ' Dropdown Picklist',
          multiselect_fancy: '[x] Multi-Select Dropdown', checkbox_group: '[x][x] Checkbox Group',
          text_area: ' Textarea', text_number: ' Number Input', date: ' Date Picker',
          radio: ' Radio Choice Group', visual_cards: ' Categorized Visual Cards', checkbox: '[x] Checkbox', file: ' File Upload'
        };
        const typeEl = document.getElementById('drawerFieldTypeLabel');
        if (typeEl) typeEl.textContent = typeLabels[newType] || 'Field Configuration';
        this.renderDrawerOptions(field);
        this.renderDrawerDateRules(field);
        this.saveFormToStorage();
        this.render(); // canvas and preview update immediately!
        markDirty();
        this._showToast(`Switched presentation to: ${typeLabels[newType] || newType}`);
      };
    }

    // Overwrite Label (optional)  overwrites Workfront Label as the displayed question
    const lblInput = document.getElementById('inputFieldLabel');
    if (lblInput) {
      lblInput.oninput = (e) => {
        field.label = e.target.value;  // empty string means "use wfLabel as fallback"
        this.saveFormToStorage();
        markDirty();
      };
    }

    // Key (if element exists)
    const keyInput = document.getElementById('inputFieldKey');
    if (keyInput) {
      keyInput.onchange = (e) => {
        field.formData = e.target.value.trim();
        this.saveFormToStorage();
        markDirty();
      };
    }

    // Placeholder
    const phInput = document.getElementById('inputFieldPlaceholder');
    if (phInput) {
      phInput.oninput = (e) => {
        field.placeholder = e.target.value;
        this.saveFormToStorage();
        markDirty();
      };
    }

    // Tooltip
    const tipInput = document.getElementById('inputFieldTooltip');
    if (tipInput) {
      tipInput.oninput = (e) => {
        field.tooltip = e.target.value;
        this.saveFormToStorage();
        markDirty();
      };
    }

    // Required
    const reqInput = document.getElementById('chkFieldRequired');
    if (reqInput) {
      reqInput.onchange = (e) => {
        field.required = e.target.checked;
        this.saveFormToStorage();
        this._applyDrawerChanges(); // immediate for checkbox
      };
    }

    // Disabled / Inactive
    const disInput = document.getElementById('chkFieldDisabled');
    if (disInput) {
      disInput.onchange = (e) => {
        field.disabled = e.target.checked;
        this.saveFormToStorage();
        this._applyDrawerChanges();
      };
    }

    // Hidden by Default
    const hidInput = document.getElementById('chkFieldHidden');
    if (hidInput) {
      hidInput.onchange = (e) => {
        field.hidden = e.target.checked;
        this.saveFormToStorage();
        this._applyDrawerChanges();
      };
    }

    // Workfront Field ID (mandatory)
    const wfInput = document.getElementById('inputWorkfrontId');
    if (wfInput) {
      wfInput.oninput = (e) => {
        field.wfId = e.target.value.trim();
        field.id = field.wfId; // keep legacy alias in sync
        this.saveFormToStorage();
        this._syncWfRequiredIndicator();
        markDirty();
      };
    }

    // Workfront Field Name (mandatory)
    const wfNameInput = document.getElementById('inputWorkfrontFieldName');
    if (wfNameInput) {
      wfNameInput.oninput = (e) => {
        field.wfFieldName = e.target.value.trim();
        field.formData = field.wfFieldName; // keep formData key in sync
        this.saveFormToStorage();
        this._syncWfRequiredIndicator();
        markDirty();
      };
    }

    // Workfront Label (mandatory)  used as default display label unless overridden
    const wfLabelInput = document.getElementById('inputWorkfrontLabel');
    if (wfLabelInput) {
      wfLabelInput.oninput = (e) => {
        field.wfLabel = e.target.value.trim();
        this.saveFormToStorage();
        this._syncWfRequiredIndicator();
        markDirty();
      };
    }

    // BA Notes Rich Editor with live char counter + saved indicator
    const baNotesInput = document.getElementById('inputFieldBaNotes');
    const baRichEl = document.getElementById('inputFieldBaNotesRich');
    const baNotesCharCount = document.getElementById('baNotesCharCount');
    const baNotesAutoSave = document.getElementById('baNotesAutoSave');

    const syncBaNotes = (rawHtml) => {
      const plainText = this._getBaNotesPlainText(rawHtml);
      const valToSave = plainText.trim() ? rawHtml : '';
      field.baNotes = valToSave;
      if (baNotesInput) baNotesInput.value = valToSave;
      if (baNotesCharCount) baNotesCharCount.textContent = plainText.length + ' chars';
      this.saveFormToStorage();
      markDirty();
      if (baNotesAutoSave) {
        baNotesAutoSave.style.display = 'inline';
        clearTimeout(this._baNotesAutoSaveTimer);
        this._baNotesAutoSaveTimer = setTimeout(() => {
          baNotesAutoSave.style.display = 'none';
        }, 1500);
      }
    };

    if (baRichEl) {
      if (baNotesCharCount) {
        baNotesCharCount.textContent = this._getBaNotesPlainText(baRichEl.innerHTML).length + ' chars';
      }
      baRichEl.oninput = () => syncBaNotes(baRichEl.innerHTML);
      // Paste as clean plain text so external Word/Confluence styles don't break the Spec Sheet
      baRichEl.onpaste = (e) => {
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData('text/plain');
        document.execCommand('insertText', false, text);
      };
    }

    if (baNotesInput) {
      baNotesInput.oninput = (e) => {
        field.baNotes = e.target.value;
        if (baRichEl) baRichEl.innerHTML = this._baNotesToEditorHtml(e.target.value);
        if (baNotesCharCount) baNotesCharCount.textContent = this._getBaNotesPlainText(e.target.value).length + ' chars';
        this.saveFormToStorage();
        markDirty();
      };
    }

    // Width Pills Click
    document.querySelectorAll('.width-pill').forEach(pill => {
      pill.onclick = () => {
        const width = pill.getAttribute('data-width');
        this.setFieldWidth(sIdx, fIdx, width);
      };
    });
  },

  /** Light up / clear the Apply Changes button's dirty indicator */
  _markDrawerDirty(dirty = true) {
    const btn = document.getElementById('btnApplyFieldChanges');
    if (!btn) return;
    if (dirty) {
      btn.classList.add('is-dirty');
      btn.textContent = 'OK Apply Changes *';
    } else {
      btn.classList.remove('is-dirty');
      btn.textContent = 'OK Apply Changes';
    }
  },


  /** Apply all drawer changes and re-render the canvas */
  _applyDrawerChanges() {
    try {
      if (!this.selectedFieldLoc) return;
      const { sectionIndex: sIdx, fieldIndex: fIdx } = this.selectedFieldLoc;
      const field = this.formSchema.sections[sIdx]?.fields[fIdx];
      if (!field) return;

      // Explicitly flush ALL current drawer input values  field object
      const phEl = document.getElementById('inputFieldPlaceholder');
      const tipEl = document.getElementById('inputFieldTooltip');
      const reqEl = document.getElementById('chkFieldRequired');
      const disEl = document.getElementById('chkFieldDisabled');
      const hidEl = document.getElementById('chkFieldHidden');
      const lblEl = document.getElementById('inputFieldLabel');
      const keyEl = document.getElementById('inputFieldKey');
      const typeEl = document.getElementById('inputFieldType');
      const wfIdEl = document.getElementById('inputWorkfrontId');
      const wfNameEl = document.getElementById('inputWorkfrontFieldName');
      const wfLabelEl = document.getElementById('inputWorkfrontLabel');
      const baRichEl = document.getElementById('inputFieldBaNotesRich');
      const baNotesEl = document.getElementById('inputFieldBaNotes');

      if (typeEl && typeEl.value) field.type = typeEl.value;

      if (phEl) field.placeholder = phEl.value;
      if (tipEl) field.tooltip = tipEl.value;
      if (reqEl) field.required = reqEl.checked;
      if (disEl) field.disabled = disEl.checked;
      if (hidEl) field.hidden = hidEl.checked;
      if (lblEl) field.label = lblEl.value;
      if (keyEl) field.formData = keyEl.value.trim();
      if (wfIdEl) { field.wfId = wfIdEl.value.trim(); field.id = field.wfId; }
      if (wfNameEl) { field.wfFieldName = wfNameEl.value.trim(); field.formData = field.wfFieldName; }
      if (wfLabelEl) field.wfLabel = wfLabelEl.value.trim();
      const drawerWfList = document.getElementById('drawerFieldWfFormsMultiList');
      if (drawerWfList) {
        const checkedBoxes = Array.from(drawerWfList.querySelectorAll('.drawer-field-wf-form-chk:checked'));
        field.wfFormIds = checkedBoxes.map(cb => cb.value).filter(Boolean);
        field.wfFormLabels = checkedBoxes.map(cb => cb.dataset.label || cb.value).filter(Boolean);
        field.wfFormId = field.wfFormIds[0] || '';
        field.wfFormLabel = field.wfFormLabels.join(', ');
      }
      if (baRichEl) {
        const plain = this._getBaNotesPlainText(baRichEl.innerHTML);
        field.baNotes = plain.trim() ? baRichEl.innerHTML : '';
      } else if (baNotesEl) {
        field.baNotes = baNotesEl.value;
      }

      // Field Audit Tracking
      const nowIso = new Date().toISOString();
      const userSig = this.getCurrentUserSignature();
      field._updatedAt = nowIso;
      field._updatedBy = userSig;
      if (!field._createdAt) {
        field._createdAt = nowIso;
        field._createdBy = userSig;
      }

      if (field.type === 'date') {
        this._saveDrawerDateConstraints(field);
      }

      if (['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'text_suggestion', 'autosuggest', 'visual_cards'].includes(field.type)) {
        const optInputs = document.querySelectorAll('#drawerOptionsList input[data-opt-idx]');
        if (optInputs.length > 0) {
          optInputs.forEach(inp => {
            const idx = parseInt(inp.getAttribute('data-opt-idx'), 10);
            if (!isNaN(idx) && field.options && field.options[idx] !== undefined) {
              if (typeof field.options[idx] === 'object' && field.options[idx] !== null) {
                field.options[idx].label = inp.value;
                field.options[idx].value = inp.value;
              } else {
                field.options[idx] = inp.value;
              }
            }
          });
        }
      }

      try {
        this.saveFormToStorage();
      } catch (saveErr) {
        console.warn('[MOPs] Failed to save form via PHP:', saveErr);
      }

      this.render();
      this._markDrawerDirty(false);

      // Re-bind drawer handlers (keeps event listeners fresh after render)
      this.bindDrawerFieldInputs(sIdx, fIdx);

      // Show brief toast confirmation
      this._showToast('Changes applied OK');
    } catch (err) {
      console.error('[MOPs] Error applying drawer changes:', err);
    }
  },

  /** Show a prominent, non-blocking toast/popup notification in the middle of the screen */
  _showToast(message, typeOrDuration = 'info', durationMs = 2400) {
    let type = 'info';
    let duration = 2400;
    if (typeof typeOrDuration === 'number') {
      duration = typeOrDuration;
    } else if (typeof typeOrDuration === 'string') {
      type = typeOrDuration;
      if (typeof durationMs === 'number') duration = durationMs;
    }

    let toast = document.getElementById('_mopsToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = '_mopsToast';
      Object.assign(toast.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%) scale(0.92)',
        background: 'linear-gradient(135deg, #003852 0%, #001c30 100%)',
        color: '#ffffff',
        padding: '14px 24px',
        borderRadius: '12px',
        fontSize: '14.5px',
        fontWeight: '600',
        zIndex: '100000',
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.15)',
        transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        pointerEvents: 'auto',
        maxWidth: '90vw',
        opacity: '0',
        backdropFilter: 'blur(8px)'
      });
      document.body.appendChild(toast);
    }

    let cleanMsg = String(message || '').trim();
    if (/^error\b/i.test(cleanMsg)) {
      type = 'error';
      cleanMsg = cleanMsg.replace(/^error[:\s-]+/i, '').trim();
    } else if (/^(ok|success)\b/i.test(cleanMsg)) {
      type = 'success';
      cleanMsg = cleanMsg.replace(/^(ok|success)[:\s-]+/i, '').trim();
    } else if (/^warning\b/i.test(cleanMsg)) {
      type = 'warning';
      cleanMsg = cleanMsg.replace(/^warning[:\s-]+/i, '').trim();
    }

    if (type === 'info') {
      const lower = cleanMsg.toLowerCase();
      if (lower.startsWith('saved') || lower.startsWith('created') || lower.startsWith('added') ||
        lower.startsWith('opened') || lower.startsWith('loaded') || lower.startsWith('swapped') ||
        lower.startsWith('restored') || lower.startsWith('renamed') || lower.startsWith('exported') ||
        lower.startsWith('inserted') || lower.startsWith('imported') || lower.includes('successfully')) {
        type = 'success';
      } else if (lower.includes('error') || lower.includes('fail')) {
        type = 'error';
      } else if (lower.includes('please') || lower.includes('no active') || lower.includes('not found') || lower.includes('warning')) {
        type = 'warning';
      }
    }

    let iconSvg = '';
    if (type === 'success') {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M20 6L9 17l-5-5"/></svg>';
    } else if (type === 'warning') {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>';
    } else if (type === 'error') {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f87171" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
    } else {
      iconSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';
    }

    toast.innerHTML = `
      <span style="display:inline-flex; align-items:center; line-height:1;">${iconSvg}</span>
      <span style="letter-spacing: 0.1px; line-height: 1.4;">${cleanMsg}</span>
      <button type="button" aria-label="Dismiss notification" style="background:transparent; border:none; color:rgba(255,255,255,0.7); cursor:pointer; font-size:14px; margin-left:8px; line-height:1; padding:2px 4px; display:inline-flex; align-items:center; transition:color 0.15s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='rgba(255,255,255,0.7)'" onclick="const t=document.getElementById('_mopsToast'); if(t){ t.style.opacity='0'; t.style.transform='translate(-50%, -50%) scale(0.92)'; }">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    `;
    requestAnimationFrame(() => {
      toast.style.opacity = '1';
      toast.style.transform = 'translate(-50%, -50%) scale(1)';
    });
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => {
      if (toast) {
        toast.style.opacity = '0';
        toast.style.transform = 'translate(-50%, -50%) scale(0.92)';
      }
    }, duration);
  },

  // Highlight missing mandatory Workfront fields with red border
  _syncWfRequiredIndicator() {
    const fields = [
      { id: 'inputWorkfrontId', label: 'Workfront Field ID' },
      { id: 'inputWorkfrontFieldName', label: 'Workfront Field Name' },
      { id: 'inputWorkfrontLabel', label: 'Workfront Label' },
    ];
    fields.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (!el.value.trim()) {
        el.classList.add('wf-field-missing');
      } else {
        el.classList.remove('wf-field-missing');
      }
    });
  },

  // Options tab in Drawer
  renderDrawerOptions(field) {
    const hasOptions = ['select', 'radio', 'multiselect_fancy', 'checkbox_group', 'text_suggestion', 'autosuggest', 'visual_cards'].includes(field.type);
    const optionsTabBtn = document.getElementById('tabBtnOptions');
    const optionsList = document.getElementById('drawerOptionsList');

    if (!hasOptions) {
      if (optionsTabBtn) optionsTabBtn.style.display = 'none';
      const activeTabBtn = document.querySelector('.drawer-tab-btn.active');
      if (activeTabBtn && activeTabBtn.getAttribute('data-tab') === 'options') {
        document.querySelectorAll('.drawer-tab-btn').forEach(b => {
          b.classList.remove('active');
          b.style.borderBottomColor = 'transparent';
          b.style.color = '#6b7280';
        });
        document.querySelectorAll('.drawer-tab-pane').forEach(p => p.classList.remove('active'));
        const genBtn = document.querySelector('.drawer-tab-btn[data-tab="general"]');
        if (genBtn) {
          genBtn.classList.add('active');
          genBtn.style.borderBottomColor = '#005fb8';
          genBtn.style.color = '#005fb8';
        }
        document.getElementById('drawerTab_general')?.classList.add('active');
      }
      return;
    }
    if (optionsTabBtn) optionsTabBtn.style.display = 'block';

    if (!Array.isArray(field.options)) {
      field.options = ['Option 1', 'Option 2'];
    }

    // Collect all OTHER fields in the form for condition rules
    const currentFieldKey = field.formData || field.wfFieldName || field.id || '';
    const allOtherFields = [];
    (this.formSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => {
        const fKey = f.formData || f.wfFieldName || f.id || '';
        if (fKey && fKey !== currentFieldKey) {
          allOtherFields.push({
            key: fKey,
            label: f.label || f.wfLabel || fKey,
            type: f.type,
            options: Array.isArray(f.options) ? f.options : []
          });
        }
      });
    });

    optionsList.innerHTML = '';

    if (field.options.length === 0) {
      const emptyBox = document.createElement('div');
      emptyBox.className = 'drawer-options-empty-state';
      emptyBox.style.cssText = 'padding:16px 12px; border:1px dashed #cbd5e1; border-radius:8px; background:#f8fafc; text-align:center; color:#64748b; font-size:12px; margin-bottom:12px;';
      emptyBox.innerHTML = `
        <div style="font-size:22px; margin-bottom:4px;"></div>
        <div style="font-weight:600; color:#334155; margin-bottom:2px;">No options configured yet</div>
        <div style="color:#94a3b8; font-size:11px; margin-bottom:10px;">This picklist currently has 0 selectable choices.</div>
        <button type="button" class="btn btn-outline-primary btn-sm" id="btnEmptyAddOption" style="font-size:11px; padding:4px 10px;">+ Add First Option</button>
      `;
      optionsList.appendChild(emptyBox);
      emptyBox.querySelector('#btnEmptyAddOption').onclick = () => {
        document.getElementById('btnAddOption').click();
      };
    }

    field.options.forEach((opt, oIdx) => {
      // Normalize to object format
      if (typeof opt !== 'object' || opt === null) {
        field.options[oIdx] = { label: String(opt), value: String(opt) };
      }
      const optObj = field.options[oIdx];
      const optLabel = optObj.label || optObj.value || '';

      // Normalize showIf to AND/OR multi-rule structure
      if (optObj.showIf) {
        if (!Array.isArray(optObj.showIf.rules)) {
          if (optObj.showIf.field) {
            optObj.showIf = {
              operator: 'AND',
              rules: [{
                field: optObj.showIf.field,
                comparison: optObj.showIf.comparison || '==',
                value: optObj.showIf.value || ''
              }]
            };
          } else {
            delete optObj.showIf;
          }
        }
      }

      const showIf = optObj.showIf || null;
      const rules = showIf && Array.isArray(showIf.rules) ? showIf.rules : [];
      const hasCondition = rules.length > 0;
      const currentOp = (showIf && showIf.operator) ? showIf.operator.toUpperCase() : 'AND';

      const row = document.createElement('div');
      row.className = 'option-row option-row-v2' + (hasCondition ? ' option-has-condition' : '');

      // Build badge text
      let badgeText = '+ Condition';
      if (hasCondition) {
        badgeText = `🔀 ${rules.length} rule${rules.length > 1 ? 's' : ''} (${currentOp})`;
      }

      // Generate HTML for each condition rule inside the panel
      const renderRuleRowsHtml = () => {
        if (rules.length === 0) {
          return `
            <div class="opt-no-rules-hint">
              No conditional rules yet. This option is currently <strong>always visible</strong>.
            </div>
          `;
        }
        return rules.map((r, rIdx) => {
          const watchedFieldObj = allOtherFields.find(f => f.key === r.field);
          const watchedOpts = watchedFieldObj ? watchedFieldObj.options : [];

          // Operator options
          const compOps = [
            { val: '==', label: '= equals' },
            { val: '!=', label: '≠ not equal' },
            { val: 'contains', label: 'contains' },
            { val: 'not_empty', label: 'is filled (not blank)' },
            { val: 'empty', label: 'is blank / empty' }
          ];

          const isValHidden = r.comparison === 'not_empty' || r.comparison === 'empty';

          // Options datalist
          const dlId = `dl_opt_${oIdx}_${rIdx}`;
          let datalistHtml = '';
          if (watchedOpts.length > 0) {
            datalistHtml = `<datalist id="${dlId}">` +
              watchedOpts.map(o => {
                const v = typeof o === 'object' && o !== null ? (o.value || o.label || '') : o;
                return `<option value="${v}">`;
              }).join('') +
            `</datalist>`;
          }

          return `
            <div class="opt-cond-rule-row" data-rule-idx="${rIdx}">
              <div class="opt-rule-prefix">${rIdx === 0 ? 'When' : currentOp}</div>
              <select class="mops-input opt-cond-field-sel" data-opt-idx="${oIdx}" data-rule-idx="${rIdx}">
                <option value="">— Select Target Field —</option>
                ${allOtherFields.map(f => `<option value="${f.key}" ${r.field === f.key ? 'selected' : ''}>${f.label} (${f.key})</option>`).join('')}
              </select>
              <select class="mops-input opt-cond-comp-sel" data-opt-idx="${oIdx}" data-rule-idx="${rIdx}">
                ${compOps.map(op => `<option value="${op.val}" ${(r.comparison || '==') === op.val ? 'selected' : ''}>${op.label}</option>`).join('')}
              </select>
              <div class="opt-cond-val-wrap" style="${isValHidden ? 'display:none;' : ''}">
                ${datalistHtml}
                <input type="text" class="mops-input opt-cond-val-input" placeholder="value" value="${r.value || ''}" data-opt-idx="${oIdx}" data-rule-idx="${rIdx}" ${datalistHtml ? `list="${dlId}"` : ''}>
              </div>
              <button type="button" class="btn btn-outline btn-sm opt-rule-del-btn" data-opt-idx="${oIdx}" data-rule-idx="${rIdx}" title="Delete this rule">✕</button>
            </div>
          `;
        }).join('');
      };

      // Summary preview text
      const getSummaryHtml = () => {
        if (!hasCondition) return '';
        const summaryParts = rules.map(r => {
          const compTxt = r.comparison === '!=' ? '≠' : (r.comparison === 'contains' ? 'contains' : (r.comparison === 'not_empty' ? 'is filled' : (r.comparison === 'empty' ? 'is blank' : '=')));
          const valTxt = (r.comparison === 'not_empty' || r.comparison === 'empty') ? '' : ` <code>${r.value || '(any)'}</code>`;
          return `<code>${r.field || 'field'}</code> ${compTxt}${valTxt}`;
        });
        return `<div class="opt-cond-preview">Show only when: ${summaryParts.join(` <strong style="color:#4338ca;">${currentOp}</strong> `)}</div>`;
      };

      row.innerHTML = `
        <div class="opt-row-main">
          <span class="opt-drag-handle" title="Drag to reorder"></span>
          <input type="text" class="mops-input opt-label-input" value="${this._escapeHtml ? this._escapeHtml(optLabel) : optLabel}" placeholder="Option label" data-opt-idx="${oIdx}">
          <button type="button" class="btn opt-condition-toggle ${hasCondition ? 'active' : ''}" title="${hasCondition ? 'Edit visibility conditions' : 'Add visibility conditions'}" data-opt-idx="${oIdx}">
            ${badgeText}
          </button>
          <button type="button" class="btn btn-danger btn-sm opt-delete-btn" onclick="App.removeOption(${oIdx})" title="Remove option">✕</button>
        </div>
        <div class="opt-condition-panel" data-opt-idx="${oIdx}">
          <div class="opt-condition-header">
            <div class="opt-logic-toggle-group">
              <span class="opt-logic-label">Logic:</span>
              <button type="button" class="opt-logic-btn ${currentOp === 'AND' ? 'active' : ''}" data-opt-idx="${oIdx}" data-logic="AND">AND (All Match)</button>
              <button type="button" class="opt-logic-btn ${currentOp === 'OR' ? 'active' : ''}" data-opt-idx="${oIdx}" data-logic="OR">OR (Any Matches)</button>
            </div>
            <div style="display:flex; gap:6px;">
              <button type="button" class="btn btn-outline-primary btn-sm opt-add-rule-btn" data-opt-idx="${oIdx}" style="font-size:11px; padding:2px 8px;">+ Add Rule</button>
              ${hasCondition ? `<button type="button" class="btn btn-outline-danger btn-sm opt-clear-rules-btn" data-opt-idx="${oIdx}" style="font-size:11px; padding:2px 8px;">Clear All</button>` : ''}
            </div>
          </div>
          <div class="opt-rules-container" data-opt-idx="${oIdx}">
            ${renderRuleRowsHtml()}
          </div>
          ${getSummaryHtml()}
        </div>
      `;

      // --- Label input binding ---
      row.querySelector('.opt-label-input').addEventListener('input', (e) => {
        field.options[oIdx].label = e.target.value;
        field.options[oIdx].value = e.target.value;
        this.saveFormToStorage();
      });
      row.querySelector('.opt-label-input').addEventListener('change', () => {
        this.render();
      });

      // --- Toggle condition panel ---
      const toggleBtn = row.querySelector('.opt-condition-toggle');
      const panel = row.querySelector('.opt-condition-panel');
      toggleBtn.addEventListener('click', () => {
        const isOpen = panel.classList.contains('open');
        panel.classList.toggle('open', !isOpen);
      });

      // Keep panel open if it was previously opened
      if (this._openedOptionConditionIdx === oIdx) {
        panel.classList.add('open');
      }

      // --- Logic operator toggle (AND / OR) ---
      row.querySelectorAll('.opt-logic-btn').forEach(lBtn => {
        lBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const newOp = lBtn.getAttribute('data-logic');
          if (!field.options[oIdx].showIf) {
            field.options[oIdx].showIf = { operator: newOp, rules: [] };
          } else {
            field.options[oIdx].showIf.operator = newOp;
          }
          this._openedOptionConditionIdx = oIdx;
          this.saveFormToStorage();
          this.renderDrawerOptions(field);
          this.render();
        });
      });

      // --- Add Rule button ---
      row.querySelector('.opt-add-rule-btn')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!field.options[oIdx].showIf) {
          field.options[oIdx].showIf = { operator: 'AND', rules: [] };
        }
        const defaultField = allOtherFields[0]?.key || '';
        field.options[oIdx].showIf.rules.push({
          field: defaultField,
          comparison: '==',
          value: ''
        });
        this._openedOptionConditionIdx = oIdx;
        this.saveFormToStorage();
        this.renderDrawerOptions(field);
        this.render();
      });

      // --- Clear All Rules button ---
      row.querySelector('.opt-clear-rules-btn')?.addEventListener('click', (e) => {
        e.stopPropagation();
        delete field.options[oIdx].showIf;
        this._openedOptionConditionIdx = null;
        this.saveFormToStorage();
        this.renderDrawerOptions(field);
        this.render();
      });

      // --- Rule row change bindings ---
      row.querySelectorAll('.opt-cond-field-sel').forEach(sel => {
        sel.addEventListener('change', (e) => {
          const rIdx = parseInt(sel.getAttribute('data-rule-idx'), 10);
          if (field.options[oIdx]?.showIf?.rules[rIdx]) {
            field.options[oIdx].showIf.rules[rIdx].field = e.target.value;
            this._openedOptionConditionIdx = oIdx;
            this.saveFormToStorage();
            this.renderDrawerOptions(field);
            this.render();
          }
        });
      });

      row.querySelectorAll('.opt-cond-comp-sel').forEach(sel => {
        sel.addEventListener('change', (e) => {
          const rIdx = parseInt(sel.getAttribute('data-rule-idx'), 10);
          if (field.options[oIdx]?.showIf?.rules[rIdx]) {
            field.options[oIdx].showIf.rules[rIdx].comparison = e.target.value;
            this._openedOptionConditionIdx = oIdx;
            this.saveFormToStorage();
            this.renderDrawerOptions(field);
            this.render();
          }
        });
      });

      row.querySelectorAll('.opt-cond-val-input').forEach(inp => {
        inp.addEventListener('input', (e) => {
          const rIdx = parseInt(inp.getAttribute('data-rule-idx'), 10);
          if (field.options[oIdx]?.showIf?.rules[rIdx]) {
            field.options[oIdx].showIf.rules[rIdx].value = e.target.value;
            this.saveFormToStorage();
          }
        });
      });

      row.querySelectorAll('.opt-rule-del-btn').forEach(delBtn => {
        delBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const rIdx = parseInt(delBtn.getAttribute('data-rule-idx'), 10);
          if (field.options[oIdx]?.showIf?.rules) {
            field.options[oIdx].showIf.rules.splice(rIdx, 1);
            if (field.options[oIdx].showIf.rules.length === 0) {
              delete field.options[oIdx].showIf;
            }
            this._openedOptionConditionIdx = oIdx;
            this.saveFormToStorage();
            this.renderDrawerOptions(field);
            this.render();
          }
        });
      });

      optionsList.appendChild(row);
    });

    document.getElementById('btnAddOption').onclick = () => {
      const newName = 'New Option ' + (field.options.length + 1);
      field.options.push({ label: newName, value: newName });
      this.saveFormToStorage();
      this.renderDrawerOptions(field);
      this.render();
    };
  },

  removeOption(oIdx) {
    if (!this.selectedFieldLoc) return;
    const field = this.formSchema.sections[this.selectedFieldLoc.sectionIndex].fields[this.selectedFieldLoc.fieldIndex];
    field.options.splice(oIdx, 1);
    this.saveFormToStorage();
    this.renderDrawerOptions(field);
    this.render(); // Keep canvas preview tags updated immediately
  },

  // ------------------------------------------------------------------------
  // Date Rules & Constraints tab in Drawer
  // ------------------------------------------------------------------------
  renderDrawerDateRules(field) {
    const isDate = field.type === 'date';
    const dateTabBtn = document.getElementById('tabBtnDateRules');

    if (!isDate) {
      if (dateTabBtn) dateTabBtn.style.display = 'none';
      const activeTabBtn = document.querySelector('.drawer-tab-btn.active');
      if (activeTabBtn && activeTabBtn.getAttribute('data-tab') === 'dateRules') {
        document.querySelectorAll('.drawer-tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.drawer-tab-pane').forEach(p => p.classList.remove('active'));
        document.querySelector('.drawer-tab-btn[data-tab="general"]')?.classList.add('active');
        document.getElementById('drawerTab_general')?.classList.add('active');
      }
      return;
    }

    if (dateTabBtn) dateTabBtn.style.display = 'inline-flex';

    // Initialize or migrate legacy date properties if dateConstraints not present
    if (!field.dateConstraints) {
      field.dateConstraints = {
        disableWeekends: field.disableWeekends !== undefined ? Boolean(field.disableWeekends) : true,
        pastTodayMode: field.grayOut ? 'allow_all' : (field.initialDateModifier ? 'disable_past' : 'allow_all'),
        disablePastDates: Boolean(field.initialDateModifier && !field.grayOut),
        disableCurrentDay: false,
        minDate: (field.initialDateModifier || field.dateRestriction) ? {
          enabled: true,
          source: field.dateRestriction ? 'field' : 'today',
          watchField: field.dateRestriction ? field.dateRestriction.field : '',
          fixedDate: '',
          offsetValue: (field.initialDateModifier?.value ?? field.dateRestriction?.modifier?.value ?? 5),
          offsetUnit: (field.initialDateModifier?.interval ?? field.dateRestriction?.modifier?.interval ?? 'weekdays'),
          boundary: (field.dateRestriction?.boundary ?? 'exclusive')
        } : null,
        maxDate: null,
        blackoutDates: [],
        freezeWindow: null
      };
    }

    const dc = field.dateConstraints;

    // Populate dependent date fields dropdowns
    const otherDateFields = [];
    (this.formSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => {
        if (f.type === 'date' && f.formData !== field.formData) {
          otherDateFields.push(f);
        }
      });
    });

    const fieldDisplayName = (f) =>
      (f.label && f.label.trim()) || (f.wfLabel && f.wfLabel.trim()) ||
      f.wfFieldName || f.formData || '(unnamed)';

    const populateDateFieldSelect = (selectEl, selectedVal) => {
      if (!selectEl) return;
      selectEl.innerHTML = '';
      if (otherDateFields.length === 0) {
        selectEl.innerHTML = '<option value="" disabled selected>(No other date fields in form)</option>';
        return;
      }
      otherDateFields.forEach(f => {
        const opt = document.createElement('option');
        opt.value = f.formData;
        opt.textContent = `${fieldDisplayName(f)} (${f.formData})`;
        if (f.formData === selectedVal) opt.selected = true;
        selectEl.appendChild(opt);
      });
      if (!selectedVal && otherDateFields[0]) {
        selectEl.value = otherDateFields[0].formData;
      }
    };

    const minWatchSelect = document.getElementById('selDateMinWatchField');
    populateDateFieldSelect(minWatchSelect, dc.minDate?.watchField);

    const maxWatchSelect = document.getElementById('selDateMaxWatchField');
    populateDateFieldSelect(maxWatchSelect, dc.maxDate?.watchField);

    // Populate UI elements
    const chkWeekends = document.getElementById('chkDateDisableWeekends');
    if (chkWeekends) chkWeekends.checked = Boolean(dc.disableWeekends);

    const selPastToday = document.getElementById('selDatePastTodayMode');
    if (selPastToday) selPastToday.value = dc.pastTodayMode || (dc.disableCurrentDay ? 'disable_today_past' : (dc.disablePastDates ? 'disable_past' : 'allow_all'));

    const chkMin = document.getElementById('chkDateMinEnabled');
    if (chkMin) chkMin.checked = Boolean(dc.minDate?.enabled);

    const selMinSource = document.getElementById('selDateMinSource');
    if (selMinSource) selMinSource.value = dc.minDate?.source || 'today';

    const inputMinFixed = document.getElementById('inputDateMinFixed');
    if (inputMinFixed) inputMinFixed.value = dc.minDate?.fixedDate || '';

    const inputMinOffset = document.getElementById('inputDateMinOffsetValue');
    if (inputMinOffset) inputMinOffset.value = dc.minDate?.offsetValue !== undefined ? dc.minDate.offsetValue : 5;

    const selMinUnit = document.getElementById('selDateMinOffsetUnit');
    if (selMinUnit) selMinUnit.value = dc.minDate?.offsetUnit || 'weekdays';

    const selMinBoundary = document.getElementById('selDateMinBoundary');
    if (selMinBoundary) selMinBoundary.value = dc.minDate?.boundary || 'exclusive';

    const chkMax = document.getElementById('chkDateMaxEnabled');
    if (chkMax) chkMax.checked = Boolean(dc.maxDate?.enabled);

    const selMaxSource = document.getElementById('selDateMaxSource');
    if (selMaxSource) selMaxSource.value = dc.maxDate?.source || 'field';

    const inputMaxFixed = document.getElementById('inputDateMaxFixed');
    if (inputMaxFixed) inputMaxFixed.value = dc.maxDate?.fixedDate || '';

    const selMaxBoundary = document.getElementById('selDateMaxBoundary');
    if (selMaxBoundary) selMaxBoundary.value = dc.maxDate?.boundary || 'exclusive';

    const inputBlackout = document.getElementById('inputDateBlackoutList');
    if (inputBlackout) inputBlackout.value = Array.isArray(dc.blackoutDates) ? dc.blackoutDates.join(', ') : '';

    const inputFreezeStart = document.getElementById('inputDateFreezeStart');
    if (inputFreezeStart) inputFreezeStart.value = dc.freezeWindow?.start || '';

    const inputFreezeEnd = document.getElementById('inputDateFreezeEnd');
    if (inputFreezeEnd) inputFreezeEnd.value = dc.freezeWindow?.end || '';

    // Function to refresh sub-element visibility & summary card
    const updateDateRulesUI = () => {
      // Min Date sub-groups
      const minEnabled = chkMin ? chkMin.checked : false;
      const minBody = document.getElementById('dateMinConfigBody');
      if (minBody) minBody.style.display = minEnabled ? 'block' : 'none';

      const minSource = selMinSource ? selMinSource.value : 'today';
      const grpMinField = document.getElementById('groupDateMinField');
      const grpMinFixed = document.getElementById('groupDateMinFixed');
      const grpMinOffset = document.getElementById('groupDateMinOffset');
      if (grpMinField) grpMinField.style.display = (minEnabled && minSource === 'field') ? 'block' : 'none';
      if (grpMinFixed) grpMinFixed.style.display = (minEnabled && minSource === 'fixed') ? 'block' : 'none';
      if (grpMinOffset) grpMinOffset.style.display = (minEnabled && minSource !== 'fixed') ? 'block' : 'none';

      const minBoundary = selMinBoundary ? selMinBoundary.value : 'exclusive';
      const hintMinBoundary = document.getElementById('hintDateMinBoundary');
      if (hintMinBoundary) {
        hintMinBoundary.textContent = minBoundary === 'exclusive'
          ? 'Exclusive: Boundary date itself IS SELECTABLE. Dates before it are greyed out.'
          : 'Inclusive: Boundary date itself IS GREYED OUT. Earliest selectable is the next day.';
      }

      // Past / Today mode hint
      const pastMode = selPastToday ? selPastToday.value : 'allow_all';
      const hintPastToday = document.getElementById('hintDatePastToday');
      if (hintPastToday) {
        if (pastMode === 'allow_all') hintPastToday.textContent = 'All historic and future dates are selectable.';
        else if (pastMode === 'disable_past') hintPastToday.textContent = 'Past dates are disabled. Current day (today) is selectable.';
        else hintPastToday.textContent = 'Current day (today) and past dates are greyed out. Earliest selectable is tomorrow.';
      }

      // Max Date sub-groups
      const maxEnabled = chkMax ? chkMax.checked : false;
      const maxBody = document.getElementById('dateMaxConfigBody');
      if (maxBody) maxBody.style.display = maxEnabled ? 'block' : 'none';

      const maxSource = selMaxSource ? selMaxSource.value : 'field';
      const grpMaxField = document.getElementById('groupDateMaxField');
      const grpMaxFixed = document.getElementById('groupDateMaxFixed');
      if (grpMaxField) grpMaxField.style.display = (maxEnabled && maxSource === 'field') ? 'block' : 'none';
      if (grpMaxFixed) grpMaxFixed.style.display = (maxEnabled && maxSource === 'fixed') ? 'block' : 'none';

      // Summary Card
      const summaryEl = document.getElementById('dateRuleSummaryText');
      if (summaryEl) {
        const rules = [];
        if (chkWeekends && chkWeekends.checked) {
          rules.push(' <strong>Weekends:</strong> Disabled (Sat & Sun greyed out)');
        }
        if (pastMode === 'disable_today_past') {
          rules.push(' <strong>Current Day:</strong> Greyed out (Tomorrow onwards)');
        } else if (pastMode === 'disable_past') {
          rules.push(' <strong>Past Dates:</strong> Disabled (Today selectable)');
        }
        if (minEnabled) {
          const offVal = inputMinOffset ? inputMinOffset.value : '0';
          const offUnit = selMinUnit ? (selMinUnit.value === 'weekdays' ? 'business days' : 'days') : 'days';
          const bLabel = minBoundary === 'inclusive' ? 'Inclusive / strictly after' : 'Exclusive / on or after';
          if (minSource === 'today') {
            rules.push(` <strong>Min Turnaround:</strong> Today + ${offVal} ${offUnit} (${bLabel})`);
          } else if (minSource === 'field') {
            const wName = minWatchSelect ? minWatchSelect.value : 'field';
            rules.push(` <strong>Min Date:</strong> ${wName} + ${offVal} ${offUnit} (${bLabel})`);
          } else {
            const fDate = inputMinFixed ? inputMinFixed.value : 'fixed date';
            rules.push(` <strong>Min Date:</strong> ${fDate} (${bLabel})`);
          }
        }
        if (maxEnabled) {
          const maxBoundary = selMaxBoundary ? selMaxBoundary.value : 'exclusive';
          const bLabel = maxBoundary === 'inclusive' ? 'Inclusive / strictly before' : 'Exclusive / up to & including';
          if (maxSource === 'field') {
            const wName = maxWatchSelect ? maxWatchSelect.value : 'field';
            rules.push(` <strong>Max Date:</strong> ${wName} (${bLabel})`);
          } else if (maxSource === 'fixed') {
            const fDate = inputMaxFixed ? inputMaxFixed.value : 'fixed date';
            rules.push(` <strong>Max Date:</strong> ${fDate} (${bLabel})`);
          } else {
            rules.push(` <strong>Max Date:</strong> Today (${bLabel})`);
          }
        }
        const bDates = (inputBlackout?.value || '').split(',').map(s => s.trim()).filter(Boolean);
        if (bDates.length > 0) {
          rules.push(` <strong>Blackouts:</strong> ${bDates.length} specific date(s) disabled`);
        }
        if (inputFreezeStart?.value && inputFreezeEnd?.value) {
          rules.push(` <strong>Freeze Window:</strong> ${inputFreezeStart.value}  ${inputFreezeEnd.value} disabled`);
        }

        if (rules.length === 0) {
          summaryEl.innerHTML = '<span style="color: #64748b;">No date constraints active (All dates selectable).</span>';
        } else {
          summaryEl.innerHTML = '<ul style="margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 4px;">' +
            rules.map(r => `<li>${r}</li>`).join('') + '</ul>';
        }
      }
    };

    updateDateRulesUI();

    // Bind input change events
    const markDirty = () => {
      this._markDrawerDirty(true);
      updateDateRulesUI();
    };

    [chkWeekends, selPastToday, chkMin, selMinSource, minWatchSelect, inputMinFixed,
      inputMinOffset, selMinUnit, selMinBoundary, chkMax, selMaxSource,
      maxWatchSelect, inputMaxFixed, selMaxBoundary, inputBlackout,
      inputFreezeStart, inputFreezeEnd
    ].forEach(el => {
      if (el) {
        el.onchange = markDirty;
        el.oninput = markDirty;
      }
    });
  },

  _saveDrawerDateConstraints(field) {
    const chkWeekends = document.getElementById('chkDateDisableWeekends');
    const selPastToday = document.getElementById('selDatePastTodayMode');
    const chkMin = document.getElementById('chkDateMinEnabled');
    const selMinSource = document.getElementById('selDateMinSource');
    const minWatchSelect = document.getElementById('selDateMinWatchField');
    const inputMinFixed = document.getElementById('inputDateMinFixed');
    const inputMinOffset = document.getElementById('inputDateMinOffsetValue');
    const selMinUnit = document.getElementById('selDateMinOffsetUnit');
    const selMinBoundary = document.getElementById('selDateMinBoundary');
    const chkMax = document.getElementById('chkDateMaxEnabled');
    const selMaxSource = document.getElementById('selDateMaxSource');
    const maxWatchSelect = document.getElementById('selDateMaxWatchField');
    const inputMaxFixed = document.getElementById('inputDateMaxFixed');
    const selMaxBoundary = document.getElementById('selDateMaxBoundary');
    const inputBlackout = document.getElementById('inputDateBlackoutList');
    const inputFreezeStart = document.getElementById('inputDateFreezeStart');
    const inputFreezeEnd = document.getElementById('inputDateFreezeEnd');

    const pastMode = selPastToday ? selPastToday.value : 'allow_all';
    const minEnabled = chkMin ? chkMin.checked : false;
    const maxEnabled = chkMax ? chkMax.checked : false;

    const blackoutDates = (inputBlackout?.value || '')
      .split(',')
      .map(s => s.trim())
      .filter(s => /^\d{4}-\d{2}-\d{2}$/.test(s));

    const freezeWindow = (inputFreezeStart?.value && inputFreezeEnd?.value) ? {
      start: inputFreezeStart.value,
      end: inputFreezeEnd.value
    } : null;

    field.dateConstraints = {
      disableWeekends: chkWeekends ? chkWeekends.checked : false,
      pastTodayMode: pastMode,
      disablePastDates: ['disable_past', 'disable_today_past'].includes(pastMode),
      disableCurrentDay: pastMode === 'disable_today_past',
      minDate: minEnabled ? {
        enabled: true,
        source: selMinSource?.value || 'today',
        watchField: minWatchSelect?.value || '',
        fixedDate: inputMinFixed?.value || '',
        offsetValue: parseInt(inputMinOffset?.value, 10) || 0,
        offsetUnit: selMinUnit?.value || 'weekdays',
        boundary: selMinBoundary?.value || 'exclusive'
      } : null,
      maxDate: maxEnabled ? {
        enabled: true,
        source: selMaxSource?.value || 'field',
        watchField: maxWatchSelect?.value || '',
        fixedDate: inputMaxFixed?.value || '',
        boundary: selMaxBoundary?.value || 'exclusive'
      } : null,
      blackoutDates,
      freezeWindow
    };

    // Backward compatibility sync with existing MOPs Angular models
    field.disableWeekends = Boolean(field.dateConstraints.disableWeekends);
    if (field.dateConstraints.disableCurrentDay) {
      field.grayOut = false;
    }
    if (minEnabled) {
      field.initialDateModifier = {
        value: field.dateConstraints.minDate.offsetValue,
        interval: field.dateConstraints.minDate.offsetUnit
      };
      if (field.dateConstraints.minDate.source === 'field') {
        field.dateRestriction = {
          type: 'gt',
          field: field.dateConstraints.minDate.watchField,
          boundary: field.dateConstraints.minDate.boundary,
          modifier: {
            type: 'add',
            value: field.dateConstraints.minDate.offsetValue,
            interval: field.dateConstraints.minDate.offsetUnit
          }
        };
      }
    }
  },

  // Display Rules tab in Drawer  Full operator set with AND/OR toggle
  renderDrawerRules(field) {
    const rulesList = document.getElementById('drawerRulesList');
    if (!rulesList) return;
    rulesList.innerHTML = '';

    // If Custom Plain JavaScript is configured
    if (field.advancedLogic?.display?.mode === 'javascript' && field.advancedLogic?.display?.customJs?.trim()) {
      rulesList.innerHTML = `
        <div class="rules-always-shown" style="background: #0f172a; border-color: #334155; color: #f1f5f9; padding: 12px 14px; text-align: left;">
          <div class="rules-always-icon" style="font-size: 20px;"></div>
          <div style="flex: 1; min-width: 0;">
            <strong style="color: #38bdf8; font-size: 13px;">Custom JavaScript Rule Active</strong>
            <div style="font-size: 11px; color: #94a3b8; margin-top: 3px;">Visibility evaluated via ES6 JavaScript expression:</div>
            <code style="font-size: 11px; color: #e2e8f0; font-family: Consolas, monospace; display: block; margin-top: 6px; background: #090d16; padding: 6px 8px; border-radius: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; border: 1px solid #1e293b;">${field.advancedLogic.display.customJs}</code>
          </div>
        </div>
        <button class="btn btn-primary btn-sm rules-add-first-btn" onclick="App.openAdvancedLogicForSelectedField()" style="margin-top: 12px; width: 100%;">
           Edit in Advanced Logic Studio
        </button>
      `;
      return;
    }

    // Collect all other fields available in the form
    const otherFields = [];
    (this.formSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => {
        if (f.formData !== field.formData) otherFields.push(f);
      });
    });

    /** Helper: get a human-readable display name for a field */
    const fieldDisplayName = (f) =>
      (f.label && f.label.trim()) || (f.wfLabel && f.wfLabel.trim()) ||
      f.wfFieldName || f.formData || '(unnamed)';

    const hasCondition = field.condition && field.condition !== true &&
      (Array.isArray(field.condition) ? field.condition.length > 0 : true);

    if (!hasCondition) {
      rulesList.innerHTML = `
        <div class="rules-always-shown">
          <div class="rules-always-icon">OK</div>
          <div>
            <strong>Always Displayed</strong><br>
            <span>This field has no conditions  it always shows in the form.</span>
          </div>
        </div>
        <button class="btn btn-primary btn-sm rules-add-first-btn" onclick="App.enableConditionOnSelectedField()">
           Add Conditional Display Rule
        </button>
      `;
      return;
    }

    // Convert condition to array if single object
    const condList = Array.isArray(field.condition) ? field.condition : [field.condition];
    const currentType = field.conditionType || 'AND';

    // --- AND/OR Header Toggle ---
    const headerDiv = document.createElement('div');
    headerDiv.className = 'rules-andor-header';
    headerDiv.innerHTML = `
      <span class="rules-andor-label">Show this field when</span>
      <div class="rules-andor-toggle">
        <button class="andor-btn ${currentType === 'AND' ? 'active' : ''}" data-type="AND">ALL (AND)</button>
        <button class="andor-btn ${currentType === 'OR' ? 'active' : ''}" data-type="OR">ANY (OR)</button>
      </div>
      <span class="rules-andor-label">of the following are true:</span>
    `;
    headerDiv.querySelectorAll('.andor-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        field.conditionType = btn.getAttribute('data-type');
        this.saveFormToStorage();
        this.renderDrawerRules(field);
      });
    });
    rulesList.appendChild(headerDiv);

    // All available operators
    const operators = [
      { value: '==', label: 'Equals' },
      { value: '!=', label: 'Does Not Equal' },
      { value: 'isSelected', label: 'Is Selected (Picklist)' },
      { value: 'isNotSelected', label: 'Is Not Selected (Picklist)' },
      { value: 'contains', label: 'Contains' },
      { value: 'doesNotContain', label: 'Does Not Contain' },
      { value: 'startsWith', label: 'Starts With' },
      { value: 'endsWith', label: 'Ends With' },
      { value: 'notempty', label: 'Is Not Empty' },
      { value: 'empty', label: 'Is Empty' },
      { value: '>', label: 'Greater Than (>)' },
      { value: '<', label: 'Less Than (<)' },
      { value: '>=', label: 'Greater Than or Equal (>=)' },
      { value: '<=', label: 'Less Than or Equal (<=)' },
      { value: 'regex', label: 'Matches Regex Pattern' },
    ];
    // Operators that don't need a value
    const noValueOps = new Set(['notempty', 'empty']);

    condList.forEach((rule, rIdx) => {
      // Ensure rule has a field set; default to first available other field
      if (!rule.field && otherFields.length > 0) {
        rule.field = otherFields[0].formData;
        this.saveFormToStorage();
      }

      const card = document.createElement('div');
      card.className = 'rule-card';

      if (!otherFields.length) {
        card.innerHTML = `<div class="rule-no-fields"> No other fields in the form yet. Add more fields first.</div>`;
        rulesList.appendChild(card);
        return;
      }

      const fieldOptions = otherFields.map(of => {
        const displayName = fieldDisplayName(of);
        const keyStr = of.formData || of.wfFieldName || '';
        const selected = rule.field === keyStr ? 'selected' : '';
        return `<option value="${keyStr}" ${selected}>${displayName}${keyStr && keyStr !== displayName ? ' (' + keyStr + ')' : ''}</option>`;
      }).join('');

      // Get options for the currently watched field (for datalist hints)
      const watchedField = otherFields.find(f => f.formData === rule.field || f.wfFieldName === rule.field);
      const watchedOptions = watchedField?.options || [];
      const datalistId = `ruleDL_${rIdx}_${Date.now()}`;
      const datalistHtml = watchedOptions.length
        ? `<datalist id="${datalistId}">${watchedOptions.map(o => {
          const v = (typeof o === 'object' && o !== null) ? (o.value || o.label || '') : String(o);
          return `<option value="${v}">`;
        }).join('')}</datalist>`
        : '';

      const isNoValue = noValueOps.has((rule.comparison || '==').toLowerCase());

      card.innerHTML = `
        <div class="rule-card-header">
          <span class="rule-card-num">RULE ${rIdx + 1}</span>
          <button class="btn btn-danger btn-sm" onclick="App.removeRule(${rIdx})"> Remove</button>
        </div>

        <div class="rule-row">
          <label class="rule-row-label">Watch Field</label>
          <select class="mops-select rule-field-select">
            <option value=""> select a field </option>
            ${fieldOptions}
          </select>
        </div>

        <div class="rule-row">
          <label class="rule-row-label">Operator</label>
          <select class="mops-select rule-comp-select">
            ${operators.map(op => `<option value="${op.value}" ${(rule.comparison || '==') === op.value ? 'selected' : ''}>${op.label}</option>`).join('')}
          </select>
        </div>

        <div class="rule-row rule-val-row" ${isNoValue ? 'style="display:none"' : ''}>
          <label class="rule-row-label">Value${watchedOptions.length ? ' <span class="rule-hint-badge"> ' + watchedOptions.length + ' options available</span>' : ''}</label>
          ${datalistHtml}
          <input type="text" class="mops-input rule-val-input" value="${rule.value || ''}" placeholder="${watchedOptions.length ? 'Type or select a value' : 'e.g. Other, Yes, Campaign A'}"${datalistHtml ? ` list="${datalistId}"` : ''}>
        </div>

        ${rIdx < condList.length - 1 ? `<div class="rule-connector">${currentType === 'OR' ? 'OR' : 'AND'}</div>` : ''}
      `;

      card.querySelector('.rule-field-select').addEventListener('change', (e) => {
        rule.field = e.target.value;
        this.saveFormToStorage();
        this.renderDrawerRules(field); // re-render to update datalist
        this.render();
      });

      card.querySelector('.rule-comp-select').addEventListener('change', (e) => {
        rule.comparison = e.target.value;
        // Show/hide value row
        const valRow = card.querySelector('.rule-val-row');
        if (valRow) valRow.style.display = noValueOps.has(e.target.value.toLowerCase()) ? 'none' : '';
        this.saveFormToStorage();
        this.render();
      });

      card.querySelector('.rule-val-input')?.addEventListener('input', (e) => {
        rule.value = e.target.value;
        this.saveFormToStorage();
        this.render();
      });

      rulesList.appendChild(card);
    });

    // Add Another Rule / Clear All footer
    const addMoreDiv = document.createElement('div');
    addMoreDiv.className = 'rules-add-more';
    addMoreDiv.innerHTML = `
      <button class="btn btn-outline btn-sm rules-add-more-btn" onclick="App.addAnotherRule()">
        + Add Another Condition
      </button>
      <button class="btn btn-danger btn-sm" onclick="App.clearAllRules()" title="Remove all rules  field will always be shown">
        x Clear All Rules
      </button>
    `;
    rulesList.appendChild(addMoreDiv);
  },

  addAnotherRule() {
    if (!this.selectedFieldLoc) return;
    const field = this.formSchema.sections[this.selectedFieldLoc.sectionIndex].fields[this.selectedFieldLoc.fieldIndex];
    // Collect other fields
    const otherFields = [];
    (this.formSchema.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => { if (f.formData !== field.formData) otherFields.push(f); });
    });
    const condList = Array.isArray(field.condition) ? field.condition : [field.condition];
    const firstTarget = otherFields[0]?.formData || 'otherField';
    condList.push({ field: firstTarget, comparison: '==', value: '' });
    field.condition = condList;
    if (!field.conditionType) field.conditionType = 'AND';
    this.saveFormToStorage();
    this.renderDrawerRules(field);
    this.render();
  },

  clearAllRules() {
    if (!this.selectedFieldLoc) return;
    const field = this.formSchema.sections[this.selectedFieldLoc.sectionIndex].fields[this.selectedFieldLoc.fieldIndex];
    if (confirm('Remove all display rules? This field will always be shown.')) {
      field.condition = null;
      field.conditionType = null;
      this.saveFormToStorage();
      this.renderDrawerRules(field);
      this.render();
    }
  },

  enableConditionOnSelectedField() {
    if (!this.selectedFieldLoc) return;
    const field = this.formSchema.sections[this.selectedFieldLoc.sectionIndex].fields[this.selectedFieldLoc.fieldIndex];

    // Find the FIRST other field to default to (not the last)
    let target = null;
    outer: for (const sec of (this.formSchema.sections || [])) {
      for (const f of (sec.fields || [])) {
        if ((f.formData || f.wfFieldName) && f.formData !== field.formData) {
          target = f.formData || f.wfFieldName;
          break outer;
        }
      }
    }

    if (!target) {
      this._showToast('Add at least one other field to the form first.');
      return;
    }

    field.condition = [{ field: target, comparison: '==', value: '' }];
    field.conditionType = 'AND';
    this.saveFormToStorage();
    this.renderDrawerRules(field);
    this.render();
  },

  removeRule(rIdx) {
    if (!this.selectedFieldLoc) return;
    const field = this.formSchema.sections[this.selectedFieldLoc.sectionIndex].fields[this.selectedFieldLoc.fieldIndex];
    if (Array.isArray(field.condition)) {
      field.condition.splice(rIdx, 1);
      if (field.condition.length === 0) {
        field.condition = null;
      }
    } else {
      field.condition = null;
    }
    this.saveFormToStorage();
    this.renderDrawerRules(field);
    this.render();
  },

  // ------------------------------------------------------------------------
  // Import / Export Operations
  // ------------------------------------------------------------------------
  downloadJson() {
    const filename = (this.formSchema.title || 'mops-form-mockup').toLowerCase().replace(/[^a-z0-9]/g, '-') + '.json';
    const blob = new Blob([JSON.stringify(this.formSchema, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    this._triggerDownload(url, filename);
  },

  handleJsonUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const loaded = JSON.parse(e.target.result);
        if (loaded.sections) {
          this.formSchema = loaded;
          const formTitleInput = document.getElementById('formTitleInput');
          if (formTitleInput) formTitleInput.value = this.formSchema.title || '';
          this.saveFormToStorage();
          this.render();
          alert('Form mockup loaded successfully!');
        } else {
          alert('Invalid form JSON file.');
        }
      } catch (err) {
        alert('Could not parse JSON file: ' + err.message);
      }
    };
    reader.readAsText(file);
  },

  downloadStandaloneHtml() {
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const css = window.MOPS_STANDALONE_CSS || window.STANDALONE_REVIEW_CSS || '';
    const formTitle = active?.label || this.formSchema.title || 'MOPs Intake Form';
    // V1=Cisco Brand, V2=Modern Studio, V3=Step Wizard (matches live preview tab order)
    const htmlV1 = window.Exporter.generateStandaloneReviewHtmlV2(this.formSchema); // Cisco Brand
    const htmlV2 = window.Exporter.generateStandaloneReviewHtml(this.formSchema, css); // Modern Studio
    const htmlV3 = window.Exporter.generateStandaloneReviewHtmlV3(this.formSchema);
    const baseName = (active?.label || active?.id || this.formSchema.title || 'mops-form').toLowerCase().replace(/[^a-z0-9]/g, '-');

    // Open Share HTML Modal  with V1, V2 and V3 options, pre-selecting current live preview variant
    this.openShareHtmlModal(htmlV1, htmlV2, htmlV3, baseName, formTitle, this.livePreviewVariant || 1);
  },

  openShareHtmlModal(htmlV1, htmlV2, htmlV3, baseName, formTitle, defaultVariant = 1) {
    const modal = document.getElementById('modalShareHtml');
    if (!modal) return;

    this._shareHtmlV1 = htmlV1;
    this._shareHtmlV2 = htmlV2;
    this._shareHtmlV3 = htmlV3;
    this._shareBaseName = baseName;
    this._shareFormTitle = formTitle;
    this._shareVariant = defaultVariant || 1;

    const titleEl = document.getElementById('shareHtmlModalTitle');
    if (titleEl) titleEl.textContent = `Share Interactive Review: ${formTitle || 'Form'}`;

    this._updateShareModalState();
    modal.classList.add('open');
  },

  selectShareVariant(v) {
    this._shareVariant = v;
    this._updateShareModalState();
  },

  _updateShareModalState() {
    const v = this._shareVariant || 1;
    // V1=Cisco Brand, V2=Modern Studio, V3=Step Wizard
    const html = v === 3 ? this._shareHtmlV3 : (v === 2 ? this._shareHtmlV2 : this._shareHtmlV1);
    const filename = `${this._shareBaseName || 'mops-form'}-review${v === 1 ? '-cisco' : (v === 3 ? '-wizard' : '-modern')}.html`;

    // Tab styling
    const tabV1 = document.getElementById('shareTabV1');
    const tabV2 = document.getElementById('shareTabV2');
    const tabV3 = document.getElementById('shareTabV3');
    if (tabV1) {
      tabV1.style.borderBottomColor = v === 1 ? '#005fb8' : 'transparent';
      tabV1.style.color = v === 1 ? '#0f172a' : '#64748b';
    }
    if (tabV2) {
      tabV2.style.borderBottomColor = v === 2 ? '#005fb8' : 'transparent';
      tabV2.style.color = v === 2 ? '#0f172a' : '#64748b';
    }
    if (tabV3) {
      tabV3.style.borderBottomColor = v === 3 ? '#005fb8' : 'transparent';
      tabV3.style.color = v === 3 ? '#0f172a' : '#64748b';
    }

    // Badge styling
    const badgeV1 = document.getElementById('shareVariantBadgeV1');
    const badgeV2 = document.getElementById('shareVariantBadgeV2');
    const badgeV3 = document.getElementById('shareVariantBadgeV3');
    if (badgeV1) badgeV1.style.display = v === 1 ? 'flex' : 'none';
    if (badgeV2) badgeV2.style.display = v === 2 ? 'flex' : 'none';
    if (badgeV3) badgeV3.style.display = v === 3 ? 'flex' : 'none';

    // Filename & stats
    const filenameBadge = document.getElementById('shareHtmlFilenameBadge');
    if (filenameBadge) filenameBadge.textContent = filename;

    const statsEl = document.getElementById('shareHtmlMetaStats');
    if (statsEl) {
      const kb = (new Blob([html || '']).size / 1024).toFixed(1);
      statsEl.textContent = `${kb} KB  Self-contained  Zero external server dependencies`;
    }

    // Bind Re-Download button (uses showSaveFilePicker if available, else blob/data)
    const btnReDownload = document.getElementById('btnShareHtmlReDownload');
    if (btnReDownload) {
      btnReDownload.onclick = async () => {
        if (window.showSaveFilePicker) {
          try {
            const handle = await window.showSaveFilePicker({
              suggestedName: filename,
              types: [{
                description: 'HTML File',
                accept: { 'text/html': ['.html'] }
              }]
            });
            const writable = await handle.createWritable();
            await writable.write(html);
            await writable.close();
            btnReDownload.textContent = 'OK Saved to Disk!';
            setTimeout(() => { btnReDownload.textContent = ' Download .html File'; }, 2000);
            return;
          } catch (err) {
            if (err.name === 'AbortError') return;
          }
        }
        const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        const u = URL.createObjectURL(blob);
        this._triggerDownload(u, filename);
        btnReDownload.textContent = 'OK Download Triggered!';
        setTimeout(() => { btnReDownload.textContent = ' Download .html File'; }, 2000);
      };
    }

    // Bind Copy HTML button
    const btnCopy = document.getElementById('btnShareHtmlCopyCode');
    if (btnCopy) {
      btnCopy.onclick = async () => {
        try {
          await navigator.clipboard.writeText(html);
          btnCopy.textContent = 'OK HTML Copied to Clipboard!';
          setTimeout(() => { btnCopy.textContent = ' Copy HTML to Clipboard'; }, 2000);
        } catch (err) {
          const ta = document.createElement('textarea');
          ta.value = html;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
          btnCopy.textContent = 'OK HTML Copied to Clipboard!';
          setTimeout(() => { btnCopy.textContent = ' Copy HTML to Clipboard'; }, 2000);
        }
      };
    }

    // Bind Open in New Tab button
    const btnOpen = document.getElementById('btnShareHtmlOpenNewTab');
    if (btnOpen) {
      btnOpen.onclick = () => {
        const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        const blobUrl = URL.createObjectURL(blob);
        const win = window.open(blobUrl, '_blank');
        if (!win) {
          const a = document.createElement('a');
          a.href = blobUrl;
          a.target = '_blank';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
      };
    }
  },

  openExportModal() {
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const tsCode = window.Exporter.generateMopsTypeScript(this.formSchema, active);
    document.getElementById('exportMopsCodeBlock').textContent = tsCode;

    const titleEl = document.querySelector('#modalExportMops .mops-modal-title');
    if (titleEl) {
      titleEl.textContent = `Export MOPs Angular Config: ${active?.label || this.formSchema.title} (${active?.configFile || 'config.ts'})`;
    }

    document.getElementById('modalExportMops').classList.add('open');

    document.getElementById('btnCopyMopsCode').onclick = () => {
      navigator.clipboard.writeText(tsCode);
      alert(`MOPs TypeScript configuration for "${active?.label || 'Form'}" copied to clipboard!`);
    };
  },

  openSpecSheetModal() {
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const tableHtml = window.Exporter.generateSpecSheetTable(this.formSchema, active);
    document.getElementById('specSheetContent').innerHTML = tableHtml;

    const titleEl = document.querySelector('#modalSpecSheet .mops-modal-title');
    if (titleEl) {
      titleEl.textContent = `Intake Form Functional Spec: ${active?.label || this.formSchema.title}`;
    }

    document.getElementById('modalSpecSheet').classList.add('open');

    document.getElementById('btnPrintSpecSheet').onclick = () => {
      window.print();
    };
  },


  // ------------------------------------------------------------------------
  // Forms Gallery Operations (All 15 forms + custom forms synced with Tab Strip)
  // ------------------------------------------------------------------------
  openFormsGallery() {
    document.getElementById('modalFormsGallery')?.classList.add('open');
    const searchInput = document.getElementById('gallerySearchInput');
    if (searchInput) searchInput.value = '';
    this.renderFormsGallery();
  },

  renderFormsGallery(searchQuery = '') {
    const container = document.getElementById('galleryGridContainer');
    if (!container) return;
    container.innerHTML = '';

    const query = (searchQuery || '').toLowerCase().trim();
    const formsList = this.allForms || [];

    const filtered = formsList.filter(f => {
      if (!query) return true;
      const title = (f.schema?.title || f.label || '').toLowerCase();
      const desc = (f.schema?.description || '').toLowerCase();
      const cfg = (f.configFile || '').toLowerCase();
      const lbl = (f.label || '').toLowerCase();
      const hasField = (f.schema?.sections || []).some(s =>
        (s.title || '').toLowerCase().includes(query) ||
        (s.fields || []).some(fld =>
          (fld.label || '').toLowerCase().includes(query) ||
          (fld.wfLabel || '').toLowerCase().includes(query) ||
          (fld.formData || '').toLowerCase().includes(query) ||
          (fld.wfFieldName || '').toLowerCase().includes(query)
        )
      );
      return title.includes(query) || desc.includes(query) || cfg.includes(query) || lbl.includes(query) || hasField;
    });

    if (filtered.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; padding: 40px; text-align: center; color: #64748b;">
          No forms found matching "${searchQuery}".
        </div>
      `;
      return;
    }

    filtered.forEach(form => {
      const isCurrent = form.id === this.activeFormId;
      let totalFields = 0;
      let totalRules = 0;
      (form.schema?.sections || []).forEach(sec => {
        (sec.fields || []).forEach(f => {
          totalFields++;
          if (f.condition && f.condition !== true) totalRules++;
          if (f.advLogic) totalRules++;
        });
      });

      const isSample = (window.SAMPLE_FORMS || []).some(s => s.id === form.id);
      const card = document.createElement('div');
      card.className = 'gallery-card' + (isCurrent ? ' current-active' : '');

      const verTag = form.activeVersionId ? `${form.activeVersionId} (${form.activeSprint || 'Sprint'})` : 'v1.0';
      const verCount = form.versions ? form.versions.length : 1;

      card.innerHTML = `
        <div class="gallery-card-top">
          <div class="gallery-card-header">
            <div style="display: flex; align-items: center; gap: 8px; overflow: hidden;">
              <span style="font-size: 20px; line-height: 1;">${form.icon || ''}</span>
              <span class="gallery-card-title" title="${form.schema?.title || form.label}">${form.schema?.title || form.label}</span>
            </div>
            <span class="library-card-badge" title="Source Config">${form.configFile || form.label}</span>
          </div>
          <div class="gallery-card-desc">${form.schema?.description || 'No description provided.'}</div>
          <div class="gallery-card-stats">
            <span class="stat-pill">${form.schema?.sections?.length || 0} Sections</span>
            <span class="stat-pill">${totalFields} Fields</span>
            ${totalRules > 0 ? `<span class="stat-pill rules"> ${totalRules} Rules</span>` : ''}
            <span class="stat-pill" style="background: rgba(0, 188, 235, 0.12); color: #005fb8; border: 1px solid rgba(0, 188, 235, 0.3); font-weight: 600;" title="Current Sprint Version"> ${verTag} (${verCount} ver)</span>
            ${form.active !== false ? '<span class="stat-pill" style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-weight: 700;">* Active</span>' : '<span class="stat-pill" style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-weight: 700;">* Inactive</span>'}
            ${isCurrent ? `<span class="stat-pill" style="background: #005fb8; color: #fff; font-weight: 600;">Currently Editing</span>` : ''}
          </div>
        </div>

        <div class="gallery-card-actions" style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px; gap: 8px;">
          <button type="button" class="btn ${isCurrent ? 'btn-secondary' : 'btn-primary'} btn-sm" onclick="App.selectFormFromGallery('${form.id}')" style="flex: 1; font-weight: 600;">
            ${isCurrent ? 'OK Currently Editing' : ' Open Form'}
          </button>
          <div style="display: flex; gap: 5px; align-items: center;">
            <button type="button" class="btn btn-outline btn-sm" onclick="App.toggleFormActiveStatus('${form.id}'); App.renderFormsGallery();" title="${form.active !== false ? 'Mark form Inactive (disabled)' : 'Mark form Active (enabled)'}">
              ${form.active !== false ? 'Deactivate' : 'Activate'}
            </button>
            <button type="button" class="btn btn-outline btn-sm" onclick="App.downloadGalleryFormJson('${form.id}')" title="Download Form JSON">
               JSON
            </button>
            <button type="button" class="btn btn-outline btn-sm" style="color: #dc2626; border-color: #fca5a5;" onclick="App.deleteForm('${form.id}'); App.renderFormsGallery();" title="Delete this intake form">
              
            </button>
          </div>
        </div>
      `;

      container.appendChild(card);
    });
  },

  selectFormFromGallery(formId) {
    if (formId !== this.activeFormId) {
      this.switchActiveForm(formId);
    }
    document.getElementById('modalFormsGallery')?.classList.remove('open');
    const f = (this.allForms || []).find(x => x.id === formId);
    this._showToast(`Opened ${f?.schema?.title || f?.label || 'form'}`);
  },



  downloadGalleryFormJson(formId) {
    const found = (this.allForms || []).find(f => f.id === formId);
    if (!found || !found.schema) return;

    const filename = (found.schema.title || found.label || 'mops-form').toLowerCase().replace(/[^a-z0-9]/g, '-') + '.json';
    const blob = new Blob([JSON.stringify(found.schema, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    this._triggerDownload(url, filename);
  },

  saveCurrentFormToGallery() {
    this.saveAllForms();
    this.renderFormTabs();
    this.renderFormsGallery();
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    alert(`"${active?.schema?.title || active?.label || 'Form'}" saved successfully!`);
  },

  createNewForm() {
    const newName = prompt('Enter a name for the new intake form:', 'New Intake Form');
    if (!newName || !newName.trim()) return;

    const trimmed = newName.trim();
    const newId = 'form_' + Date.now();
    const defaultSec = JSON.parse(JSON.stringify(window.BUILTIN_SECTIONS[0].data));
    const newForm = {
      id: newId,
      label: trimmed.length > 15 ? trimmed.substring(0, 15) + '' : trimmed,
      icon: '',
      configFile: 'form.' + trimmed.toLowerCase().replace(/[^a-z0-9]/g, '-') + '.config.ts',
      schema: {
        title: trimmed,
        description: 'Custom intake form created with MOPs Form Studio.',
        sections: [defaultSec]
      }
    };
    this.allForms.push(newForm);
    this.switchActiveForm(newId);
    this.renderFormsGallery();
    document.getElementById('modalFormsGallery')?.classList.remove('open');
  },

  deleteFormFromGallery(formId) {
    const isSample = (window.SAMPLE_FORMS || []).some(s => s.id === formId);
    if (isSample) {
      alert('Pre-seeded sample forms cannot be deleted.');
      return;
    }
    const idx = (this.allForms || []).findIndex(f => f.id === formId);
    if (idx < 0) return;

    const form = this.allForms[idx];
    if (confirm(`Delete "${form.schema?.title || form.label}"?`)) {
      this.allForms.splice(idx, 1);
      window.WorkspaceRepo?.deleteForm(formId);
      if (this.activeFormId === formId) {
        const nextId = this.allForms[0]?.id || null;
        if (nextId) {
          this.switchActiveForm(nextId);
        } else {
          this.activeFormId = null;
          this.formSchema = { title: '', description: '', sections: [] };
          this.renderFormTabs();
          this.render();
        }
      } else {
        this.saveAllForms();
        this.renderFormTabs();
      }
      this.renderFormsGallery();
    }
  }
});
