/**
 * Cisco MOPs FORM Studio - Sprint Diff & Change Highlighter Engine
 * Domain: Visual delta comparison between form versions: added, modified, removed fields with canvas highlighting & changelog
 * File: js/modules/10-sprint-diff.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
sprintDiffMode: false,
  sprintDiffBaselineId: null,
  sprintDiffData: null,

  toggleSprintDiffMode(enable) {
    this.sprintDiffMode = !!enable;
    const bar = document.getElementById('canvasSprintDiffBar');
    const compareWrap = document.getElementById('csdbCompareWrap');
    const legend = document.getElementById('csdbLegend');
    const actions = document.getElementById('csdbActions');
    const toggle = document.getElementById('csdbDiffToggle');

    if (toggle) toggle.checked = this.sprintDiffMode;
    if (bar) bar.classList.toggle('active', this.sprintDiffMode);

    if (this.sprintDiffMode) {
      if (compareWrap) compareWrap.style.display = 'flex';
      if (legend) legend.style.display = 'flex';
      if (actions) actions.style.display = 'flex';

      const activeForm = this.getActiveForm();
      this.sprintDiffData = window.VersionManager.getSprintDiff(activeForm, this.sprintDiffBaselineId);
      this.updateSprintDiffBarUI();
      this._showToast(`Sprint Change Highlighter ON  comparing with ${this.sprintDiffData?.baseline?.versionId || 'baseline'}`);
    } else {
      if (compareWrap) compareWrap.style.display = 'none';
      if (legend) legend.style.display = 'none';
      if (actions) actions.style.display = 'none';
      this.sprintDiffData = null;
      this._showToast(`Sprint Change Highlighter OFF`);
    }

    this.render();
  },

  onDiffBaselineChange(baselineVersionId) {
    this.sprintDiffBaselineId = baselineVersionId;
    const activeForm = this.getActiveForm();
    this.sprintDiffData = window.VersionManager.getSprintDiff(activeForm, this.sprintDiffBaselineId);
    this.updateSprintDiffBarUI();
    this.render();
    this._showToast(`Comparing against ${baselineVersionId}`);
  },

  updateSprintDiffBarUI() {
    const activeForm = this.getActiveForm();
    if (!activeForm) return;

    // Active sprint badge
    const badge = document.getElementById('csdbActiveSprintBadge');
    if (badge) {
      badge.textContent = `${activeForm.activeSprint || 'Current'} (${activeForm.activeVersionId || 'v1.0'})`;
    }

    // Toggle status text
    const statusText = document.getElementById('csdbToggleStatusText');
    if (statusText) {
      statusText.innerHTML = `Highlight: <strong>${this.sprintDiffMode ? 'ON' : 'OFF'}</strong>`;
    }

    // Populate baseline options in dropdown (Sprint-first grouping)
    const sel = document.getElementById('csdbBaselineSelect');
    if (sel && window.VersionManager) {
      const sprints = window.VersionManager.getSprintList(activeForm);
      if (sprints.length > 0) {
        sel.innerHTML = sprints.map(s => {
          const sVersions = s.versions || [];
          const isCurrentSprint = s.sprintId === activeForm.activeSprint || s.sprintLabel === activeForm.activeSprint;
          if (sVersions.length <= 1) {
            const v = sVersions[0] || { versionId: s.publishedVersionId || 'v1.0' };
            const isSelected = (v.versionId === (this.sprintDiffBaselineId || this.sprintDiffData?.baseline?.versionId));
            return `<option value="${v.versionId}" ${isSelected ? 'selected' : ''}>${s.sprintLabel || s.sprintId} (${v.versionId})${isCurrentSprint ? ' [Current Sprint]' : ''}</option>`;
          } else {
            const opts = sVersions.map(v => {
              const isPub = v.versionId === s.publishedVersionId;
              const isSelected = (v.versionId === (this.sprintDiffBaselineId || this.sprintDiffData?.baseline?.versionId));
              return `<option value="${v.versionId}" ${isSelected ? 'selected' : ''}>${s.sprintLabel}  ${v.versionId}${isPub ? ' [Published OK]' : ' (Patch)'}</option>`;
            }).join('');
            return `<optgroup label="${s.sprintLabel || s.sprintId}">${opts}</optgroup>`;
          }
        }).join('');
      } else {
        const versions = activeForm.versions || [];
        sel.innerHTML = versions.map(v => {
          const isCurrent = v.versionId === activeForm.activeVersionId;
          const isSelected = (v.versionId === (this.sprintDiffBaselineId || this.sprintDiffData?.baseline?.versionId));
          return `<option value="${v.versionId}" ${isSelected ? 'selected' : ''}>${v.versionId} (${v.sprint || 'Sprint'})${isCurrent ? ' [Active]' : ''}</option>`;
        }).join('');
      }
    }

    // Always compute diff data for legend counts even when visual overlay is toggled off
    if (!this.sprintDiffData && window.VersionManager) {
      this.sprintDiffData = window.VersionManager.getSprintDiff(activeForm, this.sprintDiffBaselineId);
    }

    const summary = this.sprintDiffData?.lookup?.summary || { added: 0, modified: 0, removed: 0, unchanged: 0 };
    const elAdd = document.getElementById('csdbCountAdded');
    const elMod = document.getElementById('csdbCountModified');
    const elRem = document.getElementById('csdbCountRemoved');
    const elUnc = document.getElementById('csdbCountUnchanged');

    if (elAdd) elAdd.textContent = summary.added;
    if (elMod) elMod.textContent = summary.modified;
    if (elRem) elRem.textContent = summary.removed;
    if (elUnc) elUnc.textContent = summary.unchanged;
  },

  copySprintChangelog() {
    const activeForm = this.getActiveForm();
    if (!activeForm || !this.sprintDiffData) return;

    const md = window.VersionManager.generateSprintChangelogMarkdown(activeForm, this.sprintDiffData);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(md).then(() => {
        this._showToast(` Sprint Changelog copied to clipboard! Ready to paste into Jira / Release Notes.`);
      }).catch(() => {
        this._fallbackCopyText(md);
      });
    } else {
      this._fallbackCopyText(md);
    }
  },

  _fallbackCopyText(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    this._showToast(`Sprint Changelog copied to clipboard!`);
  }
});
