/**
 * Cisco MOPs FORM Studio - Canvas Builder Modes & Layout Engine
 * Domain: Multi-variation builder views (Cisco Flat, Modern Studio, Step Wizard), between-row drop strips, slot dropzones, command palette
 * File: js/modules/04-canvas-builder.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
syncCanvasHeader() {
    const titleInput = document.getElementById('formTitleInput');
    const descInput = document.getElementById('formDescInput');
    if (titleInput) titleInput.value = this.formSchema.title || '';
    if (descInput) descInput.value = this.formSchema.description || '';

    // Sync navbar active form pill
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const navIcon = document.getElementById('navActiveFormIcon');
    const navName = document.getElementById('navActiveFormName');
    const topIcon = document.getElementById('topActiveFormIcon');
    const topName = document.getElementById('topActiveFormName');
    const topVerChip = document.getElementById('topActiveVersionChip');
    const statusTitle = document.getElementById('statusFormTitle');

    if (!active || !this._userHasOpenedForm) {
      if (navName) navName.textContent = 'No Form Selected';
      if (topName) topName.textContent = 'No Form Selected';
      if (topVerChip) topVerChip.textContent = '';
      if (statusTitle) statusTitle.textContent = 'Form: None';
      this.syncTopNavFormHeader();
      return;
    }

    if (navIcon && active) navIcon.textContent = active.icon || '';
    if (navName) navName.textContent = (active && (this.formSchema.title || active.label)) || 'No Form Selected';

    // Sync top active form selector elements in enterprise header
    if (topIcon && active) topIcon.textContent = active.icon || '';
    if (topName && active) topName.textContent = this.formSchema.title || active.label || 'Untitled Form';
    if (topVerChip && active) {
      const spId = (this.getSprintForVersion && this.getSprintForVersion(active, active.activeVersionId)) || active.activeSprint;
      topVerChip.textContent = `${spId ? spId + '  ' : ''}${active.activeVersionId || 'v1.0'}`;
    }
    this.syncTopNavFormHeader();

    // Sync status bar form title
    if (statusTitle && active) statusTitle.textContent = `Form: ${this.formSchema.title || active.label || 'Untitled Form'}`;

    // Sync canvas config file pill
    const configPill = document.getElementById('canvasConfigFilePill');
    if (configPill && active) configPill.textContent = active.configFile || 'form.config.ts';

    // Sync canvas form audit trail pill
    const auditPill = document.getElementById('canvasFormAuditPill');
    const auditText = document.getElementById('canvasFormAuditText');
    if (auditText && active) {
      const createdDate = active.createdAt ? new Date(active.createdAt).toLocaleDateString() : '';
      const createdBy = active.createdBy ? ` by ${active.createdBy}` : '';
      const updatedDate = active.updatedAt ? new Date(active.updatedAt).toLocaleDateString() : '';
      const updatedBy = active.updatedBy ? ` by ${active.updatedBy}` : '';

      let auditStr = '';
      if (updatedDate || updatedBy) {
        auditStr = `Modified: ${updatedDate}${updatedBy}`;
      } else if (createdDate || createdBy) {
        auditStr = `Created: ${createdDate}${createdBy}`;
      } else {
        auditStr = 'Default Form Spec';
      }
      auditText.textContent = auditStr;
      if (auditPill) {
        auditPill.title = `Form Created: ${active.createdAt || '--'}${createdBy}\nLast Modified: ${active.updatedAt || '--'}${updatedBy}`;
      }
    }

    // Sync sprint version badge & tab version counter
    if (active && window.VersionManager) {
      window.VersionManager.ensureFormVersions(active);
      const navVerTag = document.getElementById('navVersionTag');
      const tabVerCount = document.getElementById('btnTabVersionCountLabel');
      const navVerHistoryLabel = document.getElementById('navVerHistoryLabel');
      const topVerCountLabel = document.getElementById('topVersionCountLabel');
      const verCount = active.versions?.length || 1;
      if (navVerTag) {
        navVerTag.textContent = `${active.activeVersionId || 'v1.0'} (${active.activeSprint || 'Sprint 25.1'})`;
      }
      if (tabVerCount) {
        tabVerCount.textContent = `Versions (${verCount})`;
      }
      if (topVerCountLabel) {
        topVerCountLabel.textContent = `Versions (${verCount})`;
      }
      if (navVerHistoryLabel) {
        navVerHistoryLabel.textContent = `Versions (${verCount})`;
      }
      if (typeof this.renderNavVersionDropdown === 'function') {
        this.renderNavVersionDropdown();
      }
      if (typeof this.syncVersionSelect === 'function') {
        this.syncVersionSelect();
      }

      // Sync snapshot alert banner
      const snapAlert = document.getElementById('versionSnapshotAlert');
      const vsaTag = document.getElementById('vsaVersionTag');
      if (window.VersionManager.viewingSnapshot && window.VersionManager.snapshotVersionId) {
        if (snapAlert) snapAlert.style.display = 'flex';
        if (vsaTag) vsaTag.textContent = `${window.VersionManager.snapshotVersionId} (${active.activeSprint || ''})`;
      } else {
        if (snapAlert) snapAlert.style.display = 'none';
      }
    }

    this.updateFormHealthStatus();

    // Sync canvas naming rule bar (Project Name Live Preview)
    if (typeof this.syncCanvasNamingRuleBar === 'function') {
      this.syncCanvasNamingRuleBar();
    }
  },

  _flashSaveButtonSuccess() {
    const btn = document.getElementById('btnNavSaveForm');
    const topBtn = document.getElementById('btnTopSaveForm');
    const dot = document.getElementById('savePulseDot');
    const dotTop = document.getElementById('savePulseDotTop');
    const label = document.getElementById('btnNavSaveLabel');
    const topLabel = document.getElementById('btnTopSaveLabel');
    const syncDot = document.getElementById('topSyncPulse');
    const syncText = document.getElementById('topSyncLabel');

    if (btn) {
      btn.style.background = '#10b981';
      btn.style.borderColor = '#059669';
    }
    if (topBtn) {
      topBtn.style.background = '#10b981';
      topBtn.style.borderColor = '#059669';
    }
    if (label) label.textContent = 'Saved!';
    if (topLabel) topLabel.textContent = 'Saved!';
    if (dot) dot.classList.add('saving');
    if (dotTop) dotTop.classList.add('saving');
    if (syncDot) syncDot.classList.remove('unsaved');
    if (syncText) syncText.textContent = 'Saved just now';

    setTimeout(() => {
      if (btn) {
        btn.style.background = '';
        btn.style.borderColor = '';
      }
      if (topBtn) {
        topBtn.style.background = '';
        topBtn.style.borderColor = '';
      }
      if (label) label.textContent = 'Save Form';
      if (topLabel) topLabel.textContent = 'Save Form';
      if (dot) dot.classList.remove('saving');
      if (dotTop) dotTop.classList.remove('saving');
    }, 2000);
  },

  updateFormHealthStatus() {
    let totalFields = 0;
    let mappedWfFields = 0;
    let totalRules = 0;

    (this.formSchema?.sections || []).forEach(sec => {
      (sec.fields || []).forEach(f => {
        totalFields++;
        if (f.workfrontId || f.wfId || f.workfrontFieldName || f.wfFieldName) {
          mappedWfFields++;
        }
        if (f.rules && f.rules.length > 0) {
          totalRules += f.rules.length;
        }
        if (f.dateRules && f.dateRules.enabled) {
          totalRules++;
        }
      });
    });

    const wfHealthEl = document.getElementById('statusWfHealth');
    if (wfHealthEl) {
      if (totalFields === 0) {
        wfHealthEl.textContent = 'OK WF: Ready';
        wfHealthEl.className = 'status-health-badge';
      } else if (mappedWfFields === totalFields) {
        wfHealthEl.textContent = `OK WF: ${mappedWfFields}/${totalFields} (100%)`;
        wfHealthEl.className = 'status-health-badge';
      } else {
        const pct = Math.round((mappedWfFields / totalFields) * 100);
        wfHealthEl.textContent = ` WF: ${mappedWfFields}/${totalFields} (${pct}%)`;
        wfHealthEl.className = 'status-health-badge info';
      }
    }

    const rulesEl = document.getElementById('statusRulesCount');
    if (rulesEl) {
      rulesEl.textContent = ` ${totalRules} Active Rule${totalRules === 1 ? '' : 's'}`;
    }

    const secCountEl = document.getElementById('statusSectionsCount');
    const fldCountEl = document.getElementById('statusFieldsCount');
    const secCount = this.formSchema?.sections?.length || 0;
    if (secCountEl) secCountEl.textContent = `${secCount} Section${secCount === 1 ? '' : 's'}`;
    if (fldCountEl) fldCountEl.textContent = `${totalFields} Field${totalFields === 1 ? '' : 's'}`;

    const modeBadge = document.getElementById('statusMode');
    if (modeBadge) {
      if (this.activeMode === 'review') {
        const vNames = { 1: 'Cisco Brand', 2: 'Modern Studio', 3: 'Step Wizard' };
        modeBadge.textContent = `Mode: Simulator (${vNames[this.livePreviewVariant] || 'Cisco Brand'})`;
      } else {
        const vNames = { 1: 'Cisco Brand', 2: 'Modern Studio', 3: 'Step Wizard' };
        modeBadge.textContent = `Mode: Builder (${vNames[this.builderVariant] || 'Cisco Brand'})`;
      }
    }
  },

  setCanvasViewport(size) {
    const canvas = document.querySelector('.canvas-container');
    if (!canvas) return;
    document.querySelectorAll('.canvas-vp-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-vp') === String(size));
    });

    if (size === 'full') {
      canvas.style.maxWidth = '100%';
    } else if (size === '1280' || size === 'desktop') {
      canvas.style.maxWidth = '1280px';
    } else if (size === '768' || size === 'tablet') {
      canvas.style.maxWidth = '768px';
    } else if (size === '390' || size === 'mobile') {
      canvas.style.maxWidth = '390px';
    }
    this._showToast(`Viewport preview set to: ${size}`);
  },

  // --------------------------------------------------------------------------
  // Command Palette (Ctrl+K)
  // --------------------------------------------------------------------------
  openCommandPalette() {
    const modal = document.getElementById('modalCommandPalette');
    const input = document.getElementById('inputCommandPalette');
    if (!modal) return;
    modal.classList.add('open');
    if (input) {
      input.value = '';
      setTimeout(() => input.focus(), 50);
    }
    this.renderCommandPalette('');
  },

  closeCommandPalette() {
    const modal = document.getElementById('modalCommandPalette');
    if (modal) modal.classList.remove('open');
  },

  renderCommandPalette(query = '') {
    const container = document.getElementById('commandPaletteResults');
    if (!container) return;
    const q = (query || '').toLowerCase().trim();

    const sections = [];

    // 1. Studio Actions
    const allActions = [
      { id: 'act_save', label: 'Save Working Copy', icon: '', badge: 'Ctrl+S', run: () => this.saveCurrentVersion() },
      { id: 'act_version', label: 'Freeze Sprint Milestone Version', icon: '', badge: 'Milestone', run: () => this.openSaveNewVersionModal() },
      { id: 'act_sim', label: 'Switch to Runtime Simulator', icon: '', badge: 'Ctrl+P', run: () => this.switchMode('review') },
      { id: 'act_bld', label: 'Switch to Drag & Drop Builder', icon: '', badge: 'Mode', run: () => this.switchMode('builder') },
      { id: 'act_diff', label: 'Inspect Sprint History & AST Visual Diff', icon: '', badge: 'Time-Machine', run: () => this.openVersionHistoryModal('diff') },
      { id: 'act_mops', label: 'Export MOPs Angular Config (TypeScript)', icon: '', badge: 'MOPs Config', run: () => this.openExportModal() },
      { id: 'act_html', label: 'Share Standalone Locked HTML Review', icon: '', badge: 'Stakeholder', run: () => this.downloadStandaloneHtml() },
      { id: 'act_gallery', label: 'Browse 15 Forms in Gallery', icon: '', badge: 'Catalog', run: () => this.openFormsGallery() },
      { id: 'act_var1', label: 'Set View: Variation 1 (MOPs Cisco Brand)', icon: '', badge: 'Flat', run: () => this.switchBuilderVariant(1) },
      { id: 'act_var2', label: 'Set View: Variation 2 (Modern Studio Glassmorphism)', icon: '', badge: 'Glass', run: () => this.switchBuilderVariant(2) },
      { id: 'act_var3', label: 'Set View: Variation 3 (Guided Step Wizard)', icon: '', badge: 'Wizard', run: () => this.switchBuilderVariant(3) }
    ];

    const matchedActions = allActions.filter(a => !q || a.label.toLowerCase().includes(q) || (a.badge && a.badge.toLowerCase().includes(q)));
    if (matchedActions.length > 0) {
      sections.push({ title: 'Studio Actions', items: matchedActions });
    }

    // 2. Forms (All 15)
    const matchedForms = (this.allForms || [])
      .filter(f => !q || (f.label || '').toLowerCase().includes(q) || (f.schema?.title || '').toLowerCase().includes(q))
      .map(f => ({
        id: 'form_' + f.id,
        label: f.schema?.title || f.label || 'Intake Form',
        icon: f.icon || '',
        badge: f.activeVersionId || 'v1.0',
        run: () => {
          this.switchActiveForm(f.id);
          this.closeCommandPalette();
          this._showToast(`Switched to: ${f.schema?.title || f.label}`);
        }
      }));
    if (matchedForms.length > 0) {
      sections.push({ title: 'Intake Forms (15 Channels)', items: matchedForms });
    }

    // 3. Fields in Active Form
    const activeFields = [];
    (this.formSchema?.sections || []).forEach((sec, sIdx) => {
      (sec.fields || []).forEach((fld, fIdx) => {
        const lbl = fld.label || fld.workfrontLabel || fld.wfLabel || fld.placeholder || 'Unnamed Field';
        const key = fld.workfrontFieldName || fld.wfFieldName || fld.key || '';
        if (!q || lbl.toLowerCase().includes(q) || key.toLowerCase().includes(q)) {
          activeFields.push({
            id: `fld_${sIdx}_${fIdx}`,
            label: lbl,
            icon: '',
            badge: fld.type || 'text',
            sub: `${sec.title || 'Section'}  ${key}`,
            run: () => {
              this.closeCommandPalette();
              if (this.activeMode !== 'builder') this.switchMode('builder');
              this.selectField(sIdx, fIdx);
              setTimeout(() => {
                const el = document.getElementById(`fieldCard_${sIdx}_${fIdx}`);
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  el.style.outline = '2px solid #005fb8';
                  el.style.boxShadow = '0 0 0 4px rgba(0, 95, 184, 0.2)';
                  setTimeout(() => { el.style.outline = ''; el.style.boxShadow = ''; }, 2000);
                }
              }, 150);
            }
          });
        }
      });
    });
    if (activeFields.length > 0) {
      sections.push({ title: `Fields in Active Form (${activeFields.length})`, items: activeFields });
    }

    if (sections.length === 0) {
      container.innerHTML = `<div style="padding: 24px; text-align: center; color: #64748b; font-size: 13px;">No matching results found for "${query}"</div>`;
      return;
    }

    let html = '';
    let itemCounter = 0;
    sections.forEach(sec => {
      html += `<div class="cp-group-title">${sec.title}</div>`;
      sec.items.forEach(item => {
        const isFirst = itemCounter === 0;
        html += `
          <div class="cp-item ${isFirst ? 'selected' : ''}" data-cp-index="${itemCounter}" onclick="App._runCpAction('${item.id}')">
            <span class="cp-item-icon">${item.icon}</span>
            <div style="flex:1; display:flex; flex-direction:column; line-height:1.2;">
              <span class="cp-item-label">${item.label}</span>
              ${item.sub ? `<span style="font-size:11px; color:#64748b;">${item.sub}</span>` : ''}
            </div>
            ${item.badge ? `<span class="cp-item-badge">${item.badge}</span>` : ''}
          </div>
        `;
        itemCounter++;
      });
    });

    container.innerHTML = html;
    this._cpItems = sections.flatMap(s => s.items);
    this._cpSelectedIndex = 0;
  },

  _runCpAction(id) {
    const item = (this._cpItems || []).find(i => i.id === id);
    if (item && typeof item.run === 'function') {
      item.run();
      this.closeCommandPalette();
    }
  },

switchBuilderVariant(variant) {
    this.builderVariant = variant;
    this.livePreviewVariant = variant;

    // Sync active button in builder toolbar
    document.querySelectorAll('#builderVariationSwitcher .rev-var-btn').forEach(btn => {
      const v = parseInt(btn.getAttribute('data-variant'), 10);
      if (v === variant) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    // Sync active button in review banner
    document.querySelectorAll('#reviewVariationSwitcher .rev-var-btn').forEach(btn => {
      const v = parseInt(btn.getAttribute('data-variant'), 10);
      if (v === variant) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    const hint = document.getElementById('builderVarHintText');
    if (hint) {
      if (variant === 1) hint.textContent = ' Default: Cisco MOPs flat production layout';
      else if (variant === 2) hint.textContent = ' Modern Studio: Glassmorphism cards layout';
      else if (variant === 3) hint.textContent = ' Step Wizard: Multi-step guided sections';
    }

    this.render();
    if (typeof showToast === 'function') {
      const names = { 1: 'MOPs Cisco Brand', 2: 'Modern Studio', 3: 'Step Wizard' };
      showToast(`Builder view switched to Variation ${variant}: ${names[variant]}`);
    }
  },

toggleFieldWidth(sIdx, fIdx) {
    const sec = this.formSchema?.sections?.[sIdx];
    const field = sec?.fields?.[fIdx];
    if (!field) return;
    field.col = (field.col === 'col-lg-12') ? 'col-lg-6' : 'col-lg-12';
    this.saveFormToStorage();
    this.render();
  },

  setWizardStep(idx) {
    this.wizardActiveStep = idx;
    this.render();
  },

  prevWizardStep() {
    if (this.wizardActiveStep > 0) {
      this.wizardActiveStep--;
      this.render();
    }
  },

  nextWizardStep() {
    const total = (this.formSchema?.sections || []).length;
    if (this.wizardActiveStep < total - 1) {
      this.wizardActiveStep++;
      this.render();
    }
  },

  toggleWizardViewAll() {
    this.wizardViewAll = !this.wizardViewAll;
    this.render();
  },

renderBuilderMode(canvasRoot) {
    const v = this.builderVariant || 1;

    // Sync button active classes in builderVariationSwitcher
    document.querySelectorAll('#builderVariationSwitcher .rev-var-btn').forEach(btn => {
      const bVar = parseInt(btn.getAttribute('data-variant'), 10);
      if (bVar === v) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    const hint = document.getElementById('builderVarHintText');
    if (hint) {
      if (v === 1) hint.textContent = ' Default: Cisco MOPs flat production layout';
      else if (v === 2) hint.textContent = ' Modern Studio: Glassmorphism cards layout';
      else if (v === 3) hint.textContent = ' Step Wizard: Multi-step guided sections';
    }

    if (v === 1) {
      this.renderCiscoBuilderMode(canvasRoot);
    } else if (v === 3) {
      this.renderWizardBuilderMode(canvasRoot);
    } else {
      this.renderStudioBuilderMode(canvasRoot);
    }
  },

  // ------------------------------------------------------------------------
  // VARIATION 1: MOPs Cisco Brand (Official Flat Enterprise Builder View)
  // ------------------------------------------------------------------------
  _renderEmptySpacerCardHtml(sIdx, fIdx, colNum) {
    return `
      <div class="canvas-field-card cisco-bld-field-card canvas-empty-spacer-card" data-sec="${sIdx}" data-field="${fIdx}" data-field-type="empty_field" title="Empty Field (Blank Space) — hidden on live form and not droppable">
        <div class="cisco-bld-label-row" style="margin-bottom:4px;">
          <label class="cisco-bld-label" style="color:#64748b;font-weight:600;font-size:12px;">
            <span>⬜ Empty Field (Blank Space)</span>
          </label>
          <div class="cisco-bld-tools" style="opacity:1;">
            <button class="cisco-tool-btn" title="Toggle Width (Half / Full)" onclick="event.stopPropagation(); App.toggleFieldWidth(${sIdx}, ${fIdx})">${colNum === '12' ? 'Full' : 'Half'}</button>
            <button class="cisco-tool-btn cisco-tool-del" title="Delete Empty Field" onclick="event.stopPropagation(); App.deleteField(${sIdx}, ${fIdx})"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
        </div>
        <div class="empty-spacer-hint">Creates blank space in this row · Hidden in Simulator &amp; Live Form · Drag-drop disabled</div>
      </div>
    `;
  },

  renderCiscoBuilderMode(canvasRoot) {
    canvasRoot = canvasRoot || document.getElementById('canvasSectionsRoot');
    if (!canvasRoot) return;

    const canvasContainer = document.querySelector('.canvas-container');
    if (canvasContainer) {
      canvasContainer.classList.remove('builder-variant-studio', 'builder-variant-wizard');
      canvasContainer.classList.add('builder-variant-cisco');
    }

    // Sync Form Title in Top Navbar
    const topNavTitle = document.getElementById('topNavFormTitle');
    if (topNavTitle) {
      const active = this.getActiveForm();
      topNavTitle.textContent = this.formSchema.title || active?.label || 'Untitled Form';
    }

    // Sync Dynamic Workfront Field Counter
    const counterEl = document.getElementById('wfFieldCounterText');
    if (counterEl) {
      let fieldCount = 0;
      (this.formSchema.sections || []).forEach(s => fieldCount += (s.fields || []).length);
      counterEl.textContent = `${fieldCount}/500 fields used`;
    }

    // Top Cisco Form Header Card (inline-editable title & description)
    const ciscoCleanTitle = (this.formSchema.title || '').trim();
    const ciscoCleanDesc = (this.formSchema.description || '').trim();

    // Workfront Dynamic Routing Summary Card on Canvas
    const routing = this.formSchema.workfrontRouting || {
      defaultTemplateId: 'TEMPLATE_DART_WEB_PAGE',
      defaultTemplateLabel: 'Standard Web Page Template',
      customFormId: 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS',
      customFormLabel: 'Global Project Details Form',
      defaultCategoryIds: ['CATEGORY_DART_GLOBAL_PROJECT_DETAILS'],
      templateRules: [],
      categoryRules: []
    };
    const tCount = (routing.templateRules || []).length;
    const defTpl = routing.defaultTemplateId || 'TEMPLATE_DART_WEB_PAGE';
    const cfId = routing.customFormId || (Array.isArray(routing.defaultCategoryIds) && routing.defaultCategoryIds[0]) || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const isLocked = !!(this.formSchema && this.formSchema.readOnly);

    const topCard = document.createElement('div');
    topCard.className = 'cisco-bld-topbar';
    topCard.innerHTML = `
      <div class="cisco-bld-title-group" style="margin-bottom: 8px;">
        <div style="display:flex; align-items:center; gap:6px; margin-bottom:3px; position:relative;">
          <span style="font-size:14px; flex-shrink:0; line-height:1;" title="Form"></span>
          <input type="text" class="cisco-bld-title-edit" value="${ciscoCleanTitle.replace(/"/g, '&quot;')}"
            placeholder="Enter Form Title"
            title="Click to edit form title"
            autocomplete="off" spellcheck="false">
          <button type="button" class="cisco-bld-edit-pill" title="Click to rename form">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            Edit Title
          </button>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <span style="font-size:12px; color:#94a3b8; flex-shrink:0; line-height:1;" title="Description"></span>
          <input type="text" class="cisco-bld-desc-edit" value="${ciscoCleanDesc.replace(/"/g, '&quot;')}"
            placeholder="Add a brief description or purpose for this form"
            title="Click to edit form description"
            autocomplete="off" spellcheck="false">
        </div>
      </div>

      <!-- Workfront Dynamic Routing Banner (Compact & Integrated Ribbon) -->
      <div class="cisco-canvas-routing-bar">
        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; width:100%;">
          <div style="display:flex; align-items:center; gap:5px;">
            <span style="font-size:13px; line-height:1;"></span>
            <span style="font-size:12px; font-weight:700; color:#0f172a;">Workfront Dynamic Routing</span>
          </div>
          <span style="font-size:10.5px; font-weight:600; ${tCount > 0 ? 'background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd;' : 'background:#f1f5f9; color:#64748b; border:1px solid #cbd5e1;'} padding:1px 7px; border-radius:10px;">
            ${tCount > 0 ? `${tCount} Rule${tCount > 1 ? 's' : ''}` : 'Default Template'}
          </span>
          <div style="font-size:11px; color:#64748b; display:flex; align-items:center; gap:6px;">
            <span>Template: <code style="color:#005fb8; font-weight:700; font-size:10.5px; background:#eff6ff; padding:1px 5px; border-radius:3px;">${defTpl}</code></span>
            <span>&bull;</span>
            <span>Custom Form: <code style="color:#15803d; font-weight:700; font-size:10.5px; background:#f0fdf4; padding:1px 5px; border-radius:3px;">${cfId}</code></span>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:8px; width:100%; padding-top:4px; border-top:1px dashed #e2e8f0; margin-top:2px;">
          <button type="button" class="btn btn-outline btn-xs" onclick="App.openWorkfrontRoutingModal()" style="font-size:11px; font-weight:600; padding:4px 10px; display:inline-flex; align-items:center; gap:4px; border-color:#005fb8; color:#005fb8; background:#fff; cursor:pointer;" title="Configure conditional routing rules">
            <span> ${isLocked ? 'Inspect Routing' : 'Configure Routing'}</span>
          </button>
          <button type="button" class="btn btn-outline btn-xs" onclick="App.openWorkfrontFieldMappingModal()" style="font-size:11px; font-weight:600; padding:4px 10px; display:inline-flex; align-items:center; gap:4px; border-color:#16a34a; color:#15803d; background:#fff; cursor:pointer;" title="Map intake fields to Workfront API custom parameter names (DE:...)">
            <span> Map API Fields</span>
          </button>
        </div>
      </div>
    `;
    canvasRoot.appendChild(topCard);

    // Wire up inline editing  sync to hidden DOM inputs + schema + tree
    const titleEdit = topCard.querySelector('.cisco-bld-title-edit');
    const descEdit = topCard.querySelector('.cisco-bld-desc-edit');
    const editPill = topCard.querySelector('.cisco-bld-edit-pill');
    const hiddenTitle = document.getElementById('formTitleInput');
    const hiddenDesc = document.getElementById('formDescInput');

    if (editPill && titleEdit) {
      editPill.addEventListener('click', (e) => {
        e.stopPropagation();
        titleEdit.focus();
        titleEdit.select();
      });
    }

    let prevTitleVal = titleEdit.value.trim();
    titleEdit.addEventListener('focus', () => {
      prevTitleVal = titleEdit.value.trim();
    });

    const commitInlineTitle = () => {
      const val = titleEdit.value.trim();
      const active = this.getActiveForm();
      if (!val) {
        this.showValidationError('Version Title Required', 'Version title cannot be empty.');
        titleEdit.value = prevTitleVal || this.formSchema?.title || '';
        return;
      }
      if (val === prevTitleVal) {
        return; // No change
      }

      prevTitleVal = val;

      // Only update the CURRENT active version's title & schema  do NOT touch main form label or other versions
      this.formSchema.title = val;
      if (hiddenTitle) hiddenTitle.value = val;

      if (active) {
        let currentSprintId = active.activeSprintId || '';

        // Update active version inside its sprint
        if (active.sprints) {
          active.sprints.forEach(sp => {
            const sv = (sp.versions || []).find(x => x.versionId === active.activeVersionId);
            if (sv) {
              sv.formTitle = val;
              sv.title = val;
              if (sv.schema) sv.schema.title = val;
              currentSprintId = sp.sprintId;
            }
          });
        }
        // Also update flat versions array if present
        if (active.versions) {
          const v = active.versions.find(x => x.versionId === active.activeVersionId);
          if (v) {
            v.formTitle = val;
            v.title = val;
            if (v.schema) v.schema.title = val;
          }
        }
        if (!currentSprintId) currentSprintId = active.activeSprint || '';

        // Save via API (version-scoped  does NOT rename the form)
        window.WorkspaceRepo?.saveVersionTitle?.(active.id, currentSprintId, active.activeVersionId, val);
      }

      this.saveFormToStorage();
      this.syncCanvasHeader();
      this.renderFormsTree();
      this._showToast(`Version title updated to "${val}"`);
    };

    titleEdit.addEventListener('input', (e) => {
      const val = e.target.value.trim();
      if (!val) return;
      this.formSchema.title = val;
      if (hiddenTitle) hiddenTitle.value = val;
      const active = this.getActiveForm();
      if (active) {
        if (active.sprints) {
          active.sprints.forEach(sp => {
            const sv = (sp.versions || []).find(x => x.versionId === active.activeVersionId);
            if (sv) {
              sv.formTitle = val;
              sv.title = val;
              if (sv.schema) sv.schema.title = val;
            }
          });
        }
        if (active.versions) {
          const v = active.versions.find(x => x.versionId === active.activeVersionId);
          if (v) {
            v.formTitle = val;
            v.title = val;
            if (v.schema) v.schema.title = val;
          }
        }
      }
      // Instant live reflection in the tree for the active version link!
      document.querySelectorAll('.is-active-form-link .ft-form-name-link').forEach(link => {
        link.textContent = (active?.icon ? active.icon + ' ' : '') + val;
      });
      const topTitle = document.getElementById('topNavFormTitle');
      if (topTitle) topTitle.textContent = val;
      const topName = document.getElementById('topActiveFormName');
      if (topName) topName.textContent = val;
    });

    titleEdit.addEventListener('change', commitInlineTitle);
    titleEdit.addEventListener('blur', commitInlineTitle);
    titleEdit.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        titleEdit.blur();
      }
    });

    descEdit.addEventListener('input', (e) => {
      const val = e.target.value;
      this.formSchema.description = val;
      if (hiddenDesc) hiddenDesc.value = val;
      const active = this.getActiveForm();
      if (active) {
        if (active.schema) active.schema.description = val;
        if (active.versions) {
          const v = active.versions.find(x => x.versionId === active.activeVersionId);
          if (v && v.schema) v.schema.description = val;
        }
        if (active.sprints) {
          active.sprints.forEach(sp => {
            const sv = (sp.versions || []).find(x => x.versionId === active.activeVersionId);
            if (sv && sv.schema) sv.schema.description = val;
          });
        }
      }
      this.saveFormToStorage();
    });

    // Sections
    if ((this.formSchema.sections || []).length > 0 && window.DragDropHandler?.createBetweenSectionStrip) {
      canvasRoot.appendChild(window.DragDropHandler.createBetweenSectionStrip(0));
    }
    (this.formSchema.sections || []).forEach((sec, sIdx) => {
      const secHasCondition = !!(sec.condition && sec.condition !== true && (Array.isArray(sec.condition) ? sec.condition.length > 0 : true));
      const secBlock = document.createElement('div');
      secBlock.className = 'cisco-bld-section' + (secHasCondition ? ' section-has-condition' : '');
      secBlock.setAttribute('data-section-index', sIdx);

      secBlock.innerHTML = `
        <div class="cisco-bld-sec-header">
          <div class="cisco-bld-sec-title-wrap">
            <span class="section-drag-handle" title="Drag to reorder section"><svg width="12" height="16" viewBox="0 0 12 16" fill="none"><circle cx="4" cy="4" r="1.5" fill="#94a3b8"/><circle cx="4" cy="8" r="1.5" fill="#94a3b8"/><circle cx="4" cy="12" r="1.5" fill="#94a3b8"/><circle cx="8" cy="4" r="1.5" fill="#94a3b8"/><circle cx="8" cy="8" r="1.5" fill="#94a3b8"/><circle cx="8" cy="12" r="1.5" fill="#94a3b8"/></svg></span>
            <input type="text" class="cisco-bld-sec-title-input" value="${sec.title || ''}" placeholder="Section Title..." data-sec-idx="${sIdx}" title="Click to rename section">
            <span style="font-size: 11px; color: #64748b; font-weight: 600; white-space: nowrap; flex-shrink: 0;">${(sec.fields || []).length} fields</span>
            ${(sec.condition && sec.condition !== true && (Array.isArray(sec.condition) ? sec.condition.length > 0 : true)) ? '<span class="badge-rule" style="font-size:10px;padding:1px 6px; white-space:nowrap; flex-shrink:0;" title="This section has display conditions"> Conditional</span>' : ''}
          </div>
          <div class="cisco-bld-sec-actions">
            <button type="button" class="btn btn-outline btn-xs sec-logic-btn ${secHasCondition ? 'sec-logic-active' : ''}" title="Configure Section Display Logic" onclick="event.stopPropagation(); App.openSectionLogicModal(${sIdx})" style="padding:2px 7px; font-size:11px;">
              <span class="icon-svg"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>
              ${secHasCondition ? ' Active' : ' Logic'}
            </button>
            <button class="btn btn-outline btn-xs" title="Quickly add a text field" onclick="App.addQuickField(${sIdx}, 'text')" style="padding:2px 7px; font-size:11px;"><span class="icon-svg"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></span> Text</button>
            <button class="btn btn-outline btn-xs" title="Quickly add a dropdown" onclick="App.addQuickField(${sIdx}, 'select')" style="padding:2px 7px; font-size:11px;"><span class="icon-svg"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></span> Dropdown</button>
            <button class="btn btn-danger btn-xs" title="Delete Section" onclick="App.deleteSection(${sIdx})" style="padding:2px 6px;"><span class="icon-svg"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></span></button>
          </div>
        </div>
        <div class="section-body" style="padding: 0;">
          ${secHasCondition ? `
            <div class="sec-cond-banner" style="margin: 8px 12px 10px 12px; cursor: pointer;" onclick="App.openSectionLogicModal(${sIdx})" title="Click to edit section display rules">
              <span style="font-size: 13px;"></span>
              <span><strong>Conditional Section:</strong> Displayed when <strong>${sec.conditionType || 'AND'}</strong> of ${(Array.isArray(sec.condition) ? sec.condition : [sec.condition]).map(c => `<code>${c.field || 'field'} ${c.comparison || '=='} "${c.value !== undefined ? c.value : ''}"</code>`).join(` <em>${sec.conditionType || 'AND'}</em> `)}</span>
            </div>
          ` : ''}
          <div class="section-top-insertion-zone" data-sec="${sIdx}" title="Drop here to insert at Position 1 (Top of Section)"></div>
          <div class="mops-grid-row" id="section_grid_${sIdx}"></div>
        </div>
      `;
      canvasRoot.appendChild(secBlock);

      // Bind Section Title
      const titleInput = secBlock.querySelector('.cisco-bld-sec-title-input');
      titleInput?.addEventListener('input', (e) => {
        sec.title = e.target.value;
        this.saveFormToStorage();
      });

      // Render Field Cards
      const grid = secBlock.querySelector('#section_grid_' + sIdx);
      if (!sec.fields || sec.fields.length === 0) {
        grid.innerHTML = `
          <div class="col-12">
            <div class="section-dropzone-empty" data-drop-sec="${sIdx}">
              <div class="dropzone-empty-icon"><svg width=\"28\" height=\"28\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"opacity:0.4;color:#94a3b8\"><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><polyline points=\"17 8 12 3 7 8\"/><line x1=\"12\" y1=\"3\" x2=\"12\" y2=\"15\"/></svg></div>
              <div class="dropzone-empty-title">This section is currently empty</div>
              <div class="dropzone-empty-desc">Drag fields from the left palette, or quickly add:</div>
              <div class="dropzone-quick-actions">
                <button type="button" class="btn btn-primary btn-sm" onclick="App.addQuickField(${sIdx}, 'text')"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add Text Field</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="App.addQuickField(${sIdx}, 'select')"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add Dropdown</button>
              </div>
            </div>
          </div>
        `;
      } else {
        let currentRowCols = 0;
        sec.fields.forEach((field, fIdx) => {
          const colDiv = document.createElement('div');
          colDiv.className = 'mops-grid-col ' + (field.col || 'col-lg-6');

          const isSelected = this.selectedFieldLoc &&
            this.selectedFieldLoc.sectionIndex === sIdx &&
            this.selectedFieldLoc.fieldIndex === fIdx;

          const hasRules = (field.advancedLogic?.display?.groups?.some(g => g.rules?.length > 0)) || (field.condition && field.condition !== true);
          const colNum = (field.col || 'col-lg-6').replace('col-lg-', '');

          let diffCardClass = '';
          let diffBadgeHtml = '';
          let diffChangesHtml = '';

          if (this.sprintDiffMode && this.sprintDiffData?.lookup) {
            const fKey = field.id || field.formData || field.wfFieldName;
            if (this.sprintDiffData.lookup.added.has(fKey) || (field.formData && this.sprintDiffData.lookup.added.has(field.formData))) {
              diffCardClass = 'diff-card-added';
              diffBadgeHtml = '<span class="diff-tag diff-tag-added" title="Field added in this sprint release"> + Added</span>';
            } else if (this.sprintDiffData.lookup.modified.has(fKey) || (field.formData && this.sprintDiffData.lookup.modified.has(field.formData))) {
              const modInfo = this.sprintDiffData.lookup.modified.get(fKey) || this.sprintDiffData.lookup.modified.get(field.formData);
              diffCardClass = 'diff-card-modified';
              const changeCount = (modInfo?.changes || []).length;
              diffBadgeHtml = `<span class="diff-tag diff-tag-modified" title="Field attributes updated in this sprint">  Modified (${changeCount})</span>`;
              const changesList = (modInfo?.changes || []).map(c => `<span> <strong>${c.prop}:</strong> <span class="diff-del">${c.from}</span>  <span class="diff-ins">${c.to}</span></span>`).join('<br>');
              diffChangesHtml = `<div class="diff-inline-changes" title="Changes made in this sprint release">${changesList}</div>`;
            }
          }

          if (field.type === 'empty_field') {
            colDiv.innerHTML = this._renderEmptySpacerCardHtml(sIdx, fIdx, colNum);
          } else {
            colDiv.innerHTML = `
              <div class="canvas-field-card cisco-bld-field-card ${isSelected ? 'selected' : ''} ${diffCardClass}" data-sec="${sIdx}" data-field="${fIdx}">
              <div class="cisco-bld-label-row">
                <label class="cisco-bld-label">
                  ${field.required ? '<span class="cisco-req-star">*</span>' : ''}
                  <span>${field.label || field.wfLabel || field.formData || 'Untitled Field'}</span>
                </label>
                <div class="cisco-bld-tools">
                  ${diffBadgeHtml}
                  ${field.tooltip ? `<span class="field-tooltip-icon" title="${field.tooltip.replace(/"/g, '&quot;')}" onclick="event.stopPropagation()"><span class="field-tooltip-popup">${field.tooltip}</span></span>` : ''}
                  ${hasRules ? '<span class="badge-rule" style="font-size: 10px; padding: 1px 5px;" title="Has conditional logic rules"> Logic</span>' : ''}
                  <button class="cisco-tool-btn" title="Open Advanced Logic Studio" onclick="event.stopPropagation(); App.openAdvancedLogicModal(${sIdx}, ${fIdx})"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></button>
                  <button class="cisco-tool-btn" title="Toggle Width (Half / Full)" onclick="event.stopPropagation(); App.toggleFieldWidth(${sIdx}, ${fIdx})">${colNum === '12' ? 'Full' : 'Half'}</button>
                  <button class="cisco-tool-btn cisco-tool-del" title="Delete Field" onclick="event.stopPropagation(); App.deleteField(${sIdx}, ${fIdx})"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
              </div>

              <div class="cisco-bld-widget">
                ${this.renderWidgetPlaceholder(field)}
              </div>
              ${diffChangesHtml}
              ${field.baNotes ? `<div style="font-size: 11px; color: #b45309; background: #fef3c7; border-radius: 3px; padding: 2px 6px; margin-top: 4px;"> ${field.baNotes.substring(0, 45)}</div>` : ''}

              <div class="cisco-bld-meta">
                <span>${field.formData || ''}</span>
                ${field.disabled ? '<span style="color:#b91c1c; background:#fee2e2; font-weight:700; padding:1px 6px; border-radius:3px; font-size:10px;">INACTIVE (DISABLED)</span>' : ''}
                ${field.hidden ? '<span style="color:#6b7280; background:#f3f4f6; font-weight:700; padding:1px 6px; border-radius:3px; font-size:10px;">HIDDEN DEFAULT</span>' : ''}
                <span style="text-transform: uppercase; font-size: 9.5px; background: #f1f5f9; padding: 1px 5px; border-radius: 3px; font-weight: 600;">${field.type || 'text'}</span>
              </div>
            </div>
          `;
          }

          grid.appendChild(colDiv);

          // Track column accumulation for 12-column grid row
          const thisFieldCols = (field.col === 'col-lg-12' || field.col === 'Full') ? 12 : 6;
          currentRowCols += thisFieldCols;

          // --- Empty Half-Column Slot Dropzone (Builder 1) ---
          // A half-width field needs an empty slot on the right ONLY if it is currently alone
          // in its row (currentRowCols % 12 === 6) AND the next item starts a new row
          // (i.e. next field is full-width, or this is the last field in the section).
          const nextField = sec.fields[fIdx + 1];
          const nextFieldCols = nextField ? ((nextField.col === 'col-lg-12' || nextField.col === 'Full') ? 12 : 6) : null;
          const needsEmptySlot = (currentRowCols % 12 === 6) && (nextFieldCols === 12 || !nextField);
          if (needsEmptySlot) {
            currentRowCols += 6; // Completes the row to 12 cols
            const slotCol = document.createElement('div');
            slotCol.className = 'mops-grid-col col-lg-6 grid-empty-slot-col';
            slotCol.innerHTML = `
              <div class="grid-empty-slot-dropzone" data-sec="${sIdx}" data-insert-idx="${fIdx + 1}" onclick="App.openQuickWfFieldPicker(event, ${sIdx}, ${fIdx + 1})" style="cursor:pointer;" title="Click to pick a WF Field or drop a field here">
                <span class="slot-icon"></span>
                <span class="slot-label">+ Click or drop field here</span>
                <span class="slot-sublabel">Place next to ${field.label || field.wfLabel || 'field'}</span>
              </div>
            `;
            grid.appendChild(slotCol);
          }

          // --- Between-Row Insert Strip (Builder 1) ---
          // Show a full-width drop strip AFTER each completed row boundary so the user
          // can clearly drop a field BELOW any row (especially full-width fields).
          const rowEndsHere = (currentRowCols % 12 === 0);
          if (rowEndsHere) {
            currentRowCols = 0;
            const stripWrapper = document.createElement('div');
            stripWrapper.className = 'mops-grid-col col-lg-12';
            stripWrapper.style.padding = '0 8px';
            stripWrapper.innerHTML = `
              <div class="between-row-drop-strip" data-sec="${sIdx}" data-insert-idx="${fIdx + 1}">
                <span class="between-row-strip-label"> Drop here to insert below this row</span>
              </div>
            `;
            grid.appendChild(stripWrapper);
          }

          // Card Click -> Open Drawer (skip for empty_field spacer)
          if (field.type !== 'empty_field') {
            colDiv.querySelector('.cisco-bld-field-card')?.addEventListener('click', () => {
              this.openFieldSettings(sIdx, fIdx);
            });
          }
        });

        // If Sprint Diff Mode is active, append ghost cards for Removed Fields in this section
        if (this.sprintDiffMode && this.sprintDiffData?.lookup) {
          const removedList = this.sprintDiffData.lookup.removedBySection.get(sec.title) || [];
          removedList.forEach(remItem => {
            const remField = remItem.field;
            const ghostCol = document.createElement('div');
            ghostCol.className = 'mops-grid-col ' + (remField.col || 'col-lg-6');
            ghostCol.innerHTML = `
              <div class="canvas-field-card cisco-bld-field-card diff-card-removed" title="This field was removed from this section in the current sprint release">
                <div class="cisco-bld-label-row">
                  <label class="cisco-bld-label" style="text-decoration: line-through; color: #991b1b; font-weight: 600;">
                    <span>${remField.label || remField.wfLabel || remField.formData || 'Removed Field'}</span>
                  </label>
                  <div class="cisco-bld-tools">
                    <span class="diff-tag diff-tag-removed"> - Removed in Sprint</span>
                  </div>
                </div>
                <div style="font-size: 11px; color: #991b1b; padding: 6px 8px; background: #fee2e2; border-radius: 4px; margin-top: 6px; font-style: italic;">
                  Deprecated / Removed from specification in this sprint release
                </div>
              </div>
            `;
            grid.appendChild(ghostCol);
          });
        }
      }

      // Bind drag and drop events on this section
      window.DragDropHandler?.bindSectionDropEvents(secBlock, sIdx);

      // Visual divider break after every section + between-section drop strip
      const divider = document.createElement('div');
      divider.className = 'canvas-section-divider';
      canvasRoot.appendChild(divider);
      if (window.DragDropHandler?.createBetweenSectionStrip) {
        canvasRoot.appendChild(window.DragDropHandler.createBetweenSectionStrip(sIdx + 1));
      }
    });

    // Add Section Button
    const addSecWrap = document.createElement('div');
    addSecWrap.className = 'add-section-btn-wrap';
    addSecWrap.innerHTML = `
      <button class="btn-add-section" onclick="App.addSection()">
        <span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add New Section
      </button>
    `;
    canvasRoot.appendChild(addSecWrap);
    window.DragDropHandler?.bindAddSectionDropZone(addSecWrap);
  },

  // ------------------------------------------------------------------------
  // VARIATION 2: Modern Studio (Glassmorphism / Rounded Cards Builder View)
  // ------------------------------------------------------------------------
  renderStudioBuilderMode(canvasRoot) {
    const canvasContainer = document.querySelector('.canvas-container');
    if (canvasContainer) {
      canvasContainer.classList.remove('builder-variant-cisco', 'builder-variant-wizard');
      canvasContainer.classList.add('builder-variant-studio');
    }

    const canvasTitle = document.getElementById('canvasFormTitle');
    const canvasDesc = document.getElementById('canvasFormDesc');
    if (canvasTitle) canvasTitle.textContent = this.formSchema.title || 'Untitled Form';
    if (canvasDesc) canvasDesc.textContent = this.formSchema.description || 'Fill in the fields below to test the intake form logic.';

    if ((this.formSchema.sections || []).length > 0 && window.DragDropHandler?.createBetweenSectionStrip) {
      canvasRoot.appendChild(window.DragDropHandler.createBetweenSectionStrip(0));
    }
    (this.formSchema.sections || []).forEach((sec, sIdx) => {
      const secCard = document.createElement('div');
      secCard.className = 'form-section-card';
      secCard.setAttribute('data-section-index', sIdx);

      secCard.innerHTML = `
        <div class="section-header">
          <div class="section-title-wrap">
            <span class="section-drag-handle" title="Drag to reorder section"><svg width=\"12\" height=\"16\" viewBox=\"0 0 12 16\" fill=\"none\"><circle cx=\"4\" cy=\"4\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"4\" cy=\"8\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"4\" cy=\"12\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"8\" cy=\"4\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"8\" cy=\"8\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"8\" cy=\"12\" r=\"1.5\" fill=\"#94a3b8\"/></svg></span>
            <input type="text" class="section-title-input" value="${sec.title || ''}" placeholder="Section Title..." data-sec-idx="${sIdx}">
            <span style="font-size: 11px; color: #94a3b8;">${(sec.fields || []).length} fields</span>
          </div>
          <div class="section-actions">
            <button class="btn btn-danger btn-sm" title="Delete Section" onclick="App.deleteSection(${sIdx})"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><polyline points=\"3 6 5 6 21 6\"/><path d=\"M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6\"/><path d=\"M10 11v6M14 11v6\"/><path d=\"M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2\"/></svg></span></button>
          </div>
        </div>
        <div class="section-body">
          <div class="section-top-insertion-zone" data-sec="${sIdx}" title="Drop here to insert at Position 1 (Top of Section)"></div>
          <div class="mops-grid-row" id="section_grid_${sIdx}"></div>
        </div>
      `;

      canvasRoot.appendChild(secCard);

      // Section Title change binding
      const titleInput = secCard.querySelector('.section-title-input');
      titleInput?.addEventListener('input', (e) => {
        sec.title = e.target.value;
        this.saveFormToStorage();
      });

      // Render Field Cards
      const grid = secCard.querySelector('#section_grid_' + sIdx);
      if (!sec.fields || sec.fields.length === 0) {
        grid.innerHTML = `
          <div class="col-12">
            <div class="section-dropzone-empty" data-drop-sec="${sIdx}">
              <div class="dropzone-empty-icon"><svg width=\"28\" height=\"28\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"opacity:0.4;color:#94a3b8\"><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><polyline points=\"17 8 12 3 7 8\"/><line x1=\"12\" y1=\"3\" x2=\"12\" y2=\"15\"/></svg></div>
              <div class="dropzone-empty-title">This section is currently empty</div>
              <div class="dropzone-empty-desc">Drag & drop fields from the left palette, or quickly add:</div>
              <div class="dropzone-quick-actions">
                <button type="button" class="btn btn-primary btn-sm" onclick="App.addQuickField(${sIdx}, 'text')"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add Text Field</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="App.addQuickField(${sIdx}, 'select')"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add Dropdown</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="App.populateEmptySectionWithTemplate(${sIdx}, BUILTIN_SECTIONS[0].data)"> Populate with Stakeholder Template</button>
              </div>
            </div>
          </div>
        `;
      } else {
        let currentRowCols2 = 0;
        sec.fields.forEach((field, fIdx) => {
          const colDiv = document.createElement('div');
          colDiv.className = 'mops-grid-col ' + (field.col || 'col-lg-6');

          const isSelected = this.selectedFieldLoc &&
            this.selectedFieldLoc.sectionIndex === sIdx &&
            this.selectedFieldLoc.fieldIndex === fIdx;

          const hasRules = (field.advancedLogic?.display?.groups?.some(g => g.rules?.length > 0)) || (field.condition && field.condition !== true);
          const colNum = (field.col || 'col-lg-6').replace('col-lg-', '');

          if (field.type === 'empty_field') {
            colDiv.innerHTML = this._renderEmptySpacerCardHtml(sIdx, fIdx, colNum);
          } else {
            colDiv.innerHTML = `
              <div class="canvas-field-card ${isSelected ? 'selected' : ''}" data-sec="${sIdx}" data-field="${fIdx}">
              <div class="field-card-top">
                <span class="field-type-pill">${field.type || 'text'}</span>
                <div class="field-badges">
                  ${hasRules ? '<span class="badge-rule"> Logic</span>' : ''}
                  ${field.required ? '<span class="badge-required">* Required</span>' : ''}
                  ${field.baNotes ? '<span class="badge-notes"> Notes</span>' : ''}
                  <span class="badge-width">${colNum}/12</span>
                </div>
              </div>

              <div class="field-preview-label">
                <span>${field.label || field.wfLabel || field.formData || 'Untitled Field'}</span>
                ${field.required ? '<span class="req-star">*</span>' : ''}
                ${field.tooltip ? `<span class="field-tooltip-icon" title="${field.tooltip.replace(/"/g, '&quot;')}" onclick="event.stopPropagation()"><span class="field-tooltip-popup">${field.tooltip}</span></span>` : ''}
              </div>

              <div class="field-preview-widget">
                ${this.renderWidgetPlaceholder(field)}
              </div>
              ${field.baNotes ? `<div class="field-ba-note-badge"> BA Note: ${field.baNotes.substring(0, 50)}${field.baNotes.length > 50 ? '' : ''}</div>` : ''}

              <div class="field-card-footer">
                <span class="field-key-name">${field.formData || ''}</span>
                <div class="field-card-actions">
                  <button class="btn btn-outline btn-sm btn-logic-trigger" title="Open Advanced Logic Studio (AND/OR, Skip, Defaults, Validation)" onclick="event.stopPropagation(); App.openAdvancedLogicModal(${sIdx}, ${fIdx})"> Logic</button>
                  <button class="btn btn-outline btn-sm btn-icon-only" title="Width 50% (2-col)" onclick="event.stopPropagation(); App.setFieldWidth(${sIdx}, ${fIdx}, 'col-lg-6')">1/2</button>
                  <button class="btn btn-outline btn-sm btn-icon-only" title="Width 100% (Full)" onclick="event.stopPropagation(); App.setFieldWidth(${sIdx}, ${fIdx}, 'col-lg-12')">1/1</button>
                  <button class="btn btn-danger btn-sm btn-icon-only" title="Delete Field" onclick="event.stopPropagation(); App.deleteField(${sIdx}, ${fIdx})"></button>
                </div>
              </div>
            </div>
          `;
          }

          grid.appendChild(colDiv);

          // Track column accumulation for 12-column grid row
          const thisFieldCols2 = (field.col === 'col-lg-12' || field.col === 'Full') ? 12 : 6;
          currentRowCols2 += thisFieldCols2;

          // --- Empty Half-Column Slot Dropzone (Builder 2) ---
          const nextField2 = sec.fields[fIdx + 1];
          const nextFieldCols2 = nextField2 ? ((nextField2.col === 'col-lg-12' || nextField2.col === 'Full') ? 12 : 6) : null;
          const needsEmptySlot2 = (currentRowCols2 % 12 === 6) && (nextFieldCols2 === 12 || !nextField2);
          if (needsEmptySlot2) {
            currentRowCols2 += 6;
            const slotCol2 = document.createElement('div');
            slotCol2.className = 'mops-grid-col col-lg-6 grid-empty-slot-col';
            slotCol2.innerHTML = `
              <div class="grid-empty-slot-dropzone" data-sec="${sIdx}" data-insert-idx="${fIdx + 1}" onclick="App.openQuickWfFieldPicker(event, ${sIdx}, ${fIdx + 1})" style="cursor:pointer;" title="Click to pick a WF Field or drop a field here">
                <span class="slot-icon"></span>
                <span class="slot-label">+ Click or drop field here</span>
                <span class="slot-sublabel">Place next to ${field.label || field.wfLabel || 'field'}</span>
              </div>
            `;
            grid.appendChild(slotCol2);
          }

          // --- Between-Row Insert Strip (Builder 2) ---
          const rowEndsHere2 = (currentRowCols2 % 12 === 0);
          if (rowEndsHere2) {
            currentRowCols2 = 0;
            const stripWrapper2 = document.createElement('div');
            stripWrapper2.className = 'mops-grid-col col-lg-12';
            stripWrapper2.style.padding = '0 8px';
            stripWrapper2.innerHTML = `
              <div class="between-row-drop-strip" data-sec="${sIdx}" data-insert-idx="${fIdx + 1}">
                <span class="between-row-strip-label"> Drop here to insert below this row</span>
              </div>
            `;
            grid.appendChild(stripWrapper2);
          }

          // Card Click -> Open Drawer (skip for empty_field spacer)
          if (field.type !== 'empty_field') {
            colDiv.querySelector('.canvas-field-card')?.addEventListener('click', () => {
              this.openFieldSettings(sIdx, fIdx);
            });
          }
        });
      }

      // Bind drag and drop events on this section
      window.DragDropHandler?.bindSectionDropEvents(secCard, sIdx);

      // Visual divider break after every section + between-section drop strip
      const divider2 = document.createElement('div');
      divider2.className = 'canvas-section-divider';
      canvasRoot.appendChild(divider2);
      if (window.DragDropHandler?.createBetweenSectionStrip) {
        canvasRoot.appendChild(window.DragDropHandler.createBetweenSectionStrip(sIdx + 1));
      }
    });

    // Add Section Button
    const addSecWrap = document.createElement('div');
    addSecWrap.className = 'add-section-btn-wrap';
    addSecWrap.innerHTML = `
      <button class="btn-add-section" onclick="App.addSection()">
        <span style="font-size: 18px;">+</span> Add New Section
      </button>
    `;
    canvasRoot.appendChild(addSecWrap);
    window.DragDropHandler?.bindAddSectionDropZone(addSecWrap);
  },

  // ------------------------------------------------------------------------
  // VARIATION 3: Step Wizard (Guided Multi-Step Builder View)
  // ------------------------------------------------------------------------
  renderWizardBuilderMode(canvasRoot) {
    const canvasContainer = document.querySelector('.canvas-container');
    if (canvasContainer) {
      canvasContainer.classList.remove('builder-variant-cisco', 'builder-variant-studio');
      canvasContainer.classList.add('builder-variant-wizard');
    }

    const sections = this.formSchema.sections || [];
    if (this.wizardActiveStep >= sections.length && sections.length > 0) {
      this.wizardActiveStep = 0;
    }

    // Wizard Navigation Bar
    const navBar = document.createElement('div');
    navBar.className = 'wizard-builder-nav';

    let stepsHtml = '';
    sections.forEach((sec, idx) => {
      const isActive = idx === this.wizardActiveStep;
      stepsHtml += `
        <button type="button" class="wizard-builder-step-tab ${isActive ? 'active' : ''}" onclick="App.setWizardStep(${idx})">
          <span class="wizard-step-circle">${idx + 1}</span>
          <span>${sec.title || `Section ${idx + 1}`}</span>
          <span style="font-size: 10.5px; opacity: 0.7;">(${(sec.fields || []).length})</span>
        </button>
      `;
    });

    stepsHtml += `
      <button type="button" class="btn btn-outline btn-xs" onclick="App.addSection()" title="Add Step / Section" style="margin-left: auto;">
        + Add Step
      </button>
      <button type="button" class="btn btn-outline btn-xs" onclick="App.toggleWizardViewAll()" title="Toggle View All Sections" style="margin-left: 4px;">
        ${this.wizardViewAll ? ' Single Step' : ' All Steps'}
      </button>
    `;
    navBar.innerHTML = stepsHtml;
    canvasRoot.appendChild(navBar);

    // If wizardViewAll is true, render all sections; otherwise render only wizardActiveStep
    const sectionsToRender = this.wizardViewAll
      ? sections.map((sec, idx) => ({ sec, sIdx: idx }))
      : (sections[this.wizardActiveStep] ? [{ sec: sections[this.wizardActiveStep], sIdx: this.wizardActiveStep }] : []);

    sectionsToRender.forEach(({ sec, sIdx }) => {
      const secCard = document.createElement('div');
      secCard.className = 'form-section-card';
      secCard.setAttribute('data-section-index', sIdx);

      secCard.innerHTML = `
        <div class="section-header">
          <div class="section-title-wrap">
            <span class="section-drag-handle" title="Drag to reorder section"><svg width=\"12\" height=\"16\" viewBox=\"0 0 12 16\" fill=\"none\"><circle cx=\"4\" cy=\"4\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"4\" cy=\"8\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"4\" cy=\"12\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"8\" cy=\"4\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"8\" cy=\"8\" r=\"1.5\" fill=\"#94a3b8\"/><circle cx=\"8\" cy=\"12\" r=\"1.5\" fill=\"#94a3b8\"/></svg></span>
            <span style="font-weight: 800; color: #005fb8; font-size: 13px;">STEP ${sIdx + 1}:</span>
            <input type="text" class="section-title-input" value="${sec.title || ''}" placeholder="Section Title..." data-sec-idx="${sIdx}">
            <span style="font-size: 11px; color: #94a3b8;">${(sec.fields || []).length} fields</span>
          </div>
          <div class="section-actions">
            <button class="btn btn-danger btn-sm" title="Delete Section" onclick="App.deleteSection(${sIdx})"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><polyline points=\"3 6 5 6 21 6\"/><path d=\"M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6\"/><path d=\"M10 11v6M14 11v6\"/><path d=\"M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2\"/></svg></span></button>
          </div>
        </div>
        <div class="section-body">
          <div class="section-top-insertion-zone" data-sec="${sIdx}" title="Drop here to insert at Position 1 (Top of Section)"></div>
          <div class="mops-grid-row" id="section_grid_${sIdx}"></div>
        </div>
      `;
      canvasRoot.appendChild(secCard);

      const titleInput = secCard.querySelector('.section-title-input');
      titleInput?.addEventListener('input', (e) => {
        sec.title = e.target.value;
        this.saveFormToStorage();
      });

      const grid = secCard.querySelector('#section_grid_' + sIdx);
      if (!sec.fields || sec.fields.length === 0) {
        grid.innerHTML = `
          <div class="col-12">
            <div class="section-dropzone-empty" data-drop-sec="${sIdx}">
              <div class="dropzone-empty-icon"><svg width=\"28\" height=\"28\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"opacity:0.4;color:#94a3b8\"><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><polyline points=\"17 8 12 3 7 8\"/><line x1=\"12\" y1=\"3\" x2=\"12\" y2=\"15\"/></svg></div>
              <div class="dropzone-empty-title">Step ${sIdx + 1} is currently empty</div>
              <div class="dropzone-empty-desc">Drag & drop fields from palette, or add:</div>
              <div class="dropzone-quick-actions">
                <button type="button" class="btn btn-primary btn-sm" onclick="App.addQuickField(${sIdx}, 'text')"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add Text Field</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="App.addQuickField(${sIdx}, 'select')"><span class="icon-svg"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"><line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"/><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/></svg></span> Add Dropdown</button>
              </div>
            </div>
          </div>
        `;
      } else {
        let currentRowCols3 = 0;
        sec.fields.forEach((field, fIdx) => {
          const colDiv = document.createElement('div');
          colDiv.className = 'mops-grid-col ' + (field.col || 'col-lg-6');

          const isSelected = this.selectedFieldLoc &&
            this.selectedFieldLoc.sectionIndex === sIdx &&
            this.selectedFieldLoc.fieldIndex === fIdx;

          const hasRules = (field.advancedLogic?.display?.groups?.some(g => g.rules?.length > 0)) || (field.condition && field.condition !== true);
          const colNum = (field.col || 'col-lg-6').replace('col-lg-', '');

          if (field.type === 'empty_field') {
            colDiv.innerHTML = this._renderEmptySpacerCardHtml(sIdx, fIdx, colNum);
          } else {
            colDiv.innerHTML = `
              <div class="canvas-field-card ${isSelected ? 'selected' : ''}" data-sec="${sIdx}" data-field="${fIdx}">
              <div class="field-card-top">
                <span class="field-type-pill">${field.type || 'text'}</span>
                <div class="field-badges">
                  ${hasRules ? '<span class="badge-rule"> Logic</span>' : ''}
                  ${field.required ? '<span class="badge-required">* Required</span>' : ''}
                  <span class="badge-width">${colNum}/12</span>
                </div>
              </div>
              <div class="field-preview-label">
                <span>${field.label || field.wfLabel || field.formData || 'Untitled Field'}</span>
                ${field.required ? '<span class="req-star">*</span>' : ''}
                ${field.tooltip ? `<span class="field-tooltip-icon" title="${field.tooltip.replace(/"/g, '&quot;')}" onclick="event.stopPropagation()"><span class="field-tooltip-popup">${field.tooltip}</span></span>` : ''}
              </div>
              <div class="field-preview-widget">
                ${this.renderWidgetPlaceholder(field)}
              </div>
              <div class="field-card-footer">
                <span class="field-key-name">${field.formData || ''}</span>
                <div class="field-card-actions">
                  <button class="btn btn-outline btn-sm" title="Logic Studio" onclick="event.stopPropagation(); App.openAdvancedLogicModal(${sIdx}, ${fIdx})"> Logic</button>
                  <button class="btn btn-outline btn-sm btn-icon-only" title="Width" onclick="event.stopPropagation(); App.toggleFieldWidth(${sIdx}, ${fIdx})">${colNum === '12' ? '1/1' : '1/2'}</button>
                  <button class="btn btn-danger btn-sm btn-icon-only" title="Delete" onclick="event.stopPropagation(); App.deleteField(${sIdx}, ${fIdx})"></button>
                </div>
              </div>
            </div>
          `;
          }
          grid.appendChild(colDiv);

          // Track column accumulation for 12-column grid row
          const thisFieldCols3 = (field.col === 'col-lg-12' || field.col === 'Full') ? 12 : 6;
          currentRowCols3 += thisFieldCols3;

          // --- Empty Half-Column Slot Dropzone (Builder 3 / Wizard) ---
          const nextField3 = sec.fields[fIdx + 1];
          const nextFieldCols3 = nextField3 ? ((nextField3.col === 'col-lg-12' || nextField3.col === 'Full') ? 12 : 6) : null;
          const needsEmptySlot3 = (currentRowCols3 % 12 === 6) && (nextFieldCols3 === 12 || !nextField3);
          if (needsEmptySlot3) {
            currentRowCols3 += 6;
            const slotCol3 = document.createElement('div');
            slotCol3.className = 'mops-grid-col col-lg-6 grid-empty-slot-col';
            slotCol3.innerHTML = `
              <div class="grid-empty-slot-dropzone" data-sec="${sIdx}" data-insert-idx="${fIdx + 1}" onclick="App.openQuickWfFieldPicker(event, ${sIdx}, ${fIdx + 1})" style="cursor:pointer;" title="Click to pick a WF Field or drop a field here">
                <span class="slot-icon"></span>
                <span class="slot-label">+ Click or drop field here</span>
                <span class="slot-sublabel">Place next to ${field.label || field.wfLabel || 'field'}</span>
              </div>
            `;
            grid.appendChild(slotCol3);
          }

          // --- Between-Row Insert Strip (Builder 3 / Wizard) ---
          const rowEndsHere3 = (currentRowCols3 % 12 === 0);
          if (rowEndsHere3) {
            currentRowCols3 = 0;
            const stripWrapper3 = document.createElement('div');
            stripWrapper3.className = 'mops-grid-col col-lg-12';
            stripWrapper3.style.padding = '0 8px';
            stripWrapper3.innerHTML = `
              <div class="between-row-drop-strip" data-sec="${sIdx}" data-insert-idx="${fIdx + 1}">
                <span class="between-row-strip-label"> Drop here to insert below this row</span>
              </div>
            `;
            grid.appendChild(stripWrapper3);
          }

          if (field.type !== 'empty_field') {
            colDiv.querySelector('.canvas-field-card')?.addEventListener('click', () => {
              this.openFieldSettings(sIdx, fIdx);
            });
          }
        });
      }

      window.DragDropHandler?.bindSectionDropEvents(secCard, sIdx);

      if (this.wizardViewAll) {
        const divider3 = document.createElement('div');
        divider3.className = 'canvas-section-divider';
        canvasRoot.appendChild(divider3);
        if (window.DragDropHandler?.createBetweenSectionStrip) {
          canvasRoot.appendChild(window.DragDropHandler.createBetweenSectionStrip(sIdx + 1));
        }
      }
    });

    // Step footer bar with Prev / Next controls
    if (!this.wizardViewAll && sections.length > 0) {
      const footerBar = document.createElement('div');
      footerBar.className = 'wizard-step-footer-bar';
      const hasPrev = this.wizardActiveStep > 0;
      const hasNext = this.wizardActiveStep < sections.length - 1;

      footerBar.innerHTML = `
        <button type="button" class="btn btn-outline btn-sm" ${!hasPrev ? 'disabled' : ''} onclick="App.prevWizardStep()">
          < Previous Step
        </button>
        <span style="font-size: 12.5px; font-weight: 600; color: #475569;">
          Step ${this.wizardActiveStep + 1} of ${sections.length}: <strong>${sections[this.wizardActiveStep]?.title || ''}</strong>
        </span>
        <button type="button" class="btn btn-primary btn-sm" ${!hasNext ? 'disabled' : ''} onclick="App.nextWizardStep()">
          Next Step >
        </button>
      `;
      canvasRoot.appendChild(footerBar);
    }
  },

  renderWidgetPlaceholder(f) {
    switch (f.type) {
      case 'empty_field':
        return `<div style="padding:10px;font-size:11.5px;color:#94a3b8;text-align:center;border:1px dashed #cbd5e1;border-radius:4px;background:#f8fafc;">Blank Space (Hidden on Live Form)</div>`;
      case 'visual_cards': {
        const cats = Array.isArray(f.categories) && f.categories.length ? f.categories : [];
        if (cats.length === 0) {
          const rawOpts = Array.isArray(f.options) && f.options.length ? f.options : [];
          return `<div style="padding:6px; font-size:12px; color:#64748b; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:6px;"> Visual Cards Grid (${rawOpts.length} options)</div>`;
        }
        const colCards = cats.map(c => {
          const optCount = Array.isArray(c.options) ? c.options.length : 0;
          const firstThree = (c.options || []).slice(0, 3).map(o => {
            const lbl = typeof o === 'object' && o !== null ? (o.label || o.value || '') : o;
            return `<div style="font-size:10px; color:#334155; padding:2px 4px; background:#fff; border:1px solid #e2e8f0; border-radius:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:flex; align-items:center; justify-content:space-between;"><span>${lbl}</span><span style="font-size:8px; color:#94a3b8;"></span></div>`;
          }).join('');
          const moreCount = optCount > 3 ? `<div style="font-size:9px; color:#64748b; font-weight:600; text-align:center;">+${optCount - 3} more</div>` : '';
          return `
            <div style="flex:1; min-width:110px; background:#f8fafc; border:1px solid #e2e8f0; border-top:3px solid ${c.color || '#00bceb'}; border-radius:4px; padding:6px; display:flex; flex-direction:column; gap:4px;">
              <div style="font-size:10px; font-weight:700; color:${c.color || '#00bceb'}; text-transform:uppercase; letter-spacing:0.5px; border-bottom:1px solid #e2e8f0; padding-bottom:3px; margin-bottom:2px;">${c.title}</div>
              ${firstThree}
              ${moreCount}
            </div>
          `;
        }).join('');
        return `
          <div style="display:flex; flex-direction:column; gap:6px; width:100%;">
            ${f.placeholder ? `<div style="font-size:11px; color:#64748b; font-style:italic;">${f.placeholder}</div>` : ''}
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(110px, 1fr)); gap:8px;">${colCards}</div>
          </div>
        `;
      }
      case 'select': {
        const rawOpts = Array.isArray(f.options) && f.options.length ? f.options : [];
        const conditionalCount = rawOpts.filter(o => typeof o === 'object' && o !== null && o.showIf && o.showIf.field).length;
        const optCount = rawOpts.length ? ` (${rawOpts.length} options)` : '';
        const conditionalBadge = conditionalCount > 0
          ? `<span style="font-size:9.5px; font-weight:700; background:#ede9fe; color:#6d28d9; border:1px solid #c4b5fd; border-radius:10px; padding:1px 6px; margin-left:5px; vertical-align:middle;">🔀 ${conditionalCount} conditional</span>`
          : '';
        const defaultText = f.placeholder || (rawOpts.length ? 'Select an option' : 'No options configured');
        return `<div>
          <select class="mops-select" disabled style="background:#fff;"><option>${defaultText}${optCount} </option></select>
          ${conditionalBadge}
        </div>`;
      }
      case 'multiselect_fancy': {
        const rawOpts = Array.isArray(f.options) && f.options.length ? f.options : [];
        const conditionalCount = rawOpts.filter(o => typeof o === 'object' && o !== null && o.showIf && o.showIf.field).length;
        let tagsHtml = '';
        if (rawOpts.length > 0) {
          tagsHtml = rawOpts.slice(0, 2).map(opt => {
            const lbl = typeof opt === 'object' && opt !== null ? (opt.label || opt.name || opt.value || '') : opt;
            const hasCondition = typeof opt === 'object' && opt !== null && opt.showIf && opt.showIf.field;
            return `<span class="mops-tag" style="${hasCondition ? 'border-color:#c4b5fd; color:#6d28d9; background:#f5f3ff;' : ''}">${lbl}${hasCondition ? ' 🔀' : ''} </span>`;
          }).join('');
          if (rawOpts.length > 2) {
            tagsHtml += `<span style="font-size:10px; color:#475569; font-weight:600; padding:2px 5px; background:#f1f5f9; border-radius:3px; border:1px solid #e2e8f0;">+${rawOpts.length - 2} more</span>`;
          }
        } else {
          tagsHtml = `<span style="font-size:12px; color:#94a3b8; font-style:italic;">No options configured</span>`;
        }
        const conditionalBadge = conditionalCount > 0
          ? `<div style="margin-top:3px; font-size:9.5px; font-weight:700; color:#6d28d9;">🔀 ${conditionalCount} of ${rawOpts.length} options are conditional</div>`
          : '';
        return `<div>
          <div class="mops-multiselect-box" style="display:flex; align-items:center; justify-content:space-between; cursor:pointer; background:#fff; padding:4px 8px; min-height:36px;">
            <div style="display:flex; gap:4px; flex-wrap:wrap; align-items:center;">
              ${tagsHtml}
            </div>
            <span style="font-size:11px; color:#0369a1; font-weight:600; margin-left:auto; white-space:nowrap; padding-left:8px;">Multi-Select Dropdown </span>
          </div>
          ${conditionalBadge}
        </div>`;
      }
      case 'checkbox_group': {
        const rawOpts = Array.isArray(f.options) && f.options.length ? f.options : [];
        if (rawOpts.length === 0) {
          return `<div style="padding:4px 0; font-size:12px; color:#94a3b8; font-style:italic;">No options configured</div>`;
        }
        const cOpts = rawOpts.slice(0, 4).map((opt, i) => {
          const lbl = typeof opt === 'object' && opt !== null ? (opt.label || opt.name || opt.value) : opt;
          const checked = i === 0;
          return `
            <span class="cisco-cb-group-item ${checked ? 'checked' : ''}">
              <span class="cisco-cb-box ${checked ? 'checked' : 'unchecked'}" style="width:15px; height:15px; border-radius:3px;">
                <svg width="9" height="7" viewBox="0 0 12 10" fill="none">
                  <path d="M1.5 5.2L4.5 8.2L10.5 1.8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <span style="font-size:12px; color:#1e293b;">${lbl}</span>
            </span>
          `;
        }).join('');
        return `
          <div style="display:flex; gap:8px; flex-wrap:wrap; padding:2px 0; align-items:center;">
            ${cOpts}
            ${rawOpts.length > 4 ? `<span style="font-size:10px; color:#64748b; font-weight:600; background:#f1f5f9; padding:2px 6px; border-radius:3px;">+${rawOpts.length - 4} more</span>` : ''}
          </div>
        `;
      }
      case 'text_area':
        return `<textarea class="mops-textarea" disabled placeholder="${f.placeholder || ''}"></textarea>`;
      case 'text_number':
        return `<input type="number" class="mops-input" disabled placeholder="0">`;
      case 'date': {
        const dc = f.dateConstraints;
        let badgesHtml = '';
        if (dc) {
          const badges = [];
          if (dc.disableWeekends) badges.push(' No Weekends');
          if (dc.disableCurrentDay || dc.pastTodayMode === 'disable_today_past') badges.push(' Today Disabled');
          else if (dc.disablePastDates || dc.pastTodayMode === 'disable_past') badges.push(' Past Disabled');
          if (dc.minDate && dc.minDate.enabled) {
            const bTxt = dc.minDate.boundary === 'inclusive' ? 'Incl' : 'Excl';
            const unit = dc.minDate.offsetUnit === 'weekdays' ? 'biz days' : 'days';
            if (dc.minDate.source === 'field') {
              badges.push(` Min: ${dc.minDate.watchField || 'field'} + ${dc.minDate.offsetValue || 0} ${unit} (${bTxt})`);
            } else if (dc.minDate.source === 'today') {
              badges.push(` Min: Today + ${dc.minDate.offsetValue || 0} ${unit} (${bTxt})`);
            } else if (dc.minDate.source === 'fixed') {
              badges.push(` Min: ${dc.minDate.fixedDate || ''} (${bTxt})`);
            }
          }
          if (dc.maxDate && dc.maxDate.enabled) {
            const bTxt = dc.maxDate.boundary === 'inclusive' ? 'Incl' : 'Excl';
            badges.push(` Max: ${dc.maxDate.watchField || dc.maxDate.fixedDate || 'date'} (${bTxt})`);
          }
          if (Array.isArray(dc.blackoutDates) && dc.blackoutDates.length) {
            badges.push(` ${dc.blackoutDates.length} Blackout(s)`);
          }
          if (dc.freezeWindow && dc.freezeWindow.start) {
            badges.push(` Freeze: ${dc.freezeWindow.start}  ${dc.freezeWindow.end}`);
          }
          if (badges.length) {
            badgesHtml = `<div class="date-constraints-badges">${badges.map(b => `<span class="date-rule-pill-badge">${b}</span>`).join('')}</div>`;
          }
        }
        return `<div class="date-input-preview-box"><input type="date" class="mops-input" disabled>${badgesHtml}</div>`;
      }
      case 'radio': {
        const rawOpts = Array.isArray(f.options) && f.options.length ? f.options : [];
        if (rawOpts.length === 0) {
          return `<div style="padding:4px 0; font-size:12px; color:#94a3b8; font-style:italic;">No options configured</div>`;
        }
        const rOpts = rawOpts.slice(0, 4).map((opt, i) => {
          const lbl = typeof opt === 'object' && opt !== null ? (opt.label || opt.name || opt.value) : opt;
          return `<label class="mops-radio-item"><input type="radio" disabled ${i === 0 ? 'checked' : ''}> ${lbl}</label>`;
        }).join('');
        return `<div style="display:flex; gap:12px; flex-wrap:wrap; padding:4px 0; align-items:center;">${rOpts}${rawOpts.length > 4 ? `<span style="font-size:10px; color:#64748b; font-weight:600;">+${rawOpts.length - 4} more</span>` : ''}</div>`;
      }
      case 'checkbox': {
        const isChecked = f.defaultValue !== false;
        let ackText = (f.placeholder || '').trim();
        if (!ackText) {
          const lbl = (f.label || f.wfLabel || '').trim();
          if (lbl.toLowerCase().startsWith('i confirm') || lbl.toLowerCase().startsWith('i agree') || lbl.length > 32) {
            ackText = 'Yes, I acknowledge & confirm';
          } else if (lbl.length > 0) {
            ackText = `I confirm: ${lbl}`;
          } else {
            ackText = 'Yes, I acknowledge & confirm';
          }
        }
        return `
          <div class="cisco-checkbox-card-preview ${isChecked ? 'is-checked' : ''}" title="Checkbox (Single Boolean Acknowledgment)">
            <div class="cisco-cb-left">
              <span class="cisco-cb-box ${isChecked ? 'checked' : 'unchecked'}">
                <svg width="11" height="9" viewBox="0 0 12 10" fill="none">
                  <path d="M1.5 5.2L4.5 8.2L10.5 1.8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <span class="cisco-cb-text">${ackText}</span>
            </div>
            <span class="cisco-cb-status-badge ${isChecked ? 'checked' : 'unchecked'}">${isChecked ? 'OK Default Checked' : '* Default Unchecked'}</span>
          </div>
        `;
      }
      case 'file':
        return `<div class="mops-file-drop"> Attachment Upload</div>`;
      case 'text_suggestion':
      case 'autosuggest': {
        const rawOpts = Array.isArray(f.options) && f.options.length ? f.options : [];
        const optCount = rawOpts.length ? ` (${rawOpts.length} suggestion${rawOpts.length === 1 ? '' : 's'})` : '';
        return `
          <div class="mops-autosuggest-box" style="position:relative; width:100%;">
            <div style="display:flex; align-items:center; background:#fff; border:1px solid #cbd5e1; border-radius:4px; padding:0 10px; height:36px; box-sizing:border-box;">
              <span style="color:#005fb8; margin-right:8px; font-size:13px; line-height:1;"></span>
              <span style="color:#94a3b8; font-size:12px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${f.placeholder || 'Start typing to search...'}</span>
              <span style="font-size:10px; color:#0284c7; background:#e0f2fe; padding:2px 7px; border-radius:3px; white-space:nowrap; font-weight:600; border:1px solid #bae6fd;">Auto Suggest${optCount}</span>
            </div>
          </div>`;
      }
      case 'text':
      default:
        return `<input type="text" class="mops-input" disabled placeholder="${f.placeholder || 'Type here...'}">`;
    }
  },

  // ------------------------------------------------------------------------
  // REVIEW / INTERACTIVE MODE Rendering (Multi-Variation)
  // ------------------------------------------------------------------------
});
