/**
 * Cisco MOPs FORM Studio - Configuration Screen & Reusable Fields Inventory
 * Domain: Full-page workstation takeover for cross-form field directory, Workfront custom forms/templates registries, and usage analytics
 * File: js/modules/15-config-screen.js
 */

window.App = window.App || {};

Object.assign(window.App, {
  WORKFRONT_FORMS_CATALOG: {
    'webinar': { id: '69f8b16e00073ef209400e7853908e1f', name: 'Webinar Request Form' },
    'digitalmedia': { id: '677e39e000030a861f66c81b448d239d', name: 'Digital Media Intake Form' },
    'webrequest': { id: '61fc4e41000b3380c699a6fc41df5b33', name: 'UAP MOPs Form' },
    'collateral': { id: '6a4624ee000003b5b4f8e799d7bb1865', name: 'Collateral Request Form' },
    'email': { id: '61fc4e41000b3380c699a6fc41df5b33', name: 'UAP MOPs Form' },
    'contentsyndication': { id: '6696499c0076cb846e77f2c480f4d305', name: 'Content Syndication MOPs' },
    'audience': { id: '63c819a00041d8e6241a8c9034f5e821', name: 'Audience Strategy Custom Form' },
    'event': { id: '62fa71e00018a4d700192e21b7a2d810', name: 'Event Intake Custom Form' },
    'planning': { id: '64a781b00029b9f71291b821a7c3e901', name: 'Campaign Planning Custom Form' },
    'social': { id: '65b902e10037a8c9192b7401c904a782', name: 'Social Media Custom Form' },
    'seo': { id: '66d013e20048b9a1038e91823ab47c19', name: 'SEO Content Custom Form' },
    'report': { id: '67e124f30059ca12049f02934bc58d20', name: 'Research & Report Custom Form' },
    'video': { id: '68f235a4006ad12315a013a45cd69e31', name: 'Video Production Custom Form' },
    'flexitive-banner': { id: '69a346b5007be23426b124b56de7af42', name: 'HTML5 Banner Custom Form' },
    'get-help': { id: '60b457c6008cf34537c235c67ef8b053', name: 'General MOPs Support Form' },
    'test-form': { id: '61af990000192a8374b8819001b9ca10', name: 'UAP Validation Custom Form' }
  },

  WORKFRONT_FIELD_REGISTRY_CATALOG: {
    '55c56c890004de6b949a182d0d1d59a6': { wfName: 'uap Stakeholder Unit', forms: 'all', type: 'select' },
    '65e59550000ead23557756ab008eaad9': { wfName: 'uap Budget Approval', forms: ['webinar', 'digitalmedia', 'email'], type: 'select' },
    '58cf9871004173935b70fdaf4f233781': { wfName: 'Key Stakeholder', forms: ['webinar', 'email', 'webrequest', 'collateral', 'digitalmedia'], type: 'text_suggestion' },
    '615456f4003df2410a0df256f671c6ca': { wfName: 'uap Content Format', forms: ['webinar', 'email', 'digitalmedia'], type: 'select' },
    '677f8b84000d9902b89823ce8735886e': { wfName: 'Localizationrequest1', forms: 'all', type: 'select' },
    'storyFeaturedPages': { wfName: 'uap Story Featured Pages', forms: ['webinar'], type: 'multi_text_fields' },
    '61df5582003a92b049cafa45f74e87ac': { wfName: 'contentTitle', forms: 'all', type: 'text' },
    '635040d700147670ca356476308a58f6': { wfName: 'CampaignAlign', forms: 'all', type: 'select' },
    '6194882e000216183c446bb100698419': { wfName: 'regions1', forms: ['webinar', 'collateral', 'audience', 'email', 'digitalmedia', 'event', 'planning', 'social', 'contentsyndication'], type: 'multiselect_fancy' },
    '61df3f2c002f52ac4278ec4100a9a2ff': { wfName: 'programAlign', forms: ['webinar', 'collateral', 'email'], type: 'select' },
    '5fd6790400ac1378f2aebf708de432c1': { wfName: 'activityId', forms: 'all', type: 'text' },
    '692dbe0a0009f89c619aa416f0bdced7': { wfName: 'webinarType', forms: ['webinar'], type: 'select' },
    '69e601ee00026c8dce072dc3da6eb96f': { wfName: 'uapSupportType', forms: ['webinar'], type: 'multiselect_fancy' },
    '64bf6b5e007654df0e6c19343d9454d3': { wfName: 'webinarTitle', forms: ['webinar'], type: 'text' },
    '61df3f90002f52ac427bec410099a2ff': { wfName: 'desiredGoLiveDate', forms: ['webinar'], type: 'date' }
  },

  _fieldsDirectoryData: null,
  _fieldsDirectoryFiltered: null,

  _escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },

  openFieldsDirectoryModal() {
    const modal = document.getElementById('modalFieldsDirectory');
    if (!modal) return;

    modal.classList.add('open');
    modal.style.cssText = 'display:flex;align-items:center;justify-content:center;opacity:1;pointer-events:auto;';

    // Collect all data fresh
    this.collectFieldsDirectoryInventory();

    // Populate filter select options
    this.populateFieldsDirectoryFilters();

    // Render table & metrics
    this.filterFieldsDirectory();
  },

  closeFieldsDirectoryModal() {
    const modal = document.getElementById('modalFieldsDirectory');
    if (modal) {
      modal.classList.remove('open');
      modal.style.cssText = 'display:none;opacity:0;pointer-events:none;';
    }
  },

  collectFieldsDirectoryInventory() {
    const catalog = new Map();
    const wfCat = this.WORKFRONT_FORMS_CATALOG;
    const wfReg = this.WORKFRONT_FIELD_REGISTRY_CATALOG;

    // Helper to normalize field type
    const normalizeType = (t) => {
      t = (t || '').toLowerCase();
      if (t.includes('suggest') || t.includes('stakeholder')) return 'suggest';
      if (t.includes('multi')) return 'multiselect';
      if (t.includes('select') || t.includes('dropdown')) return 'select';
      if (t.includes('date')) return 'date';
      if (t.includes('area') || t.includes('note') || t.includes('desc')) return 'textarea';
      if (t.includes('number') || t.includes('int')) return 'number';
      if (t.includes('check')) return 'checkbox';
      if (t.includes('file') || t.includes('upload')) return 'file';
      if (t.includes('radio')) return 'radio';
      return 'text';
    };

    // 1. Gather all reusable / saved library fields
    const libFields = Array.isArray(this.reusableFields) ? this.reusableFields : [];
    libFields.forEach((item, idx) => {
      const f = item.data || item;
      const key = (f.formData || f.id || item.label || `lib_fld_${idx}`).trim();
      const label = item.label || f.label || key;
      const fType = normalizeType(f.type);
      const isPreset = Boolean(item.badge && item.badge !== 'Custom');

      if (!catalog.has(key)) {
        catalog.set(key, {
          key: key,
          label: label,
          type: fType,
          badge: isPreset ? (item.badge || 'Library Preset') : 'Custom Field',
          source: isPreset ? 'preset' : 'custom',
          wfName: f.wfFieldName || f.wfLabel || '',
          wfObject: item.wfObject || f.wfObject || 'Project',
          status: item.status || 'active',
          libIdx: idx,
          wfForms: new Set(Array.isArray(item.wfFormLabels) ? item.wfFormLabels : (Array.isArray(f.wfFormLabels) ? f.wfFormLabels : [])),
          uiForms: [],
          options: Array.isArray(f.options) ? f.options : [],
          required: Boolean(f.required),
          rawField: f
        });
      }
    });

    // 2. Gather from WORKFRONT_FIELD_REGISTRY_CATALOG
    Object.keys(wfReg).forEach(regKey => {
      const meta = wfReg[regKey];
      let entry = catalog.get(regKey);
      if (!entry) {
        // check by wfName
        for (let [, val] of catalog.entries()) {
          if (val.wfName === meta.wfName || val.key === meta.wfName) {
            entry = val;
            break;
          }
        }
      }
      if (!entry) {
        entry = {
          key: regKey,
          label: meta.wfName || regKey,
          type: normalizeType(meta.type),
          badge: 'Workfront Master',
          source: 'master',
          wfName: meta.wfName || '',
          wfForms: new Set(),
          uiForms: [],
          options: Array.isArray(meta.customOptions) ? meta.customOptions : [],
          required: false,
          rawField: { id: regKey, label: meta.wfName, type: meta.type }
        };
        catalog.set(regKey, entry);
      }

      // Add mapped Workfront forms
      if (meta.forms === 'all') {
        Object.values(wfCat).forEach(wff => entry.wfForms.add(wff.name));
      } else if (Array.isArray(meta.forms)) {
        meta.forms.forEach(fKey => {
          if (wfCat[fKey]) entry.wfForms.add(wfCat[fKey].name);
        });
      }
    });

    // 3. Scan all Frontend UI Forms
    const allFormsList = [];
    const seenFormIds = new Set();
    (this.allForms || []).forEach(f => {
      if (!seenFormIds.has(f.id)) { seenFormIds.add(f.id); allFormsList.push(f); }
    });
    if (window.MOPS_FORMS_REPOSITORY && Array.isArray(window.MOPS_FORMS_REPOSITORY.forms)) {
      window.MOPS_FORMS_REPOSITORY.forms.forEach(f => {
        if (!seenFormIds.has(f.id)) { seenFormIds.add(f.id); allFormsList.push(f); }
      });
    }
    if (window.SAMPLE_FORMS && Array.isArray(window.SAMPLE_FORMS)) {
      window.SAMPLE_FORMS.forEach(f => {
        if (!seenFormIds.has(f.id)) { seenFormIds.add(f.id); allFormsList.push(f); }
      });
    }

    allFormsList.forEach(form => {
      const fId = form.id;
      const fLabel = form.label || (form.schema && form.schema.title) || fId;
      const fIcon = form.icon || '';
      const defaultWfForm = wfCat[fId] ? wfCat[fId].name : `${fLabel} Custom Form`;

      const sections = (form.schema && Array.isArray(form.schema.sections)) ? form.schema.sections : [];
      sections.forEach(sec => {
        const secTitle = sec.title || 'General';
        (sec.fields || []).forEach(fld => {
          const key = (fld.formData || fld.wfFieldName || fld.wfId || fld.id || '').trim();
          if (!key) return;

          let entry = catalog.get(key);
          if (!entry) {
            // Check matching by wfId or wfFieldName or label
            for (let [, val] of catalog.entries()) {
              if (val.key === fld.wfId || (val.wfName && val.wfName === fld.wfFieldName) || (fld.label && val.label === fld.label)) {
                entry = val;
                break;
              }
            }
          }

          if (!entry) {
            entry = {
              key: key,
              label: fld.label || fld.wfLabel || fld.wfFieldName || fld.formData || 'Form Field',
              type: normalizeType(fld.type),
              badge: 'Shared Intake Field',
              source: 'shared',
              wfName: fld.wfFieldName || fld.wfLabel || '',
              wfForms: new Set(),
              uiForms: [],
              options: Array.isArray(fld.options) ? fld.options : [],
              required: Boolean(fld.required),
              rawField: fld
            };
            catalog.set(key, entry);
          }

          // Attach Workfront form
          entry.wfForms.add(defaultWfForm);

          // Add UI Form usage if not already recorded for this form+section
          const alreadyAdded = entry.uiForms.some(u => u.formId === fId && u.sectionTitle === secTitle);
          if (!alreadyAdded) {
            entry.uiForms.push({
              formId: fId,
              formLabel: fLabel,
              formIcon: fIcon,
              sectionTitle: secTitle,
              required: Boolean(fld.required),
              condition: fld.condition || null
            });
          }

          if (fld.required) entry.required = true;
          if (Array.isArray(fld.options) && fld.options.length > entry.options.length) {
            entry.options = fld.options;
          }
        });
      });
    });

    // Convert to Array & Sort by UI Form Usages desc, then by Label
    const list = Array.from(catalog.values()).map(item => ({
      ...item,
      wfFormsList: Array.from(item.wfForms)
    }));

    list.sort((a, b) => {
      if (b.uiForms.length !== a.uiForms.length) {
        return b.uiForms.length - a.uiForms.length;
      }
      return a.label.localeCompare(b.label);
    });

    this._fieldsDirectoryData = list;
    return list;
  },

  populateFieldsDirectoryFilters() {
    const list = this._fieldsDirectoryData || [];

    // 1. Workfront Forms Filter
    const selWf = document.getElementById('fldDirFilterWfForm');
    if (selWf) {
      const allWfForms = new Set();
      list.forEach(item => (item.wfFormsList || []).forEach(wf => allWfForms.add(wf)));
      const sortedWf = Array.from(allWfForms).sort();
      selWf.innerHTML = '<option value="">All Workfront Forms (' + sortedWf.length + ')</option>' +
        sortedWf.map(w => `<option value="${this._escapeHtml(w)}">${this._escapeHtml(w)}</option>`).join('');
    }

    // 2. Frontend UI Forms Filter
    const selUi = document.getElementById('fldDirFilterUiForm');
    if (selUi) {
      const allUiForms = new Map();
      list.forEach(item => {
        (item.uiForms || []).forEach(u => allUiForms.set(u.formId, u.formLabel));
      });
      const sortedUi = Array.from(allUiForms.entries()).sort((a, b) => a[1].localeCompare(b[1]));
      selUi.innerHTML = '<option value="">All Frontend UI Forms (' + sortedUi.length + ')</option>' +
        sortedUi.map(([fid, flbl]) => `<option value="${this._escapeHtml(fid)}">${this._escapeHtml(flbl)}</option>`).join('');
    }
  },

  onFieldsDirectoryFilterChange() {
    this.filterFieldsDirectory();
  },

  resetFieldsDirectoryFilters() {
    const inSearch = document.getElementById('fldDirSearchInput');
    const selType = document.getElementById('fldDirFilterType');
    const selObj = document.getElementById('fldDirFilterObject');
    const selWf = document.getElementById('fldDirFilterWfForm');
    const selUi = document.getElementById('fldDirFilterUiForm');
    const selUsage = document.getElementById('fldDirFilterUsageStatus');
    const selStatus = document.getElementById('fldDirFilterStatus');

    if (inSearch) inSearch.value = '';
    if (selType) selType.value = '';
    if (selObj) selObj.value = '';
    if (selWf) selWf.value = '';
    if (selUi) selUi.value = '';
    if (selUsage) selUsage.value = '';
    if (selStatus) selStatus.value = '';

    this.filterFieldsDirectory();
  },

  filterFieldsDirectory() {
    const all = this._fieldsDirectoryData || [];
    const q = (document.getElementById('fldDirSearchInput')?.value || '').trim().toLowerCase();
    const typeF = document.getElementById('fldDirFilterType')?.value || '';
    const objF = (document.getElementById('fldDirFilterObject')?.value || '').toLowerCase();
    const wfF = document.getElementById('fldDirFilterWfForm')?.value || '';
    const uiF = document.getElementById('fldDirFilterUiForm')?.value || '';
    const usageF = document.getElementById('fldDirFilterUsageStatus')?.value || '';
    const statusF = document.getElementById('fldDirFilterStatus')?.value || '';

    const filtered = all.filter(item => {
      // Type filter
      if (typeF && item.type !== typeF) return false;

      // Workfront Object filter
      if (objF && !(item.wfObject || 'Project').toLowerCase().includes(objF)) return false;

      // Usage status filter
      if (usageF === 'used' && item.uiForms.length === 0) return false;
      if (usageF === 'unused' && item.uiForms.length > 0) return false;

      // Field Active/Inactive status filter
      const itemStatus = item.status || 'active';
      if (statusF && itemStatus !== statusF) return false;

      // Workfront form filter
      if (wfF && !(item.wfFormsList || []).includes(wfF)) return false;

      // Frontend UI form filter
      if (uiF && !(item.uiForms || []).some(u => u.formId === uiF)) return false;

      // Text Search Query
      if (q) {
        const inLabel = (item.label || '').toLowerCase().includes(q);
        const inKey = (item.key || '').toLowerCase().includes(q);
        const inWf = (item.wfName || '').toLowerCase().includes(q);
        const inType = (item.type || '').toLowerCase().includes(q);
        const inWfForms = (item.wfFormsList || []).some(w => w.toLowerCase().includes(q));
        const inUiForms = (item.uiForms || []).some(u => u.formLabel.toLowerCase().includes(q) || u.sectionTitle.toLowerCase().includes(q));

        if (!inLabel && !inKey && !inWf && !inType && !inWfForms && !inUiForms) {
          return false;
        }
      }

      return true;
    });

    this._fieldsDirectoryFiltered = filtered;

    // Update KPI metrics
    this.updateFieldsDirectoryKpis(all, filtered);

    // Render table
    this.renderFieldsDirectoryTable(filtered);
  },

  updateFieldsDirectoryKpis(all, filtered) {
    const elTotal = document.getElementById('fldDirKpiTotal');
    const elWf = document.getElementById('fldDirKpiWfForms');
    const elUi = document.getElementById('fldDirKpiUiForms');
    const elPlacements = document.getElementById('fldDirKpiPlacements');
    const elFooter = document.getElementById('fldDirFooterCount');

    const totalFields = all.length;
    const totalWfForms = new Set(all.flatMap(i => i.wfFormsList || [])).size;
    const totalUiForms = new Set(all.flatMap(i => (i.uiForms || []).map(u => u.formId))).size;
    const totalPlacements = all.reduce((acc, i) => acc + (i.uiForms || []).length, 0);

    if (elTotal) elTotal.textContent = totalFields;
    if (elWf) elWf.textContent = totalWfForms;
    if (elUi) elUi.textContent = totalUiForms;
    if (elPlacements) elPlacements.textContent = totalPlacements;

    if (elFooter) {
      elFooter.textContent = `Showing ${filtered.length} of ${totalFields} fields (${totalPlacements} total cross-form placements)`;
    }
  },

  renderFieldsDirectoryTable(items) {
    const tbody = document.getElementById('tbodyFieldsDirectory');
    if (!tbody) return;

    if (items.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align:center; padding: 40px 20px; color:#64748b;">
            <div style="font-size: 28px; margin-bottom: 8px;"></div>
            <div style="font-weight: 700; font-size: 14px; color:#0f172a;">No fields match your search & filter criteria</div>
            <div style="font-size: 12px; margin-top: 4px;">Try clearing filters or search query to see all reusable fields.</div>
            <button type="button" class="btn btn-outline btn-sm" onclick="App.resetFieldsDirectoryFilters()" style="margin-top:12px;">Reset Filters</button>
          </td>
        </tr>
      `;
      return;
    }

    const typeIcons = {
      'text': ' Single Line Text',
      'select': ' Dropdown Picklist',
      'multiselect': ' Multi-Select',
      'suggest': ' Auto Suggest',
      'date': ' Date Picker',
      'textarea': ' Textarea / Notes',
      'number': ' Number Input',
      'checkbox': '[x] Checkbox',
      'file': ' File Upload',
      'radio': ' Radio Choice'
    };

    const typeClasses = {
      'text': 'text',
      'select': 'select',
      'multiselect': 'multiselect',
      'suggest': 'suggest',
      'date': 'date',
      'textarea': 'textarea',
      'number': 'number',
      'checkbox': 'text',
      'file': 'file',
      'radio': 'select'
    };

    const html = items.map(item => {
      const typeLabel = typeIcons[item.type] || item.type;
      const typeCls = typeClasses[item.type] || 'text';

      // Workfront forms pills
      let wfFormsHtml = '';
      if (item.wfFormsList && item.wfFormsList.length > 0) {
        if (item.wfFormsList.length >= 10) {
          wfFormsHtml = `<span class="fld-wf-pill fld-wf-global" title="${item.wfFormsList.join(', ')}"> All Workfront Forms (${item.wfFormsList.length})</span>`;
        } else {
          wfFormsHtml = item.wfFormsList.map(w => `<span class="fld-wf-pill" title="Workfront Custom Form: ${w}"> ${this._escapeHtml(w)}</span>`).join('');
        }
      } else {
        wfFormsHtml = '<span style="font-size:11px; color:#94a3b8; font-style:italic;">None mapped</span>';
      }

      // Frontend UI forms pills
      let uiFormsHtml = '';
      if (item.uiForms && item.uiForms.length > 0) {
        const countBadge = `<span class="fld-usage-count-badge active" style="margin-right:6px;">${item.uiForms.length} UI Form${item.uiForms.length > 1 ? 's' : ''}</span>`;
        const pills = item.uiForms.slice(0, 4).map(u => `
          <span class="fld-ui-pill" onclick="App.openFormFromDirectory('${u.formId}')" title="Placed in section: ${this._escapeHtml(u.sectionTitle)}">
            ${u.formIcon || ''} ${this._escapeHtml(u.formLabel)}
          </span>
        `).join('');
        const morePill = item.uiForms.length > 4 ?
          `<span class="fld-ui-pill" onclick="App.openFieldDirectoryDetailModal('${this._escapeHtml(item.key)}')" style="background:#f1f5f9; color:#475569; border-color:#cbd5e1;">+${item.uiForms.length - 4} more</span>` : '';
        uiFormsHtml = countBadge + pills + morePill;
      } else {
        uiFormsHtml = `<span class="fld-usage-count-badge unused">Library Only (0 UI usages)</span>`;
      }

      // Attributes
      const reqBadge = item.required ?
        '<span style="background:#fee2e2; color:#b91c1c; font-size:10px; font-weight:700; padding:1px 5px; border-radius:3px;">Req</span>' :
        '<span style="background:#f1f5f9; color:#64748b; font-size:10px; padding:1px 5px; border-radius:3px;">Opt</span>';

      const optCount = item.options && item.options.length > 0 ?
        `<span style="font-size:11px; color:#0369a1; font-weight:600;">${item.options.length} opts</span>` : '';

      const isInactive = item.status === 'inactive';
      const statusBadge = isInactive
        ? '<span style="background:#fee2e2; color:#991b1b; font-size:10px; font-weight:700; padding:2px 6px; border-radius:4px;">Inactive</span>'
        : '<span style="background:#dcfce7; color:#166534; font-size:10px; font-weight:700; padding:2px 6px; border-radius:4px;">Active</span>';

      return `
        <tr style="${isInactive ? 'opacity:0.65;' : ''}">
          <td>
            <div class="fld-dir-name-title">
              <span>${this._escapeHtml(item.label)}</span>
              <span class="fld-dir-badge ${item.source}">${item.badge || 'Field'}</span>
            </div>
            <div class="fld-dir-name-sub">
              API: <code>${this._escapeHtml(item.key)}</code>
              ${item.wfName && item.wfName !== item.key ? `<span style="color:#7c3aed; margin-left:6px;">wf: DE:${this._escapeHtml(item.wfName)}</span>` : ''}
            </div>
          </td>
          <td>
            <span class="fld-type-pill ${typeCls}">${typeLabel}</span>
          </td>
          <td>
            <span style="font-size:11.5px; font-weight:600; color:#334155;">${this._escapeHtml(item.wfObject || 'Project')}</span>
          </td>
          <td>
            <div style="display:flex; flex-wrap:wrap; align-items:center; max-width: 240px;">
              ${wfFormsHtml}
            </div>
          </td>
          <td>
            <div style="display:flex; flex-wrap:wrap; align-items:center; max-width: 260px;">
              ${uiFormsHtml}
            </div>
          </td>
          <td>
            ${statusBadge}
          </td>
          <td style="text-align:right; white-space:nowrap;">
            <button type="button" class="btn btn-outline btn-xs" onclick="App.openFieldDirectoryDetailModal('${this._escapeHtml(item.key)}')" title="View complete schema & live preview" style="padding: 2px 7px; font-size:11px;">
              View
            </button>
            ${item.libIdx !== undefined ? `<button type="button" class="btn btn-outline btn-xs" onclick="App.closeFieldsDirectoryModal(); App.openEditSavedFieldModal(${item.libIdx})" title="Edit WF Field (with usage impact check)" style="padding: 2px 7px; font-size:11px;">Edit</button>` : ''}
            <button type="button" class="btn btn-outline btn-xs" onclick="App.openFieldWhereUsedModal('${this._escapeHtml(item.key)}')" title="View Intake Form usage" style="padding: 2px 7px; font-size:11px;">Usage</button>
            ${isInactive ? '' : `<button type="button" class="btn btn-outline btn-xs" onclick="App.insertFieldFromDirectory('${this._escapeHtml(item.key)}')" title="Insert this reusable field into the active canvas form" style="padding: 2px 7px; font-size:11px; color:#0284c7; border-color:#bae6fd;">+ Add</button>`}
          </td>
        </tr>
      `;
    }).join('');

    tbody.innerHTML = html;
  },

  openFieldDirectoryDetailModal(fieldKey) {
    const list = this._fieldsDirectoryData || [];
    const item = list.find(f => f.key === fieldKey || f.label === fieldKey || f.wfName === fieldKey);
    if (!item) return;

    this._activeDetailField = item;

    const modal = document.getElementById('modalFieldDirectoryDetail');
    const titleEl = document.getElementById('fldDirDetailTitle');
    const subEl = document.getElementById('fldDirDetailSubtitle');
    const bodyEl = document.getElementById('fldDirDetailBody');

    if (titleEl) titleEl.textContent = item.label;
    if (subEl) subEl.textContent = `Type: ${item.type.toUpperCase()}  Key: ${item.key}  ${item.badge}`;

    // Generate live interactive field preview HTML
    let previewWidgetHtml = '';
    if (item.type === 'select') {
      const opts = (item.options || []).map(o => {
        const val = typeof o === 'object' ? (o.value || o.label) : o;
        const lbl = typeof o === 'object' ? (o.label || o.value) : o;
        return `<option value="${this._escapeHtml(val)}">${this._escapeHtml(lbl)}</option>`;
      }).join('');
      previewWidgetHtml = `<select class="mops-input" style="background:#fff;">${opts || '<option>Select an option...</option>'}</select>`;
    } else if (item.type === 'multiselect') {
      const pills = (item.options || []).slice(0, 5).map(o => {
        const lbl = typeof o === 'object' ? (o.label || o.value) : o;
        return `<span style="background:#ede9fe; color:#6d28d9; border:1px solid #ddd6fe; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600;">OK ${this._escapeHtml(lbl)}</span>`;
      }).join('');
      previewWidgetHtml = `<div style="display:flex; flex-wrap:wrap; gap:6px; padding:6px; background:#fff; border:1px solid #cbd5e1; border-radius:6px;">${pills || '<span style="color:#94a3b8; font-size:11px;">Multi-select options</span>'}</div>`;
    } else if (item.type === 'date') {
      previewWidgetHtml = `<input type="date" class="mops-input" value="2026-11-25" style="background:#fff;">`;
    } else if (item.type === 'textarea') {
      previewWidgetHtml = `<textarea class="mops-input" rows="2" placeholder="Sample textarea preview..." style="background:#fff;"></textarea>`;
    } else if (item.type === 'checkbox') {
      previewWidgetHtml = `<label style="display:flex; align-items:center; gap:8px; font-size:12px; cursor:pointer;"><input type="checkbox" checked> ${this._escapeHtml(item.label)}</label>`;
    } else {
      previewWidgetHtml = `<input type="text" class="mops-input" placeholder="Type here..." style="background:#fff;">`;
    }

    // Workfront custom forms list HTML
    const wfListHtml = (item.wfFormsList && item.wfFormsList.length > 0) ?
      item.wfFormsList.map(w => `<li style="padding:3px 0; font-size:12px; color:#475569;"> <strong>${this._escapeHtml(w)}</strong></li>`).join('') :
      '<li style="color:#94a3b8; font-size:12px;">Not directly attached to any static Workfront form.</li>';

    // Frontend UI forms list HTML
    const uiListHtml = (item.uiForms && item.uiForms.length > 0) ?
      item.uiForms.map(u => `
        <li style="display:flex; justify-content:space-between; align-items:center; padding:4px 0; border-bottom:1px solid #f1f5f9; font-size:12px;">
          <div>
            <span>${u.formIcon || ''} <strong>${this._escapeHtml(u.formLabel)}</strong></span>
            <span style="color:#64748b; margin-left:6px;">(Section: ${this._escapeHtml(u.sectionTitle)})</span>
          </div>
          <button type="button" class="btn btn-outline btn-xs" onclick="App.openFormFromDirectory('${u.formId}')" style="font-size:10.5px; padding:2px 6px;">Open Form</button>
        </li>
      `).join('') :
      '<li style="color:#94a3b8; font-size:12px;">Currently unused on frontend UI forms (Available in Library).</li>';

    // Options breakdown table HTML
    let optionsTableHtml = '';
    if (item.options && item.options.length > 0) {
      const optRows = item.options.map((o, idx) => {
        const val = typeof o === 'object' ? (o.value || '') : o;
        const lbl = typeof o === 'object' ? (o.label || '') : o;
        return `<tr><td style="padding:3px 8px; font-size:11px; color:#64748b;">${idx + 1}</td><td style="padding:3px 8px; font-size:11.5px; font-weight:600;">${this._escapeHtml(lbl)}</td><td style="padding:3px 8px; font-size:11px; font-family:monospace; color:#475569;">${this._escapeHtml(val)}</td></tr>`;
      }).join('');
      optionsTableHtml = `
        <div style="margin-top:14px; background:#fff; border:1px solid #e2e8f0; border-radius:6px; padding:10px 12px;">
          <div style="font-size:11.5px; font-weight:700; color:#0f172a; margin-bottom:6px;">Configured Picklist Options (${item.options.length})</div>
          <div style="max-height:140px; overflow-y:auto; border:1px solid #f1f5f9; border-radius:4px;">
            <table style="width:100%; border-collapse:collapse;">
              <thead><tr style="background:#f8fafc; font-size:10px; color:#64748b; text-transform:uppercase;"><th style="padding:4px 8px;">#</th><th style="padding:4px 8px;">Display Label</th><th style="padding:4px 8px;">Value</th></tr></thead>
              <tbody>${optRows}</tbody>
            </table>
          </div>
        </div>
      `;
    }

    if (bodyEl) {
      bodyEl.innerHTML = `
        <!-- Live Preview Card -->
        <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:12px 14px; margin-bottom:14px;">
          <div style="font-size:11px; font-weight:700; color:#0369a1; text-transform:uppercase; letter-spacing:0.4px; margin-bottom:6px;">Live Visual Field Preview</div>
          <div style="margin-bottom:6px;">
            <label style="font-size:12px; font-weight:600; color:#1e293b;">${this._escapeHtml(item.label)} ${item.required ? '<span style="color:#ef4444;">*</span>' : ''}</label>
          </div>
          ${previewWidgetHtml}
        </div>

        <!-- Workfront Custom Forms -->
        <div style="background:#fff; border:1px solid #e2e8f0; border-radius:6px; padding:10px 12px; margin-bottom:12px;">
          <div style="font-size:11.5px; font-weight:700; color:#7c3aed; margin-bottom:6px;">Workfront Custom Form(s) (${item.wfFormsList ? item.wfFormsList.length : 0})</div>
          <ul style="list-style:none; padding:0; margin:0;">${wfListHtml}</ul>
        </div>

        <!-- Frontend UI Forms -->
        <div style="background:#fff; border:1px solid #e2e8f0; border-radius:6px; padding:10px 12px; margin-bottom:12px;">
          <div style="font-size:11.5px; font-weight:700; color:#0284c7; margin-bottom:6px;">Frontend UI Intake Form Usages (${item.uiForms ? item.uiForms.length : 0})</div>
          <ul style="list-style:none; padding:0; margin:0; max-height:150px; overflow-y:auto;">${uiListHtml}</ul>
        </div>

        ${optionsTableHtml}

        <!-- JSON Config Viewer -->
        <div style="margin-top:12px;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <span style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;">Raw JSON Configuration</span>
            <button type="button" class="btn btn-outline btn-xs" onclick="navigator.clipboard.writeText(JSON.stringify(App._activeDetailField.rawField, null, 2)); App._showToast('JSON copied to clipboard!');" style="font-size:10px; padding:1px 6px;">Copy JSON</button>
          </div>
          <pre style="background:#0f172a; color:#f8fafc; padding:10px; border-radius:6px; font-size:10.5px; max-height:120px; overflow-y:auto; margin:0;">${this._escapeHtml(JSON.stringify(item.rawField, null, 2))}</pre>
        </div>
      `;
    }

    if (modal) {
      modal.classList.add('open');
      modal.style.cssText = 'display:flex;align-items:center;justify-content:center;opacity:1;pointer-events:auto;';
    }
  },

  closeFieldDirectoryDetailModal() {
    const modal = document.getElementById('modalFieldDirectoryDetail');
    if (modal) {
      modal.classList.remove('open');
      modal.style.cssText = 'display:none;opacity:0;pointer-events:none;';
    }
  },

  openFormFromDirectory(formId) {
    this.closeFieldDirectoryDetailModal();
    this.closeFieldsDirectoryModal();
    this.switchActiveForm(formId);
    this._showToast(`Switched to intake form: "${formId}"`);
  },

  insertFieldFromDetailToForm() {
    if (this._activeDetailField) {
      this.insertFieldFromDirectory(this._activeDetailField.key);
      this.closeFieldDirectoryDetailModal();
    }
  },

  insertFieldFromDirectory(fieldKey) {
    const list = this._fieldsDirectoryData || [];
    const item = list.find(f => f.key === fieldKey);
    if (!item) return;

    if (!this.activeFormId) {
      this._showToast('Please open an intake form on the canvas before inserting fields.');
      return;
    }

    const form = this.getActiveForm();
    if (!form || !form.sections || form.sections.length === 0) {
      this._showToast('The active form does not have any sections to place fields into.');
      return;
    }

    const targetSection = form.sections[0];
    const newFieldObj = JSON.parse(JSON.stringify(item.rawField || {}));
    newFieldObj.id = 'fld_' + Math.floor(Math.random() * 1000000);
    newFieldObj.formData = newFieldObj.formData || item.key;
    newFieldObj.label = newFieldObj.label || item.label;
    newFieldObj.type = newFieldObj.type || item.type;
    newFieldObj.col = newFieldObj.col || 'col-lg-6';

    targetSection.fields.push(newFieldObj);
    this.saveAllForms();
    this.renderCanvas();

    this._showToast(`Inserted "${item.label}" into section "${targetSection.title}"!`);
  },

  exportFieldsDirectoryCsv() {
    const list = this._fieldsDirectoryFiltered || this._fieldsDirectoryData || [];
    if (list.length === 0) {
      this._showToast('No fields to export.');
      return;
    }

    const headers = [
      'Field Display Name',
      'Field Key / ID',
      'Field Type',
      'Source / Classification',
      'Workfront Parameter (wfName)',
      'Workfront Custom Forms',
      'Frontend UI Intake Forms',
      'Total UI Form Usages',
      'Required',
      'Options Count'
    ];

    const rows = list.map(item => {
      const escapeCsv = (str) => {
        const val = String(str || '').replace(/"/g, '""');
        return `"${val}"`;
      };

      const wfFormsStr = (item.wfFormsList || []).join('; ');
      const uiFormsStr = (item.uiForms || []).map(u => `${u.formLabel} (${u.sectionTitle})`).join('; ');

      return [
        escapeCsv(item.label),
        escapeCsv(item.key),
        escapeCsv(item.type),
        escapeCsv(item.badge),
        escapeCsv(item.wfName),
        escapeCsv(wfFormsStr),
        escapeCsv(uiFormsStr),
        (item.uiForms || []).length,
        item.required ? 'Yes' : 'No',
        (item.options || []).length
      ].join(',');
    });

    const csvContent = '' + [headers.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    this._triggerDownload(url, `MOPS_Reusable_Fields_Inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    this._showToast(`Exported ${list.length} fields to CSV!`);
  }
});

/* --- WF Registries --- */
App._wfCustomFormsRegistry = null;
App._wfTemplatesRegistry = null;

App._initWfRegistries = function () {
  if (!this._wfCustomFormsRegistry) {
    var seed = this.WORKFRONT_FORMS_CATALOG || {};
    var rows = [];
    Object.keys(seed).forEach(function (fKey) {
      var v = seed[fKey];
      rows.push({ _rowId: fKey, name: v.name || '', wfId: v.id || '', frontendForm: fKey, notes: '' });
    });
    var extras = [
      { _rowId: 'email', name: 'Email Campaign Form', wfId: 'ea4210000083a06d1700c92bc09c3d20', frontendForm: 'email', notes: '' },
      { _rowId: 'social', name: 'Social Media Brief', wfId: 'b3f120000074b06d2600b93ce07c2d10', frontendForm: 'social', notes: '' },
      { _rowId: 'event', name: 'Event & Webinar Request', wfId: 'c5d230000085c17d3710e94df18e3e31', frontendForm: 'event', notes: '' },
      { _rowId: 'paid', name: 'Paid Media Intake', wfId: 'd6e340000096d28e4820f05e029f4f42', frontendForm: 'paid', notes: '' },
      { _rowId: 'report', name: 'Campaign Report Form', wfId: 'f8g560000018f4a06a40h27g24b6b64', frontendForm: 'report', notes: '' }
    ];
    extras.forEach(function (e) {
      if (!rows.find(function (r) { return r._rowId === e._rowId; })) rows.push(e);
    });
    this._wfCustomFormsRegistry = rows;
  }
  if (!this._wfTemplatesRegistry) {
    this._wfTemplatesRegistry = [
      { _rowId: 't1', name: 'Standard Campaign', wfId: 'TPL_01_STANDARD', description: 'General campaign intake template', category: 'Marketing' },
      { _rowId: 't2', name: 'Email Campaign', wfId: 'TPL_02_EMAIL', description: 'Template for email sends', category: 'Email' },
      { _rowId: 't3', name: 'Event & Webinar', wfId: 'TPL_03_EVENT', description: 'Events, webinars, seminars', category: 'Events' },
      { _rowId: 't4', name: 'Paid Social / Digital', wfId: 'TPL_04_PAID', description: 'Paid social & display media', category: 'Paid Media' },
      { _rowId: 't5', name: 'Content Syndication', wfId: 'TPL_05_SYNDICATION', description: '3rd-party content syndication', category: 'Content' },
      { _rowId: 't6', name: 'Partner / Channel', wfId: 'TPL_06_PARTNER', description: 'Channel & partner programs', category: 'Channel' },
      { _rowId: 't7', name: 'Executive Briefing', wfId: 'TPL_07_EXEC', description: 'EBC & executive events', category: 'Events' }
    ];
  }
};

App._wfFormRowChange = function (idx, field, val) { if (this._wfCustomFormsRegistry && this._wfCustomFormsRegistry[idx]) this._wfCustomFormsRegistry[idx][field] = val; };
App._wfTemplateRowChange = function (idx, field, val) { if (this._wfTemplatesRegistry && this._wfTemplatesRegistry[idx]) this._wfTemplatesRegistry[idx][field] = val; };
App._wfDeleteFormRow = function (idx) { if (this._wfCustomFormsRegistry) { this._wfCustomFormsRegistry.splice(idx, 1); this._renderCfgWfFormsTable(); this._updateCfgWfBadges(); } };
App._wfDeleteTemplateRow = function (idx) { if (this._wfTemplatesRegistry) { this._wfTemplatesRegistry.splice(idx, 1); this._renderCfgWfTplTable(); this._updateCfgWfBadges(); } };

App._updateCfgWfBadges = function () {
  var fl = (this._wfCustomFormsRegistry || []).length;
  var tl = (this._wfTemplatesRegistry || []).length;
  ['cfgWfFormsBadge', 'wfFormsBadge'].forEach(function (id) { var e = document.getElementById(id); if (e) e.textContent = fl; });
  ['cfgWfTplBadge', 'wfTemplatesBadge'].forEach(function (id) { var e = document.getElementById(id); if (e) e.textContent = tl; });
};

App._renderCfgWfFormsTable = function () {
  var tbody = document.getElementById('cfgWfFormsTbody');
  if (!tbody) return;
  var esc = this._escapeHtml ? this._escapeHtml.bind(this) : function (s) { return String(s || ''); };
  tbody.innerHTML = '';
  (this._wfCustomFormsRegistry || []).forEach(function (row, idx) {
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td><input type="text" class="mops-input" value="' + esc(row.name) + '" placeholder="Display Name" style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfFormRowChange(' + idx + ',\'name\',this.value);App._updateCfgWfBadges();"></td>' +
      '<td><input type="text" class="mops-input" value="' + esc(row.wfId) + '" placeholder="WF Form ID" style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfFormRowChange(' + idx + ',\'wfId\',this.value)"></td>' +
      '<td><input type="text" class="mops-input" value="' + esc(row.frontendForm) + '" placeholder="e.g. email" style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfFormRowChange(' + idx + ',\'frontendForm\',this.value)"></td>' +
      '<td><input type="text" class="mops-input" value="' + esc(row.notes) + '" placeholder="Notes..." style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfFormRowChange(' + idx + ',\'notes\',this.value)"></td>' +
      '<td style="text-align:center;"><button class="wf-cfg-btn-delete" title="Delete" onclick="App._wfDeleteFormRow(' + idx + ')">&#x1F5D1;</button></td>';
    tbody.appendChild(tr);
  });
};

App._renderCfgWfTplTable = function () {
  var tbody = document.getElementById('cfgWfTplTbody');
  if (!tbody) return;
  var esc = this._escapeHtml ? this._escapeHtml.bind(this) : function (s) { return String(s || ''); };
  tbody.innerHTML = '';
  (this._wfTemplatesRegistry || []).forEach(function (row, idx) {
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td><input type="text" class="mops-input" value="' + esc(row.name) + '" placeholder="Template Name" style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfTemplateRowChange(' + idx + ',\'name\',this.value);App._updateCfgWfBadges();"></td>' +
      '<td><input type="text" class="mops-input" value="' + esc(row.wfId) + '" placeholder="Template ID" style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfTemplateRowChange(' + idx + ',\'wfId\',this.value)"></td>' +
      '<td><input type="text" class="mops-input" value="' + esc(row.description) + '" placeholder="Description..." style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfTemplateRowChange(' + idx + ',\'description\',this.value)"></td>' +
      '<td><input type="text" class="mops-input" value="' + esc(row.category) + '" placeholder="Category" style="font-size:12.5px;padding:5px 8px;width:100%;" onchange="App._wfTemplateRowChange(' + idx + ',\'category\',this.value)"></td>' +
      '<td style="text-align:center;"><button class="wf-cfg-btn-delete" title="Delete" onclick="App._wfDeleteTemplateRow(' + idx + ')">&#x1F5D1;</button></td>';
    tbody.appendChild(tr);
  });
};

App.wfAddCustomFormRow = function () {
  this._initWfRegistries();
  this._wfCustomFormsRegistry.push({ _rowId: 'new_' + Date.now(), name: '', wfId: '', frontendForm: '', notes: '' });
  this._renderCfgWfFormsTable();
  this._updateCfgWfBadges();
  this._showToast('New row added', 'info');
};

App.wfAddTemplateRow = function () {
  this._initWfRegistries();
  this._wfTemplatesRegistry.push({ _rowId: 'new_' + Date.now(), name: '', wfId: '', description: '', category: '' });
  this._renderCfgWfTplTable();
  this._updateCfgWfBadges();
  this._showToast('New template row added', 'info');
};

App.saveWfConfigChanges = function () {
  this._populateWfSelectorsInFieldModal();
  this._showToast('Workfront configuration saved!', 'success');
};

App.wfConfigExportJson = function () {
  var data = { customForms: this._wfCustomFormsRegistry || [], templates: this._wfTemplatesRegistry || [], exportedAt: new Date().toISOString() };
  var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url; a.download = 'workfront-config.json'; a.click();
  URL.revokeObjectURL(url);
  this._showToast('Config exported as JSON', 'success');
};

App._renderWfFormsMultiCheckboxes = function (listElId, countElId, selectedIds, chkClass, onChangeFn) {
  this._initWfRegistries();
  var listEl = document.getElementById(listElId);
  if (!listEl) return;
  var selSet = new Set(Array.isArray(selectedIds) ? selectedIds.filter(Boolean) : (selectedIds ? [selectedIds] : []));
  listEl.innerHTML = '';
  var forms = (this._wfCustomFormsRegistry || []).filter(function (r) { return r.name || r.wfId; });
  if (forms.length === 0) {
    listEl.innerHTML = '<div style="font-size:11.5px; color:#94a3b8; padding:4px;">No Workfront custom forms registered yet.</div>';
  } else {
    forms.forEach(function (r) {
      var val = r._rowId || r.wfId;
      var label = r.name || r.wfId;
      var row = document.createElement('label');
      row.style.cssText = 'display:flex; align-items:center; gap:8px; padding:4px 6px; border-radius:4px; cursor:pointer; font-size:12px; color:#1e293b;';
      row.innerHTML = '<input type="checkbox" class="' + chkClass + '" value="' + val.replace(/"/g, '&quot;') + '" data-label="' + label.replace(/"/g, '&quot;') + '"' + (selSet.has(val) ? ' checked' : '') + ' onchange="' + onChangeFn + '"><span>' + label.replace(/</g, '&lt;') + '</span>';
      listEl.appendChild(row);
    });
  }
  var cntEl = document.getElementById(countElId);
  if (cntEl) {
    var checked = listEl.querySelectorAll('.' + chkClass + ':checked').length;
    cntEl.textContent = checked + ' selected';
  }
};

App._populateWfSelectorsInFieldModal = function (selectedIds) {
  this._renderWfFormsMultiCheckboxes('savedFieldWfFormsMultiList', 'savedFieldWfFormsCount', selectedIds, 'saved-field-wf-form-chk', 'App._updateWfFormMultiCount()');
};

App._updateWfFormMultiCount = function () {
  var cntEl = document.getElementById('savedFieldWfFormsCount');
  if (!cntEl) return;
  var checked = document.querySelectorAll('#savedFieldWfFormsMultiList .saved-field-wf-form-chk:checked').length;
  cntEl.textContent = checked + ' selected';
};

/* --- Configuration Screen --- */
App._cfgActiveTab = 'fields';
App._cfgWfSubTab = 'forms';

App.openConfigScreen = function (tab) {
  var screen = document.getElementById('screenConfiguration');
  if (!screen) return;
  screen.style.display = 'flex';
  var btn = document.getElementById('btnTopNavConfig');
  if (btn) btn.classList.add('active');
  this.switchConfigTab(tab || this._cfgActiveTab || 'fields');
};

App.closeConfigScreen = function () {
  var screen = document.getElementById('screenConfiguration');
  if (screen) screen.style.display = 'none';
  var btn = document.getElementById('btnTopNavConfig');
  if (btn) btn.classList.remove('active');
};

App.switchConfigTab = function (tab) {
  this._cfgActiveTab = tab;
  var navMap = { fields: 'cfgNavFields', mappings: 'cfgNavMappings', wfconfig: 'cfgNavWf' };
  var paneMap = { fields: 'cfgPaneFields', mappings: 'cfgPaneMappings', wfconfig: 'cfgPaneWf' };
  ['cfgNavFields', 'cfgNavMappings', 'cfgNavWf'].forEach(function (id) { var e = document.getElementById(id); if (e) e.classList.remove('active'); });
  var nav = document.getElementById(navMap[tab]); if (nav) nav.classList.add('active');
  ['cfgPaneFields', 'cfgPaneMappings', 'cfgPaneWf'].forEach(function (id) { var e = document.getElementById(id); if (e) e.style.display = 'none'; });
  var pane = document.getElementById(paneMap[tab]); if (pane) pane.style.display = 'block';
  if (tab === 'fields') this._loadCfgFields();
  if (tab === 'mappings') this._loadCfgMappings();
  if (tab === 'wfconfig') this._loadCfgWf();
};

App._loadCfgFields = function () {
  if (typeof this.collectFieldsDirectoryInventory === 'function') this.collectFieldsDirectoryInventory();
  this._renderCfgFieldsTable();
  this._updateCfgFieldsKpis();
};

App._updateCfgFieldsKpis = function () {
  var data = this._fieldsDirectoryData || [];
  var wfF = {}, uiF = {}, pl = 0;
  data.forEach(function (r) { (r.wfForms || []).forEach(function (f) { wfF[f] = 1; }); (r.uiForms || []).forEach(function (f) { uiF[f] = 1; pl++; }); });
  function set(id, v) { var e = document.getElementById(id); if (e) e.textContent = v; }
  set('cfgKpiTotal', data.length); set('cfgKpiWfForms', Object.keys(wfF).length);
  set('cfgKpiUiForms', Object.keys(uiF).length); set('cfgKpiPlacements', pl);
};

App._renderCfgFieldsTable = function () {
  var tbody = document.getElementById('cfgFieldsTableBody');
  if (!tbody) return;
  var esc = this._escapeHtml ? this._escapeHtml.bind(this) : function (s) { return String(s || '').replace(/</g, '&lt;'); };
  var data = (this._fieldsDirectoryData || []).slice();
  function getV(id) { var e = document.getElementById(id); return e ? e.value.trim().toLowerCase() : ''; }
  var search = getV('cfgFieldsSearch'), typeF = getV('cfgFilterType'), wfF = getV('cfgFilterWfForm'), uiF = getV('cfgFilterUiForm'), usageF = getV('cfgFilterUsage');
  if (search) data = data.filter(function (r) { return (r.label || '').toLowerCase().indexOf(search) > -1 || (r.key || '').toLowerCase().indexOf(search) > -1; });
  if (typeF) data = data.filter(function (r) { return r.type === typeF; });
  if (wfF) data = data.filter(function (r) { return (r.wfForms || []).some(function (f) { return f.toLowerCase().indexOf(wfF) > -1; }); });
  if (uiF) data = data.filter(function (r) { return (r.uiForms || []).some(function (f) { return f.toLowerCase().indexOf(uiF) > -1; }); });
  if (usageF === 'used') data = data.filter(function (r) { return (r.uiForms || []).length > 0; });
  if (usageF === 'unused') data = data.filter(function (r) { return (r.uiForms || []).length === 0; });
  if (!data.length) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:40px;color:#94a3b8;">No fields match.</td></tr>'; return; }
  var tl = { text: 'Text', select: 'Dropdown', multiselect_fancy: 'Multi-Select', date: 'Date', radio: 'Radio', text_area: 'Textarea', text_number: 'Number', file: 'File', visual_cards: 'Visual Cards', text_suggestion: 'Auto Suggest', checkbox: 'Checkbox', checkboxgroup: 'Checkbox Group' };
  tbody.innerHTML = data.map(function (r) {
    var type = tl[r.type] || r.type || '';
    var wfl = (r.wfForms || []).length ? r.wfForms.map(function (f) { return '<span style="background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;border-radius:4px;font-size:10.5px;padding:1px 6px;margin:1px 2px;display:inline-block;">' + esc(f) + '</span>'; }).join('') : '<span style="color:#94a3b8;font-size:11px;"></span>';
    var uil = (r.uiForms || []).length ? r.uiForms.map(function (f) { return '<span style="background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0;border-radius:4px;font-size:10.5px;padding:1px 6px;margin:1px 2px;display:inline-block;">' + esc(f) + '</span>'; }).join('') : '<span style="background:#fef9c3;color:#854d0e;border:1px solid #fde047;border-radius:4px;font-size:10px;padding:1px 6px;">Unused</span>';
    var attrs = [(r.required ? 'Required' : ''), (r.options && r.options.length ? r.options.length + ' opts' : '')].filter(Boolean).join('  ') || '';
    return '<tr><td><div style="font-weight:600;font-size:13px;color:#1e293b;">' + esc(r.label) + '</div><code style="font-family:monospace;font-size:11px;color:#64748b;display:block;">' + esc(r.key) + '</code></td><td><span style="background:#f1f5f9;color:#374151;border-radius:4px;font-size:11px;padding:2px 7px;font-weight:600;">' + esc(type) + '</span></td><td>' + wfl + '</td><td>' + uil + '</td><td style="font-size:11.5px;color:#64748b;">' + esc(attrs) + '</td><td><button class="btn btn-outline btn-xs" onclick="App.openFieldDirectoryDetailModal(\'' + esc(r.key) + '\')" style="font-size:10.5px;padding:2px 7px;">View</button></td></tr>';
  }).join('');
};

App.cfgResetFilters = function () {
  ['cfgFieldsSearch', 'cfgFilterType', 'cfgFilterWfForm', 'cfgFilterUiForm', 'cfgFilterUsage'].forEach(function (id) { var e = document.getElementById(id); if (e) e.value = ''; });
  this._renderCfgFieldsTable();
};

App._loadCfgMappings = function () {
  var sel = document.getElementById('cfgMappingSelector');
  if (!sel) return;
  var tables = window.MappingManager ? window.MappingManager.getTables() : [];
  var prev = sel.value;
  sel.innerHTML = '<option value="">Select a mapping table...</option>';
  tables.forEach(function (t) {
    var opt = document.createElement('option');
    opt.value = t.id;
    var rowCount = window.MappingManager.flattenToRows(t.id).length;
    opt.textContent = (t.title || t.name || t.id) + ' (' + rowCount + ' rows)';
    if (t.id === prev) opt.selected = true;
    sel.appendChild(opt);
  });
  if (!sel.value && tables.length > 0) {
    sel.value = tables[0].id;
  }
  this.onCfgMappingChange();
};

App._cfgRebuildTableFromRows = function (tableId, rows) {
  if (!window.MappingManager) return;
  var table = window.MappingManager.getTable(tableId);
  if (!table) return;
  table.nodes = [];
  var validRows = rows.filter(function (r) {
    return r.levels && r.levels[0] && r.levels[0].trim() !== '';
  });
  if (validRows.length > 0) {
    window.MappingManager.importRows(tableId, validRows);
  } else {
    window.MappingManager.save();
  }
};

App.onCfgMappingChange = function () {
  var sel = document.getElementById('cfgMappingSelector');
  var wrap = document.getElementById('cfgMappingTreeWrap');
  if (!sel || !wrap) return;
  var key = sel.value;
  if (!key) {
    wrap.innerHTML = '<div style="text-align:center; color:#94a3b8; padding:60px 0 40px; font-size:14px;">Select a mapping table above to view and edit its rows.</div>';
    return;
  }
  var table = window.MappingManager ? window.MappingManager.getTable(key) : null;
  if (!table) return;

  var levels = table.levelLabels || ['Level 1', 'Level 2', 'Level 3'];
  var allRows = window.MappingManager.flattenToRows(key);
  var searchVal = (document.getElementById('cfgMappingSearch')?.value || '').trim().toLowerCase();

  var esc = function (s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  };

  // Keep track of original index so edits/deletes map back even when filtered
  var indexedRows = allRows.map(function (r, idx) {
    return { idx: idx, levels: r.levels || [], code: r.code || '' };
  });
  var visibleRows = !searchVal ? indexedRows : indexedRows.filter(function (item) {
    var hay = (item.levels.join(' ') + ' ' + item.code).toLowerCase();
    return hay.indexOf(searchVal) !== -1;
  });

  // Build Excel-like table header
  var thCols = levels.map(function (lvl, cIdx) {
    return '<th style="background:#f1f5f9;color:#1e293b;font-size:12px;font-weight:700;padding:8px 10px;border-bottom:2px solid #cbd5e1;border-right:1px solid #e2e8f0;text-align:left;position:sticky;top:0;z-index:2;">' +
      '<span style="color:#64748b;font-weight:600;margin-right:4px;">Col ' + (cIdx + 1) + ':</span>' + esc(lvl) +
      '</th>';
  }).join('');

  var bodyHtml = visibleRows.map(function (item, vIdx) {
    var cellsHtml = levels.map(function (_, cIdx) {
      var val = item.levels[cIdx] || '';
      return '<td style="padding:0;border-bottom:1px solid #e2e8f0;border-right:1px solid #e2e8f0;">' +
        '<input type="text" value="' + esc(val) + '" data-row-idx="' + item.idx + '" data-col-idx="' + cIdx + '" ' +
        'onchange="App.cfgUpdateExcelCell(\'' + esc(table.id) + '\', ' + item.idx + ', ' + cIdx + ', this.value)" ' +
        'onkeydown="if(event.key===\'Enter\'){this.blur();}" ' +
        'style="width:100%;border:none;outline:none;padding:7px 10px;font-size:12.5px;background:transparent;color:#0f172a;box-sizing:border-box;" ' +
        'onfocus="this.style.background=\'#eff6ff\';this.style.boxShadow=\'inset 0 0 0 2px #005fb8\';" ' +
        'onblur="this.style.background=\'transparent\';this.style.boxShadow=\'none\';">' +
        '</td>';
    }).join('');

    return '<tr style="background:' + (vIdx % 2 === 0 ? '#ffffff' : '#fafbfc') + ';">' +
      '<td style="width:42px;text-align:center;font-size:11px;color:#94a3b8;font-weight:600;background:#f8fafc;border-bottom:1px solid #e2e8f0;border-right:1px solid #e2e8f0;">' + (item.idx + 1) + '</td>' +
      cellsHtml +
      '<td style="padding:0;border-bottom:1px solid #e2e8f0;border-right:1px solid #e2e8f0;width:120px;">' +
      '<input type="text" value="' + esc(item.code) + '" placeholder="—" ' +
      'onchange="App.cfgUpdateExcelCode(\'' + esc(table.id) + '\', ' + item.idx + ', this.value)" ' +
      'onkeydown="if(event.key===\'Enter\'){this.blur();}" ' +
      'style="width:100%;border:none;outline:none;padding:7px 10px;font-size:12px;font-family:monospace;background:transparent;color:#475569;box-sizing:border-box;" ' +
      'onfocus="this.style.background=\'#eff6ff\';this.style.boxShadow=\'inset 0 0 0 2px #005fb8\';" ' +
      'onblur="this.style.background=\'transparent\';this.style.boxShadow=\'none\';">' +
      '</td>' +
      '<td style="width:52px;text-align:center;border-bottom:1px solid #e2e8f0;padding:2px;">' +
      '<button type="button" onclick="App.cfgDeleteMappingRow(\'' + esc(table.id) + '\', ' + item.idx + ')" title="Delete row" ' +
      'style="border:none;background:transparent;color:#ef4444;cursor:pointer;font-size:13px;font-weight:700;padding:3px 7px;border-radius:4px;" ' +
      'onmouseover="this.style.background=\'#fee2e2\'" onmouseout="this.style.background=\'transparent\'">✕</button>' +
      '</td>' +
      '</tr>';
  }).join('');

  if (visibleRows.length === 0) {
    bodyHtml = '<tr><td colspan="' + (levels.length + 3) + '" style="text-align:center;color:#94a3b8;padding:28px;font-size:13px;">' +
      (searchVal ? 'No rows match "' + esc(searchVal) + '".' : 'This sheet is empty. Add a row below or paste from Excel!') +
      '</td></tr>';
  }

  // Quick-add row at the bottom (Excel-like blank new row)
  var quickInputsHtml = levels.map(function (lvl, cIdx) {
    return '<td style="padding:4px;border-right:1px solid #bfdbfe;background:#f0f9ff;">' +
      '<input type="text" id="cfgQuickAddLvl_' + cIdx + '" placeholder="+ ' + esc(lvl) + '" ' +
      'onkeydown="if(event.key===\'Enter\'){event.preventDefault();App.cfgAddQuickRow(\'' + esc(table.id) + '\');}" ' +
      'style="width:100%;border:1px solid #bae6fd;border-radius:4px;padding:5px 8px;font-size:12px;background:#fff;box-sizing:border-box;">' +
      '</td>';
  }).join('');

  var quickAddRowHtml =
    '<tr id="cfgQuickAddRow">' +
    '<td style="text-align:center;font-size:13px;font-weight:700;color:#0284c7;background:#f0f9ff;border-right:1px solid #bfdbfe;">+</td>' +
    quickInputsHtml +
    '<td style="padding:4px;border-right:1px solid #bfdbfe;background:#f0f9ff;width:120px;">' +
    '<input type="text" id="cfgQuickAddCode" placeholder="Code" ' +
    'onkeydown="if(event.key===\'Enter\'){event.preventDefault();App.cfgAddQuickRow(\'' + esc(table.id) + '\');}" ' +
    'style="width:100%;border:1px solid #bae6fd;border-radius:4px;padding:5px 8px;font-size:12px;font-family:monospace;background:#fff;box-sizing:border-box;">' +
    '</td>' +
    '<td style="padding:4px;text-align:center;background:#f0f9ff;">' +
    '<button type="button" class="btn btn-primary btn-sm" onclick="App.cfgAddQuickRow(\'' + esc(table.id) + '\')" style="font-size:11px;padding:4px 10px;background:#005fb8;">Add</button>' +
    '</td>' +
    '</tr>';

  // Live Cascade Preview Bar
  var previewSelectsHtml = levels.map(function (lvl, cIdx) {
    return '<div style="flex:1;min-width:150px;">' +
      '<label style="display:block;font-size:11px;font-weight:600;color:#475569;margin-bottom:3px;">' + esc(lvl) + '</label>' +
      '<select id="cfgPreviewLvl_' + cIdx + '" class="mops-select" onchange="App.cfgUpdateCascadePreview(\'' + esc(table.id) + '\', ' + cIdx + ')" style="font-size:12px;height:30px;padding:3px 8px;"></select>' +
      '</div>';
  }).join('');

  wrap.innerHTML =
    '<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#f8fafc;border-bottom:1px solid #e2e8f0;flex-wrap:wrap;gap:8px;">' +
    '<div>' +
    '<span style="font-weight:700;font-size:14px;color:#0f172a;">' + esc(table.title || table.name || key) + '</span>' +
    '<span style="font-size:12px;color:#64748b;margin-left:10px;">' + allRows.length + ' rows · Click any cell to edit</span>' +
    '</div>' +
    '<span style="font-size:11px;color:#64748b;">Tip: Press <strong>Enter</strong> in the bottom row to quickly add entries</span>' +
    '</div>' +
    '<div style="max-height:420px;overflow:auto;">' +
    '<table style="width:100%;border-collapse:collapse;table-layout:auto;">' +
    '<thead><tr>' +
    '<th style="width:42px;background:#f1f5f9;color:#64748b;font-size:11px;font-weight:700;padding:8px 6px;border-bottom:2px solid #cbd5e1;border-right:1px solid #e2e8f0;text-align:center;position:sticky;top:0;z-index:2;">#</th>' +
    thCols +
    '<th style="width:120px;background:#f1f5f9;color:#1e293b;font-size:12px;font-weight:700;padding:8px 10px;border-bottom:2px solid #cbd5e1;border-right:1px solid #e2e8f0;text-align:left;position:sticky;top:0;z-index:2;">Code</th>' +
    '<th style="width:52px;background:#f1f5f9;color:#64748b;font-size:11px;font-weight:700;padding:8px 6px;border-bottom:2px solid #cbd5e1;text-align:center;position:sticky;top:0;z-index:2;">Del</th>' +
    '</tr></thead>' +
    '<tbody>' + bodyHtml + quickAddRowHtml + '</tbody>' +
    '</table>' +
    '</div>' +
    '<div style="padding:12px 14px;background:#f8fafc;border-top:1px solid #e2e8f0;">' +
    '<div style="font-size:11.5px;font-weight:700;color:#334155;margin-bottom:8px;">Live Dropdown Test (How submitters will see these cascading fields):</div>' +
    '<div style="display:flex;gap:12px;flex-wrap:wrap;">' + previewSelectsHtml + '</div>' +
    '</div>';

  this.cfgUpdateCascadePreview(table.id, -1);
};

App.cfgUpdateExcelCell = function (tableId, rowIdx, colIdx, newVal) {
  if (!window.MappingManager) return;
  var rows = window.MappingManager.flattenToRows(tableId).map(function (r) {
    return { levels: (r.levels || []).slice(), code: r.code || '' };
  });
  if (!rows[rowIdx]) return;
  rows[rowIdx].levels[colIdx] = newVal.trim();
  this._cfgRebuildTableFromRows(tableId, rows);
  this.cfgUpdateCascadePreview(tableId, -1);
  this._showToast('Cell saved', 'success');
};

App.cfgUpdateExcelCode = function (tableId, rowIdx, newCode) {
  if (!window.MappingManager) return;
  var rows = window.MappingManager.flattenToRows(tableId).map(function (r) {
    return { levels: (r.levels || []).slice(), code: r.code || '' };
  });
  if (!rows[rowIdx]) return;
  rows[rowIdx].code = newCode.trim();
  this._cfgRebuildTableFromRows(tableId, rows);
  this._showToast('Code saved', 'success');
};

App.cfgDeleteMappingRow = function (tableId, rowIdx) {
  if (!window.MappingManager) return;
  var rows = window.MappingManager.flattenToRows(tableId).map(function (r) {
    return { levels: (r.levels || []).slice(), code: r.code || '' };
  });
  rows.splice(rowIdx, 1);
  this._cfgRebuildTableFromRows(tableId, rows);
  this._loadCfgMappings();
  var sel = document.getElementById('cfgMappingSelector');
  if (sel) sel.value = tableId;
  this.onCfgMappingChange();
  this._showToast('Row deleted', 'info');
};

App.cfgAddQuickRow = function (tableId) {
  if (!window.MappingManager) return;
  var table = window.MappingManager.getTable(tableId);
  if (!table) return;
  var levels = table.levelLabels || ['Level 1', 'Level 2', 'Level 3'];
  var vals = levels.map(function (_, idx) {
    return (document.getElementById('cfgQuickAddLvl_' + idx)?.value || '').trim();
  });
  if (!vals[0]) {
    this._showToast('Please enter a value for ' + (levels[0] || 'Column 1') + '.', 'warning');
    document.getElementById('cfgQuickAddLvl_0')?.focus();
    return;
  }
  var code = (document.getElementById('cfgQuickAddCode')?.value || '').trim();
  window.MappingManager.importRows(tableId, [{ levels: vals, code: code }]);
  this._loadCfgMappings();
  var sel = document.getElementById('cfgMappingSelector');
  if (sel) sel.value = tableId;
  this.onCfgMappingChange();
  this._showToast('Row added to sheet!', 'success');
  setTimeout(function () { document.getElementById('cfgQuickAddLvl_0')?.focus(); }, 30);
};

App.cfgFocusNewRow = function () {
  var inp = document.getElementById('cfgQuickAddLvl_0');
  if (inp) {
    inp.scrollIntoView({ behavior: 'smooth', block: 'center' });
    inp.focus();
  } else {
    this._showToast('Select a mapping table first.', 'warning');
  }
};

App.cfgToggleExcelPaste = function () {
  var box = document.getElementById('cfgExcelPasteBox');
  if (!box) return;
  var show = box.style.display === 'none';
  box.style.display = show ? 'block' : 'none';
  if (show) {
    setTimeout(function () { document.getElementById('cfgExcelPasteInput')?.focus(); }, 50);
  }
};

App.cfgImportExcelPaste = function () {
  var sel = document.getElementById('cfgMappingSelector');
  var tableId = sel ? sel.value : '';
  if (!tableId) {
    this._showToast('Please select a mapping table first.', 'warning');
    return;
  }
  var raw = (document.getElementById('cfgExcelPasteInput')?.value || '').trim();
  if (!raw) {
    this._showToast('Paste rows from Excel first.', 'warning');
    return;
  }
  var table = window.MappingManager ? window.MappingManager.getTable(tableId) : null;
  var numLevels = (table && table.levelLabels) ? table.levelLabels.length : 3;

  var lines = raw.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
  var parsedRows = [];
  lines.forEach(function (line) {
    var parts = line.indexOf('\t') !== -1 ? line.split('\t') : line.split(',');
    parts = parts.map(function (p) { return p.trim(); });
    if (!parts[0]) return;
    var rowLevels = parts.slice(0, numLevels);
    var code = parts.length > numLevels ? parts[numLevels] : '';
    parsedRows.push({ levels: rowLevels, code: code });
  });

  if (parsedRows.length === 0) {
    this._showToast('No valid rows found in pasted text.', 'warning');
    return;
  }

  window.MappingManager.importRows(tableId, parsedRows);
  document.getElementById('cfgExcelPasteInput').value = '';
  document.getElementById('cfgExcelPasteBox').style.display = 'none';
  this._loadCfgMappings();
  if (sel) sel.value = tableId;
  this.onCfgMappingChange();
  this._showToast('Imported ' + parsedRows.length + ' rows from Excel!', 'success');
};

App.cfgUpdateCascadePreview = function (tableId, changedIdx) {
  if (!window.MappingManager) return;
  var table = window.MappingManager.getTable(tableId);
  if (!table) return;
  var levels = table.levelLabels || ['Level 1', 'Level 2', 'Level 3'];

  var parentPath = [];
  for (var i = 0; i < levels.length; i++) {
    var selEl = document.getElementById('cfgPreviewLvl_' + i);
    if (!selEl) continue;

    if (changedIdx === -1 || i > changedIdx) {
      var opts = window.MappingManager.resolveOptions(tableId, parentPath);
      var prevVal = selEl.value;
      selEl.innerHTML = '<option value="">— Select ' + levels[i] + ' —</option>';
      opts.forEach(function (o) {
        var op = document.createElement('option');
        op.value = o.label;
        op.textContent = o.label + (o.code ? ' (' + o.code + ')' : '');
        selEl.appendChild(op);
      });
      if (i > changedIdx && changedIdx !== -1) {
        selEl.value = '';
      } else if (prevVal && opts.some(function (o) { return o.label === prevVal; })) {
        selEl.value = prevVal;
      }
      selEl.disabled = opts.length === 0;
    }
    if (selEl.value) {
      parentPath.push(selEl.value);
    } else {
      // Clear remaining downstream dropdowns
      for (var j = i + 1; j < levels.length; j++) {
        var downEl = document.getElementById('cfgPreviewLvl_' + j);
        if (downEl) {
          downEl.innerHTML = '<option value="">— Select ' + levels[j] + ' —</option>';
          downEl.disabled = true;
        }
      }
      break;
    }
  }
};

App.cfgExportMappingsCsv = function () {
  var sel = document.getElementById('cfgMappingSelector');
  var tableId = sel ? sel.value : '';
  if (!tableId || !window.MappingManager) {
    this._showToast('Please select a mapping table first.', 'warning');
    return;
  }
  var table = window.MappingManager.getTable(tableId);
  var rows = window.MappingManager.flattenToRows(tableId);
  var levels = (table && table.levelLabels) ? table.levelLabels : ['Level 1', 'Level 2', 'Level 3'];
  var csvEsc = function (v) {
    var s = String(v == null ? '' : v);
    return (s.indexOf(',') !== -1 || s.indexOf('"') !== -1) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  var lines = [levels.concat(['Code']).map(csvEsc).join(',')];
  rows.forEach(function (r) {
    var cols = levels.map(function (_, idx) { return (r.levels && r.levels[idx]) || ''; });
    cols.push(r.code || '');
    lines.push(cols.map(csvEsc).join(','));
  });
  var blob = new Blob([lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = (table.id || 'mapping-table') + '.csv';
  a.click();
  URL.revokeObjectURL(url);
  this._showToast('Downloaded Excel CSV!', 'success');
};

App.cfgOpenMappingHub = function (tableId) {
  var sel = document.getElementById('cfgMappingSelector');
  var targetId = tableId || (sel ? sel.value : null) || null;
  this.closeConfigScreen();
  var self = this;
  setTimeout(function () { if (typeof self.openMappingHubModal === 'function') self.openMappingHubModal(targetId); }, 80);
};

App.cfgAddNewMapping = function () {
  if (typeof this.openNewCascadeTableModal === 'function') {
    this.openNewCascadeTableModal();
  } else {
    this.cfgOpenMappingHub();
  }
};

App.exportMappingsJson = function () {
  var tables = window.MappingManager ? window.MappingManager.getTables() : [];
  var blob = new Blob([JSON.stringify(tables, null, 2)], { type: 'application/json' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a'); a.href = url; a.download = 'mapping-tables.json'; a.click();
  URL.revokeObjectURL(url);
  this._showToast('Mapping tables exported', 'success');
};

App._loadCfgWf = function () {
  this._initWfRegistries();
  this._renderCfgWfFormsTable();
  this._renderCfgWfTplTable();
  this._updateCfgWfBadges();
  this.switchCfgWfSubTab(this._cfgWfSubTab || 'forms');
};

App.switchCfgWfSubTab = function (tab) {
  this._cfgWfSubTab = tab;
  var pf = document.getElementById('cfgWfPaneForms'), pt = document.getElementById('cfgWfPaneTemplates');
  var bf = document.getElementById('cfgWfSubForms'), bt = document.getElementById('cfgWfSubTemplates');
  if (pf) pf.style.display = tab === 'forms' ? 'block' : 'none';
  if (pt) pt.style.display = tab === 'templates' ? 'block' : 'none';
  if (bf) bf.classList.toggle('active', tab === 'forms');
  if (bt) bt.classList.toggle('active', tab === 'templates');
};
