/**
 * Cisco MOPs FORM Studio - Forms Directory Tree Explorer Controller
 * Domain: Windows Explorer / VS Code collapsible tree navigation (Forms -> Sprints -> Versions -> Form JSON), node expansion, quick action buttons
 * File: js/modules/02-tree-controller.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
switchActiveForm(formId) {
    if (formId === this.activeFormId) return;

    // Save current form state back
    const current = this.allForms.find(f => f.id === this.activeFormId);
    if (current && this.formSchema && this.formSchema.sections && this.formSchema.sections.length > 0) {
      current.schema = this.formSchema;
    }

    // Switch
    this.activeFormId = formId;
    const next = this.allForms.find(f => f.id === formId);
    if (next) {
      if ((!next.schema || !next.schema.sections || next.schema.sections.length === 0) && next.versions?.length > 0) {
        const withSections = next.versions.filter(v => v.schema && v.schema.sections && v.schema.sections.length > 0);
        if (withSections.length > 0) {
          next.schema = JSON.parse(JSON.stringify(withSections[withSections.length - 1].schema));
        }
      }
      this.formSchema = next.schema;
    }

    // Close drawer, reset selection
    this.selectedFieldLoc = null;
    this.closeDrawer();

    this.saveAllForms();
    this.renderFormTabs();
    this.syncCanvasHeader();

    if (this.sprintDiffMode) {
      this.sprintDiffBaselineId = null;
      this.sprintDiffData = window.VersionManager.getSprintDiff(next, null);
      this.updateSprintDiffBarUI();
    }

    this.render();
  },

  formsViewMode: 'tree',
  _expandedTreeNodes: null,

  /**
   * Helper to resolve the sprint ID that contains a specific version ID
   */
  getSprintForVersion(form, versionId) {
    if (!form || !versionId) return null;
    const cleanVer = String(versionId).trim().toLowerCase();
    if (Array.isArray(form.sprints)) {
      for (const sp of form.sprints) {
        if (Array.isArray(sp.versions)) {
          if (sp.versions.some(v => {
            const vId = (typeof v === 'object' && v !== null ? v.versionId : v) || '';
            return String(vId).trim().toLowerCase() === cleanVer;
          })) {
            return sp.sprintId;
          }
        }
        if (sp.publishedVersionId && String(sp.publishedVersionId).trim().toLowerCase() === cleanVer) {
          return sp.sprintId;
        }
      }
    }
    return form.activeSprint || null;
  },

  _getExpandedTreeNodes() {
    if (!this._expandedTreeNodes) {
      this._expandedTreeNodes = new Set();
      // By default, auto-expand tree down to the latest sprint version node
      const targetForm = (this.activeFormId && this.allForms?.find(f => f.id === this.activeFormId)) ||
        (this.allForms?.find(f => f.id === 'test-form')) ||
        (this.allForms && this.allForms[0]);
      if (targetForm) {
        this._expandedTreeNodes.add(`form:${targetForm.id}`);
        this._expandedTreeNodes.add(`sprints:${targetForm.id}`);
        // Find latest sprint (Active status, activeSprint, or last sprint in list)
        let latestSprint = null;
        if (Array.isArray(targetForm.sprints) && targetForm.sprints.length > 0) {
          latestSprint = targetForm.sprints.find(s => s.status === 'Active' || s.sprintId === targetForm.activeSprint) ||
            targetForm.sprints[targetForm.sprints.length - 1];
        }
        if (latestSprint) {
          this._expandedTreeNodes.add(`sprint:${targetForm.id}:${latestSprint.sprintId}`);
          this._expandedTreeNodes.add(`vers:${targetForm.id}:${latestSprint.sprintId}`);
        }
      }
    }
    return this._expandedTreeNodes;
  },

  setFormsViewMode(mode) {
    this.formsViewMode = mode;
    const btnTree = document.getElementById('btnFormsViewTree');
    const btnCards = document.getElementById('btnFormsViewCards');
    const tools = document.getElementById('formsTreeTools');
    if (btnTree) btnTree.classList.toggle('active', mode === 'tree');
    if (btnCards) btnCards.classList.toggle('active', mode === 'cards');
    if (tools) tools.style.display = mode === 'tree' ? 'flex' : 'none';
    this.renderFormTabs();
  },

  toggleTreeNode(nodeKey, event) {
    if (event) {
      event.stopPropagation();
      event.preventDefault();
    }
    const set = this._getExpandedTreeNodes();
    if (set.has(nodeKey)) {
      set.delete(nodeKey);
    } else {
      set.add(nodeKey);
    }
    this.renderFormTabs();
  },

  expandAllTreeNodes() {
    const set = this._getExpandedTreeNodes();
    (this.allForms || []).forEach(form => {
      set.add(`form:${form.id}`);
      set.add(`sprints:${form.id}`);
      (form.sprints || []).forEach(s => {
        set.add(`sprint:${form.id}:${s.sprintId}`);
        set.add(`vers:${form.id}:${s.sprintId}`);
      });
    });
    this.renderFormTabs();
  },

  collapseAllTreeNodes() {
    this._expandedTreeNodes = new Set();
    this.renderFormTabs();
  },

  /**
   * Open a specific form version directly on the canvas
   */
  _isVersionReadOnly(form, sprint, version) {
    if (!form || !version) return false;
    const isExplicitlyLocked = Boolean(form.lockedVersions && form.lockedVersions.includes(version.versionId));
    const isHistoricalOrArchived = Boolean(
      (sprint && (sprint.status === 'Archived' || (sprint.publishedVersionId && version.versionId !== sprint.publishedVersionId))) ||
      version.status === 'Archived'
    );
    return isExplicitlyLocked || isHistoricalOrArchived;
  },

  openVersionFromTree(formId, versionId) {
    const form = (this.allForms || []).find(f => f.id === formId);
    if (!form) return;

    this.activeFormId = formId;
    this._userHasOpenedForm = true; // flag: user explicitly opened a form via version link

    let targetVer = (form.versions || []).find(v => v.versionId === versionId);
    let targetSprint = null;
    if (!targetVer && form.sprints) {
      for (const sp of form.sprints) {
        targetVer = (sp.versions || []).find(v => v.versionId === versionId);
        if (targetVer) { targetSprint = sp; break; }
      }
    }

    if (targetVer) {
      form.activeVersionId = targetVer.versionId;
      if (targetVer.sprint) form.activeSprint = targetVer.sprint;

      const isLocked = this._isVersionReadOnly(form, targetSprint, targetVer);
      form.readOnly = isLocked;

      if (targetVer.schema && targetVer.schema.sections) {
        this.formSchema = JSON.parse(JSON.stringify(targetVer.schema));
        this.formSchema.readOnly = isLocked;
        if (targetVer.formTitle || targetVer.title) {
          this.formSchema.title = targetVer.formTitle || targetVer.title;
        }
        // Ensure workfrontRouting is always present on opened schema
        if (!this.formSchema.workfrontRouting) {
          this.formSchema.workfrontRouting = {
            defaultTemplateId: "TEMPLATE_DART_WEB_PAGE",
            defaultTemplateLabel: "Standard Web Page Template",
            defaultCategoryIds: ["CATEGORY_DART_GLOBAL_PROJECT_DETAILS"],
            templateRules: [],
            categoryRules: []
          };
        }
        form.schema = this.formSchema;
      }
    }

    const expanded = this._getExpandedTreeNodes();
    expanded.add(`form:${formId}`);
    expanded.add(`sprints:${formId}`);
    if (form.activeSprint) {
      expanded.add(`sprint:${formId}:${form.activeSprint}`);
      expanded.add(`vers:${formId}:${form.activeSprint}`);
    }

    this.selectedFieldLoc = null;
    this.closeDrawer();
    this.sprintDiffMode = false;

    this.renderFormTabs();
    this.syncCanvasHeader();
    this.renderFormsTree();
    this.render();

    if (this.activeMode !== 'review' && !form.readOnly) {
      const wfLibBtn = document.querySelector('.sidebar-tab-btn[data-tab-content="tabPaneReusableFields"]');
      if (wfLibBtn && typeof this.switchSidebarTab === 'function') {
        this.switchSidebarTab('tabPaneReusableFields', wfLibBtn);
      }
      this._showToast(`Opened ${form.label || form.id} ${targetVer ? targetVer.versionId : versionId} — ready to add fields`);
    } else {
      this._showToast(`Opened ${form.label || form.id} ${targetVer ? targetVer.versionId : versionId}`);
    }
  },

  onTreeSprintClick(formId, sprintId, sprintNodeKey) {
    const expanded = this._getExpandedTreeNodes();
    expanded.add(sprintNodeKey);
    expanded.add(`vers:${formId}:${sprintId}`);

    const form = (this.allForms || []).find(f => f.id === formId);
    if (form) {
      const sp = (form.sprints || []).find(s => s.sprintId === sprintId);
      const targetVerId = sp?.publishedVersionId || (sp?.versions?.[sp.versions.length - 1]?.versionId);
      if (targetVerId) {
        this.openVersionFromTree(formId, targetVerId);
        return;
      }
    }
    this.renderFormTabs();
  },

  onTreeFormClick(formId, formNodeKey) {
    // Clicking the form root node only expands the tree  does NOT open the form on canvas.
    // To open the form, click the " FormName [Open]" link inside a specific version.
    const expanded = this._getExpandedTreeNodes();
    if (expanded.has(formNodeKey)) {
      expanded.delete(formNodeKey);
    } else {
      expanded.add(formNodeKey);
      expanded.add(`sprints:${formId}`);
      const form = this.allForms.find(f => f.id === formId);
      if (form) {
        (form.sprints || []).forEach(sp => {
          expanded.add(`sprint:${formId}:${sp.sprintId}`);
          expanded.add(`vers:${formId}:${sp.sprintId}`);
        });
      }
    }
    this.renderFormTabs();
  },

  renderFormTabs() {
    const sidebarList = document.getElementById('sidebarFormsList');
    const emptyState = document.getElementById('sidebarFormsEmpty');

    if (sidebarList) {
      sidebarList.innerHTML = '';

      if (!this.allForms || this.allForms.length === 0) {
        if (emptyState) emptyState.style.display = 'flex';
      } else {
        if (emptyState) emptyState.style.display = 'none';

        if (this.formsViewMode === 'cards') {
          this.renderFormCards(sidebarList);
        } else {
          this.renderFormsTree(sidebarList);
        }
      }
    }

    // Update status bar form title
    const statusTitle = document.getElementById('statusFormTitle');
    if (statusTitle) {
      const active = this.allForms.find(f => f.id === this.activeFormId);
      statusTitle.textContent = 'Form: ' + (active?.label || 'Untitled');
    }

    // Update navbar gallery label (kept for backward compat)
    const galleryLabel = document.getElementById('btnTabGalleryLabel');
    if (galleryLabel) {
      galleryLabel.textContent = `Form Gallery (${this.allForms.length})`;
    }
  },

  renderFormsTree(container) {
    const target = container || document.getElementById('sidebarFormsList');
    if (!target) return;
    target.innerHTML = '';
    const tree = document.createElement('div');
    tree.className = 'forms-tree-view';
    const expanded = this._getExpandedTreeNodes();

    const folderIconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="#f59e0b" stroke="#d97706" stroke-width="0.8"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>`;
    const fileIconSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`;

    this.allForms.forEach(form => {
      const isSelected = form.id === this.activeFormId;
      const isFormActive = form.active !== false;
      const isReadOnly = form.readOnly === true;
      const formNodeKey = `form:${form.id}`;
      const isFormExpanded = expanded.has(formNodeKey);

      // --- 1. Form Root Node (Level 0) ---
      const formRow = document.createElement('div');
      formRow.className = `ft-node ft-level-0 ${isSelected ? 'is-active-form' : ''} ${!isFormActive ? 'form-inactive' : ''}`;
      formRow.title = `${form.label || form.id}  Click to expand sprints`;

      // Resolve display version badge (fallback to latest existing version if activeVersionId was deleted)
      const allVers = [];
      (form.sprints || []).forEach(sp => (sp.versions || []).forEach(v => allVers.push(v)));
      (form.versions || []).forEach(v => allVers.push(v));
      const hasActiveVer = form.activeVersionId && allVers.some(v => v.versionId === form.activeVersionId);
      const displayVerId = hasActiveVer
        ? form.activeVersionId
        : (allVers.length > 0 ? allVers[allVers.length - 1].versionId : (form.activeVersionId || 'v1.0'));

      formRow.innerHTML = `
        <span class="ft-arrow ${isFormExpanded ? 'expanded' : ''}" onclick="App.toggleTreeNode('${formNodeKey}', event)">></span>
        <span class="ft-icon folder">${folderIconSvg}</span>
        <div class="ft-content" onclick="App.onTreeFormClick('${form.id}', '${formNodeKey}')">
          <span class="ft-label">${form.icon ? form.icon + ' ' : ''}${form.label || form.id}</span>
          <span class="ft-badge badge-blue">${displayVerId}</span>
          ${!isFormActive ? '<span class="ft-badge" style="color:#ef4444;">Inactive</span>' : ''}
        </div>
        <div class="ft-actions">
          <button type="button" class="ft-action-btn ft-rename-btn" onclick="event.stopPropagation(); App.promptRenameForm('${form.id}', event)" title="Rename Form ${form.label || form.id}">
            Rename
          </button>
          <button type="button" class="ft-action-btn ft-sprint-btn" onclick="event.stopPropagation(); App.promptCloneForm('${form.id}', event)" title="Clone Form ${form.label || form.id}">
            Clone
          </button>
          <button type="button" class="ft-action-btn ft-sprint-btn" onclick="event.stopPropagation(); App.openCreateNewSprintModal('${form.id}')" title="Add Sprint to ${form.label || form.id}">
            + Sprint
          </button>
          <button type="button" class="ft-action-btn del" onclick="App.deleteForm('${form.id}', event)" title="Delete Form ${form.label || form.id}">
            Delete
          </button>
        </div>
      `;
      tree.appendChild(formRow);

      if (!isFormExpanded) return;

      // --- 2. Sprints Subfolder (Level 1) ---
      const sprints = form.sprints || [];
      const sprintsNodeKey = `sprints:${form.id}`;
      const isSprintsExpanded = expanded.has(sprintsNodeKey);

      const sprintsRow = document.createElement('div');
      sprintsRow.className = 'ft-node ft-level-1';
      sprintsRow.title = `Sprint Releases (${sprints.length})`;
      sprintsRow.innerHTML = `
        <span class="ft-arrow ${isSprintsExpanded ? 'expanded' : ''}" onclick="App.toggleTreeNode('${sprintsNodeKey}', event)">></span>
        <span class="ft-icon folder">${folderIconSvg}</span>
        <div class="ft-content" onclick="App.toggleTreeNode('${sprintsNodeKey}', event)">
          <span class="ft-label">sprints</span>
          <span class="ft-badge">${sprints.length}</span>
        </div>
        <div class="ft-actions" style="opacity:1; display:flex;">
          <button type="button" class="ft-action-btn ft-sprint-btn" onclick="event.stopPropagation(); App.openCreateNewSprintModal('${form.id}')" title="Add Sprint to ${form.label || form.id}">
            + Sprint
          </button>
        </div>
      `;
      tree.appendChild(sprintsRow);

      if (isSprintsExpanded) {
        if (sprints.length === 0 && form.versions && form.versions.length > 0) {
          form.versions.forEach(v => {
            const isVerActive = v.versionId === form.activeVersionId && isSelected;
            const vRow = document.createElement('div');
            vRow.className = `ft-node ft-level-2 ${isVerActive ? 'is-active-version' : ''}`;
            vRow.title = `Open ${v.versionId} on canvas`;
            vRow.onclick = () => App.openVersionFromTree(form.id, v.versionId);
            vRow.innerHTML = `
              <span class="ft-arrow-spacer"></span>
              <span class="ft-icon file">${fileIconSvg}</span>
              <div class="ft-content">
                <span class="ft-label">${v.versionId}.json</span>
                ${isVerActive ? '<span class="ft-badge badge-green">Active</span>' : ''}
              </div>
              <div class="ft-actions" style="opacity:1; display:flex;">
                <button type="button" class="ft-action-btn ft-diff-btn"
                  onclick="event.stopPropagation(); App.showVersionChangeHistory('${form.id}', '${v.versionId}')"
                  title="See what changed in ${v.versionId} from previous version">
                   Changes
                </button>
              </div>
            `;
            tree.appendChild(vRow);
          });
        } else {
          sprints.forEach(sp => {
            const sprintNodeKey = `sprint:${form.id}:${sp.sprintId}`;
            const isSprintExpanded = expanded.has(sprintNodeKey);
            const isSprintActive = sp.status === 'Active' || sp.sprintId === form.activeSprint;

            const spRow = document.createElement('div');
            spRow.className = 'ft-node ft-level-2';
            spRow.title = `${sp.sprintLabel || sp.sprintId} (${sp.status || 'Active'})  Click to open sprint`;
            spRow.innerHTML = `
              <span class="ft-arrow ${isSprintExpanded ? 'expanded' : ''}" onclick="App.toggleTreeNode('${sprintNodeKey}', event)">></span>
              <span class="ft-icon folder">${folderIconSvg}</span>
              <div class="ft-content" onclick="App.onTreeSprintClick('${form.id}', '${sp.sprintId}', '${sprintNodeKey}')">
                <span class="ft-label">${sp.sprintLabel || sp.sprintId}</span>
                <span class="ft-badge ${isSprintActive ? 'badge-green' : 'badge-purple'}">${sp.status || 'Active'}</span>
              </div>
              <div class="ft-actions" style="opacity:1; display:flex; gap:3px;">
                <button type="button" class="ft-action-btn ft-rename-btn" onclick="event.stopPropagation(); App.promptRenameSprint('${form.id}', '${sp.sprintId}', event)" title="Rename Sprint ${sp.sprintLabel || sp.sprintId}">
                   Rename
                </button>
              </div>
            `;
            tree.appendChild(spRow);

            if (isSprintExpanded) {
              const versNodeKey = `vers:${form.id}:${sp.sprintId}`;
              const isVersExpanded = expanded.has(versNodeKey);

              // 1. Ensure spVersions is a valid array of versions
              let spVersions = [];
              if (Array.isArray(sp.versions)) {
                spVersions = sp.versions;
              } else if (sp.versions && typeof sp.versions === 'object') {
                spVersions = [sp.versions];
              }

              // Fallback: match from form.versions by sprint label or ID
              if (spVersions.length === 0 && Array.isArray(form.versions) && form.versions.length > 0) {
                const spNorm = (sp.sprintId || sp.sprintLabel || '').toLowerCase().replace(/[^a-z0-9]/g, '');
                spVersions = form.versions.filter(v => {
                  const vSp = (v.sprint || v.sprintId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
                  const vId = (v.versionId || '').toLowerCase();
                  return (vSp && spNorm && (vSp === spNorm || vSp.includes(spNorm) || spNorm.includes(vSp))) ||
                    (sp.publishedVersionId && vId === sp.publishedVersionId.toLowerCase());
                });
              }

              const versSubRow = document.createElement('div');
              versSubRow.className = 'ft-node ft-level-3';
              versSubRow.innerHTML = `
                <span class="ft-arrow ${isVersExpanded ? 'expanded' : ''}" onclick="App.toggleTreeNode('${versNodeKey}', event)">></span>
                <span class="ft-icon folder">${folderIconSvg}</span>
                <div class="ft-content" onclick="App.toggleTreeNode('${versNodeKey}', event)">
                  <span class="ft-label">versions</span>
                  <span class="ft-badge">${spVersions.length}</span>
                </div>
                <div class="ft-actions" style="opacity:1; display:flex;">
                  <button type="button" class="ft-action-btn ft-sprint-btn"
                    onclick="event.stopPropagation(); App.openAddVersionModal('${form.id}', '${sp.sprintId}')"
                    title="Add new version to ${sp.sprintLabel || sp.sprintId}">
                    + Version
                  </button>
                </div>
              `;
              tree.appendChild(versSubRow);

              if (isVersExpanded) {
                spVersions.forEach(v => {
                  const isVerActive = v.versionId === form.activeVersionId && isSelected;
                  const isVerLocked = this._isVersionReadOnly(form, sp, v);

                  // --- Version file row (Level 4) ---
                  const vRow = document.createElement('div');
                  vRow.className = `ft-node ft-level-4 ${isVerActive ? 'is-active-version' : ''}`;
                  vRow.title = `Click to open ${v.versionId} on canvas`;
                  vRow.onclick = () => App.openVersionFromTree(form.id, v.versionId);
                  vRow.innerHTML = `
                    <span class="ft-arrow-spacer"></span>
                    <span class="ft-icon file">${fileIconSvg}</span>
                    <div class="ft-content">
                      <span class="ft-label">${v.versionId}.json</span>
                      ${isVerActive ? '<span class="ft-badge badge-green">Active</span>' : ''}
                      ${isVerLocked ? '<span class="ft-badge badge-lock"> Read Only</span>' : ''}
                      ${v.stats?.fieldCount ? `<span class="ft-sublabel">${v.stats.fieldCount} fields</span>` : ''}
                    </div>
                    <div class="ft-actions">
                      <button type="button" class="ft-action-btn ft-diff-btn"
                        onclick="event.stopPropagation(); App.showVersionChangeHistory('${form.id}', '${v.versionId}')"
                        title="View what changed in ${v.versionId} from previous version">
                        Changes
                      </button>
                      <button type="button" class="ft-action-btn del"
                        onclick="event.stopPropagation(); App.promptDeleteVersion('${form.id}', '${v.versionId}', event)"
                        title="Delete Version ${v.versionId}">
                        Delete
                      </button>
                    </div>
                  `;
                  tree.appendChild(vRow);

                  // --- Form Name Link row (Level 5)  click to open, lock to toggle read-only ---
                  const formLinkRow = document.createElement('div');
                  formLinkRow.className = `ft-node ft-level-5 ft-form-link ${isVerActive ? 'is-active-form-link' : ''} ${isVerLocked ? 'ft-form-link-locked' : ''}`;

                  // Use version's own form title if set; fallback to form's base label
                  const verDisplayName = v.formTitle || v.title ||
                    (v.schema?.title && v.schema.title !== 'TestForm - Multi-Sprint and Flow Validation Form' ? v.schema.title : null) ||
                    form.label || form.id;

                  formLinkRow.title = isVerLocked
                    ? `${verDisplayName} (${v.versionId}) - Read Only (click Unlock to allow edits)`
                    : `Click to open ${verDisplayName} (${v.versionId})`;
                  formLinkRow.innerHTML = `
                    <span class="ft-arrow-spacer"></span>
                    <span class="ft-icon file" style="font-size:13px;">${fileIconSvg}</span>
                    <div class="ft-content" onclick="App.openVersionFromTree('${form.id}', '${v.versionId}')" style="flex:1; cursor:pointer;">
                      <span class="ft-label ft-form-name-link" style="color: ${isVerLocked ? '#92400e' : '#005fb8'}; font-weight: 600;">
                        ${form.icon ? form.icon + ' ' : ''}${verDisplayName}
                      </span>
                      <span class="ft-badge ${isVerLocked ? 'badge-lock' : 'badge-blue'} ft-open-badge">
                        ${isVerLocked ? 'Read Only' : 'Open'}
                      </span>
                    </div>
                    <div class="ft-actions">
                      <button type="button" class="ft-action-btn ft-lock-btn ${isVerLocked ? 'locked' : ''}"
                        onclick="App.toggleVersionReadOnly('${form.id}', '${v.versionId}', event)"
                        title="${isVerLocked ? 'Unlock - allow edits to this version' : 'Lock - protect this version as read-only'}">
                        ${isVerLocked ? 'Unlock' : 'Lock'}
                      </button>
                    </div>
                  `;
                  tree.appendChild(formLinkRow);
                });
              }

              // sprint.json
              const spJsonRow = document.createElement('div');
              spJsonRow.className = 'ft-node ft-level-3';
              spJsonRow.title = `sprint.json for ${sp.sprintId}`;
              spJsonRow.onclick = () => App.onTreeSprintClick(form.id, sp.sprintId, sprintNodeKey);
              spJsonRow.innerHTML = `
                <span class="ft-arrow-spacer"></span>
                <span class="ft-icon file">${fileIconSvg}</span>
                <div class="ft-content">
                  <span class="ft-label">sprint.json</span>
                  ${sp.publishedVersionId ? `<span class="ft-sublabel">pub: ${sp.publishedVersionId}</span>` : ''}
                </div>
              `;
              tree.appendChild(spJsonRow);
            }
          });
        }
      }

      // --- 3. Direct Form Files (Level 1) ---
      const formJsonRow = document.createElement('div');
      formJsonRow.className = 'ft-node ft-level-1';
      formJsonRow.title = 'form.json  Working Schema (Click to open form)';
      formJsonRow.onclick = () => {
        App.onTreeFormClick(form.id, formNodeKey);
      };
      formJsonRow.innerHTML = `
        <span class="ft-arrow-spacer"></span>
        <span class="ft-icon file">${fileIconSvg}</span>
        <div class="ft-content">
          <span class="ft-label">form.json</span>
          <span class="ft-badge badge-orange">${form.schema?.sections?.length || 0} secs</span>
        </div>
      `;
      tree.appendChild(formJsonRow);

      const manifestJsonRow = document.createElement('div');
      manifestJsonRow.className = 'ft-node ft-level-1';
      manifestJsonRow.title = 'manifest.json  Metadata Configuration';
      manifestJsonRow.innerHTML = `
        <span class="ft-arrow-spacer"></span>
        <span class="ft-icon file">${fileIconSvg}</span>
        <div class="ft-content">
          <span class="ft-label">manifest.json</span>
          <span class="ft-sublabel">config</span>
        </div>
      `;
      tree.appendChild(manifestJsonRow);
    });

    target.appendChild(tree);
  },

  renderFormCards(sidebarList) {
    this.allForms.forEach(form => {
      const isSelected = form.id === this.activeFormId;
      const isFormActive = form.active !== false;
      const verCount = form.versions?.length || 1;
      const activeVer = form.activeVersionId || 'v1.0';

      const card = document.createElement('div');
      card.className = 'sidebar-form-card' + (isSelected ? ' active' : '') + (!isFormActive ? ' form-inactive' : '');
      card.dataset.formId = form.id;
      card.title = `${form.schema?.title || form.label}  ${isFormActive ? 'Active' : 'Inactive'}`;
      card.innerHTML = `
        <div class="sfc-main" onclick="App.switchActiveForm('${form.id}')">
          <div class="sfc-icon">${form.icon || ''}</div>
          <div class="sfc-info">
            <div class="sfc-name-row" style="display: flex; align-items: center; justify-content: space-between; gap: 4px;">
              <span class="sfc-name" style="${!isFormActive ? 'color: #94a3b8; text-decoration: line-through;' : ''}">${form.schema?.title || form.label}</span>
              <span class="sfc-status-dot ${isFormActive ? 'status-active' : 'status-inactive'}" title="${isFormActive ? 'Form is Active in Workfront' : 'Form is Inactive / Disabled'}"></span>
            </div>
            <div class="sfc-meta">
              <span class="sfc-ver-badge">${activeVer}</span>
              <span class="sfc-ver-count">${verCount} ver</span>
              ${!isFormActive ? '<span class="sfc-inactive-pill">Inactive</span>' : ''}
            </div>
          </div>
        </div>
        <div class="sfc-actions">
          <button type="button" class="sfc-action-btn" onclick="App.toggleFormActiveStatus('${form.id}', event)" title="${isFormActive ? 'Mark Inactive (disable form)' : 'Mark Active (enable form)'}">
            ${isFormActive ? '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>' : '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>'}
          </button>
          <button type="button" class="sfc-action-btn sfc-del-btn" onclick="App.deleteForm('${form.id}', event)" title="Delete form">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
          </button>
        </div>
        ${isSelected ? `<div class="sfc-active-indicator" title="Currently editing"></div>` : ''}
      `;
      sidebarList.appendChild(card);
    });

    setTimeout(() => {
      const activeCard = sidebarList.querySelector('.sidebar-form-card.active');
      if (activeCard) activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 50);
  }
});
