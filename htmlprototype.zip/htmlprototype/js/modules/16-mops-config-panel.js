/**
 * Cisco MOPs FORM Studio - MOPs Config Studio Panel
 * Domain: Side slide-in drawer showing complete JSON / Angular TypeScript config for MOPs Form Studio
 * File: js/modules/16-mops-config-panel.js
 * Architecture: Extends window.App with domain methods
 */

window.App = window.App || {};

Object.assign(window.App, {
openMopsConfigPanel(versionId = null) {
    const backdrop = document.getElementById('mopsConfigPanelBackdrop');
    if (!backdrop) return;

    // Store the versionId to view (null = current working version)
    this._dcpViewingVersionId = versionId;

    this._renderMopsConfigPanel();

    backdrop.style.display = 'flex';
    // Trigger CSS open state on next frame for animation
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        backdrop.classList.add('open');
      });
    });

    // Close on Escape
    this._dcpEscHandler = (e) => { if (e.key === 'Escape') this.closeMopsConfigPanel(); };
    document.addEventListener('keydown', this._dcpEscHandler);
  },

  closeMopsConfigPanel() {
    const backdrop = document.getElementById('mopsConfigPanelBackdrop');
    if (!backdrop) return;
    backdrop.classList.add('closing');
    backdrop.classList.remove('open');
    setTimeout(() => {
      backdrop.style.display = 'none';
      backdrop.classList.remove('closing');
    }, 250);
    if (this._dcpEscHandler) {
      document.removeEventListener('keydown', this._dcpEscHandler);
      this._dcpEscHandler = null;
    }
  },

  onDcpVersionChange(versionId) {
    this._dcpViewingVersionId = versionId;
    this._renderMopsConfigPanel();
  },

  /**
   * Core renderer: builds all sections of the Config Studio panel
   * from the selected version's stored schema snapshot.
   */
  _renderMopsConfigPanel() {
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    if (!active) return;

    window.VersionManager.ensureFormVersions(active);

    // Resolve which version/schema to use
    let schema, version;
    const vid = this._dcpViewingVersionId;
    if (vid && active.versions) {
      version = active.versions.find(v => v.versionId === vid);
      schema = version ? JSON.parse(JSON.stringify(version.schema || active.schema)) : this.formSchema;
    } else {
      schema = this.formSchema;
      version = window.VersionManager.getActiveVersion(active);
    }

    const allVersions = active.versions || [];
    const configFile = active.configFile || `form.${(active.id || 'config').toLowerCase().replace(/[^a-z0-9]/g, '-')}.config.ts`;
    const versionId = version?.versionId || active.activeVersionId || 'v1.0';
    const sprint = version?.sprint || active.activeSprint || 'Current';
    const isArchived = version?.status === 'Archived';

    // 1. Header: config filename
    const titleEl = document.getElementById('dcpTitle');
    if (titleEl) titleEl.textContent = configFile;

    // 2. Populate version selector
    const vSelect = document.getElementById('dcpVersionSelect');
    if (vSelect) {
      vSelect.innerHTML = '';
      // Always add "Working Copy" at top if not viewing a named snapshot
      const wc = document.createElement('option');
      wc.value = '';
      wc.textContent = ` Working Copy (Live)`;
      wc.selected = !vid;
      vSelect.appendChild(wc);

      // Versions newest-first
      [...allVersions].reverse().forEach(v => {
        const opt = document.createElement('option');
        opt.value = v.versionId;
        const statusIcon = v.status === 'Active' ? 'OK' : v.status === 'Archived' ? '' : '';
        opt.textContent = `${statusIcon} ${v.versionId} (${v.sprint || ''}) ${v.status === 'Active' ? ' ACTIVE' : ''}`;
        opt.selected = v.versionId === vid;
        vSelect.appendChild(opt);
      });
    }

    // 3. Version status pill
    const statusEl = document.getElementById('dcpVersionStatus');
    if (statusEl) {
      statusEl.textContent = isArchived ? 'Archived' : (!vid ? 'Working' : (version?.status || 'Active'));
      statusEl.className = 'dcp-version-status' + (isArchived ? ' archived' : '');
    }

    // 4. Sprint chip
    const sprintEl = document.getElementById('dcpSprintChip');
    if (sprintEl) sprintEl.textContent = sprint;

    // 5. File path meta
    const filePathEl = document.getElementById('dcpFilePath');
    if (filePathEl) filePathEl.textContent = `src/app/config/${configFile}`;

    // 6. Stats
    const sections = schema?.sections || [];
    const fieldCount = sections.reduce((n, s) => n + (s.fields?.length || 0), 0);
    const ruleCount = sections.reduce((n, s) => n + (s.fields || []).filter(f => f.condition && f.condition !== true).length, 0);
    const secEl = document.getElementById('dcpSectionCount');
    const fldEl = document.getElementById('dcpFieldCount');
    const rulEl = document.getElementById('dcpRuleCount');
    if (secEl) secEl.textContent = `${sections.length} section${sections.length !== 1 ? 's' : ''}`;
    if (fldEl) fldEl.textContent = `${fieldCount} field${fieldCount !== 1 ? 's' : ''}`;
    if (rulEl) rulEl.textContent = `${ruleCount} rule${ruleCount !== 1 ? 's' : ''}`;

    // 7. Download filename chip
    const dlFnEl = document.getElementById('dcpDownloadFilename');
    if (dlFnEl) dlFnEl.textContent = configFile;

    // 8. Generate TypeScript code
    const formMeta = { activeVersionId: versionId, activeSprint: sprint, configFile };
    const tsCode = window.Exporter.generateMopsTypeScript(schema, formMeta);
    this._dcpCurrentCode = tsCode;

    // 9. Render with syntax highlighting + line numbers
    this.renderMopsConfigCode(tsCode);

    // 10. Footer timestamp
    const tsEl = document.getElementById('dcpTimestamp');
    if (tsEl) tsEl.textContent = `Generated ${new Date().toLocaleTimeString()}`;
  },

  /**
   * Renders the TypeScript code into the line-numbered, syntax-highlighted table.
   */
  renderMopsConfigCode(code) {
    const tbody = document.getElementById('dcpCodeBody');
    if (!tbody) return;

    const lines = (code || '').split('\n');
    const fragment = document.createDocumentFragment();

    lines.forEach((rawLine, i) => {
      const tr = document.createElement('tr');

      // Line number cell
      const numTd = document.createElement('td');
      numTd.className = 'dcp-line-num';
      numTd.textContent = i + 1;
      tr.appendChild(numTd);

      // Code cell with syntax highlighting
      const codeTd = document.createElement('td');
      codeTd.className = 'dcp-line-code';
      codeTd.innerHTML = this._highlightTsLine(rawLine);
      tr.appendChild(codeTd);

      fragment.appendChild(tr);
    });

    tbody.innerHTML = '';
    tbody.appendChild(fragment);
  },

  /**
   * Lightweight TypeScript line highlighter.
   */
  _highlightTsLine(line) {
    // Escape HTML first
    const esc = line
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Apply syntax coloring via regex replacements (order matters)
    return esc
      // Comments (// ...)
      .replace(/(\/\/.*$)/g, '<span class="ts-comment">$1</span>')
      // Strings  double quoted
      .replace(/("(?:[^"\\]|\\.)*")/g, '<span class="ts-string">$1</span>')
      // Strings  single quoted
      .replace(/('(?:[^'\\]|\\.)*')/g, '<span class="ts-string">$1</span>')
      // Booleans
      .replace(/\b(true|false|null|undefined)\b/g, '<span class="ts-bool">$1</span>')
      // Numbers
      .replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="ts-number">$1</span>')
      // TypeScript / JS keywords
      .replace(/\b(import|export|const|let|var|from|type|interface|enum|return|if|else|function|async|await|class|new|this|of|in)\b/g, '<span class="ts-keyword">$1</span>')
      // TYPE_ constants
      .replace(/\b(TYPE_[A-Z_]+)\b/g, '<span class="ts-type">$1</span>')
      // Object keys (word before a colon)
      .replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)(?=\s*:)/g, '<span class="ts-prop">$1</span>');
  },

  /** Download the currently displayed config as a .ts file */
  downloadMopsConfigTs() {
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const configFile = active?.configFile || `form.${(active?.id || 'config').toLowerCase().replace(/[^a-z0-9]/g, '-')}.config.ts`;
    const code = this._dcpCurrentCode || '';

    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });

    if (window.showSaveFilePicker) {
      window.showSaveFilePicker({
        suggestedName: configFile,
        types: [{ description: 'TypeScript file', accept: { 'text/plain': ['.ts'] } }]
      }).then(async (handle) => {
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        this._dcpFlashSuccess('dcpBtnDownload', 'OK Saved!', ' Download');
      }).catch(() => {
        this._fallbackDownload(blob, configFile);
      });
    } else {
      this._fallbackDownload(blob, configFile);
    }
  },

  _fallbackDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
    this._dcpFlashSuccess('dcpBtnDownload', 'OK Downloaded!', ' Download');
  },

  /** Copy the config code to clipboard */
  async copyMopsConfigToClipboard() {
    const code = this._dcpCurrentCode || '';
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    this._dcpFlashSuccess('dcpBtnCopy', 'OK Copied!', ' Copy');
  },

  /** Open config in new tab as plain text */
  openMopsConfigInNewTab() {
    const code = this._dcpCurrentCode || '';
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  },

  /** Flash a success state on a button then restore its label */
  _dcpFlashSuccess(btnId, successText, originalText) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.classList.add('success');
    const prevHtml = btn.innerHTML;
    btn.innerHTML = successText;
    setTimeout(() => {
      btn.innerHTML = prevHtml;
      btn.classList.remove('success');
    }, 1800);
  }
});
