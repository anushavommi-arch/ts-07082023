/**
 * MOPS Form Mockup & Rule Studio - Workfront Routing Engine
 *
 * Resolves the Workfront Template ID and Custom Form (Category) IDs
 * dynamically from live form values and the form schema's workfrontRouting config.
 *
 * Design mirrors the existing RuleEngine (display logic) pattern:
 *   - Same condition evaluator: RuleEngine.evaluateCondition()
 *   - Template rules: priority-ordered, first-match wins
 *   - Category rules: additive, all matching rules fire
 *
 * Usage:
 *   const result = WorkfrontRoutingEngine.resolveAll(formSchema, formValues);
 *   // result = { templateId, templateLabel, categoryIds, matchedRule, matchedCategoryRules }
 */

window.WorkfrontRoutingEngine = {

  // -------------------------------------------------------------------------
  // Condition evaluation - delegates to the existing RuleEngine
  // -------------------------------------------------------------------------

  /**
   * Evaluate a single routing rule's conditions against current form values.
   * Respects conditionOperator: 'AND' (default) or 'OR'.
   */
  _evalConditions(rule, formValues) {
    if (!rule || !Array.isArray(rule.conditions) || rule.conditions.length === 0) return true;
    const engine = window.RuleEngine;
    if (!engine) {
      console.warn('[WorkfrontRoutingEngine] RuleEngine not loaded.');
      return false;
    }
    const op = (rule.conditionOperator || 'AND').toUpperCase();
    if (op === 'OR') {
      return rule.conditions.some(c => engine.evaluateCondition(c, formValues));
    }
    return rule.conditions.every(c => engine.evaluateCondition(c, formValues));
  },

  // -------------------------------------------------------------------------
  // Template ID Resolution
  // -------------------------------------------------------------------------

  /**
   * Returns the resolved Template ID string.
   * Evaluates templateRules in priority order; first match wins.
   * Falls back to defaultTemplateId if no rule matches.
   *
   * @param {Object} formSchema  - full form schema (must have workfrontRouting)
   * @param {Object} formValues  - live key/value map from the form
   * @returns {{ templateId: string, templateLabel: string, matchedRule: Object|null }}
   */
  resolveTemplate(formSchema, formValues) {
    const routing = formSchema?.workfrontRouting || {};
    const rules   = Array.isArray(routing.templateRules) ? routing.templateRules : [];

    // Sort by priority ascending (lower number = higher priority)
    const sorted = [...rules].sort((a, b) => (a.priority || 99) - (b.priority || 99));

    for (const rule of sorted) {
      if (this._evalConditions(rule, formValues)) {
        return {
          templateId:    rule.templateId   || routing.defaultTemplateId   || 'TEMPLATE_UNKNOWN',
          templateLabel: rule.label         || rule.templateId || 'Matched Rule',
          matchedRule:   rule
        };
      }
    }

    // Default fallback
    return {
      templateId:    routing.defaultTemplateId    || 'TEMPLATE_UNKNOWN',
      templateLabel: routing.defaultTemplateLabel || 'Default Template',
      matchedRule:   null
    };
  },

  // -------------------------------------------------------------------------
  // -------------------------------------------------------------------------
  // Custom Form (Category) Resolution (Static Attachment - 1 per Form)
  // -------------------------------------------------------------------------

  /**
   * Returns the single attached Workfront Custom Form (Category) ID.
   * In Workfront, an intake form attaches to one Custom Form (fixed, no conditions).
   *
   * @param {Object} formSchema
   * @param {Object} formValues
   * @returns {{ customFormId: string, categoryIds: string[], matchedCategoryRules: Object[] }}
   */
  resolveCategories(formSchema, formValues) {
    const routing      = formSchema?.workfrontRouting || {};
    const customFormId = routing.customFormId || (Array.isArray(routing.defaultCategoryIds) && routing.defaultCategoryIds[0]) || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';

    return {
      customFormId,
      categoryIds: [customFormId],
      matchedCategoryRules: []
    };
  },

  // -------------------------------------------------------------------------
  // Combined Resolution (main entry point)
  // -------------------------------------------------------------------------

  /**
   * Resolves both Template ID (conditional) and Custom Form ID (static) in one call.
   *
   * @param {Object} formSchema
   * @param {Object} formValues
   * @returns {{
   *   templateId: string,
   *   templateLabel: string,
   *   matchedRule: Object|null,
   *   customFormId: string,
   *   categoryIds: string[],
   *   matchedCategoryRules: Object[],
   *   hasRouting: boolean
   * }}
   */
  resolveAll(formSchema, formValues) {
    const hasRouting = !!(formSchema?.workfrontRouting);

    if (!hasRouting) {
      return {
        templateId:           'NOT_CONFIGURED',
        templateLabel:        'No routing configured',
        matchedRule:          null,
        customFormId:         'NOT_CONFIGURED',
        categoryIds:          [],
        matchedCategoryRules: [],
        hasRouting:           false
      };
    }

    const { templateId, templateLabel, matchedRule } = this.resolveTemplate(formSchema, formValues);
    const { customFormId, categoryIds }             = this.resolveCategories(formSchema, formValues);

    return {
      templateId,
      templateLabel,
      matchedRule,
      customFormId,
      categoryIds,
      matchedCategoryRules: [],
      hasRouting: true
    };
  },

  // -------------------------------------------------------------------------
  // Spec Sheet HTML Generator
  // Returns an HTML string block for the Full Spec Sheet export
  // -------------------------------------------------------------------------

  buildSpecSheetBlock(formSchema) {
    const routing = formSchema?.workfrontRouting;
    if (!routing) return '';

    const esc = s => String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const templateRules   = Array.isArray(routing.templateRules) ? routing.templateRules : [];
    const customFormId    = routing.customFormId || (Array.isArray(routing.defaultCategoryIds) && routing.defaultCategoryIds[0]) || 'CATEGORY_DART_GLOBAL_PROJECT_DETAILS';
    const customFormLabel = routing.customFormLabel || 'Global Project Details Form';

    const condText = (rule) => {
      if (!Array.isArray(rule.conditions) || rule.conditions.length === 0) return '<em style="color:#94a3b8;">Always</em>';
      const op = rule.conditionOperator || 'AND';
      return rule.conditions.map(c =>
        `<code style="font-size:11px; background:#f1f5f9; padding:1px 4px; border-radius:3px;">${esc(c.field)}</code> ${esc(c.comparison)} <strong>"${esc(c.value)}"</strong>`
      ).join(` <span style="color:#0369a1; font-weight:700;">${op}</span> `);
    };

    // Template rules table rows
    const templateRows = templateRules
      .sort((a, b) => (a.priority || 99) - (b.priority || 99))
      .map(r => `
        <tr>
          <td style="padding:8px 10px; border:1px solid #e2e8f0; text-align:center; font-weight:700; color:#0369a1;">${esc(String(r.priority || '-'))}</td>
          <td style="padding:8px 10px; border:1px solid #e2e8f0; font-weight:600; color:#0f172a;">${esc(r.label || r.templateId)}</td>
          <td style="padding:8px 10px; border:1px solid #e2e8f0; font-size:12px;">${condText(r)}</td>
          <td style="padding:8px 10px; border:1px solid #e2e8f0;"><code style="font-size:11px; background:#dbeafe; color:#1d4ed8; padding:2px 6px; border-radius:4px; font-weight:600;">${esc(r.templateId)}</code></td>
        </tr>`).join('');

    return `
    <!--  -->
    <!-- WORKFRONT ROUTING CONFIGURATION                                     -->
    <!--  -->
    <div style="margin-bottom:36px; page-break-inside:avoid;">
      <div style="display:flex; align-items:center; background:#fef3c7; padding:10px 16px; border-left:4px solid #d97706; margin-bottom:4px; border-radius:0 6px 6px 0;">
        <h2 style="font-size:14px; color:#92400e; margin:0; font-weight:700;"> Workfront Routing &amp; Payload Specification</h2>
        <span style="margin-left:12px; font-size:12px; color:#78350f;">Dynamic Template ID &amp; Attached Custom Form ID</span>
      </div>

      <!-- Config Cards row -->
      <div style="display:flex; gap:16px; margin:12px 0; flex-wrap:wrap;">
        <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:6px; padding:12px 16px; flex:1; min-width:260px;">
          <div style="font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#15803d; margin-bottom:4px;"> Attached Custom Form (Static)</div>
          <code style="font-size:12.5px; color:#166534; font-weight:700;">${esc(customFormId)}</code>
          <div style="font-size:11px; color:#475569; margin-top:3px;">${esc(customFormLabel)}</div>
          <div style="font-size:10.5px; color:#15803d; margin-top:4px; font-weight:600;"> Applied to 100% of submissions (no conditions)</div>
        </div>
        <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:6px; padding:12px 16px; flex:1; min-width:260px;">
          <div style="font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#1d4ed8; margin-bottom:4px;">Default Fallback Template</div>
          <code style="font-size:12.5px; color:#1e40af; font-weight:700;">${esc(routing.defaultTemplateId || 'NOT SET')}</code>
          ${routing.defaultTemplateLabel ? `<div style="font-size:11px; color:#64748b; margin-top:3px;">${esc(routing.defaultTemplateLabel)}</div>` : ''}
          <div style="font-size:10.5px; color:#64748b; margin-top:4px; font-style:italic;">Used when no conditional template rule matches</div>
        </div>
      </div>

      ${templateRows ? `
      <!-- Template Rules Table -->
      <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#475569; margin:16px 0 6px;">
         Conditional Template Rules <span style="font-weight:400; color:#94a3b8;">(Evaluated in Priority Order - First Match Wins)</span>
      </div>
      <table style="width:100%; border-collapse:collapse; font-size:12px; border:1px solid #e2e8f0; margin-bottom:16px;">
        <thead>
          <tr style="background:#1e3a5f; color:#fff;">
            <th style="padding:9px 10px; width:5%; border-right:1px solid rgba(255,255,255,0.1);">Pri</th>
            <th style="padding:9px 10px; width:22%; border-right:1px solid rgba(255,255,255,0.1);">Rule Label</th>
            <th style="padding:9px 10px; width:40%; border-right:1px solid rgba(255,255,255,0.1);">Conditions</th>
            <th style="padding:9px 10px; width:33%;">Target Template ID</th>
          </tr>
        </thead>
        <tbody>${templateRows}</tbody>
      </table>` : ''}
    </div>`;
  },

  // -------------------------------------------------------------------------
  // TypeScript Export Block
  // Returns a TS code string to append to the MOPS config export
  // -------------------------------------------------------------------------

  buildTypeScriptBlock(formSchema) {
    const routing = formSchema?.workfrontRouting;
    if (!routing) return '';

    return `\n// -- Workfront Routing Configuration --\nexport const workfront_routing = ${JSON.stringify(routing, null, 2)};\n`;
  }

};

