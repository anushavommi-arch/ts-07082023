/**
 * ============================================================================
 * Cisco MOPs FORM Studio - Core Application Coordinator (app.js)
 * ============================================================================
 * Architecture: Domain-Modular Vanilla JS Architecture
 * 
 * This file serves as the central application coordinator. It initializes
 * global state, manages user session & permissions, orchestrates the master
 * render cycle, and binds top-level event listeners.
 * 
 * Domain Subsystems (Loaded via js/modules/*.js):
 *   01-toast-service.js     - Feedback toasts & alerts
 *   02-tree-controller.js   - Forms Directory Tree Explorer (Levels 0-5)
 *   03-sprint-versioning.js - Sprints, versions, lock/unlock, delete, rename
 *   04-canvas-builder.js    - Canvas views (Cisco Flat, Studio, Wizard) & dropzones
 *   05-field-operations.js  - Canvas CRUD & reusable library operations
 *   06-field-inspector.js   - Right property drawer & display/date/option rules
 *   07-simulator-engine.js  - Runtime simulator & interactive review mode
 *   08-advanced-logic.js    - Visual condition tree & JS expression studio
 *   09-section-logic.js     - Section-level dynamic show/hide rules
 *   10-sprint-diff.js       - Sprint diffing & visual change highlighting
 *   11-naming-studio.js     - Project naming convention studio & live preview
 *   12-workfront-studio.js  - Workfront routing & custom field mapping hub
 *   13-where-used-tracker.js- Where-used tracker & shared impact guard
 *   14-cascading-studio.js  - BA-friendly cascading dropdowns (Excel & 3-column)
 *   15-config-screen.js     - Full-page reusable fields inventory & registry
 *   16-mops-config-panel.js - MOPs Config Studio side panel
 * ============================================================================
 */

window.App = window.App || {};

Object.assign(window.App, {
_triggerDownload(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.target = '_blank';
    a.rel = 'noopener';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
      try {
        URL.revokeObjectURL(url);
      } catch (e) { }
    }, 60000);
  },
  formSchema: {
    title: '',
    description: '',
    sections: []
  },

  activeMode: 'builder', // 'builder' | 'review'  default to 'builder'
  builderVariant: 1, // 1: MOPs Cisco Brand (Default) | 2: Modern Studio | 3: Step Wizard
  livePreviewVariant: 1, // 1=MOPs Cisco Brand | 2=Modern Studio | 3=Step Wizard
  wizardActiveStep: 0, // for Step Wizard builder view
  wizardViewAll: false, // for Step Wizard builder view toggle
  selectedFieldLoc: null,
  formValues: {},
  reusableSections: [],
  reusableFields: [],
  galleryForms: [],

  // Multi-form tab system
  allForms: [],      // Array of { id, label, icon, schema }  one per tab
  activeFormId: null, // ID of the currently active form tab


  // ==========================================================================
  // RESIZABLE / MOVABLE SIDEBARS HANDLER (Workfront Drag Splitters)
  // ==========================================================================
  initResizableSidebars() {
    const leftSplitter = document.getElementById('splitterLeft');
    const rightSplitter = document.getElementById('splitterRight');
    const sidebar = document.getElementById('sidebarPalette');
    const drawer = document.getElementById('settingsDrawer');

    // 1. Restore saved widths from sessionStorage (tab-only, PHP-safe  no localStorage)
    const savedLeftWidth = sessionStorage.getItem('mops_sidebar_left_width');
    const savedRightWidth = sessionStorage.getItem('mops_sidebar_right_width');

    if (savedLeftWidth) {
      const w = parseInt(savedLeftWidth, 10);
      if (w >= 240 && w <= 520) {
        document.documentElement.style.setProperty('--sidebar-left-width', `${w}px`);
      }
    }
    if (savedRightWidth) {
      const w = parseInt(savedRightWidth, 10);
      if (w >= 260 && w <= 640) {
        document.documentElement.style.setProperty('--sidebar-right-width', `${w}px`);
      }
    }

    // Helper to start dragging
    const setupDrag = (splitterEl, isLeft) => {
      if (!splitterEl) return;

      splitterEl.addEventListener('mousedown', (e) => {
        // Prevent default text selection
        e.preventDefault();
        e.stopPropagation();

        const startX = e.clientX;
        const targetEl = isLeft ? sidebar : drawer;
        if (!targetEl) return;

        const startWidth = targetEl.getBoundingClientRect().width;
        splitterEl.classList.add('active-drag');
        document.body.classList.add('is-resizing');

        const onMouseMove = (moveEvent) => {
          let newWidth;
          if (isLeft) {
            const deltaX = moveEvent.clientX - startX;
            newWidth = Math.max(240, Math.min(520, startWidth + deltaX));
            document.documentElement.style.setProperty('--sidebar-left-width', `${newWidth}px`);
          } else {
            const deltaX = startX - moveEvent.clientX;
            newWidth = Math.max(260, Math.min(640, startWidth + deltaX));
            document.documentElement.style.setProperty('--sidebar-right-width', `${newWidth}px`);
          }
        };

        const onMouseUp = () => {
          document.removeEventListener('mousemove', onMouseMove);
          document.removeEventListener('mouseup', onMouseUp);
          splitterEl.classList.remove('active-drag');
          document.body.classList.remove('is-resizing');

          // Save final width
          const finalRect = targetEl.getBoundingClientRect();
          if (isLeft) {
            sessionStorage.setItem('mops_sidebar_left_width', Math.round(finalRect.width));
          } else {
            sessionStorage.setItem('mops_sidebar_right_width', Math.round(finalRect.width));
          }
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });

      // Double-click to reset to standard default width
      splitterEl.addEventListener('dblclick', () => {
        if (isLeft) {
          document.documentElement.style.setProperty('--sidebar-left-width', '360px');
          sessionStorage.setItem('mops_sidebar_left_width', '360px');
          App._showToast('Left sidebar width reset to default (360px)');
        } else {
          document.documentElement.style.setProperty('--sidebar-right-width', '380px');
          sessionStorage.setItem('mops_sidebar_right_width', '380px');
          App._showToast('Right inspector width reset to default (380px)');
        }
      });
    };

    setupDrag(leftSplitter, true);
    setupDrag(rightSplitter, false);
  },

  init() {
    this.loadLibraries();
    this.loadGallery();

    // Default to Builder mode with Variation 1: MOPs Cisco Brand
    this.activeMode = 'builder';
    this.builderVariant = 1;
    this.livePreviewVariant = 1;

    // Detect server mode, then load forms from folder structure
    this.initMultiForms();

    this.bindGlobalEvents();
    this.renderSidebar();
    this.renderFormTabs();
    this.syncCanvasHeader();

    // Check if opened with explicit review mode override (?mode=review)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('mode') === 'review' || urlParams.get('view') === 'review') {
      this.switchMode('review');
    } else {
      this.switchMode('builder');
    }

    this.initResizableSidebars();
    window.DragDropHandler.init();
    this.loadCurrentUser();
  },

  /**
   * Fetch logged-in Cisco SSO user details from api.php (backed by users.config.php)
   */
  loadCurrentUser() {
    const url = window.WorkspaceRepo ? window.WorkspaceRepo._endpoint('user') : 'api.php?action=user';
    fetch(url)
      .then(r => r.ok ? r.json() : null)
      .then(user => {
        if (!user || !user.ok) return;
        this.currentUser = user;
        this.renderUserNavbar(user);
      })
      .catch(e => {
        console.warn('[MOPs] Failed to fetch user info:', e);
      });
  },

  renderUserNavbar(user) {
    const fullNameEl = document.getElementById('navUserFullName');
    const cecIdEl = document.getElementById('navUserCecId');
    const avatarEl = document.getElementById('navUserAvatar');
    const pillEl = document.getElementById('topNavUserPill');

    if (fullNameEl) fullNameEl.textContent = user.fullName || user.cecId || 'Cisco User';
    if (cecIdEl) cecIdEl.textContent = user.cecId ? `@${user.cecId}` : '';
    if (avatarEl) avatarEl.textContent = user.initials || '';

    if (pillEl) {
      const authText = user.authenticated ? 'Authenticated via Cisco SSO' : 'Default User (users.config.php)';
      const emailText = user.email ? `  ${user.email}` : '';
      const countryText = user.country ? `  ${user.country}` : '';
      pillEl.title = `${user.fullName} (${user.cecId})${emailText}${countryText}\n[${authText}]`;

      if (user.authenticated) {
        pillEl.style.borderColor = 'rgba(16, 185, 129, 0.45)';
        if (avatarEl) avatarEl.style.background = '#0284c7';
      }
    }
  },

  /**
   * Returns a clean signature of the active user: "FullName (cecId)"
   */
  getCurrentUserSignature() {
    if (this.currentUser && this.currentUser.fullName) {
      const cec = this.currentUser.cecId ? ` (${this.currentUser.cecId})` : '';
      return `${this.currentUser.fullName}${cec}`;
    }
    return 'Cisco User';
  },

  getCurrentUserCecId() {
    return (this.currentUser && this.currentUser.cecId) || 'cisco-user';
  },

  // ------------------------------------------------------------------------
  // Storage & Libraries
  // ------------------------------------------------------------------------
  loadLibraries() {
    // Reusable Sections  always seed from built-ins; PHP api.php saves to data/libraries.json
    this.reusableSections = JSON.parse(JSON.stringify(window.BUILTIN_SECTIONS || []));

    // Reusable Fields  seed from built-ins; custom fields added by user come from api.php async
    this.reusableFields = JSON.parse(JSON.stringify(window.BUILTIN_FIELDS || []));

    // Async: load user-customised library data from PHP backend
    const libUrl = window.WorkspaceRepo ? window.WorkspaceRepo._endpoint('libraries') : 'api.php?action=libraries';
    fetch(libUrl)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!data) return;
        if (Array.isArray(data.reusableSections) && data.reusableSections.length > 0) {
          this.reusableSections = data.reusableSections;
        }
        if (Array.isArray(data.reusableFields) && data.reusableFields.length > 0) {
          // Merge: built-ins first, then user custom fields
          const userIds = data.reusableFields.map(f => f.id || f.label);
          this.reusableFields = data.reusableFields;
          (window.BUILTIN_FIELDS || []).forEach(bf => {
            if (!this.reusableFields.some(f => f.label === bf.label)) {
              this.reusableFields.unshift(JSON.parse(JSON.stringify(bf)));
            }
          });
        }
        this.renderSidebar();
      })
      .catch(() => {
        // PHP not reachable  built-ins already in place, continue silently
      });
  },

  saveLibraries() {
    // Persist to PHP backend as forms/libraries.json
    const libUrl = window.WorkspaceRepo ? window.WorkspaceRepo._endpoint('libraries') : 'api.php?action=libraries';
    return fetch(libUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reusableSections: this.reusableSections,
        reusableFields: this.reusableFields
      })
    })
      .then(async res => {
        const payload = await res.json().catch(() => ({}));
        if (!res.ok) {
          throw new Error(payload.error || `Server error (${res.status})`);
        }
        return payload;
      })
      .catch(e => {
        console.warn('[MOPs] saveLibraries: PHP write failed:', e);
        throw e;
      });
  },

  loadGallery() {
    // Gallery forms come entirely from forms-manifest.js (PHP-generated static bundle)
    // and from the PHP api.php manifest endpoint  no localStorage needed
    this.galleryForms = JSON.parse(JSON.stringify(window.BUILTIN_GALLERY_FORMS || []));
  },

  saveGallery() {
    // Gallery is rebuilt automatically by api.php when forms are saved/deleted
    // Nothing to do here  no localStorage, no manual write needed
  },

  // ------------------------------------------------------------------------
  // Multi-Form Tab System
  // ------------------------------------------------------------------------
  initMultiForms() {
    // -----------------------------------------------------------------------
    // FOLDER-BASED PERSISTENCE (No localStorage)
    // Load forms from WorkspaceRepo (server API or static forms-manifest.js)
    // -----------------------------------------------------------------------
    const self = this;

    // Synchronously seed from static forms-manifest.js first so UI renders immediately
    const staticData = window.MOPS_FORMS_REPOSITORY;
    if (staticData && staticData.forms && staticData.forms.length > 0) {
      self.allForms = window.WorkspaceRepo._normalizeManifest(staticData);
    } else {
      // Last resort: seed from bundled SAMPLE_FORMS registry
      self.allForms = JSON.parse(JSON.stringify(window.SAMPLE_FORMS || []));
    }

    // Ensure version histories
    if (window.VersionManager) {
      self.allForms.forEach(f => window.VersionManager.ensureFormVersions(f));
    }

    // Do NOT auto-select a form on startup  canvas starts blank.
    // The user must explicitly click " FormName [Open]" inside a version to load a form.
    self.activeFormId = null;
    self.formSchema = { title: '', description: '', sections: [] };

    // Async: refresh from server if available (upgrade in background)
    window.WorkspaceRepo.loadRepository().then(forms => {
      if (forms && forms.length > 0) {
        // Merge: preserve any new in-memory changes the user made, but update from disk
        forms.forEach(diskForm => {
          const existing = self.allForms.find(f => f.id === diskForm.id);
          if (!existing) {
            self.allForms.push(diskForm);
          } else {
            // Only update metadata + versions from disk, preserve live canvas edits
            if (diskForm.icon) existing.icon = diskForm.icon;
            if (diskForm.label) existing.label = diskForm.label;
            if (diskForm.configFile) existing.configFile = diskForm.configFile;
            if (diskForm.activeVersionId) existing.activeVersionId = diskForm.activeVersionId;
            if (diskForm.activeSprint) existing.activeSprint = diskForm.activeSprint;
            if (diskForm.sprints && diskForm.sprints.length > 0) existing.sprints = diskForm.sprints;
            if (diskForm.versions && diskForm.versions.length > 0) existing.versions = diskForm.versions;
            if ((!existing.schema?.sections || existing.schema.sections.length === 0) && diskForm.schema?.sections?.length > 0) {
              existing.schema = JSON.parse(JSON.stringify(diskForm.schema));
              // Only re-render if the user has already explicitly opened this form
              if (existing.id === self.activeFormId && self._userHasOpenedForm) {
                self.formSchema = existing.schema;
                self.render();
              }
            }
          }
        });

        if (window.VersionManager) {
          self.allForms.forEach(f => window.VersionManager.ensureFormVersions(f));
        }

        self.renderFormTabs();
        self.syncCanvasHeader();

        const modeEl = document.getElementById('navStorageModeChip');
        if (modeEl) modeEl.textContent = window.WorkspaceRepo.getModeBadge();
      }
    }).catch(e => console.warn('[MOPs] WorkspaceRepo.loadRepository error:', e));
  },

  saveAllForms() {
    // -----------------------------------------------------------------------
    // FOLDER-BASED SAVE (No localStorage)
    // Syncs active form schema to disk via WorkspaceRepo
    // -----------------------------------------------------------------------
    const active = this.getActiveForm();
    if (active) {
      const now = new Date().toISOString();
      const userSig = this.getCurrentUserSignature();
      active.updatedAt = now;
      active.updatedBy = userSig;
      if (!active.createdAt) {
        active.createdAt = now;
        active.createdBy = userSig;
      }
      if (this.formSchema && this.formSchema.sections && this.formSchema.sections.length > 0) {
        active.schema = JSON.parse(JSON.stringify(this.formSchema));
      } else if (!active.schema || !active.schema.sections || active.schema.sections.length === 0) {
        const withSec = (active.versions || []).filter(v => v.schema && v.schema.sections && v.schema.sections.length > 0);
        if (withSec.length > 0) {
          active.schema = JSON.parse(JSON.stringify(withSec[withSec.length - 1].schema));
          this.formSchema = active.schema;
        }
      }
    }

    // Async write to disk
    if (active && window.WorkspaceRepo) {
      window.WorkspaceRepo.saveForm(active, this.formSchema)
        .then(result => {
          const modeEl = document.getElementById('navStorageModeChip');
          if (modeEl) modeEl.textContent = window.WorkspaceRepo.getModeBadge();
          if (result && result.ok) {
            console.log(`[MOPs]  Disk write: ${result.filePath}`);
          }
        })
        .catch(e => console.warn('[MOPs] Disk save warning:', e));
    }

    // Flash canvas save dot
    const dot = document.getElementById('saveStatusDot');
    if (dot) {
      dot.classList.add('saved');
      clearTimeout(this._saveDotTimer);
      this._saveDotTimer = setTimeout(() => dot.classList.remove('saved'), 1500);
    }

    // Flash navbar pulse dot
    const pulseDot = document.getElementById('savePulseDot');
    if (pulseDot) {
      pulseDot.classList.add('saving');
      clearTimeout(this._pulseDotTimer);
      this._pulseDotTimer = setTimeout(() => pulseDot.classList.remove('saving'), 800);
    }

    // Update navbar autosave chip
    const autoSaveText = document.getElementById('navAutoSaveText');
    const autoSaveDot = document.getElementById('navAutoSaveDotChip');
    if (autoSaveText) {
      autoSaveText.textContent = 'Saving';
      clearTimeout(this._autoSaveTextTimer);
      this._autoSaveTextTimer = setTimeout(() => {
        if (autoSaveText) autoSaveText.textContent = 'Folder Saved';
        if (autoSaveDot) autoSaveDot.classList.add('saved');
        clearTimeout(this._autoSaveDotTimer);
        this._autoSaveDotTimer = setTimeout(() => {
          if (autoSaveDot) autoSaveDot.classList.remove('saved');
          if (autoSaveText) autoSaveText.textContent = window.WorkspaceRepo?.getModeBadge() || 'Saved';
        }, 1800);
      }, 600);
    }
  },



  /**
   * Save the current form to the active version (Ctrl+S / "Save Form" button).
   * Updates the active version's schema snapshot in the version ledger, persists
   * to disk via WorkspaceRepo, and shows a success confirmation modal.
   */
  saveCurrentVersion() {
    const active = this.getActiveForm();
    if (!active) return;

    // Flush any open field inspector drawer edits before saving
    if (this.selectedFieldLoc && typeof this._applyDrawerChanges === 'function') {
      this._applyDrawerChanges();
    }

    // Sync title from canvas input if user was typing in it
    const titleInput = document.querySelector('.cisco-bld-title-edit');
    if (titleInput && titleInput.value.trim()) {
      this.formSchema.title = titleInput.value.trim();
    }

    // Sync live canvas edits into form schema
    active.schema = JSON.parse(JSON.stringify(this.formSchema));

    // Update the version inside active.sprints
    let currentSprintId = '';
    if (active.sprints) {
      active.sprints.forEach(sp => {
        const sv = (sp.versions || []).find(v => v.versionId === active.activeVersionId);
        if (sv) {
          sv.schema = JSON.parse(JSON.stringify(this.formSchema));
          sv.formTitle = this.formSchema.title;
          sv.title = this.formSchema.title;
          currentSprintId = sp.sprintId;
        }
      });
    }

    // Update the snapshot of the currently-active version in flat versions list
    if (active.versions && active.versions.length > 0) {
      const activeVer = active.versions.find(v => v.versionId === active.activeVersionId);
      if (activeVer) {
        activeVer.schema = JSON.parse(JSON.stringify(this.formSchema));
        activeVer.formTitle = this.formSchema.title;
        activeVer.title = this.formSchema.title;
        activeVer.timestamp = new Date().toISOString(); // mark as re-saved
        if (window.VersionManager) {
          activeVer.stats = {
            sectionCount: this.formSchema.sections?.length || 0,
            fieldCount: window.VersionManager.countFields(this.formSchema),
            rulesCount: window.VersionManager.countRules(this.formSchema)
          };
        }
      }
    }

    if (!currentSprintId) currentSprintId = active.activeSprint || '';
    if (this.formSchema.title) {
      window.WorkspaceRepo?.saveVersionTitle?.(active.id, currentSprintId, active.activeVersionId, this.formSchema.title);
    }

    // Persist to disk
    this.saveAllForms();
    this.syncCanvasHeader();
    this.renderFormsTree();
    this._flashSaveButtonSuccess();

    // Show the save success modal
    this.openSaveFormSuccessModal();
    this._showToast(`Saved to ${active.activeVersionId || 'v1.0'}!`);
  },

  /**
   * Cancel / discard changes and close the currently open form.
   */
  cancelCurrentForm() {
    this.activeFormId = null;
    this._userHasOpenedForm = false;
    this.formSchema = { title: '', description: '', sections: [] };
    this.selectedFieldLoc = null;
    this.closeDrawer();

    const footerBar = document.getElementById('wfCanvasFooter');
    if (footerBar) footerBar.style.display = 'none';

    this.renderFormTabs();
    this.syncCanvasHeader();
    this.render();

    this._showToast('Form closed. Unsaved changes discarded.');
  },

  /**
   * Save changes and close the currently open form.
   */
  saveAndCloseCurrentVersion() {
    const active = this.getActiveForm();
    if (!active) {
      this.cancelCurrentForm();
      return;
    }

    // Flush any open field inspector drawer edits before saving
    if (this.selectedFieldLoc && typeof this._applyDrawerChanges === 'function') {
      this._applyDrawerChanges();
    }

    // 1. Sync title from canvas input if user was typing
    const titleInput = document.querySelector('.cisco-bld-title-edit');
    if (titleInput && titleInput.value.trim()) {
      this.formSchema.title = titleInput.value.trim();
    }

    // 2. Sync schema to active form
    active.schema = JSON.parse(JSON.stringify(this.formSchema));

    // 3. Update the version inside active.sprints
    let currentSprintId = '';
    if (active.sprints) {
      active.sprints.forEach(sp => {
        const sv = (sp.versions || []).find(v => v.versionId === active.activeVersionId);
        if (sv) {
          sv.schema = JSON.parse(JSON.stringify(this.formSchema));
          sv.formTitle = this.formSchema.title;
          sv.title = this.formSchema.title;
          currentSprintId = sp.sprintId;
        }
      });
    }

    // 4. Update flat versions list
    if (active.versions && active.versions.length > 0) {
      const activeVer = active.versions.find(v => v.versionId === active.activeVersionId);
      if (activeVer) {
        activeVer.schema = JSON.parse(JSON.stringify(this.formSchema));
        activeVer.formTitle = this.formSchema.title;
        activeVer.title = this.formSchema.title;
        activeVer.timestamp = new Date().toISOString();
        if (window.VersionManager) {
          activeVer.stats = {
            sectionCount: this.formSchema.sections?.length || 0,
            fieldCount: window.VersionManager.countFields(this.formSchema),
            rulesCount: window.VersionManager.countRules(this.formSchema)
          };
        }
      }
    }

    if (!currentSprintId) currentSprintId = active.activeSprint || '';
    if (this.formSchema.title) {
      window.WorkspaceRepo?.saveVersionTitle?.(active.id, currentSprintId, active.activeVersionId, this.formSchema.title);
    }

    // 5. Persist to disk
    this.saveAllForms();

    const savedVer = active.activeVersionId || 'v1.0';

    // 6. Close the form
    this.activeFormId = null;
    this._userHasOpenedForm = false;
    this.formSchema = { title: '', description: '', sections: [] };
    this.selectedFieldLoc = null;
    this.closeDrawer();

    const footerBar = document.getElementById('wfCanvasFooter');
    if (footerBar) footerBar.style.display = 'none';

    // 7. Re-render UI in closed state
    this.renderFormTabs();
    this.syncCanvasHeader();
    this.render();

    this._showToast(`Saved to ${savedVer} and closed.`);
  },

  closeSaveFormSuccessModal() {
    document.getElementById('modalSaveFormSuccess')?.classList.remove('open');
  },

syncTopNavFormHeader() {
    const topNavTitle = document.getElementById('topNavFormTitle');
    const topNavVerLabel = document.getElementById('topNavVersionLabel');
    const topNavVerPill = document.getElementById('topNavVersionPill');
    const infoTrigger = document.querySelector('.wf-info-trigger');
    const formGroup = document.getElementById('topNavFormGroup');
    const active = this.getActiveForm();

    if (!active || (this.allForms || []).length === 0 || !this._userHasOpenedForm) {
      if (formGroup) {
        formGroup.classList.remove('form-active');
        formGroup.style.setProperty('display', 'none', 'important');
      }
      if (topNavTitle) topNavTitle.textContent = '';
      if (topNavVerPill) topNavVerPill.style.display = 'none';
      if (infoTrigger) infoTrigger.style.display = 'none';
      return;
    }

    if (formGroup) {
      formGroup.classList.add('form-active');
      formGroup.style.removeProperty('display');
      formGroup.style.setProperty('display', 'inline-flex', 'important');
      formGroup.title = 'Active Form Specification (Click to edit title or inspect version)';
    }

    if (topNavVerPill) topNavVerPill.style.display = 'inline-flex';
    if (infoTrigger) infoTrigger.style.display = '';

    if (topNavTitle) {
      topNavTitle.textContent = (this.formSchema && this.formSchema.title) || active.label || 'Untitled Form';
    }
    const ver = active.activeVersionId || (this.formSchema && this.formSchema.version) || 'v1.0';
    const verText = ver.startsWith('v') ? ver : `v${ver}`;
    const spId = (this.getSprintForVersion && this.getSprintForVersion(active, ver)) || active.activeSprint;
    const combinedVer = spId ? `${spId}  ${verText}` : verText;

    if (topNavVerLabel) {
      topNavVerLabel.textContent = combinedVer;
    }
    if (topNavVerPill) {
      topNavVerPill.title = `Active Version: ${combinedVer} (Click to inspect version history)`;
    }
  },

saveFormToStorage() {
    this.saveAllForms();
  },

  downloadActiveFormJson() {
    const active = (this.allForms || []).find(f => f.id === this.activeFormId);
    const filename = ((active?.label || this.formSchema.title || 'mops-form').toLowerCase().replace(/[^a-z0-9]/g, '-')) + '.json';
    const blob = new Blob([JSON.stringify(this.formSchema, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    this._triggerDownload(url, filename);
  },

  loadDefaultTemplate() {
    // Pre-populate with MOPs Stakeholder section
    const defaultSec = JSON.parse(JSON.stringify(window.BUILTIN_SECTIONS[0].data));
    this.formSchema = {
      title: 'Customer Web Page Request - Corporate Page',
      description: 'Use this form to submit requests for corporate customer web pages, collateral, and campaign assets.',
      sections: [defaultSec]
    };
    this.saveFormToStorage();
  },

  // ------------------------------------------------------------------------
  // Mode Switching (Builder vs Review)
  // ------------------------------------------------------------------------
  switchMode(mode) {
    this.activeMode = mode;
    this.closeDrawer();

    const btnBuilder = document.getElementById('btnModeBuilder');
    const btnReview = document.getElementById('btnModeReview');
    const topBtnBuilder = document.getElementById('btnTopModeBuilder');
    const topBtnReview = document.getElementById('btnTopModeReview');
    const sidebar = document.getElementById('sidebarPalette');
    const reviewBanner = document.getElementById('reviewModeBanner');
    const devInspectorBtn = document.getElementById('btnOpenDevInspector');
    const formHeaderCard = document.getElementById('formHeaderCard');
    const canvasContainer = document.querySelector('.canvas-container');
    const settingsDrawer = document.getElementById('settingsDrawer');
    const wfCanvasFooter = document.getElementById('wfCanvasFooter');

    // Ensure sidebar has NO inline width styles so it always uses --sidebar-left-width consistently
    if (sidebar) {
      sidebar.style.width = '';
      sidebar.style.minWidth = '';
      sidebar.style.maxWidth = '';
      sidebar.style.flexShrink = '';
    }

    const mainCanvas = document.getElementById('mainCanvasArea');
    if (mainCanvas) {
      mainCanvas.style.padding = '';
      mainCanvas.style.display = '';
      mainCanvas.style.flexDirection = '';
      mainCanvas.style.alignItems = '';
      mainCanvas.style.boxSizing = '';
      mainCanvas.style.overflow = '';
    }
    if (canvasContainer) {
      canvasContainer.style.maxWidth = '';
      canvasContainer.style.width = '';
      canvasContainer.style.margin = '';
      canvasContainer.style.padding = '';
    }

    if (mode === 'review') {
      document.body.classList.add('mode-review');
      document.querySelector('.app-container')?.classList.add('mode-review');
      btnBuilder?.classList.remove('active');
      btnReview?.classList.add('active');
      topBtnBuilder?.classList.remove('active');
      topBtnReview?.classList.add('active');

      // Keep sidebar visible, show only Forms tab (hide Sections, +Fields, WF Field Library, Gallery, New)
      if (sidebar) sidebar.style.display = 'flex';
      document.querySelectorAll('.sidebar-tab-btn').forEach(b => {
        b.classList.remove('active');
        const isForms = b.getAttribute('data-tab-content') === 'tabPaneForms';
        b.style.display = isForms ? '' : 'none';
      });
      document.querySelectorAll('.sidebar-tab-content').forEach(c => c.style.display = 'none');
      const formsTabBtn = document.querySelector('.sidebar-tab-btn[data-tab-content="tabPaneForms"]');
      const formsTabPane = document.getElementById('tabPaneForms');
      if (formsTabBtn) formsTabBtn.classList.add('active');
      if (formsTabPane) formsTabPane.style.display = 'block';
      const btnGallery = document.getElementById('btnSidebarGallery');
      const btnNewForm = document.getElementById('btnSidebarNewForm');
      if (btnGallery) btnGallery.style.display = 'none';
      if (btnNewForm) btnNewForm.style.display = 'none';

      // Hide field settings drawer completely during simulation
      if (settingsDrawer) settingsDrawer.style.display = 'none';
      // Hide bottom action bar (Cancel, Save and Close, Apply) in simulator mode
      if (wfCanvasFooter) wfCanvasFooter.style.display = 'none';

      if (reviewBanner) reviewBanner.style.display = 'flex';
      if (devInspectorBtn) devInspectorBtn.style.display = 'inline-flex';
      if (formHeaderCard) formHeaderCard.style.display = 'none';
      if (canvasContainer) canvasContainer.classList.add('review-mode-active');

      const specLabel = document.getElementById('btnReviewFullSpecLabel');
      if (specLabel) specLabel.textContent = 'Full Spec Sheet';

      this.formValues = {}; // Clear test data
    } else {
      document.body.classList.remove('mode-review');
      document.querySelector('.app-container')?.classList.remove('mode-review');
      btnReview?.classList.remove('active');
      btnBuilder?.classList.add('active');
      topBtnReview?.classList.remove('active');
      topBtnBuilder?.classList.add('active');

      if (sidebar) sidebar.style.display = 'flex';
      // Restore all sidebar tabs, Gallery, New Form, and palette tab in builder mode
      document.querySelectorAll('.sidebar-tab-btn').forEach(b => {
        b.classList.remove('active');
        b.style.display = '';
      });
      const btnGallery = document.getElementById('btnSidebarGallery');
      const btnNewForm = document.getElementById('btnSidebarNewForm');
      if (btnGallery) btnGallery.style.display = '';
      if (btnNewForm) btnNewForm.style.display = '';
      document.querySelectorAll('.sidebar-tab-content').forEach(c => c.style.display = 'none');
      const paletteTabBtn = document.querySelector('.sidebar-tab-btn[data-tab-content="tabPanePalette"]');
      const paletteTabPane = document.getElementById('tabPanePalette');
      if (paletteTabBtn) paletteTabBtn.classList.add('active');
      if (paletteTabPane) paletteTabPane.style.display = 'block';
      // Restore settings drawer in builder mode
      if (settingsDrawer) settingsDrawer.style.display = '';
      // Restore bottom action bar in builder mode
      if (wfCanvasFooter) wfCanvasFooter.style.display = 'flex';

      if (reviewBanner) reviewBanner.style.display = 'none';
      if (devInspectorBtn) devInspectorBtn.style.display = 'none';
      if (formHeaderCard) formHeaderCard.style.display = '';
      if (canvasContainer) canvasContainer.classList.remove('review-mode-active');
      document.getElementById('devInspectorPanel')?.classList.remove('open');
    }

    this.updateFormHealthStatus();
    this.render();
  },

bindGlobalEvents() {
    // Form Title Input
    const formTitleInput = document.getElementById('formTitleInput');
    if (formTitleInput) {
      formTitleInput.value = this.formSchema.title || '';
      formTitleInput.addEventListener('input', (e) => {
        this.formSchema.title = e.target.value;
        const statusTitle = document.getElementById('statusFormTitle');
        if (statusTitle) statusTitle.textContent = 'Form: ' + (e.target.value || 'Untitled');
        const navActiveName = document.getElementById('navActiveFormName');
        if (navActiveName) navActiveName.textContent = e.target.value || 'Untitled Form';
        this.saveFormToStorage();
      });
    }

    // Form Description Input
    const formDescInput = document.getElementById('formDescInput');
    if (formDescInput) {
      formDescInput.value = this.formSchema.description || '';
      formDescInput.addEventListener('input', (e) => {
        this.formSchema.description = e.target.value;
        this.saveFormToStorage();
      });
    }

    // Advanced Logic Custom JS textarea input listener
    const advJsTextarea = document.getElementById('advLogicCustomJsTextarea');
    if (advJsTextarea) {
      advJsTextarea.addEventListener('input', () => {
        if (this.advLogicState?.draft?.display) {
          this.advLogicState.draft.display.customJs = advJsTextarea.value;
        }
        this.validateCurrentJsCode();
      });
    }

    // Form-Level Actions Dropdown Toggle
    const formActionsBtn = document.getElementById('btnFormActionsMenu');
    const formActionsWrap = document.getElementById('formActionsDropdownWrap');

    if (formActionsBtn && formActionsWrap) {
      formActionsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        formActionsWrap.classList.toggle('open');
      });

      // Close on outside click
      document.addEventListener('click', () => {
        formActionsWrap.classList.remove('open');
      });

      // Close on clicking any item inside
      document.querySelectorAll('#formActionsDropdownMenu .dropdown-item').forEach(item => {
        item.addEventListener('click', () => {
          formActionsWrap.classList.remove('open');
        });
      });
    }

    // Close save split-button dropdown on outside click
    document.addEventListener('click', (e) => {
      const splitWrap = document.getElementById('navSaveSplitWrap');
      if (splitWrap && !splitWrap.contains(e.target)) {
        this._closeSaveSplitMenu();
      }
    });

    // Close save split-button dropdown on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this._closeSaveSplitMenu();
      }
    });

    // Form Actions Items
    document.getElementById('btnFormShareHtml')?.addEventListener('click', () => this.downloadStandaloneHtml());
    document.getElementById('btnFormSaveToGallery')?.addEventListener('click', () => this.saveCurrentFormToGallery());
    document.getElementById('btnFormDownloadJson')?.addEventListener('click', () => this.downloadActiveFormJson());
    document.getElementById('btnFormLoadJson')?.addEventListener('click', () => document.getElementById('fileInputJson')?.click());
    document.getElementById('btnFormLoadStakeholderTemplate')?.addEventListener('click', () => {
      this.loadDefaultTemplate();
      this.render();
      alert('Applied Stakeholder Template to active form!');
    });
    document.getElementById('btnFormClearFields')?.addEventListener('click', () => {
      if (confirm(`Clear all fields in "${this.formSchema.title || 'this form'}"?`)) {
        (this.formSchema.sections || []).forEach(sec => sec.fields = []);
        this.saveFormToStorage();
        this.render();
      }
    });

    // Mode Switcher Buttons
    document.getElementById('btnModeBuilder')?.addEventListener('click', () => this.switchMode('builder'));
    document.getElementById('btnModeReview')?.addEventListener('click', () => this.switchMode('review'));

    // Top Right Shortcuts Button
    document.getElementById('btnTopNavShortcuts')?.addEventListener('click', () => {
      document.getElementById('modalShortcuts')?.classList.add('open');
    });

    // File Input Upload for Form JSON
    document.getElementById('fileInputJson')?.addEventListener('change', (e) => this.handleJsonUpload(e));

    // Per-form tab MOPs Code, Spec Sheet, Share HTML & Form Gallery buttons
    document.getElementById('btnTabMopsCode')?.addEventListener('click', () => this.openExportModal());
    document.getElementById('btnTabSpecSheet')?.addEventListener('click', () => this.openSpecSheetModal());
    document.getElementById('btnTabExportHtml')?.addEventListener('click', () => this.downloadStandaloneHtml());
    document.getElementById('btnTabGallery')?.addEventListener('click', () => this.openFormsGallery());
    document.getElementById('btnTabNewForm')?.addEventListener('click', () => this.openCreateNewFormModal());

    // Sprint Versioning Bindings
    document.getElementById('btnNavVersionPicker')?.addEventListener('click', (e) => this.toggleNavVersionDropdown(e));
    document.getElementById('navVersionBadge')?.addEventListener('click', (e) => this.toggleNavVersionDropdown(e));
    document.getElementById('btnTabSaveVersion')?.addEventListener('click', () => this.openSaveNewVersionModal());
    document.getElementById('btnTabVersionHistory')?.addEventListener('click', () => this.openVersionHistoryModal());
    document.getElementById('btnFormSaveSprintVersion')?.addEventListener('click', () => this.openSaveSprintVersionModal());
    document.getElementById('btnFormOpenVersionHistory')?.addEventListener('click', () => this.openVersionHistoryModal());
    document.getElementById('btnFormExportAllVersionsBundle')?.addEventListener('click', () => this.exportAllVersionsBundle());

    // Close nav version dropdown on click outside
    document.addEventListener('click', (e) => {
      const wrap = document.getElementById('navVerPickerWrap');
      if (wrap && !wrap.contains(e.target)) {
        this.closeNavVersionDropdown();
      }
    });

    // Navbar Save Form, Save as New Version & Version History buttons
    // Note: btnNavSaveForm and btnNavSaveNewVersion already have onclick attrs in HTML  no duplicate addEventListener needed
    document.getElementById('btnNavSaveVersion')?.addEventListener('click', () => this.openSaveNewVersionModal());
    document.getElementById('btnNavVersionHistory')?.addEventListener('click', () => this.openVersionHistoryModal());

    // Snapshot Banner Action Buttons
    document.getElementById('btnVsaRestore')?.addEventListener('click', () => this.restoreCurrentSnapshot());
    document.getElementById('btnVsaCompare')?.addEventListener('click', () => this.openVersionHistoryModal('diff'));
    document.getElementById('btnVsaFork')?.addEventListener('click', () => this.forkCurrentSnapshot());
    document.getElementById('btnVsaExit')?.addEventListener('click', () => this.exitSnapshotView());

    // Mouse wheel horizontal scroll on tab strip
    const formTabsScroll = document.getElementById('formTabsScroll');
    if (formTabsScroll) {
      formTabsScroll.addEventListener('wheel', (e) => {
        if (e.deltaY !== 0) {
          formTabsScroll.scrollLeft += e.deltaY;
          e.preventDefault();
        }
      }, { passive: false });
    }

    // Forms Gallery Bindings
    document.getElementById('gallerySearchInput')?.addEventListener('input', (e) => this.renderFormsGallery(e.target.value));
    document.getElementById('btnSaveCurrentToGallery')?.addEventListener('click', () => this.saveCurrentFormToGallery());
    document.getElementById('btnGalleryNewForm')?.addEventListener('click', () => this.openCreateNewFormModal());

    // Global Keyboard Shortcuts (Ctrl+K Command Palette, Ctrl+S Save, Ctrl+P Preview)
    document.addEventListener('keydown', (e) => {
      // Allow Ctrl+K / Cmd+K anywhere
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        this.openCommandPalette();
        return;
      }
      if (e.key === 'Escape') {
        const cpModal = document.getElementById('modalCommandPalette');
        if (cpModal && cpModal.classList.contains('open')) {
          this.closeCommandPalette();
          return;
        }
      }

      const tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        this.saveCurrentVersion();
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        this.switchMode(this.activeMode === 'review' ? 'builder' : 'review');
      } else if (e.altKey && e.key === '1') {
        e.preventDefault();
        this.switchMode('builder');
      } else if (e.altKey && e.key === '2') {
        e.preventDefault();
        this.switchMode('review');
      } else if (e.altKey && (e.key === 'g' || e.key === 'G')) {
        e.preventDefault();
        this.openFormsGallery();
      } else if (e.altKey && (e.key === 'n' || e.key === 'N')) {
        e.preventDefault();
        this.openCreateNewFormModal();
      }
    });

    // Command Palette Input Listeners
    document.getElementById('inputCommandPalette')?.addEventListener('input', (e) => {
      this.renderCommandPalette(e.target.value);
    });

    document.getElementById('inputCommandPalette')?.addEventListener('keydown', (e) => {
      const items = document.querySelectorAll('#commandPaletteResults .cp-item');
      if (!items || items.length === 0) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        this._cpSelectedIndex = (this._cpSelectedIndex + 1) % items.length;
        items.forEach((it, i) => it.classList.toggle('selected', i === this._cpSelectedIndex));
        items[this._cpSelectedIndex]?.scrollIntoView({ block: 'nearest' });
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        this._cpSelectedIndex = (this._cpSelectedIndex - 1 + items.length) % items.length;
        items.forEach((it, i) => it.classList.toggle('selected', i === this._cpSelectedIndex));
        items[this._cpSelectedIndex]?.scrollIntoView({ block: 'nearest' });
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const selected = items[this._cpSelectedIndex];
        if (selected) selected.click();
      }
    });

    // Close top share dropdown on outside click
    document.addEventListener('click', (e) => {
      const shareWrap = document.getElementById('topShareDropdownContainer');
      const shareFlyout = document.getElementById('topShareDropdownFlyout');
      if (shareWrap && !shareWrap.contains(e.target) && shareFlyout) {
        shareFlyout.classList.remove('open');
      }
    });

    // Drawer Tabs & Close
    document.getElementById('btnCloseDrawer')?.addEventListener('click', () => this.closeDrawer());
    document.querySelectorAll('.drawer-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        // Reset ALL tabs - clear both class and inline style overrides to prevent bleed-through
        document.querySelectorAll('.drawer-tab-btn').forEach(b => {
          b.classList.remove('active');
          b.style.borderBottomColor = 'transparent';
          b.style.color = '#6b7280';
        });
        document.querySelectorAll('.drawer-tab-pane').forEach(p => p.classList.remove('active'));
        // Activate clicked tab
        btn.classList.add('active');
        btn.style.borderBottomColor = '#005fb8';
        btn.style.color = '#005fb8';
        const tabId = btn.getAttribute('data-tab');
        document.getElementById('drawerTab_' + tabId)?.classList.add('active');
      });
    });

    // Apply changes button in field settings drawer
    document.getElementById('btnApplyFieldChanges')?.addEventListener('click', () => this._applyDrawerChanges());

    // Save field to library button
    document.getElementById('btnSaveFieldToLib')?.addEventListener('click', () => this.saveSelectedFieldToLibrary());

    // Delete field from drawer
    document.getElementById('btnDeleteFieldFromDrawer')?.addEventListener('click', () => {
      if (this.selectedFieldLoc) {
        this.deleteField(this.selectedFieldLoc.sectionIndex, this.selectedFieldLoc.fieldIndex);
        this.closeDrawer();
      }
    });

    // Developer Inspector
    document.getElementById('btnOpenDevInspector')?.addEventListener('click', () => {
      const panel = document.getElementById('devInspectorPanel');
      panel.classList.toggle('open');
      if (panel.classList.contains('open')) {
        const tsCode = window.Exporter.generateMopsTypeScript(this.formSchema);
        document.getElementById('inspectorCodeBlock').textContent = tsCode;
      }
    });

    document.getElementById('btnCloseInspector')?.addEventListener('click', () => {
      document.getElementById('devInspectorPanel')?.classList.remove('open');
    });

    document.getElementById('btnCopyInspectorCode')?.addEventListener('click', () => {
      const code = document.getElementById('inspectorCodeBlock')?.textContent;
      navigator.clipboard.writeText(code || '');
      this._showToast('MOPs TypeScript config copied to clipboard!');
    });

    // Modals Close  X button inside modal
    document.querySelectorAll('.btn-close-modal').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.mops-modal-backdrop').forEach(m => {
          m.classList.remove('open');
          m.style.display = 'none';
        });
      });
    });

    // Modals Close  click outside dialog (backdrop click)
    document.querySelectorAll('.mops-modal-backdrop').forEach(backdrop => {
      backdrop.addEventListener('click', (e) => {
        // Only close if the click is directly on the backdrop (not inside the dialog)
        if (e.target === backdrop) {
          backdrop.classList.remove('open');
          backdrop.style.display = 'none';
        }
      });
    });

    // Modals & Drawer Close  Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const openModal = document.querySelector('.mops-modal-backdrop.open');
        if (openModal) {
          openModal.classList.remove('open');
          openModal.style.display = 'none';
          e.stopPropagation();
        } else {
          this.closeDrawer();
        }
      }
    });
  },

  // ------------------------------------------------------------------------
  // Sidebar Tab Switching  called via onclick="App.switchSidebarTab(...)"
  // ------------------------------------------------------------------------
  switchSidebarTab(contentId, btnEl) {
    // Remove active from all tab buttons
    document.querySelectorAll('.sidebar-tab-btn').forEach(b => b.classList.remove('active'));
    // Hide all tab panes
    document.querySelectorAll('.sidebar-tab-content').forEach(p => { p.style.display = 'none'; });

    // Show the target pane
    const targetPane = document.getElementById(contentId);
    if (targetPane) targetPane.style.display = 'block';

    // Mark the clicked button active
    const activeBtn = btnEl || document.querySelector(`.sidebar-tab-btn[data-tab-content="${contentId}"]`);
    if (activeBtn) activeBtn.classList.add('active');

    // Per-tab side effects
    if (contentId === 'tabPaneForms') {
      this.renderFormTabs();
    } else if (contentId === 'tabPaneMappings') {
      this.renderSidebarMappingsList();
    }

    if (!this.activeFormId) {
      this.render();
    }
  },

  // ------------------------------------------------------------------------
  // Sidebar Rendering (Palette + Reusable Libraries)
  // ------------------------------------------------------------------------
  renderSidebar() {
    // Tab switching is now handled by onclick="App.switchSidebarTab(...)" on each button.
    // No addEventListener loop here - avoids duplicate stacked handlers on repeated renderSidebar() calls.

    // 2. Render Reusable Sections Library
    const secLibList = document.getElementById('reusableSectionsList');
    if (secLibList) {
      secLibList.innerHTML = '';
      this.reusableSections.forEach((sec, idx) => {
        const fields = sec.data?.fields || [];
        const fieldPreview = fields.slice(0, 6).map(f =>
          `<div style="display:flex;align-items:center;gap:5px;padding:3px 0;border-bottom:1px solid #f1f5f9;font-size:11px;color:#374151;">
            <span style="color:#94a3b8;font-size:10px;width:14px;text-align:center;">${({text:'T',select:'▼',multiselect_fancy:'☐',date:'D',text_area:'=',text_number:'#',radio:'o'})[f.type] || '·'}</span>
            <span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${f.label}">${f.label}</span>
            ${f.required ? '<span style="color:#ef4444;font-size:10px;font-weight:700;">*</span>' : ''}
            ${f.condition ? '<span style="font-size:9px;background:#fef3c7;color:#92400e;border-radius:3px;padding:0 3px;" title="Conditional field">IF</span>' : ''}
          </div>`
        ).join('');
        const moreCount = fields.length > 6 ? fields.length - 6 : 0;

        const item = document.createElement('div');
        item.className = 'reusable-section-card draggable-section-lib';
        item.setAttribute('data-section-id', sec.id || ('sec_' + idx));
        item.setAttribute('data-sec-idx', idx);
        item.setAttribute('draggable', 'true');
        item.innerHTML = `
          <div class="rsc-header">
            <span class="rsc-icon">${sec.icon || '📋'}</span>
            <div class="rsc-meta">
              <div class="rsc-title">${sec.title}</div>
              <div class="rsc-badge">${sec.badge || 'Template'} · ${fields.length} field${fields.length !== 1 ? 's' : ''}</div>
            </div>
          </div>
          <div class="rsc-desc">${sec.description || ''}</div>
          <div class="rsc-field-list">${fieldPreview}${moreCount > 0 ? `<div style="font-size:10px;color:#94a3b8;padding:4px 0 0;">+${moreCount} more field${moreCount !== 1 ? 's' : ''}…</div>` : ''}</div>
          <div class="rsc-actions">
            <span class="rsc-drag-hint">⣿ drag</span>
            <div style="display:flex; align-items:center; gap:4px;" onclick="event.stopPropagation();">
              <button type="button" class="btn-saved-action" title="Edit reusable section" onclick="App.openEditReusableSectionModal(${idx})">Edit</button>
              <button type="button" class="btn-saved-action btn-danger-hover" title="Delete from library" onclick="App.deleteReusableSection(${idx})">×</button>
              <button type="button" class="btn btn-primary btn-sm" onclick="App.insertReusableSection(App.reusableSections[${idx}].data)">+ Add to Form</button>
            </div>
          </div>
        `;
        secLibList.appendChild(item);
      });
    }

    // 3. Render Centralized WF Field Library
    const wfFormFilterEl = document.getElementById('wfLibFilterForm');
    if (wfFormFilterEl && typeof this._initWfRegistries === 'function') {
      this._initWfRegistries();
      const prevFormVal = wfFormFilterEl.value;
      wfFormFilterEl.innerHTML = '<option value="">All Custom Forms</option>';
      (this._wfCustomFormsRegistry || []).forEach(r => {
        if (!r.name && !r.wfId) return;
        const val = r._rowId || r.wfId;
        const opt = document.createElement('option');
        opt.value = val;
        opt.textContent = r.name || r.wfId;
        if (val === prevFormVal) opt.selected = true;
        wfFormFilterEl.appendChild(opt);
      });
    }

    const fieldLibList = document.getElementById('reusableFieldsList');
    if (fieldLibList) {
      fieldLibList.innerHTML = '';
      const allFields = this.reusableFields || [];
      const totalEl = document.getElementById('wfLibTotalCount');
      const usedEl = document.getElementById('wfLibUsedCount');
      let usedFieldsCount = 0;

      // Compute usages once for summary & filtering
      const usageCache = allFields.map(f => {
        const u = this.getFieldWhereUsed(f.data?.formData || f.label);
        if (u.length > 0) usedFieldsCount++;
        return u;
      });
      if (totalEl) totalEl.textContent = allFields.length;
      if (usedEl) usedEl.textContent = usedFieldsCount;

      const q = (document.getElementById('wfLibSearchInput')?.value || '').trim().toLowerCase();
      const typeF = document.getElementById('wfLibFilterType')?.value || '';
      const objF = (document.getElementById('wfLibFilterObject')?.value || '').toLowerCase();
      const formF = document.getElementById('wfLibFilterForm')?.value || '';
      const statusF = document.getElementById('wfLibFilterStatus')?.value || 'all';

      const filteredEntries = allFields.map((f, idx) => ({ f, idx, usages: usageCache[idx] })).filter(({ f, usages }) => {
        const name = (f.label || f.data?.label || '').toLowerCase();
        const apiName = (f.data?.formData || '').toLowerCase();
        const wfLabel = (f.data?.wfLabel || '').toLowerCase();
        if (q && !name.includes(q) && !apiName.includes(q) && !wfLabel.includes(q)) return false;
        if (typeF && (f.data?.type || 'text') !== typeF) return false;
        const wfObj = (f.wfObject || f.data?.wfObject || 'Project').toLowerCase();
        if (objF && !wfObj.includes(objF)) return false;
        if (formF) {
          const fIds = Array.isArray(f.wfFormIds) ? f.wfFormIds : (Array.isArray(f.data?.wfFormIds) ? f.data.wfFormIds : (f.wfFormId || f.data?.wfFormId ? [f.wfFormId || f.data?.wfFormId] : []));
          if (!fIds.includes(formF)) return false;
        }
        const isInactive = f.status === 'inactive';
        if (statusF === 'active' && isInactive) return false;
        if (statusF === 'inactive' && !isInactive) return false;
        if (statusF === 'used' && usages.length === 0) return false;
        if (statusF === 'unused' && usages.length > 0) return false;
        return true;
      });

      if (allFields.length === 0) {
        fieldLibList.innerHTML = `<div style="font-size:12px; color:#94a3b8; text-align:center; padding:16px;">No Workfront fields in library yet. Click <strong>+ New Field</strong> to create one.</div>`;
      } else if (filteredEntries.length === 0) {
        fieldLibList.innerHTML = `<div style="font-size:12px; color:#94a3b8; text-align:center; padding:16px;">No Workfront fields match the current filters.</div>`;
      } else {
        const typeIcons = {
          text: '', select: '', multiselect_fancy: '[x]', text_area: '',
          text_number: '', date: '', radio: '', checkbox: '[x]', file: ''
        };

        filteredEntries.forEach(({ f, idx, usages }) => {
          const isInactive = f.status === 'inactive';
          const item = document.createElement('div');
          item.className = 'saved-field-card' + (isInactive ? ' wf-field-inactive' : ' draggable-field-lib');
          item.setAttribute('data-field-lib-id', f.data?.formData || f.label);
          item.setAttribute('data-lib-idx', idx);
          if (isInactive) {
            item.style.opacity = '0.62';
            item.style.background = '#f8fafc';
          }
          item.title = isInactive
            ? 'Inactive field — reactivate in Edit to use in Intake Forms'
            : 'Drag or click + Add to insert this Workfront field into the form';

          const icon = typeIcons[f.data?.type] || '';
          const optsCount = Array.isArray(f.data?.options) ? f.data.options.length : 0;
          const metaText = optsCount > 0 ? `${optsCount} picklist options` : (f.data?.required ? 'Mandatory' : 'Optional');
          const wfObj = f.wfObject || f.data?.wfObject || 'Project';
          const wfForms = Array.isArray(f.wfFormLabels) && f.wfFormLabels.length
            ? f.wfFormLabels
            : (Array.isArray(f.data?.wfFormLabels) && f.data.wfFormLabels.length ? f.data.wfFormLabels : (f.wfFormLabel || f.data?.wfFormLabel ? [f.wfFormLabel || f.data?.wfFormLabel] : []));
          const wfFormBadge = wfForms.length > 0
            ? `<span style="font-size:10px; background:#f3e8ff; color:#6d28d9; border:1px solid #e9d5ff; border-radius:4px; padding:1px 6px;">${wfForms[0]}${wfForms.length > 1 ? ` +${wfForms.length - 1}` : ''}</span>`
            : '';
          const statusBadge = isInactive
            ? `<span style="font-size:9.5px; font-weight:700; background:#fee2e2; color:#991b1b; border-radius:4px; padding:1px 5px;">Inactive</span>`
            : `<span style="font-size:9.5px; font-weight:700; background:#dcfce7; color:#166534; border-radius:4px; padding:1px 5px;">Active</span>`;
          const usagePillHtml = usages.length > 0
            ? `<span class="lib-where-used-pill" title="Click to view ${usages.length} Intake form(s) using this field" onclick="event.stopPropagation(); App.openFieldWhereUsedModal('${f.data?.formData || f.label}')"> Used in ${usages.length} Intake form(s)</span>`
            : `<span class="lib-where-used-pill unused" title="This field is not currently used in any active form"> Unused</span>`;

          item.innerHTML = `
            <div class="saved-field-top">
              <div class="saved-field-name">
                <span style="font-size:14px;">${icon}</span>
                <span>${f.label || f.data?.label || 'Untitled'}</span>
              </div>
              <div style="display:flex; gap:4px; align-items:center;">
                ${statusBadge}
                <span class="saved-field-badge">${f.badge || 'WF'}</span>
              </div>
            </div>
            <div class="saved-field-key">API: <code>${f.data?.formData || ''}</code> · ${f.data?.type || 'text'} · <span style="color:#475569; font-weight:600;">${wfObj}</span></div>
            <div style="margin: 4px 0 6px; display:flex; flex-wrap:wrap; gap:4px; align-items:center;">
              ${usagePillHtml}
              ${wfFormBadge}
            </div>
            <div class="saved-field-meta">
              <span style="font-size:10.5px; color:#64748b;">${metaText}</span>
              <div class="saved-field-actions" onclick="event.stopPropagation();">
                ${isInactive ? '' : `<button type="button" class="btn-saved-action" title="Add to form" onclick="App.insertReusableField(${idx})">+ Add</button>`}
                <button type="button" class="btn-saved-action" title="View Usage" onclick="App.openFieldWhereUsedModal('${f.data?.formData || f.label}')">Usage</button>
                <button type="button" class="btn-saved-action" title="Inspect & Edit" onclick="App.openEditSavedFieldModal(${idx})">Edit</button>
                <button type="button" class="btn-saved-action" title="${isInactive ? 'Reactivate' : 'Deactivate'}" onclick="App.toggleSavedFieldStatus(${idx})">${isInactive ? 'Activate' : 'Deactivate'}</button>
              </div>
            </div>
          `;

          if (!isInactive) {
            item.addEventListener('click', (e) => {
              if (!e.target.closest('.saved-field-actions')) {
                this.insertReusableField(idx);
              }
            });
          }

          fieldLibList.appendChild(item);
        });
      }
    }

    this.renderSidebarMappingsList();
    window.DragDropHandler?.bindPaletteDraggables();
  },

  // ------------------------------------------------------------------------
  // Main Canvas Rendering (Builder or Review Mode)
  // ------------------------------------------------------------------------
  render() {
    this.updateSprintDiffBarUI();
    const canvasRoot = document.getElementById('canvasSectionsRoot');
    if (!canvasRoot) return;
    canvasRoot.innerHTML = '';

    const formHeaderCard = document.getElementById('formHeaderCard');
    const footerBar = document.getElementById('wfCanvasFooter');
    const active = this.getActiveForm();

    if (!active || (this.allForms || []).length === 0 || !this._userHasOpenedForm) {
      if (formHeaderCard) formHeaderCard.style.display = 'none';
      if (footerBar) footerBar.style.display = 'none';
      this.syncTopNavFormHeader();
      this.renderCanvasEmptyState(canvasRoot);
      return;
    }

    if (formHeaderCard) formHeaderCard.style.display = '';
    if (footerBar) footerBar.style.display = 'flex';

    // ---- READ-ONLY MODE ----
    const isReadOnly = active.readOnly === true;
    const canvasContainer = document.getElementById('canvasContainer') || canvasRoot.parentElement;

    // Remove any existing read-only banner
    document.getElementById('canvasReadOnlyBanner')?.remove();

    if (isReadOnly) {
      // Show banner above canvas
      const verText = active.activeVersionId ? ` (${active.activeVersionId})` : '';
      const banner = document.createElement('div');
      banner.id = 'canvasReadOnlyBanner';
      banner.className = 'canvas-readonly-banner';
      banner.innerHTML = `
        <span class="ro-icon"></span>
        <span class="ro-text">This form${verText} is <strong>Read Only</strong>  no edits are allowed.</span>
        <button type="button" class="ro-unlock-btn" onclick="App.toggleVersionReadOnly('${active.id}', '${active.activeVersionId || ''}', event)">
           Unlock to Edit
        </button>
      `;
      canvasRoot.parentElement?.insertBefore(banner, canvasRoot);

      // Disable header inputs
      if (formHeaderCard) {
        formHeaderCard.querySelectorAll('input, textarea, button:not(.ro-unlock-btn)').forEach(el => {
          if (!el.closest('#canvasReadOnlyBanner')) el.setAttribute('disabled', 'true');
        });
      }
    } else {
      // Re-enable header inputs
      if (formHeaderCard) {
        formHeaderCard.querySelectorAll('[disabled]').forEach(el => el.removeAttribute('disabled'));
      }
    }

    // Apply/remove read-only class to canvas for CSS targeting
    canvasRoot.classList.toggle('canvas-locked', isReadOnly);

    // Synchronize canvas document header card inputs
    const formTitleInput = document.getElementById('formTitleInput');
    if (formTitleInput && document.activeElement !== formTitleInput) {
      formTitleInput.value = this.formSchema.title || '';
    }
    const formDescInput = document.getElementById('formDescInput');
    if (formDescInput && document.activeElement !== formDescInput) {
      formDescInput.value = this.formSchema.description || '';
    }
    this.syncTopNavFormHeader();

    // Synchronize bottom desktop status bar
    const statusTitle = document.getElementById('statusFormTitle');
    if (statusTitle) statusTitle.textContent = 'Form: ' + (this.formSchema.title || 'Untitled Form');

    const totalSections = (this.formSchema.sections || []).length;
    let totalFields = 0;
    (this.formSchema.sections || []).forEach(s => totalFields += (s.fields || []).length);

    const statusSec = document.getElementById('statusSectionsCount');
    if (statusSec) statusSec.textContent = `${totalSections} Section${totalSections === 1 ? '' : 's'}`;

    const statusFld = document.getElementById('statusFieldsCount');
    if (statusFld) statusFld.textContent = `${totalFields} Field${totalFields === 1 ? '' : 's'}`;

    const statusMode = document.getElementById('statusMode');
    if (statusMode) statusMode.textContent = `Mode: ${this.activeMode === 'review' ? 'Live Preview (Variation ' + (this.livePreviewVariant || 1) + ')' : 'Builder'}`;

    if (this.activeMode === 'review') {
      this.renderReviewMode(canvasRoot);
    } else {
      this.renderBuilderMode(canvasRoot);
    }
  },

  renderCanvasEmptyState(canvasRoot) {
    // Detect which sidebar tab is currently active
    const formsPane = document.getElementById('tabPaneForms');
    const isFormsTabActive = formsPane && formsPane.style.display !== 'none';

    const emptyWrapper = document.createElement('div');
    emptyWrapper.className = 'canvas-empty-state-wrapper';

    if (isFormsTabActive) {
      // Forms tab: tell user to pick a version from the tree
      emptyWrapper.innerHTML = `
        <div class="canvas-empty-card">
          <div class="cec-icon-wrap">
            <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#005fb8" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
              <line x1="12" y1="11" x2="12" y2="17"/>
              <line x1="9" y1="14" x2="15" y2="14"/>
            </svg>
          </div>
          <h2 class="cec-title">No Form Open</h2>
          <p class="cec-subtitle">
            Expand a form &rarr; <em>sprints</em> &rarr; a sprint &rarr; <em>versions</em> &rarr; then click&nbsp;<strong> [Open]</strong> under a version to load it here.
          </p>
          <div class="cec-actions">
            <button type="button" class="btn btn-primary" onclick="App.openCreateNewFormModal()">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
                <line x1="12" y1="5" x2="12" y2="19"/>
                <line x1="5" y1="12" x2="19" y2="12"/>
              </svg>
              Create New Form
            </button>
            <button type="button" class="btn btn-outline" onclick="App.openFormsGallery()">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect width="7" height="7" x="3" y="3" rx="1"/>
                <rect width="7" height="7" x="14" y="3" rx="1"/>
                <rect width="7" height="7" x="14" y="14" rx="1"/>
                <rect width="7" height="7" x="3" y="14" rx="1"/>
              </svg>
              Browse Gallery
            </button>
          </div>
          <div class="cec-footer-hint">
            <span class="cec-badge">MOPs Studio Tip</span>
            Forms created here auto-generate official Cisco Workfront field IDs and MOPs Angular configuration files.
          </div>
        </div>
      `;
    } else {
      // Fields / Library tab: show an interactive placeholder with direct open & drop capabilities
      emptyWrapper.innerHTML = `
        <div class="canvas-empty-card" style="max-width: 460px; padding: 32px 24px; text-align: center;">
          <div class="cec-icon-wrap" style="opacity:0.5; margin-bottom: 12px;">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#005fb8" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <line x1="3" y1="9" x2="21" y2="9"/>
              <line x1="9" y1="21" x2="9" y2="9"/>
            </svg>
          </div>
          <h2 class="cec-title" style="color:#0f172a; font-size: 18px; margin-bottom: 6px;">Canvas Ready</h2>
          <p class="cec-subtitle" style="color:#64748b; font-size: 13px; line-height: 1.5; margin-bottom: 18px;">
            Click <strong>"+ Add"</strong> on any library field to add it directly to a form, or open <strong>TestForm</strong> to explore all sections.
          </p>
          <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
            <button type="button" class="btn btn-primary" onclick="App.openDefaultForm()">
               Open TestForm (Active Sprint)
            </button>
            <button type="button" class="btn btn-outline" onclick="App.openCreateNewFormModal()">
              + New Form
            </button>
          </div>
        </div>
      `;

      // Enable drag & drop directly onto the empty canvas
      emptyWrapper.addEventListener('dragover', (e) => {
        e.preventDefault();
        emptyWrapper.querySelector('.canvas-empty-card')?.classList.add('drag-over');
      });
      emptyWrapper.addEventListener('dragleave', () => {
        emptyWrapper.querySelector('.canvas-empty-card')?.classList.remove('drag-over');
      });
      emptyWrapper.addEventListener('drop', (e) => {
        e.preventDefault();
        emptyWrapper.querySelector('.canvas-empty-card')?.classList.remove('drag-over');
        if (window.DragDropHandler?.activeDragData) {
          window.App.ensureActiveForm();
          if (window.DragDropHandler.activeDragData.source === 'section-library') {
            window.App.insertReusableSection(window.DragDropHandler.activeDragData.sectionData);
          } else if (window.DragDropHandler.activeDragData.source === 'palette') {
            window.App.insertPaletteField(window.DragDropHandler.activeDragData.type);
          } else if (window.DragDropHandler.activeDragData.source === 'field-library') {
            window.App.insertReusableField(null, 0, window.DragDropHandler.activeDragData.fieldData);
          }
        }
      });
    }

    canvasRoot.appendChild(emptyWrapper);

    // Ensure footer is hidden when empty state is showing
    const footerBar = document.getElementById('wfCanvasFooter');
    if (footerBar) footerBar.style.display = 'none';

    // Update bottom status bar
    const statusTitle = document.getElementById('statusFormTitle');
    if (statusTitle) statusTitle.textContent = 'Form: None';
    const statusSec = document.getElementById('statusSectionsCount');
    if (statusSec) statusSec.textContent = '0 Sections';
    const statusFld = document.getElementById('statusFieldsCount');
    if (statusFld) statusFld.textContent = '0 Fields';
  },

  // ------------------------------------------------------------------------
  // BUILDER MODE Rendering (Multi-Variation)
  // ------------------------------------------------------------------------
});

// ============================================================================
// Application Bootstrap (DOM Ready)
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
  if (typeof window.App.init === 'function') {
    window.App.init();
  }
});
