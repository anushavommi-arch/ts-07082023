/**
 * MOPs FORM Studio - Mapping Manager & Taxonomy Hub
 * Manages hierarchical cascading lookups (Band -> Country -> Language, Campaign -> Program -> Solution, etc.)
 * Supports interactive drilldown, node addition/editing/deletion, and integration into form fields.
 */

(function () {
  'use strict';

  // Default pre-seeded MOPS mapping tables based on Cisco MOPs / MOPS specifications
  const DEFAULT_MAPPING_TABLES = [
    {
      id: 'region_country_lang',
      title: 'Region - Country - Language Mapping',
      description: 'Cascading hierarchy: Band / Region -> Country -> Language & Localization Codes',
      levelLabels: ['Band / Category', 'Country', 'Language & Code'],
      nodes: [
        {
          id: 'band_a',
          label: 'Band A (Priority Tier 1)',
          code: 'BAND_A',
          children: [
            {
              id: 'c_us',
              label: 'United States',
              code: 'US',
              region: 'AMER',
              children: [
                { id: 'l_us_en', label: 'English - United States', code: 'US_EN', tag: 'Primary' }
              ]
            },
            {
              id: 'c_ca',
              label: 'Canada',
              code: 'CA',
              region: 'AMER',
              children: [
                { id: 'l_ca_en', label: 'English - Canada', code: 'CA_EN', tag: 'Primary' },
                { id: 'l_ca_fr', label: 'French - Canada', code: 'CA_FR', tag: 'Regional' }
              ]
            },
            {
              id: 'c_uk',
              label: 'United Kingdom',
              code: 'UK',
              region: 'EMEA',
              children: [
                { id: 'l_uk_en', label: 'English - United Kingdom', code: 'UK_EN', tag: 'Primary' }
              ]
            },
            {
              id: 'c_fr',
              label: 'France',
              code: 'FR',
              region: 'EMEA',
              children: [
                { id: 'l_fr_fr', label: 'French - France', code: 'FR_FR', tag: 'Primary' }
              ]
            },
            {
              id: 'c_de',
              label: 'Germany',
              code: 'DE',
              region: 'EMEA',
              children: [
                { id: 'l_de_de', label: 'German - Germany', code: 'DE_DE', tag: 'Primary' }
              ]
            },
            {
              id: 'c_sa',
              label: 'Saudi Arabia',
              code: 'SA',
              region: 'EMEA',
              children: [
                { id: 'l_sa_ar', label: 'Arabic - Saudi Arabia', code: 'SA_AR', tag: 'Primary' },
                { id: 'l_sa_en', label: 'English - Saudi Arabia', code: 'SA_EN', tag: 'Business' }
              ]
            },
            {
              id: 'c_cn',
              label: 'China',
              code: 'CN',
              region: 'APJC',
              children: [
                { id: 'l_cn_zh', label: 'Chinese (Simplified) - China', code: 'CN_ZH', tag: 'Primary' }
              ]
            },
            {
              id: 'c_anz',
              label: 'Australia & New Zealand',
              code: 'ANZ',
              region: 'APJC',
              children: [
                { id: 'l_anz_en', label: 'English - Australia & New Zealand', code: 'ANZ_EN', tag: 'Primary' }
              ]
            },
            {
              id: 'c_in',
              label: 'India',
              code: 'IN',
              region: 'APJC',
              children: [
                { id: 'l_in_en', label: 'English - India', code: 'IN_EN', tag: 'Primary' }
              ]
            },
            {
              id: 'c_jp',
              label: 'Japan',
              code: 'JP',
              region: 'APJC',
              children: [
                { id: 'l_jp_ja', label: 'Japanese - Japan', code: 'JP_JA', tag: 'Primary' }
              ]
            }
          ]
        },
        {
          id: 'band_b',
          label: 'Band B (Tier 2 Growth)',
          code: 'BAND_B',
          children: [
            {
              id: 'c_mx',
              label: 'Mexico',
              code: 'MX',
              region: 'AMER',
              children: [
                { id: 'l_mx_es', label: 'Spanish - Mexico', code: 'MX_ES', tag: 'Primary' }
              ]
            },
            {
              id: 'c_br',
              label: 'Brazil',
              code: 'BR',
              region: 'AMER',
              children: [
                { id: 'l_br_pt', label: 'Portuguese - Brazil', code: 'BR_PT', tag: 'Primary' }
              ]
            },
            {
              id: 'c_se',
              label: 'Sweden',
              code: 'SE',
              region: 'EMEA',
              children: [
                { id: 'l_se_sv', label: 'Swedish - Sweden', code: 'SE_SV', tag: 'Primary' }
              ]
            },
            {
              id: 'c_es',
              label: 'Spain',
              code: 'ES',
              region: 'EMEA',
              children: [
                { id: 'l_es_es', label: 'Spanish - Spain', code: 'ES_ES', tag: 'Primary' }
              ]
            },
            {
              id: 'c_ch',
              label: 'Switzerland',
              code: 'CH',
              region: 'EMEA',
              children: [
                { id: 'l_ch_de', label: 'German - Switzerland', code: 'CH_DE', tag: 'Regional' },
                { id: 'l_ch_fr', label: 'French - Switzerland', code: 'CH_FR', tag: 'Regional' }
              ]
            },
            {
              id: 'c_nl',
              label: 'Netherlands',
              code: 'NL',
              region: 'EMEA',
              children: [
                { id: 'l_nl_nl', label: 'Dutch - Netherlands', code: 'NL_NL', tag: 'Primary' }
              ]
            },
            {
              id: 'c_it',
              label: 'Italy',
              code: 'IT',
              region: 'EMEA',
              children: [
                { id: 'l_it_it', label: 'Italian - Italy', code: 'IT_IT', tag: 'Primary' }
              ]
            },
            {
              id: 'c_ae',
              label: 'United Arab Emirates',
              code: 'AE',
              region: 'EMEA',
              children: [
                { id: 'l_ae_ar', label: 'Arabic - UAE', code: 'AE_AR', tag: 'Primary' },
                { id: 'l_ae_en', label: 'English - UAE', code: 'AE_EN', tag: 'Business' }
              ]
            },
            {
              id: 'c_sg',
              label: 'Singapore',
              code: 'SG',
              region: 'APJC',
              children: [
                { id: 'l_sg_en', label: 'English - Singapore', code: 'SG_EN', tag: 'Primary' }
              ]
            },
            {
              id: 'c_kr',
              label: 'Korea (Republic of)',
              code: 'KR',
              region: 'APJC',
              children: [
                { id: 'l_kr_ko', label: 'Korean - Korea', code: 'KR_KO', tag: 'Primary' }
              ]
            },
            {
              id: 'c_tw',
              label: 'Taiwan',
              code: 'TW',
              region: 'APJC',
              children: [
                { id: 'l_tw_zh', label: 'Mandarin Chinese - Taiwan', code: 'TW_ZH', tag: 'Primary' }
              ]
            }
          ]
        },
        {
          id: 'band_c',
          label: 'Band C (Tier 3 Regional)',
          code: 'BAND_C',
          children: [
            { id: 'c_co', label: 'Colombia', code: 'CO', region: 'AMER', children: [{ id: 'l_co_es', label: 'Spanish - Colombia', code: 'CO_ES' }] },
            { id: 'c_ar', label: 'Argentina', code: 'AR', region: 'AMER', children: [{ id: 'l_ar_es', label: 'Spanish - Argentina', code: 'AR_ES' }] },
            { id: 'c_no', label: 'Norway', code: 'NO', region: 'EMEA', children: [{ id: 'l_no_no', label: 'Norwegian - Norway', code: 'NO_NO' }] },
            { id: 'c_at', label: 'Austria', code: 'AT', region: 'EMEA', children: [{ id: 'l_at_de', label: 'German - Austria', code: 'AT_DE' }] },
            { id: 'c_dk', label: 'Denmark', code: 'DK', region: 'EMEA', children: [{ id: 'l_dk_da', label: 'Danish - Denmark', code: 'DK_DA' }] },
            { id: 'c_be', label: 'Belux (Belgium + Lux)', code: 'BE', region: 'EMEA', children: [
              { id: 'l_be_en', label: 'English - Belux', code: 'BE_EN' },
              { id: 'l_be_fr', label: 'French - Belux', code: 'BE_FR' },
              { id: 'l_be_nl', label: 'Dutch - Belux', code: 'BE_NL' }
            ]},
            { id: 'c_il', label: 'Israel', code: 'IL', region: 'EMEA', children: [{ id: 'l_il_en', label: 'English - Israel', code: 'IL_EN' }] },
            { id: 'c_pl', label: 'Poland', code: 'PL', region: 'EMEA', children: [{ id: 'l_pl_pl', label: 'Polish - Poland', code: 'PL_PL' }] },
            { id: 'c_za', label: 'South Africa', code: 'ZA', region: 'EMEA', children: [{ id: 'l_za_en', label: 'English - South Africa', code: 'ZA_EN' }] },
            { id: 'c_qa', label: 'Qatar', code: 'QA', region: 'EMEA', children: [
              { id: 'l_qa_ar', label: 'Arabic - Qatar', code: 'AE_AR' },
              { id: 'l_qa_en', label: 'English - Qatar', code: 'AE_EN' }
            ]},
            { id: 'c_cz', label: 'Czech Republic', code: 'CZ', region: 'EMEA', children: [{ id: 'l_cz_cs', label: 'Czech - Czech Republic', code: 'CZ_CS' }] },
            { id: 'c_tr', label: 'Turkey', code: 'TR', region: 'EMEA', children: [{ id: 'l_tr_tr', label: 'Turkish - Turkey', code: 'TR_TR' }] },
            { id: 'c_hk', label: 'Hong Kong', code: 'HK', region: 'APJC', children: [
              { id: 'l_hk_en', label: 'English - Hong Kong', code: 'HK_EN' },
              { id: 'l_hk_zh', label: 'Chinese - Hong Kong', code: 'HK_ZH' }
            ]},
            { id: 'c_vn', label: 'Vietnam', code: 'VN', region: 'APJC', children: [{ id: 'l_vn_vi', label: 'Vietnamese - Vietnam', code: 'VN_VI' }] },
            { id: 'c_my', label: 'Malaysia', code: 'MY', region: 'APJC', children: [{ id: 'l_my_en', label: 'English - Malaysia', code: 'MY_EN' }] },
            { id: 'c_id', label: 'Indonesia', code: 'ID', region: 'APJC', children: [{ id: 'l_id_en', label: 'English - Indonesia', code: 'ID_EN' }] },
            { id: 'c_ph', label: 'Philippines', code: 'PH', region: 'APJC', children: [{ id: 'l_ph_en', label: 'English - Philippines', code: 'PH_EN' }] },
            { id: 'c_th', label: 'Thailand', code: 'TH', region: 'APJC', children: [{ id: 'l_th_th', label: 'Thai - Thailand', code: 'TH_TH' }] }
          ]
        },
        {
          id: 'band_row',
          label: 'Band RoW (Rest of World)',
          code: 'BAND_ROW',
          children: [
            { id: 'c_eg', label: 'Egypt', code: 'EG', region: 'EMEA', children: [
              { id: 'l_eg_ar', label: 'Arabic - Egypt', code: 'EG_AR' },
              { id: 'l_eg_en', label: 'English - Egypt', code: 'EG_EN' }
            ]},
            { id: 'c_dz', label: 'Africa (General)', code: 'DZ', region: 'EMEA', children: [
              { id: 'l_dz_en', label: 'English - Africa', code: 'DZ_EN' },
              { id: 'l_dz_fr', label: 'French - Africa', code: 'DZ_FR' }
            ]},
            { id: 'c_hu', label: 'Hungary', code: 'HU', region: 'EMEA', children: [{ id: 'l_hu_hu', label: 'Hungarian - Hungary', code: 'HU_HU' }] },
            { id: 'c_ua', label: 'Ukraine', code: 'UA', region: 'EMEA', children: [
              { id: 'l_ua_ru', label: 'Russian - Ukraine', code: 'UA_RU' },
              { id: 'l_ua_uk', label: 'Ukrainian - Ukraine', code: 'UA_UK' }
            ]},
            { id: 'c_pt', label: 'Portugal', code: 'PT', region: 'EMEA', children: [{ id: 'l_pt_pt', label: 'Portuguese - Portugal', code: 'PT_PT' }] },
            { id: 'c_ro', label: 'Romania', code: 'RO', region: 'EMEA', children: [{ id: 'l_ro_ro', label: 'Romanian - Romania', code: 'RO_RO' }] },
            { id: 'c_cl', label: 'Chile', code: 'CL', region: 'AMER', children: [{ id: 'l_cl_es', label: 'Spanish - Chile', code: 'CL_ES' }] },
            { id: 'c_cr', label: 'Costa Rica', code: 'CR', region: 'AMER', children: [{ id: 'l_cr_es', label: 'Spanish - Costa Rica', code: 'CR_ES' }] },
            { id: 'c_pe', label: 'Peru', code: 'PE', region: 'AMER', children: [{ id: 'l_pe_es', label: 'Spanish - Peru', code: 'PE_ES' }] },
            { id: 'c_bz', label: 'Caribbean', code: 'BZ', region: 'AMER', children: [{ id: 'l_bz_es', label: 'Spanish - Caribbean', code: 'BZ_ES' }] },
            { id: 'c_ec', label: 'Ecuador', code: 'EC', region: 'AMER', children: [{ id: 'l_ec_es', label: 'Spanish - Ecuador', code: 'EC_ES' }] },
            { id: 'c_pa', label: 'Panama', code: 'PA', region: 'AMER', children: [{ id: 'l_pa_es', label: 'Spanish - Panama', code: 'PA_ES' }] }
          ]
        }
      ]
    },
    {
      id: 'campaign_program_solution',
      title: 'Campaign - Program - Solution Taxonomy',
      description: 'Cascading hierarchy: Campaign Theme -> Growth Priority (Program) -> Product / Solution / Tech',
      levelLabels: ['Campaign Theme', 'Program (Growth Priority)', 'Solution / Tech'],
      nodes: [
        {
          id: 'cmp_aidc',
          label: 'AI-Ready Data Center',
          code: 'AIDC',
          children: [
            {
              id: 'prg_dci',
              label: 'Data Center Infrastructure',
              code: 'DCI',
              children: [
                { id: 'sol_nexus', label: 'Nexus 9k Switches', code: 'NX9K' },
                { id: 'sol_intersight', label: 'Cisco Intersight', code: 'IS' },
                { id: 'sol_ucs', label: 'UCS X-Series / M7', code: 'UCS' }
              ]
            },
            {
              id: 'prg_neocloud',
              label: 'Neocloud or Sovereign',
              code: 'NOS',
              children: [
                { id: 'sol_cloudmgmt', label: 'Cloud Management for Catalyst', code: 'CMC' },
                { id: 'sol_optics', label: 'Coherent Optics & Transceivers', code: 'OPT' }
              ]
            },
            {
              id: 'prg_sp',
              label: 'Defend & Expand in Service Provider',
              code: 'DES',
              children: [
                { id: 'sol_ron', label: 'Routed Optical Networking (RON)', code: 'RON' },
                { id: 'sol_crosswork', label: 'Crosswork Automation', code: 'CW' }
              ]
            },
            {
              id: 'prg_hmf',
              label: 'Hybrid Mesh Firewall',
              code: 'HMF',
              children: [
                { id: 'sol_fw', label: 'Firewall Modernize', code: 'FWMOD' },
                { id: 'sol_cloudsec', label: 'Cloud Protection Suite - Secure Workload', code: 'CPSSW' }
              ]
            },
            {
              id: 'prg_cxp1',
              label: 'Cross Program',
              code: 'CXP',
              children: [
                { id: 'sol_cxp_gen', label: 'Cross-Architecture General', code: 'XARCH' }
              ]
            }
          ]
        },
        {
          id: 'cmp_fpw',
          label: 'Future-Proofed Workplaces',
          code: 'FPWP',
          children: [
            {
              id: 'prg_umn',
              label: 'Up Market Networking LDOS',
              code: 'UPNL',
              children: [
                { id: 'sol_cat9k', label: 'Catalyst 9100 WiFi 6e & Cat9k Switches', code: 'CAT9K' },
                { id: 'sol_catcenter', label: 'Catalyst Center', code: 'DNAC' }
              ]
            },
            {
              id: 'prg_mmn',
              label: 'Mid Market Networking LDOS and New Customer',
              code: 'MNLD',
              children: [
                { id: 'sol_meraki_ap', label: 'Meraki Access Points & MS Switches', code: 'MRK' },
                { id: 'sol_meraki_dash', label: 'Meraki Dashboard', code: 'MRKD' }
              ]
            },
            {
              id: 'prg_sase',
              label: 'UZTNA or SASE',
              code: 'UZSA',
              children: [
                { id: 'sol_sec_connect', label: 'Cisco Secure Connect', code: 'CSC' },
                { id: 'sol_duo', label: 'Duo Security & User Protection', code: 'DUO' }
              ]
            }
          ]
        },
        {
          id: 'cmp_dgr',
          label: 'Digital Resilience',
          code: 'DGR',
          children: [
            {
              id: 'prg_assurance',
              label: 'Assurance',
              code: 'ASR',
              children: [
                { id: 'sol_te', label: 'ThousandEyes Network Assurance', code: 'TE' }
              ]
            },
            {
              id: 'prg_platform',
              label: 'Platform Approach',
              code: 'PLA',
              children: [
                { id: 'sol_splunk', label: 'Splunk & Full Stack Observability', code: 'SPLK' }
              ]
            },
            {
              id: 'prg_secnet',
              label: 'Secure Networking',
              code: 'SNW',
              children: [
                { id: 'sol_xdr', label: 'Cisco XDR & Breach Protection Suite', code: 'XDR' }
              ]
            }
          ]
        },
        {
          id: 'cmp_ste',
          label: 'Secure the Enterprise',
          code: 'StE',
          children: [
            { id: 'prg_ste_fw', label: 'Firewall', code: 'SFW', children: [{ id: 'sol_ste_fw1', label: 'Next-Gen Firewall', code: 'NGFW' }] },
            { id: 'prg_ste_bp', label: 'Breach Protection', code: 'SBP', children: [{ id: 'sol_ste_bp1', label: 'XDR Incubation', code: 'XDRI' }] },
            { id: 'prg_ste_up', label: 'User Protection', code: 'SUP', children: [{ id: 'sol_ste_up1', label: 'SSE / Umbrella SIG', code: 'SIG' }] },
            { id: 'prg_ste_cp', label: 'Cloud Protection', code: 'SCP', children: [{ id: 'sol_ste_cp1', label: 'Panoptica Multicloud', code: 'PANO' }] }
          ]
        }
      ]
    }
  ];

  window.MappingManager = {
    tables: [],

    init() {
      // Seed from built-in mapping definitions in memory (No localStorage)
      this.tables = JSON.parse(JSON.stringify(DEFAULT_MAPPING_TABLES));
    },

    save() {
      // In-memory mapping table state (No localStorage)
    },

    getTables() {
      if (!this.tables || this.tables.length === 0) this.init();
      return this.tables;
    },

    getTable(tableId) {
      return this.getTables().find(t => t.id === tableId) || this.tables[0];
    },

    /**
     * Resolves a cascading path e.g. ["Band A", "Canada"] -> returns language options
     */
    resolveOptions(tableId, parentPathArray) {
      const table = this.getTable(tableId);
      if (!table || !parentPathArray) return [];
      let currentNodes = table.nodes || [];
      for (const p of parentPathArray) {
        const hit = currentNodes.find(n => (n.id === p || n.label === p || n.code === p));
        if (!hit || !hit.children) return [];
        currentNodes = hit.children;
      }
      return currentNodes.map(n => ({
        label: n.label,
        value: n.code || n.label,
        code: n.code,
        region: n.region,
        tag: n.tag
      }));
    },

    /**
     * Add a node to a specific level
     */
    addNode(tableId, parentPathArray, newNode) {
      const table = this.getTable(tableId);
      if (!table) return false;
      if (!parentPathArray || parentPathArray.length === 0) {
        // Add root node
        table.nodes.push(newNode);
        this.save();
        return true;
      }
      let currentNodes = table.nodes || [];
      let targetParent = null;
      for (const p of parentPathArray) {
        targetParent = currentNodes.find(n => (n.id === p || n.label === p || n.code === p));
        if (!targetParent) return false;
        if (!targetParent.children) targetParent.children = [];
        currentNodes = targetParent.children;
      }
      if (targetParent) {
        targetParent.children.push(newNode);
        this.save();
        return true;
      }
      return false;
    },

    /**
     * Delete a node by ID
     */
    deleteNode(tableId, nodeId) {
      const table = this.getTable(tableId);
      if (!table) return false;
      const removeRecursive = (list) => {
        const idx = list.findIndex(n => n.id === nodeId);
        if (idx !== -1) {
          list.splice(idx, 1);
          return true;
        }
        for (const item of list) {
          if (item.children && removeRecursive(item.children)) return true;
        }
        return false;
      };
      const ok = removeRecursive(table.nodes || []);
      if (ok) this.save();
      return ok;
    },

    /**
     * Update node label, code or tag
     */
    updateNode(tableId, nodeId, updates) {
      const table = this.getTable(tableId);
      if (!table) return false;
      const updateRecursive = (list) => {
        const node = list.find(n => n.id === nodeId);
        if (node) {
          Object.assign(node, updates);
          return true;
        }
        for (const item of list) {
          if (item.children && updateRecursive(item.children)) return true;
        }
        return false;
      };
      const ok = updateRecursive(table.nodes || []);
      if (ok) this.save();
      return ok;
    },

    /**
     * Flatten hierarchical tree into 2D table rows for table/excel view and export
     */
    flattenToRows(tableId) {
      const table = this.getTable(tableId);
      if (!table || !table.nodes) return [];
      const rows = [];
      const walk = (node, path) => {
        const currentPath = [...path, node];
        if (!node.children || node.children.length === 0) {
          rows.push({
            levels: currentPath.map(n => n.label || ''),
            code: node.code || '',
            region: node.region || '',
            tag: node.tag || '',
            leafId: node.id,
            nodes: currentPath
          });
        } else {
          node.children.forEach(c => walk(c, currentPath));
        }
      };
      table.nodes.forEach(n => walk(n, []));
      return rows;
    },

    /**
     * Create a new cascading taxonomy table
     */
    createTable(title, description, levelLabels) {
      const cleanTitle = (title || 'New Cascading Lookup').trim();
      const id = 'map_' + cleanTitle.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Date.now().toString(36);
      const levels = (levelLabels && levelLabels.length > 0)
        ? levelLabels.map(l => (l || '').trim()).filter(Boolean)
        : ['Category', 'Sub-Category', 'Option'];
      const newTable = {
        id,
        title: cleanTitle,
        description: description || `Cascading hierarchy: ${levels.join(' -> ')}`,
        levelLabels: levels,
        nodes: []
      };
      this.tables.push(newTable);
      this.save();
      return newTable;
    },

    /**
     * Delete an entire mapping table
     */
    deleteTable(tableId) {
      const idx = this.tables.findIndex(t => t.id === tableId);
      if (idx !== -1) {
        this.tables.splice(idx, 1);
        this.save();
        return true;
      }
      return false;
    },

    /**
     * Import multiple rows from parsed Excel/CSV data into hierarchical structure
     */
    importRows(tableId, parsedRows) {
      const table = this.getTable(tableId);
      if (!table) return 0;
      if (!table.nodes) table.nodes = [];
      let importedCount = 0;

      for (const r of parsedRows) {
        if (!r.levels || r.levels.length === 0 || !r.levels[0]) continue;
        let currentLevelList = table.nodes;

        for (let i = 0; i < r.levels.length; i++) {
          const val = (r.levels[i] || '').trim();
          if (!val) continue;
          let node = currentLevelList.find(n => (n.label || '').toLowerCase() === val.toLowerCase());
          const isLeaf = (i === r.levels.length - 1);

          if (!node) {
            const id = 'node_' + Math.random().toString(36).substr(2, 9);
            node = {
              id,
              label: val,
              code: isLeaf ? (r.code || '') : '',
              region: isLeaf ? (r.region || '') : '',
              tag: isLeaf ? (r.tag || '') : '',
              children: []
            };
            currentLevelList.push(node);
            importedCount++;
          } else if (isLeaf) {
            if (r.code) node.code = r.code;
            if (r.region) node.region = r.region;
            if (r.tag) node.tag = r.tag;
          }

          if (!node.children) node.children = [];
          currentLevelList = node.children;
        }
      }
      this.save();
      return importedCount;
    }
  };

  // Initialize immediately
  window.MappingManager.init();

})();
