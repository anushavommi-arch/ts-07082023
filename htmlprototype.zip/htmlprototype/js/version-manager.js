/**
 * MOPs FORM Studio  Version Manager & Time-Machine Engine
 * Enables sprint-by-sprint form versioning, snapshots, diffing, and version swapping.
 */

window.VersionManager = {
  // Flag indicating if the user is currently previewing/viewing an older historical snapshot
  viewingSnapshot: false,
  snapshotVersionId: null,
  activeSnapshotFormId: null,
  cachedActiveWorkingSchema: null,

  /**
   * Initializes or repairs version history on any form.
   * If pre-seeded sample forms exist (like webinar), sets up realistic multi-sprint history.
   */
  ensureFormVersions(form) {
    if (!form) return;

    if (!form.versions || !Array.isArray(form.versions) || form.versions.length === 0) {
      if (form.id === 'webinar') {
        form.versions = this._createSampleWebinarVersions(form);
        form.activeVersionId = 'v2.1';
        form.activeSprint = 'Sprint 25.1';
      } else if (form.id === 'email') {
        form.versions = this._createSampleEmailVersions(form);
        form.activeVersionId = 'v1.2';
        form.activeSprint = 'Sprint 25.1';
      } else {
        const fieldCount = this.countFields(form.schema);
        const rulesCount = this.countRules(form.schema);
        const startingSprint = form.activeSprint || 'sprint-25.2';
        const startingVer = form.activeVersionId || 'v1.0';
        const baseline = {
          versionId: startingVer,
          versionLabel: `${startingVer} (${startingSprint})`,
          sprint: startingSprint,
          timestamp: new Date().toISOString(),
          author: 'MOPs Business Ops',
          status: 'Active',
          notes: `Initial baseline specification for ${form.schema?.title || form.label}. Configured with Workfront custom forms mapping and standard Cisco validation.`,
          schema: JSON.parse(JSON.stringify(form.schema || { sections: [] })),
          stats: {
            sectionCount: form.schema?.sections?.length || 0,
            fieldCount: fieldCount,
            rulesCount: rulesCount
          }
        };
        form.versions = [baseline];
        form.activeVersionId = startingVer;
        form.activeSprint = startingSprint;
      }
    }

    if (!form.activeVersionId && form.versions.length > 0) {
      form.activeVersionId = form.versions[form.versions.length - 1].versionId;
      form.activeSprint = form.versions[form.versions.length - 1].sprint;
    }
  },

  /**
   * Count total fields in a form schema
   */
  countFields(schema) {
    if (!schema || !schema.sections) return 0;
    let count = 0;
    schema.sections.forEach(sec => {
      if (sec.fields) count += sec.fields.length;
    });
    return count;
  },

  /**
   * Count conditional / advanced rules in a form schema
   */
  countRules(schema) {
    if (!schema || !schema.sections) return 0;
    let count = 0;
    schema.sections.forEach(sec => {
      (sec.fields || []).forEach(f => {
        if (f.condition && f.condition !== true) count++;
        if (f.advLogic && Object.keys(f.advLogic).length > 0) count++;
      });
    });
    return count;
  },

  /**
   * Gets the active or selected version object for a form
   */
  getActiveVersion(form) {
    if (!form || !form.versions) return null;
    return form.versions.find(v => v.versionId === form.activeVersionId) || form.versions[form.versions.length - 1] || null;
  },

  /**
   * Normalizes version tag strings into standard semantic format (e.g. "2" -> "v2.0", "v2" -> "v2.0", "2.1" -> "v2.1")
   */
  normalizeVersionTag(tag) {
    if (!tag) return 'v1.0';
    let s = String(tag).trim();
    // Strip leading "version" or "ver"
    s = s.replace(/^(?:version|ver)\s*/i, '');
    if (!s.startsWith('v') && !s.startsWith('V')) {
      s = 'v' + s;
    } else {
      s = 'v' + s.slice(1);
    }
    // If just "v1" or "v2", normalize to "v1.0", "v2.0"
    if (/^v\d+$/i.test(s)) {
      s = s + '.0';
    }
    return s.toLowerCase();
  },

  /**
   * Suggests next logical major, minor, and sprint identifier based on form's version history.
   */
  getNextVersionSuggestions(form) {
    if (!form) return { defaultVer: 'v2.0', nextMajor: 'v2.0', nextMinor: 'v1.1', nextSprint: 'Sprint 25.2' };
    this.ensureFormVersions(form);

    const versions = form.versions || [];
    const currentTag = form.activeVersionId || (versions[versions.length - 1]?.versionId) || 'v1.0';
    const currentSprint = form.activeSprint || (versions[versions.length - 1]?.sprint) || 'Sprint 25.1';

    // Parse highest existing major and minor in form history
    let maxMajor = 1;
    let maxMinor = 0;
    versions.forEach(v => {
      const m = (v.versionId || '').match(/^v?(\d+)(?:\.(\d+))?/i);
      if (m) {
        const maj = parseInt(m[1], 10);
        const min = m[2] !== undefined ? parseInt(m[2], 10) : 0;
        if (maj > maxMajor) {
          maxMajor = maj;
          maxMinor = min;
        } else if (maj === maxMajor && min > maxMinor) {
          maxMinor = min;
        }
      }
    });

    // Parse current active version
    const curMatch = currentTag.match(/^v?(\d+)(?:\.(\d+))?/i);
    const curMajor = curMatch ? parseInt(curMatch[1], 10) : 1;
    const curMinor = (curMatch && curMatch[2] !== undefined) ? parseInt(curMatch[2], 10) : 0;

    // Suggestions:
    // If user is at v1.0, next major is v2.0, next minor is v1.1. Default is v2.0 (Version 2)!
    const nextMajor = `v${Math.max(maxMajor + 1, curMajor + 1)}.0`;
    const nextMinor = `v${curMajor}.${curMinor + 1}`;

    let defaultVer = 'v2.0';
    if (curMajor === 1 && curMinor === 0) {
      defaultVer = 'v2.0'; // Business requirement: Version 1 -> Version 2
    } else if (curMinor > 0) {
      defaultVer = nextMinor;
    } else {
      defaultVer = nextMajor;
    }

    // Increment sprint: e.g. "Sprint 25.1" -> "Sprint 25.2", "Sprint 24.8" -> "Sprint 24.9"
    let nextSprint = 'Sprint 25.2';
    const sprintMatch = currentSprint.match(/Sprint\s+(\d+)\.(\d+)/i);
    if (sprintMatch) {
      const year = parseInt(sprintMatch[1], 10);
      const num = parseInt(sprintMatch[2], 10) + 1;
      nextSprint = `Sprint ${year}.${num}`;
    }

    return {
      currentTag,
      currentSprint,
      defaultVer,
      nextMajor,
      nextMinor,
      nextSprint
    };
  },

  /**
   * Saves a new sprint snapshot to the form's version ledger
   */
  saveVersion(form, meta) {
    if (!form) return false;
    this.ensureFormVersions(form);

    const rawVer = (meta.versionId || 'v' + (form.versions.length + 1) + '.0').trim();
    const versionId = this.normalizeVersionTag(rawVer);
    const sprint = (meta.sprint || 'Sprint ' + new Date().toLocaleDateString()).trim();
    const author = (meta.author || 'MOPs Business Team').trim();
    const status = meta.status || 'Active';
    const notes = (meta.notes || 'Sprint update from business requirements.').trim();

    // Deep clone working schema
    const schemaSnapshot = JSON.parse(JSON.stringify(form.schema));
    const stats = {
      sectionCount: schemaSnapshot.sections?.length || 0,
      fieldCount: this.countFields(schemaSnapshot),
      rulesCount: this.countRules(schemaSnapshot)
    };

    const newVersion = {
      versionId,
      versionLabel: `${versionId} (${sprint})`,
      sprint,
      timestamp: new Date().toISOString(),
      author,
      status,
      notes,
      schema: schemaSnapshot,
      stats
    };

    // If active, archive previous versions so only this new release is active
    if (status === 'Active') {
      form.versions.forEach(v => {
        if (v.versionId !== versionId) {
          v.status = 'Archived';
        }
      });
    }

    // If an existing version with this versionId exists, remove its old position
    const existingIndex = form.versions.findIndex(v => v.versionId === versionId);
    if (existingIndex >= 0) {
      form.versions.splice(existingIndex, 1);
    }

    // Push newVersion to end so it is ALWAYS the latest entry (top of reversed list)
    form.versions.push(newVersion);

    form.activeVersionId = versionId;
    form.activeSprint = sprint;

    // Reset snapshot preview if we were in one
    if (this.viewingSnapshot && this.activeSnapshotFormId === form.id) {
      this.viewingSnapshot = false;
      this.snapshotVersionId = null;
      this.cachedActiveWorkingSchema = null;
    }

    return newVersion;
  },

  /**
   * Swap the current active form to a selected past version (Permanent replacement)
   */
  swapToVersion(form, versionId) {
    if (!form || !form.versions) return false;
    const target = form.versions.find(v => v.versionId === versionId);
    if (!target) return false;

    // Deep clone snapshot schema into current active schema
    form.schema = JSON.parse(JSON.stringify(target.schema));
    form.activeVersionId = target.versionId;
    form.activeSprint = target.sprint;

    // Set swapped version status to Active and archive previous active
    form.versions.forEach(v => {
      if (v.versionId === versionId) {
        v.status = 'Active';
      } else if (v.status === 'Active') {
        v.status = 'Archived';
      }
    });

    // Clear snapshot banner mode since this is now permanent working copy
    this.viewingSnapshot = false;
    this.snapshotVersionId = null;
    this.cachedActiveWorkingSchema = null;

    return target;
  },

  /**
   * Preview a past sprint version in snapshot mode (Non-destructive)
   */
  previewSnapshot(form, versionId) {
    if (!form || !form.versions) return false;
    const target = form.versions.find(v => v.versionId === versionId);
    if (!target) return false;

    // Cache current working schema if not already cached
    if (!this.viewingSnapshot || this.activeSnapshotFormId !== form.id) {
      this.cachedActiveWorkingSchema = JSON.parse(JSON.stringify(form.schema));
    }

    this.viewingSnapshot = true;
    this.snapshotVersionId = versionId;
    this.activeSnapshotFormId = form.id;

    // Temporarily point form.schema to target snapshot
    form.schema = JSON.parse(JSON.stringify(target.schema));
    return target;
  },

  /**
   * Exit snapshot preview and restore previous working schema
   */
  exitSnapshot(form) {
    if (!this.viewingSnapshot || !this.cachedActiveWorkingSchema) {
      this.viewingSnapshot = false;
      return;
    }
    form.schema = JSON.parse(JSON.stringify(this.cachedActiveWorkingSchema));
    this.viewingSnapshot = false;
    this.snapshotVersionId = null;
    this.cachedActiveWorkingSchema = null;
  },

  /**
   * Permanently restore the currently previewed snapshot as the main working schema
   */
  restoreCurrentSnapshot(form) {
    if (!this.viewingSnapshot || !this.snapshotVersionId) return;
    const vId = this.snapshotVersionId;
    this.swapToVersion(form, vId);
  },

  /**
   * Delete a version from form's history (cannot delete if it's the only one)
   */
  deleteVersion(form, versionId) {
    if (!form || !form.versions || form.versions.length <= 1) {
      alert('Cannot delete the only remaining version in history.');
      return false;
    }
    const idx = form.versions.findIndex(v => v.versionId === versionId);
    if (idx < 0) return false;

    form.versions.splice(idx, 1);
    if (form.activeVersionId === versionId) {
      const fallback = form.versions[form.versions.length - 1];
      form.activeVersionId = fallback.versionId;
      form.activeSprint = fallback.sprint;
    }
    return true;
  },

  /**
   * Fork a past version as an entirely new form tab (e.g. "Webinar - Sprint 24.8 Variant")
   */
  forkVersionAsNewForm(form, versionId, newTitle) {
    if (!form || !form.versions) return null;
    const target = form.versions.find(v => v.versionId === versionId);
    if (!target) return null;

    const title = newTitle || `${form.schema?.title || form.label} (${target.sprint})`;
    const newId = 'form_' + Date.now();
    const clonedSchema = JSON.parse(JSON.stringify(target.schema));
    clonedSchema.title = title;

    const newForm = {
      id: newId,
      label: title.length > 16 ? title.substring(0, 16) + '' : title,
      icon: form.icon || '',
      configFile: 'form.' + title.toLowerCase().replace(/[^a-z0-9]/g, '-') + '.config.ts',
      schema: clonedSchema,
      activeVersionId: 'v1.0',
      activeSprint: target.sprint + ' (Fork)',
      versions: [
        {
          versionId: 'v1.0',
          versionLabel: `v1.0 (Forked from ${target.versionId})`,
          sprint: target.sprint,
          timestamp: new Date().toISOString(),
          author: 'Forked by Business Ops',
          status: 'Active',
          notes: `Forked from ${form.schema?.title || form.label} [${target.versionId} / ${target.sprint}].`,
          schema: JSON.parse(JSON.stringify(clonedSchema)),
          stats: {
            sectionCount: clonedSchema.sections?.length || 0,
            fieldCount: this.countFields(clonedSchema),
            rulesCount: this.countRules(clonedSchema)
          }
        }
      ]
    };

    return newForm;
  },

  /**
   * Diff two form schemas (Schema A = Baseline/Previous, Schema B = New/Current)
   * Exhaustively captures ALL schema changes:
   *   - Sections: added, removed, renamed, reordered, condition changed
   *   - Fields: added, removed, field-level property diffs including:
   *       label, type, required, column width, workfront mapping,
   *       picklist options (count + added/removed values),
   *       placeholder, tooltip, help text, display condition (full detail),
   *       advanced logic, section move, field reorder within section
   *   - Form title / description changes
   */
  diffVersions(schemaA, schemaB) {
    const secA = schemaA?.sections || [];
    const secB = schemaB?.sections || [];

    //  Helper: stringify condition rules for human-readable diff 
    const condStr = (cond) => {
      if (!cond || cond === true) return 'None';
      const rules = Array.isArray(cond) ? cond : [cond];
      return rules.map(r => {
        const val = ['notempty','empty'].includes((r.comparison||'').toLowerCase())
          ? '' : ` "${r.value}"`;
        return `${r.field} ${r.comparison}${val}`;
      }).join(' AND ');
    };

    //  Helper: stringify picklist options array 
    const optStr = (opts) => {
      if (!opts || opts.length === 0) return '(none)';
      return opts.map(o => (typeof o === 'object' && o !== null ? (o.label || o.value || '') : String(o))).join(', ');
    };

    //  Helper: get option value-set 
    const optSet = (opts) => new Set((opts || []).map(o =>
      typeof o === 'object' && o !== null ? (o.label || o.value || '') : String(o)
    ));

    // 
    // SECTION-LEVEL DIFF
    // 
    const secMapA = new Map(secA.map(s => [s.id, s]));
    const secMapB = new Map(secB.map(s => [s.id, s]));

    const sectionsAdded   = secB.filter(s => !secMapA.has(s.id));
    const sectionsRemoved = secA.filter(s => !secMapB.has(s.id));
    const sectionsModified = [];

    // Build section-order map (index by id)
    const secOrderA = new Map(secA.map((s, i) => [s.id, i]));
    const secOrderB = new Map(secB.map((s, i) => [s.id, i]));

    secB.forEach(sB => {
      if (!secMapA.has(sB.id)) return; // new section  handled above
      const sA = secMapA.get(sB.id);
      const secChanges = [];

      // Section renamed
      if ((sA.title || '') !== (sB.title || '')) {
        secChanges.push({ prop: 'Section Name', from: sA.title || '(untitled)', to: sB.title || '(untitled)' });
      }
      // Section description changed
      if ((sA.description || '') !== (sB.description || '')) {
        secChanges.push({ prop: 'Section Description', from: sA.description || '(none)', to: sB.description || '(none)' });
      }
      // Section display condition changed
      if (condStr(sA.condition) !== condStr(sB.condition)) {
        secChanges.push({ prop: 'Section Visibility', from: condStr(sA.condition), to: condStr(sB.condition) });
      }
      // Section reordered
      if (secOrderA.get(sB.id) !== secOrderB.get(sB.id)) {
        secChanges.push({ prop: 'Section Position', from: `Position ${secOrderA.get(sB.id) + 1}`, to: `Position ${secOrderB.get(sB.id) + 1}` });
      }

      if (secChanges.length > 0) {
        sectionsModified.push({ sectionId: sB.id, title: sB.title || sA.title, changes: secChanges });
      }
    });

    // 
    // FIELD-LEVEL DIFF
    // 

    // Map all fields by ID, and also track their index within their section
    const fieldsMapA = new Map();
    const fieldOrderA = new Map(); // fieldId -> { secId, secTitle, posInSection }
    secA.forEach(s => {
      (s.fields || []).forEach((f, idx) => {
        fieldsMapA.set(f.id, { field: f, section: s.title, secId: s.id });
        fieldOrderA.set(f.id, { secId: s.id, secTitle: s.title, pos: idx });
      });
    });

    const fieldsMapB = new Map();
    const fieldOrderB = new Map();
    secB.forEach(s => {
      (s.fields || []).forEach((f, idx) => {
        fieldsMapB.set(f.id, { field: f, section: s.title, secId: s.id });
        fieldOrderB.set(f.id, { secId: s.id, secTitle: s.title, pos: idx });
      });
    });

    const fieldsAdded    = [];
    const fieldsRemoved  = [];
    const fieldsModified = [];
    let fieldsUnchanged  = 0;

    fieldsMapB.forEach((valB, id) => {
      if (!fieldsMapA.has(id)) {
        fieldsAdded.push({ field: valB.field, section: valB.section });
        return;
      }

      const valA = fieldsMapA.get(id);
      const fA = valA.field;
      const fB = valB.field;
      const changes = [];

      //  Label 
      const labelA = (fA.label || fA.wfLabel || '').trim();
      const labelB = (fB.label || fB.wfLabel || '').trim();
      if (labelA !== labelB) {
        changes.push({ prop: 'Label', from: labelA || '(empty)', to: labelB || '(empty)' });
      }

      //  Field Type 
      if ((fA.type || '') !== (fB.type || '')) {
        changes.push({ prop: 'Field Type', from: fA.type || '(none)', to: fB.type || '(none)' });
      }

      //  Required / Optional 
      if (Boolean(fA.required) !== Boolean(fB.required)) {
        changes.push({ prop: 'Required', from: fA.required ? 'Yes (Required)' : 'No (Optional)', to: fB.required ? 'Yes (Required)' : 'No (Optional)' });
      }

      //  Column Width 
      if ((fA.col || '') !== (fB.col || '')) {
        const toReadable = c => c ? c.replace('col-lg-', '') + '/12 cols' : '(default)';
        changes.push({ prop: 'Column Width', from: toReadable(fA.col), to: toReadable(fB.col) });
      }

      //  Workfront Field Mapping 
      if ((fA.wfFieldName || '') !== (fB.wfFieldName || '')) {
        changes.push({ prop: 'Workfront Field Key', from: fA.wfFieldName || '(none)', to: fB.wfFieldName || '(none)' });
      }
      if ((fA.wfId || '') !== (fB.wfId || '')) {
        changes.push({ prop: 'Workfront ID', from: fA.wfId || '(none)', to: fB.wfId || '(none)' });
      }

      //  Picklist / Dropdown Options 
      const optCountA = fA.options?.length || 0;
      const optCountB = fB.options?.length || 0;
      if (JSON.stringify(fA.options || []) !== JSON.stringify(fB.options || [])) {
        // Detailed: show added & removed option values
        const setA = optSet(fA.options);
        const setB = optSet(fB.options);
        const addedOpts   = [...setB].filter(v => !setA.has(v));
        const removedOpts = [...setA].filter(v => !setB.has(v));

        if (addedOpts.length > 0 || removedOpts.length > 0) {
          if (addedOpts.length > 0) {
            changes.push({ prop: 'Options Added', from: '', to: addedOpts.join(', ') });
          }
          if (removedOpts.length > 0) {
            changes.push({ prop: 'Options Removed', from: removedOpts.join(', '), to: '' });
          }
        } else if (optCountA !== optCountB) {
          // Order changed or values changed
          changes.push({ prop: 'Options', from: optStr(fA.options), to: optStr(fB.options) });
        } else {
          // Same count but different content (option values reordered or renamed)
          changes.push({ prop: 'Options (Reordered/Renamed)', from: optStr(fA.options), to: optStr(fB.options) });
        }
      }

      //  Placeholder 
      if ((fA.placeholder || '') !== (fB.placeholder || '')) {
        changes.push({ prop: 'Placeholder', from: fA.placeholder || '(none)', to: fB.placeholder || '(none)' });
      }

      //  Tooltip 
      if ((fA.tooltip || '') !== (fB.tooltip || '')) {
        changes.push({ prop: 'Tooltip', from: fA.tooltip || '(none)', to: fB.tooltip || '(none)' });
      }

      //  Help Text 
      if ((fA.helpText || '') !== (fB.helpText || '')) {
        changes.push({ prop: 'Help Text', from: fA.helpText || '(none)', to: fB.helpText || '(none)' });
      }

      //  BA Notes 
      if ((fA.baNotes || '') !== (fB.baNotes || '')) {
        changes.push({ prop: 'BA Notes', from: fA.baNotes ? '(had notes)' : '(none)', to: fB.baNotes ? '(has notes)' : '(none)' });
      }

      //  Display Condition (full rule detail) 
      const condA = condStr(fA.condition);
      const condB = condStr(fB.condition);
      if (condA !== condB) {
        changes.push({ prop: 'Display Condition', from: condA, to: condB });
      }

      //  Condition Logic Type (AND / OR) 
      if ((fA.conditionType || 'AND') !== (fB.conditionType || 'AND')) {
        changes.push({ prop: 'Condition Logic', from: fA.conditionType || 'AND', to: fB.conditionType || 'AND' });
      }

      //  Advanced Logic 
      if (JSON.stringify(fA.advLogic || null) !== JSON.stringify(fB.advLogic || null)) {
        changes.push({ prop: 'Advanced Logic Rules', from: fA.advLogic ? 'Configured' : 'None', to: fB.advLogic ? 'Configured' : 'None' });
      }

      //  Section Move (field moved from one section to another) 
      if (valA.secId !== valB.secId) {
        changes.push({ prop: 'Moved to Section', from: valA.section || valA.secId, to: valB.section || valB.secId });
      }

      //  Field Position / Reorder within same section 
      const orderA = fieldOrderA.get(id);
      const orderB = fieldOrderB.get(id);
      if (orderA && orderB && orderA.secId === orderB.secId && orderA.pos !== orderB.pos) {
        changes.push({ prop: 'Field Position', from: `Position ${orderA.pos + 1}`, to: `Position ${orderB.pos + 1}` });
      }

      if (changes.length > 0) {
        fieldsModified.push({ fieldA: fA, fieldB: fB, section: valB.section, changes });
      } else {
        fieldsUnchanged++;
      }
    });

    fieldsMapA.forEach((valA, id) => {
      if (!fieldsMapB.has(id)) {
        fieldsRemoved.push({ field: valA.field, section: valA.section });
      }
    });

    // 
    // FORM-LEVEL DIFF (title / description)
    // 
    const titleChanged = ((schemaA?.title || '').trim() !== (schemaB?.title || '').trim())
      ? { from: schemaA?.title || '(untitled)', to: schemaB?.title || '(untitled)' }
      : null;

    const descChanged = ((schemaA?.description || '').trim() !== (schemaB?.description || '').trim())
      ? { from: schemaA?.description || '', to: schemaB?.description || '' }
      : null;

    //  WORKFRONT ROUTING DIFF 
    const routingDiff = [];
    const rA = schemaA?.workfrontRouting || null;
    const rB = schemaB?.workfrontRouting || null;

    if (!rA && rB) {
      routingDiff.push({ prop: 'Workfront Routing Configured', from: 'None', to: `${(rB.templateRules||[]).length} Template Rules, ${(rB.categoryRules||[]).length} Category Rules` });
    } else if (rA && !rB) {
      routingDiff.push({ prop: 'Workfront Routing Deprecated', from: 'Configured', to: 'None' });
    } else if (rA && rB) {
      if ((rA.defaultTemplateId || '') !== (rB.defaultTemplateId || '')) {
        routingDiff.push({ prop: 'Default Template ID', from: rA.defaultTemplateId || '(none)', to: rB.defaultTemplateId || '(none)' });
      }
      const catsA = (rA.defaultCategoryIds || []).join(', ');
      const catsB = (rB.defaultCategoryIds || []).join(', ');
      if (catsA !== catsB) {
        routingDiff.push({ prop: 'Default Custom Form IDs', from: catsA || '(none)', to: catsB || '(none)' });
      }
      const trCountA = (rA.templateRules || []).length;
      const trCountB = (rB.templateRules || []).length;
      if (trCountA !== trCountB) {
        routingDiff.push({ prop: 'Template Rules Count', from: `${trCountA} rules`, to: `${trCountB} rules` });
      }
      const crCountA = (rA.categoryRules || []).length;
      const crCountB = (rB.categoryRules || []).length;
      if (crCountA !== crCountB) {
        routingDiff.push({ prop: 'Custom Form Rules Count', from: `${crCountA} rules`, to: `${crCountB} rules` });
      }
    }

    const totalChanges = sectionsAdded.length + sectionsRemoved.length + sectionsModified.length +
      fieldsAdded.length + fieldsRemoved.length + fieldsModified.length +
      (titleChanged ? 1 : 0) + (descChanged ? 1 : 0) + routingDiff.length;

    return {
      sectionsAdded,
      sectionsRemoved,
      sectionsModified,
      fieldsAdded,
      fieldsRemoved,
      fieldsModified,
      fieldsUnchanged,
      titleChanged,
      descChanged,
      routingDiff,
      totalChanges
    };
  },

  /**
   * Export single version JSON download
   */
  exportVersionJson(form, versionId) {
    if (!form || !form.versions) return;
    const target = form.versions.find(v => v.versionId === versionId);
    if (!target) return;

    const data = {
      formId: form.id,
      formLabel: form.label,
      version: target,
      exportedAt: new Date().toISOString()
    };
    const slug = (form.label || 'form').toLowerCase().replace(/[^a-z0-9]/g, '-');
    const filename = `${slug}-${target.versionId}-${(target.sprint || 'sprint').toLowerCase().replace(/[^a-z0-9]/g, '-')}.json`;
    this._downloadJson(data, filename);
  },

  /**
   * Export full version ledger package for Git or team sharing
   */
  exportAllVersionsBundle(form) {
    if (!form) return;
    this.ensureFormVersions(form);

    const bundle = {
      formId: form.id,
      label: form.label,
      icon: form.icon,
      configFile: form.configFile,
      activeVersionId: form.activeVersionId,
      activeSprint: form.activeSprint,
      totalVersions: form.versions.length,
      versions: form.versions,
      exportedAt: new Date().toISOString()
    };
    const slug = (form.label || 'form').toLowerCase().replace(/[^a-z0-9]/g, '-');
    const filename = `${slug}-full-version-history.json`;
    this._downloadJson(bundle, filename);
  },

  _downloadJson(obj, filename) {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.target = '_blank';
    a.rel = 'noopener';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
      try {
        URL.revokeObjectURL(url);
      } catch (e) {}
    }, 60000);
  },

  /**
   * Creates realistic historical sprint snapshots for Webinar form to demonstrate
   * sprint-to-sprint evolution right out of the box!
   */
  _createSampleWebinarVersions(form) {
    const currentSchema = JSON.parse(JSON.stringify(form.schema));

    // Sprint 24.8 (v1.0): Baseline Intake Form (Fewer fields, basic requirements)
    const v1Schema = {
      title: 'Webinar Intake Form (Baseline)',
      description: 'Submit requests for Live, Simu-Live, or On-Demand Webinar production and promotion.',
      sections: [
        {
          id: 'wbn_s1',
          title: 'Stakeholder / Requestor',
          collapsed: false,
          fields: [
            currentSchema.sections[0]?.fields[0] || {
              id: 'wbn_f1',
              wfId: '61df5582003a92b049cafa45f74e87ac',
              wfFieldName: 'contentTitle',
              wfLabel: 'Project Name',
              label: '',
              type: 'text',
              col: 'col-lg-6',
              required: true,
              placeholder: 'e.g. Cisco Live 2025 Webinar Series'
            },
            currentSchema.sections[0]?.fields[1] || {
              id: 'wbn_f2',
              wfId: '635040d700147670ca356476308a58f6',
              wfFieldName: 'CampaignAlign',
              wfLabel: 'Campaign Alignment',
              label: '',
              type: 'select',
              col: 'col-lg-6',
              required: true,
              options: [{ label: 'Accelerate', value: 'Accelerate' }, { label: 'Foundation', value: 'Foundation' }]
            }
          ]
        },
        {
          id: 'wbn_s2',
          title: 'Webinar Project Type',
          collapsed: false,
          fields: [
            {
              id: 'wbn_f5',
              wfId: '692dbe0a0009f89c619aa416f0bdced7',
              wfFieldName: 'webinarType',
              wfLabel: 'Webinar Type',
              label: '',
              type: 'select',
              col: 'col-lg-6',
              required: true,
              options: [
                { label: 'Live Broadcast', value: 'Live' },
                { label: 'On-Demand Recording', value: 'On-Demand' }
              ]
            }
          ]
        }
      ]
    };

    // Sprint 24.9 (v2.0): Added Multi-Session & Speaker Logic
    const v2Schema = JSON.parse(JSON.stringify(currentSchema));
    // Remove the last section or couple fields to simulate the progression
    if (v2Schema.sections && v2Schema.sections.length > 2) {
      v2Schema.sections = v2Schema.sections.slice(0, 3);
    }

    return [
      {
        versionId: 'v1.0',
        versionLabel: 'v1.0 (Sprint 24.8 - Baseline)',
        sprint: 'Sprint 24.8',
        timestamp: '2026-07-15T10:00:00Z',
        author: 'MOPs Business Team',
        status: 'Archived',
        notes: 'Initial production baseline form. Contains core stakeholder and basic webinar type picklists.',
        schema: v1Schema,
        stats: {
          sectionCount: v1Schema.sections.length,
          fieldCount: this.countFields(v1Schema),
          rulesCount: 0
        }
      },
      {
        versionId: 'v2.0',
        versionLabel: 'v2.0 (Sprint 24.9 - Speaker & Platform)',
        sprint: 'Sprint 24.9',
        timestamp: '2026-08-28T14:20:00Z',
        author: 'Sarah Jenkins (MOPs)',
        status: 'Archived',
        notes: 'Added ON24 platform integration, Speaker Bio fields, and conditional Simu-Live rules based on sprint feedback.',
        schema: v2Schema,
        stats: {
          sectionCount: v2Schema.sections.length,
          fieldCount: this.countFields(v2Schema),
          rulesCount: this.countRules(v2Schema)
        }
      },
      {
        versionId: 'v2.1',
        versionLabel: 'v2.1 (Sprint 25.1 - Current Active)',
        sprint: 'Sprint 25.1',
        timestamp: '2026-09-20T09:30:00Z',
        author: 'Cisco MOPs Team',
        status: 'Active',
        notes: 'Current sprint release: Added GDPR consent checkboxes, APJC / EMEA routing logic, and dynamic SLA alert banners.',
        schema: currentSchema,
        stats: {
          sectionCount: currentSchema.sections?.length || 0,
          fieldCount: this.countFields(currentSchema),
          rulesCount: this.countRules(currentSchema)
        }
      }
    ];
  },

  /**
   * Sample versions for Email blast form
   */
  _createSampleEmailVersions(form) {
    const currentSchema = JSON.parse(JSON.stringify(form.schema));
    const v1Schema = JSON.parse(JSON.stringify(currentSchema));
    if (v1Schema.sections && v1Schema.sections.length > 2) {
      v1Schema.sections = v1Schema.sections.slice(0, 2);
    }

    return [
      {
        versionId: 'v1.0',
        versionLabel: 'v1.0 (Sprint 24.9 - Baseline)',
        sprint: 'Sprint 24.9',
        timestamp: '2026-08-10T11:00:00Z',
        author: 'Email Ops Group',
        status: 'Archived',
        notes: 'Initial Email Blast intake form covering audience list, sender name, and target send date.',
        schema: v1Schema,
        stats: {
          sectionCount: v1Schema.sections.length,
          fieldCount: this.countFields(v1Schema),
          rulesCount: 0
        }
      },
      {
        versionId: 'v1.2',
        versionLabel: 'v1.2 (Sprint 25.1 - Current Active)',
        sprint: 'Sprint 25.1',
        timestamp: '2026-09-18T16:00:00Z',
        author: 'MOPs Business Team',
        status: 'Active',
        notes: 'Added Eloqua dynamic content fields, A/B testing parameters, and UTM tracking builders.',
        schema: currentSchema,
        stats: {
          sectionCount: currentSchema.sections?.length || 0,
          fieldCount: this.countFields(currentSchema),
          rulesCount: this.countRules(currentSchema)
        }
      }
    ];
  }
,
/**
   * Builds an O(1) fast lookup index map from diffVersions() result
   */
  buildDiffLookupMap(diff) {
    const map = {
      added: new Map(),
      modified: new Map(),
      removed: new Map(),
      removedBySection: new Map(),
      summary: {
        added: diff?.fieldsAdded?.length || 0,
        modified: diff?.fieldsModified?.length || 0,
        removed: diff?.fieldsRemoved?.length || 0,
        unchanged: diff?.fieldsUnchanged || 0,
        total: diff?.totalChanges || 0
      }
    };

    (diff?.fieldsAdded || []).forEach(item => {
      const f = item.field;
      const key = f.id || f.formData || f.wfFieldName;
      if (key) map.added.set(key, item);
      if (f.formData) map.added.set(f.formData, item);
    });

    (diff?.fieldsModified || []).forEach(item => {
      const fB = item.fieldB;
      const key = fB.id || fB.formData || fB.wfFieldName;
      if (key) map.modified.set(key, item);
      if (fB.formData) map.modified.set(fB.formData, item);
    });

    (diff?.fieldsRemoved || []).forEach(item => {
      const f = item.field;
      const key = f.id || f.formData || f.wfFieldName;
      if (key) map.removed.set(key, item);
      if (f.formData) map.removed.set(f.formData, item);

      const secName = item.section || 'General';
      if (!map.removedBySection.has(secName)) map.removedBySection.set(secName, []);
      map.removedBySection.get(secName).push(item);
    });

    return map;
  },

  /**
   * Returns sprint hierarchy for baseline selector grouping
   */
  getSprintList(form) {
    if (!form) return [];
    if (form.sprints && form.sprints.length > 0) {
      return form.sprints;
    }
    // Fallback: build from versions array
    const map = new Map();
    (form.versions || []).forEach(v => {
      const s = v.sprint || 'Sprint 24.8';
      const sId = s.toLowerCase().replace(/[^a-z0-9.]/g, '-');
      if (!map.has(sId)) {
        map.set(sId, { sprintId: sId, sprintLabel: s, publishedVersionId: v.versionId, versions: [] });
      }
      map.get(sId).versions.push(v);
      if (v.status === 'Published' || v.status === 'Active') {
        map.get(sId).publishedVersionId = v.versionId;
      }
    });
    return Array.from(map.values());
  },

  /**
   * Retrieves or computes the sprint diff between a form's active schema and a baseline snapshot
   */
  getSprintDiff(currentForm, baselineVersionId = null) {
    if (!currentForm) return null;
    this.ensureFormVersions(currentForm);

    const versions = currentForm.versions || [];
    if (versions.length === 0) return null;

    let baseline = null;
    if (baselineVersionId) {
      // 1. Check if baselineVersionId matches a sprintId
      const sprints = this.getSprintList(currentForm);
      const matchedSprint = sprints.find(s => s.sprintId === baselineVersionId);
      if (matchedSprint && matchedSprint.publishedVersionId) {
        baseline = versions.find(v => v.versionId === matchedSprint.publishedVersionId);
      }
      // 2. Check if it matches versionId directly
      if (!baseline) {
        baseline = versions.find(v => v.versionId === baselineVersionId);
      }
    }

    if (!baseline) {
      const sprints = this.getSprintList(currentForm);
      const activeSprintSlug = (currentForm.activeSprint || '').toLowerCase().replace(/[^a-z0-9.]/g, '-');
      const sIdx = sprints.findIndex(s => s.sprintId === activeSprintSlug || s.sprintId === currentForm.activeSprint);
      if (sIdx > 0) {
        const prevSprint = sprints[sIdx - 1];
        baseline = versions.find(v => v.versionId === prevSprint.publishedVersionId);
      }
      if (!baseline) {
        const activeIdx = versions.findIndex(v => v.versionId === currentForm.activeVersionId);
        if (activeIdx > 0) {
          baseline = versions[activeIdx - 1];
        } else if (versions.length > 1) {
          baseline = versions[0];
        } else {
          baseline = versions[0];
        }
      }
    }

    if (!baseline || !baseline.schema) return null;

    const currentSchema = currentForm.schema || { sections: [] };
    const diff = this.diffVersions(baseline.schema, currentSchema);
    const lookup = this.buildDiffLookupMap(diff);

    return {
      baseline,
      diff,
      lookup
    };
  },

  /**
   * Formats a clean Jira/Markdown release note table of all sprint changes
   */
  generateSprintChangelogMarkdown(currentForm, sprintDiffResult) {
    if (!sprintDiffResult || !currentForm) return 'No diff data available.';
    const { baseline, diff } = sprintDiffResult;
    const activeVer = currentForm.activeVersionId || 'Current';
    const activeSprint = currentForm.activeSprint || 'Current Sprint';
    const baseVer = baseline.versionId || 'v1.0';
    const baseSprint = baseline.sprint || 'Previous Sprint';

    let md = `##  Sprint Release Notes: ${currentForm.schema?.title || currentForm.label || 'Intake Form'}\n\n`;
    md += `* **Form Scope:** \`${currentForm.id}\`\n`;
    md += `* **Comparing Release:** \`${activeVer}\` (${activeSprint}) vs Baseline \`${baseVer}\` (${baseSprint})\n`;
    md += `* **Generated on:** ${new Date().toLocaleDateString()} by MOPs Form Studio\n\n`;

    md += `###  Summary Legend\n`;
    md += `*  **Added:** ${diff.fieldsAdded.length} new fields\n`;
    md += `*  **Modified:** ${diff.fieldsModified.length} fields updated\n`;
    md += `*  **Removed:** ${diff.fieldsRemoved.length} fields deprecated\n`;
    md += `*  **Unchanged:** ${diff.fieldsUnchanged} baseline fields untouched\n\n`;

    if (diff.fieldsAdded.length > 0) {
      md += `###  Added Fields (${diff.fieldsAdded.length})\n`;
      md += `| Field Label | Section | Type | Workfront Key | Required |\n`;
      md += `| :--- | :--- | :--- | :--- | :--- |\n`;
      diff.fieldsAdded.forEach(item => {
        const f = item.field;
        md += `| **${f.label || f.wfLabel || f.formData}** | ${item.section} | \`${f.type || 'text'}\` | \`${f.formData || f.wfFieldName || '-'}\` | ${f.required ? 'Yes' : 'No'} |\n`;
      });
      md += `\n`;
    }

    if (diff.fieldsModified.length > 0) {
      md += `###  Modified Fields (${diff.fieldsModified.length})\n`;
      md += `| Field Label | Section | What Changed (Before  After) |\n`;
      md += `| :--- | :--- | :--- |\n`;
      diff.fieldsModified.forEach(item => {
        const fB = item.fieldB;
        const changeStr = item.changes.map(c => ` **${c.prop}:** \`${c.from}\`  \`${c.to}\``).join('<br>');
        md += `| **${fB.label || fB.wfLabel || fB.formData}** | ${item.section} | ${changeStr} |\n`;
      });
      md += `\n`;
    }

    if (diff.fieldsRemoved.length > 0) {
      md += `###  Removed / Deprecated Fields (${diff.fieldsRemoved.length})\n`;
      md += `| Field Label | Previous Section | Workfront Key |\n`;
      md += `| :--- | :--- | :--- |\n`;
      diff.fieldsRemoved.forEach(item => {
        const f = item.field;
        md += `| ~~${f.label || f.wfLabel || f.formData}~~ | ${item.section} | \`${f.formData || f.wfFieldName || '-'}\` |\n`;
      });
      md += `\n`;
    }

    return md;
  }
};
