/**
 * MOPS Form Mockup & Rule Studio - Presets & Data Models
 * Standard field types, presets, and common reusable sections matching MOPS
 */

window.MOPS_TYPES = {
  TYPE_TEXT: 'text',
  TYPE_TEXT_SUGGESTION: 'text_suggestion',
  TYPE_SELECT: 'select',
  TYPE_MULTI_SELECT_FANCY: 'multiselect_fancy',
  TYPE_TEXT_AREA: 'text_area',
  TYPE_TEXT_NUMBER: 'text_number',
  TYPE_DATE: 'date',
  TYPE_RADIO: 'radio',
  TYPE_CHECKBOX: 'checkbox',
  TYPE_FILE: 'file',
  TYPE_EMPTY: 'empty_field'
};

window.DEFAULT_PALETTE_ITEMS = [
  {
    type: window.MOPS_TYPES.TYPE_TEXT,
    label: 'Single Line Text',
    icon: '',
    desc: 'Short text input',
    defaultData: {
      label: 'New Text Field',
      formData: 'newTextField',
      placeholder: 'Type here...',
      tooltip: '',
      col: 'col-lg-6',
      required: false,
      type: window.MOPS_TYPES.TYPE_TEXT,
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_TEXT_SUGGESTION,
    label: 'Auto Suggest',
    icon: '',
    desc: 'Typeahead search with suggestions',
    defaultData: {
      label: 'New Auto Suggest',
      formData: 'newAutoSuggest',
      placeholder: 'Start typing to search...',
      tooltip: 'Type to see matching suggestions',
      col: 'col-lg-6',
      required: false,
      type: window.MOPS_TYPES.TYPE_TEXT_SUGGESTION,
      options: ['Option 1', 'Option 2', 'Option 3', 'Option 4'],
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_SELECT,
    label: 'Dropdown Picklist',
    icon: '',
    desc: 'Single selection dropdown',
    defaultData: {
      label: 'New Dropdown',
      formData: 'newDropdown',
      placeholder: 'Please select an option',
      tooltip: '',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_SELECT,
      options: ['Option 1', 'Option 2', 'Other'],
      condition: null,
      resets: []
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_MULTI_SELECT_FANCY,
    label: 'Multi-Select Fancy',
    icon: '[x]',
    desc: 'Multi-select pill tags',
    defaultData: {
      label: 'New Multi-Select',
      formData: 'newMultiSelect',
      placeholder: 'Please select one or more',
      tooltip: '',
      col: 'col-lg-6',
      required: false,
      type: window.MOPS_TYPES.TYPE_MULTI_SELECT_FANCY,
      options: ['Option A', 'Option B', 'Option C'],
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_TEXT_AREA,
    label: 'Textarea / Description',
    icon: '',
    desc: 'Multi-line text area',
    defaultData: {
      label: 'Description / Notes',
      formData: 'descriptionNotes',
      placeholder: 'Enter detailed notes or requirements...',
      tooltip: '',
      col: 'col-lg-12',
      required: false,
      type: window.MOPS_TYPES.TYPE_TEXT_AREA,
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_TEXT_NUMBER,
    label: 'Number Input',
    icon: '',
    desc: 'Numeric values only',
    defaultData: {
      label: 'Number of Items',
      formData: 'numberOfItems',
      placeholder: '0',
      tooltip: '',
      col: 'col-lg-6',
      required: false,
      type: window.MOPS_TYPES.TYPE_TEXT_NUMBER,
      min: 0,
      max: 100,
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_DATE,
    label: 'Date Picker',
    icon: '',
    desc: 'Deployment or target date',
    defaultData: {
      label: 'Target Launch Date',
      formData: 'targetLaunchDate',
      placeholder: 'Select date',
      tooltip: 'Must be at least 10 business days from today',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_DATE,
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_RADIO,
    label: 'Radio Options',
    icon: '',
    desc: 'Single choice radio group',
    defaultData: {
      label: 'Please Choose',
      formData: 'choiceSelection',
      tooltip: '',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_RADIO,
      options: ['Yes', 'No'],
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_CHECKBOX,
    label: 'Checkbox',
    icon: '[x]',
    desc: 'Yes/No acknowledgment',
    defaultData: {
      label: 'Compliance Acknowledgment',
      placeholder: 'I confirm that this project aligns with guidelines',
      formData: 'guidelineConfirmation',
      tooltip: 'Check this box to certify compliance with Cisco brand guidelines.',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_CHECKBOX,
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_FILE,
    label: 'File Upload',
    icon: '',
    desc: 'Attachment or asset upload',
    defaultData: {
      label: 'Attach Asset or Brief',
      formData: 'attachedFiles',
      placeholder: 'Drag and drop files here, or browse',
      tooltip: 'Supported formats: ZIP, PDF, XLSX, DOCX (Max 25MB)',
      col: 'col-lg-12',
      required: false,
      type: window.MOPS_TYPES.TYPE_FILE,
      condition: null
    }
  },
  {
    type: window.MOPS_TYPES.TYPE_EMPTY,
    label: 'Empty Field',
    icon: '⬜',
    desc: 'Blank space to keep a row slot empty',
    defaultData: {
      label: 'Empty Space',
      formData: 'emptySpace',
      col: 'col-lg-6',
      required: false,
      type: window.MOPS_TYPES.TYPE_EMPTY,
      condition: null
    }
  }
];

// Built-in MOPS Reusable Sections
window.BUILTIN_SECTIONS = [
  {
    id: 'common_stakeholder_section',
    title: 'Stakeholder & Project Details',
    badge: 'MOPS Common',
    icon: '👥',
    description: 'Project Name, Key Stakeholder, Organization, Campaign, Program, Primary Technology',
    data: {
      title: 'Project & Stakeholder Details',
      id: 'Common_Stakeholder',
      condition: null,
      fields: [
        {
          id: '6356aa180050abb3b52c1409164bbba6',
          label: 'Project Name',
          formData: 'contentTitle',
          type: window.MOPS_TYPES.TYPE_TEXT,
          col: 'col-lg-6',
          placeholder: 'e.g. Q4 Security Warming Newsletter',
          tooltip: 'Please keep activity name simple. Other fields specify campaign, quarter, etc.',
          required: true,
          condition: null
        },
        {
          id: '58cf9871004173935b70fdaf4f233781',
          label: 'Key Stakeholder (CEC ID)',
          formData: 'keyholder',
          type: window.MOPS_TYPES.TYPE_TEXT,
          col: 'col-lg-6',
          placeholder: 'Type CEC ID (e.g. jdoe)',
          tooltip: 'Type the first 4 letters of the stakeholder ID or name.',
          required: true,
          condition: null
        },
        {
          id: '61df3e28002ed9a13613feb23fb6cb6b',
          label: 'What organization does this project belong to?',
          formData: 'stakeHolderUnit',
          type: window.MOPS_TYPES.TYPE_SELECT,
          col: 'col-lg-6',
          placeholder: 'Please select organization',
          tooltip: 'Select the primary organization sponsoring this request',
          required: true,
          options: [
            'Brand Marketing',
            'Corporate Communications',
            'Global Partner Organization',
            'Product Marketing',
            'Field Marketing',
            'Other'
          ],
          resets: ['uapOtherStakeholderGroup'],
          condition: null
        },
        {
          id: '65e070a3000066c6578fe1be8879e810',
          label: 'If Other, please specify your organization',
          formData: 'uapOtherStakeholderGroup',
          type: window.MOPS_TYPES.TYPE_TEXT,
          col: 'col-lg-6',
          placeholder: 'Specify organization name...',
          tooltip: 'Required if "Other" was selected above',
          required: true,
          condition: { field: 'stakeHolderUnit', comparison: '==', value: 'Other' }
        },
        {
          id: '635040d700147670ca356476308a58f6',
          label: 'Choose Campaign',
          formData: 'CampaignAlign',
          type: window.MOPS_TYPES.TYPE_SELECT,
          col: 'col-lg-6',
          placeholder: 'Please select campaign',
          tooltip: 'Align to overarching business campaign',
          required: true,
          options: [
            'Security & Networking Convergence',
            'Hybrid Work Acceleration',
            'Full-Stack Observability',
            'Small & Medium Business',
            'Corporate Brand'
          ],
          condition: null
        },
        {
          id: '635040d700147670ca356476308a58f7',
          label: 'Choose Program',
          formData: 'programAlign',
          type: window.MOPS_TYPES.TYPE_SELECT,
          col: 'col-lg-6',
          placeholder: 'Please select program',
          tooltip: 'Align to sub-program',
          required: true,
          options: [
            'Global Demand Generation',
            'Partner Co-Marketing Initiatives',
            'Digital Acceleration',
            'Executive Thought Leadership'
          ],
          condition: null
        },
        {
          id: 'primary_tech_field',
          label: 'Choose Primary Technology',
          formData: 'primaryTechnology',
          type: window.MOPS_TYPES.TYPE_SELECT,
          col: 'col-lg-6',
          placeholder: 'Please select technology',
          tooltip: 'Select the primary Cisco technology focus area',
          required: false,
          options: [
            'Networking',
            'Security',
            'Collaboration',
            'Cloud & Hybrid',
            'Data Center',
            'IoT & Industrial',
            'AI & Analytics',
            'Other'
          ],
          condition: null
        }
      ]
    }
  },
  {
    id: 'common_country_section',
    title: 'Country & Language Targeting',
    badge: 'MOPS Common',
    icon: '🌍',
    description: 'US Corporate vs Global, Choose Band, Countries, Languages',
    data: {
      title: 'Country & Language Targeting',
      id: 'Common_Country',
      condition: null,
      fields: [
        {
          id: 'country_scope_field',
          label: 'Is this request for US corporate or global country site(s)?',
          formData: 'regions1',
          type: window.MOPS_TYPES.TYPE_SELECT,
          col: 'col-lg-12',
          placeholder: 'Please select scope',
          tooltip: 'Choose whether this targets the US corporate site or international country sites',
          required: true,
          options: ['US Corporate', 'Global Country Sites'],
          resets: ['chooseBand', 'targetCountries', 'targetLanguages'],
          condition: null
        },
        {
          id: 'choose_band_field',
          label: 'Choose Band',
          formData: 'chooseBand',
          type: window.MOPS_TYPES.TYPE_SELECT,
          col: 'col-lg-6',
          placeholder: 'Select geographic band',
          tooltip: 'Select the geographic band for the global country sites deployment',
          required: true,
          options: [
            'Americas',
            'EMEA',
            'APJC',
            'Global — All Regions'
          ],
          condition: { field: 'regions1', comparison: '==', value: 'Global Country Sites' }
        },
        {
          id: 'target_countries_field',
          label: 'Choose Countries',
          formData: 'targetCountries',
          type: window.MOPS_TYPES.TYPE_MULTI_SELECT_FANCY,
          col: 'col-lg-6',
          placeholder: 'Select all applicable countries',
          tooltip: 'Countries where this campaign/page will be active',
          required: false,
          options: [
            'United States', 'Canada', 'Mexico',
            'United Kingdom', 'Germany', 'France', 'Netherlands', 'Spain', 'Italy',
            'Japan', 'Australia', 'Singapore', 'India', 'South Korea', 'China'
          ],
          condition: { field: 'regions1', comparison: '==', value: 'Global Country Sites' }
        },
        {
          id: 'target_languages_field',
          label: 'Choose Languages',
          formData: 'targetLanguages',
          type: window.MOPS_TYPES.TYPE_MULTI_SELECT_FANCY,
          col: 'col-lg-12',
          placeholder: 'Select all applicable languages',
          tooltip: 'Languages in which the content should be localized',
          required: false,
          options: [
            'English', 'Spanish', 'French', 'German', 'Portuguese',
            'Japanese', 'Chinese (Simplified)', 'Chinese (Traditional)',
            'Korean', 'Italian', 'Dutch', 'Arabic'
          ],
          condition: { field: 'regions1', comparison: '==', value: 'Global Country Sites' }
        }
      ]
    }
  }
];

// Common reusable individual fields
window.BUILTIN_FIELDS = [
  {
    label: 'Key Stakeholder (Auto Suggest)',
    badge: 'Stakeholder',
    data: {
      label: 'Key Stakeholder (CEC ID)',
      formData: 'keyholder',
      id: '58cf9871004173935b70fdaf4f233781',
      placeholder: 'Type CEC ID or name (e.g. jdoe)',
      tooltip: 'Type the first 3 letters of the stakeholder ID or name',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_TEXT_SUGGESTION,
      options: ['jdoe (John Doe)', 'asmith (Alice Smith)', 'rkumar (Raj Kumar)', 'mgarcia (Maria Garcia)', 'bchen (Bob Chen)'],
      condition: null
    }
  },
  {
    label: 'Activity ID (Workfront)',
    badge: 'Standard',
    data: {
      label: 'Activity ID',
      formData: 'activityId',
      id: '5fd6790400ac1378f2aebf708de432c1',
      placeholder: 'Enter 10-digit Activity ID',
      tooltip: 'Workfront Marketing Activity ID',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_TEXT,
      condition: null
    }
  },
  {
    label: 'Audience Request Type',
    badge: 'Picklist',
    data: {
      label: 'Audience Request Type',
      formData: 'audienceRequestType',
      id: '62869498003888f7ac001e49ad8ef921',
      placeholder: 'Select request type',
      tooltip: 'Choose your audience strategy category',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_SELECT,
      options: ['Outbound Play', 'Inbound Nurture', 'Account-Based Marketing (ABM)', 'Event Audience List'],
      resets: ['follozeBoardURL', 'numberOfAccounts'],
      condition: null
    }
  },
  {
    label: 'Fiscal Quarter',
    badge: 'Quarter',
    data: {
      label: 'Fiscal Quarter',
      formData: 'fiscalQuarter',
      placeholder: 'Select Quarter',
      tooltip: 'Cisco Fiscal Quarter',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_SELECT,
      options: ['FY26 Q1', 'FY26 Q2', 'FY26 Q3', 'FY26 Q4'],
      condition: null
    }
  },
  {
    label: 'Folloze Board URL',
    badge: 'URL',
    data: {
      label: 'Folloze Board URL',
      formData: 'follozeBoardURL',
      id: '633af3c3001889c914144e50d655a63e',
      placeholder: 'https://cisco.folloze.com/...',
      tooltip: 'Link to the active Folloze board',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_TEXT,
      condition: {
        field: 'audienceRequestType',
        comparison: '==',
        value: 'Outbound Play'
      }
    }
  },
  {
    label: 'Number of Accounts',
    badge: 'Number',
    data: {
      label: 'Number of Target Accounts',
      formData: 'numberOfAccounts',
      id: '6989f17600082d2edf73abf1f984afea',
      placeholder: 'e.g. 50',
      tooltip: 'Total number of target accounts in scope',
      col: 'col-lg-6',
      required: true,
      type: window.MOPS_TYPES.TYPE_TEXT_NUMBER,
      min: 1,
      max: 5000,
      condition: {
        field: 'audienceRequestType',
        comparison: '==',
        value: 'Outbound Play'
      }
    }
  }
];

// Pre-built Intake Forms for the Forms Gallery
window.BUILTIN_GALLERY_FORMS = [
  {
    id: 'form_webpage_corporate',
    title: 'Customer Web Page Request - Corporate Page',
    badge: 'Standard Preset',
    description: 'Corporate customer web pages, gated resource centers, collateral, and campaign assets with legal/compliance sign-offs.',
    updatedAt: '2026-09-16',
    schema: {
      title: 'Customer Web Page Request - Corporate Page',
      description: 'Use this form to submit requests for corporate customer web pages, collateral, and campaign assets.',
      sections: [
        window.BUILTIN_SECTIONS[0].data,
        {
          title: 'Web Page Specifications & Targeting',
          id: 'WebPage_Specs',
          condition: null,
          fields: [
            {
              label: 'What type of web project is this?',
              formData: 'webProjectType',
              type: window.MOPS_TYPES.TYPE_SELECT,
              col: 'col-lg-6',
              placeholder: 'Please select project type',
              tooltip: 'Determine whether this is a corporate page, product page, or gated asset',
              required: true,
              options: [
                'Corporate Landing Page',
                'Gated Resource Center',
                'Blog / Article Publication',
                'Navigation & Menu Update'
              ],
              resets: ['gatedFormDetails', 'resourceAssetUrl'],
              condition: null
            },
            {
              label: 'Provide Gated Form Details',
              formData: 'gatedFormDetails',
              type: window.MOPS_TYPES.TYPE_TEXT_AREA,
              col: 'col-lg-12',
              placeholder: 'Specify Eloqua form name or lead routing rules...',
              tooltip: 'Required for gated resource downloads',
              required: true,
              condition: {
                field: 'webProjectType',
                comparison: '==',
                value: 'Gated Resource Center'
              }
            },
            {
              label: 'Direct Resource Asset URL',
              formData: 'resourceAssetUrl',
              type: window.MOPS_TYPES.TYPE_TEXT,
              col: 'col-lg-6',
              placeholder: 'https://www.cisco.com/c/dam/...',
              tooltip: 'Link to the PDF or asset on Cisco DAM',
              required: true,
              condition: {
                field: 'webProjectType',
                comparison: '==',
                value: 'Gated Resource Center'
              }
            },
            {
              label: 'Target Deployment Date',
              formData: 'targetDeploymentDate',
              type: window.MOPS_TYPES.TYPE_DATE,
              col: 'col-lg-6',
              placeholder: 'Select deployment date',
              tooltip: 'Standard SLA is 10 business days from complete submission',
              required: true,
              condition: null
            },
            {
              label: 'I confirm that all copy and assets have been reviewed by legal/compliance',
              formData: 'complianceApprovalConfirmed',
              type: window.MOPS_TYPES.TYPE_CHECKBOX,
              col: 'col-lg-12',
              required: true,
              condition: null
            }
          ]
        }
      ]
    }
  },
  {
    id: 'form_standard_intake',
    title: 'MOPS Standard Master Intake Form',
    badge: 'Master Template',
    description: 'Universal intake foundation containing Stakeholder Information and Regional & Country Geo Targeting.',
    updatedAt: '2026-09-16',
    schema: {
      title: 'MOPS Standard Master Intake Form',
      description: 'Standard request intake template for all marketing and campaign projects.',
      sections: [
        window.BUILTIN_SECTIONS[0].data,
        window.BUILTIN_SECTIONS[1].data
      ]
    }
  },
  {
    id: 'form_audience_request',
    title: 'Audience & Targeted Campaign Intake',
    badge: 'Audience Preset',
    description: 'Audience strategy intake with Outbound Play logic, Folloze board URL, and target account thresholds.',
    updatedAt: '2026-09-16',
    schema: {
      title: 'Audience & Targeted Campaign Intake',
      description: 'Specify audience targeting parameters, account counts, and campaign alignment.',
      sections: [
        window.BUILTIN_SECTIONS[0].data,
        {
          title: 'Audience Strategy & List Parameters',
          id: 'Audience_Section',
          condition: null,
          fields: [
            {
              label: 'Audience Request Type',
              formData: 'audienceRequestType',
              id: '62869498003888f7ac001e49ad8ef921',
              type: window.MOPS_TYPES.TYPE_SELECT,
              col: 'col-lg-6',
              placeholder: 'Select request type',
              tooltip: 'Choose your audience strategy category',
              required: true,
              options: ['Outbound Play', 'Inbound Nurture', 'Account-Based Marketing (ABM)', 'Event Audience List'],
              resets: ['follozeBoardURL', 'numberOfAccounts'],
              condition: null
            },
            {
              label: 'Folloze Board URL',
              formData: 'follozeBoardURL',
              id: '633af3c3001889c914144e50d655a63e',
              type: window.MOPS_TYPES.TYPE_TEXT,
              col: 'col-lg-6',
              placeholder: 'https://cisco.folloze.com/...',
              tooltip: 'Link to active Folloze board',
              required: true,
              condition: {
                field: 'audienceRequestType',
                comparison: '==',
                value: 'Outbound Play'
              }
            },
            {
              label: 'Number of Target Accounts',
              formData: 'numberOfAccounts',
              id: '6989f17600082d2edf73abf1f984afea',
              type: window.MOPS_TYPES.TYPE_TEXT_NUMBER,
              col: 'col-lg-6',
              placeholder: 'e.g. 50',
              tooltip: 'Total accounts in scope',
              required: true,
              min: 1,
              max: 5000,
              condition: {
                field: 'audienceRequestType',
                comparison: '==',
                value: 'Outbound Play'
              }
            },
            {
              label: 'Expected Launch Quarter',
              formData: 'launchQuarter',
              type: window.MOPS_TYPES.TYPE_SELECT,
              col: 'col-lg-6',
              placeholder: 'Choose Quarter',
              tooltip: 'Target Cisco quarter',
              required: true,
              options: ['FY26 Q1', 'FY26 Q2', 'FY26 Q3', 'FY26 Q4'],
              condition: null
            }
          ]
        }
      ]
    }
  }
];

