/**
 * MOPS Form Mockup & Rule Studio - Rule Engine
 * Real-time condition evaluation for conditional show/hide logic,
 * advanced logic groups (DNF: Groups of ANDs joined by OR),
 * dynamic defaults, validation, and field resets.
 */

window.RuleEngine = {
  /**
   * Evaluate whether a single condition rule is satisfied against current form values
   * @param {Object} rule - { field: 'fieldName', comparison: '==', value: 'Expected' }
   * @param {Object} formValues - Key-value map of current form values { fieldName: value }
   * @returns {boolean}
   */
  evaluateCondition(rule, formValues) {
    if (!rule || !rule.field) return true;

    const actual = formValues[rule.field];
    const target = rule.value;
    const comp = (rule.comparison || '==').toLowerCase().replace(/\s+/g, '');

    // Actual value string representation
    const actualStr = (actual === undefined || actual === null) ? '' : String(actual).trim();
    const targetStr = (target === undefined || target === null) ? '' : String(target).trim();

    switch (comp) {
      // Picklist / Selection operators (from screenshot: "is Selected", "is Not Selected")
      case 'isselected':
      case 'selected':
        if (Array.isArray(actual)) {
          return actual.some(a => {
            const val = (typeof a === 'object' && a !== null) ? (a.value || a.label || '') : String(a);
            return val.toLowerCase() === targetStr.toLowerCase();
          });
        }
        return actualStr.toLowerCase() === targetStr.toLowerCase();

      case 'isnotselected':
      case 'notselected':
        if (Array.isArray(actual)) {
          return !actual.some(a => {
            const val = (typeof a === 'object' && a !== null) ? (a.value || a.label || '') : String(a);
            return val.toLowerCase() === targetStr.toLowerCase();
          });
        }
        return actualStr.toLowerCase() !== targetStr.toLowerCase();

      case '==':
      case 'equals':
        return actualStr.toLowerCase() === targetStr.toLowerCase();

      case '!=':
      case 'notequals':
        return actualStr.toLowerCase() !== targetStr.toLowerCase();

      case 'contains':
        return actualStr.toLowerCase().includes(targetStr.toLowerCase());

      case 'doesnotcontain':
      case 'not':
        return !actualStr.toLowerCase().includes(targetStr.toLowerCase());

      case 'startswith':
        return actualStr.toLowerCase().startsWith(targetStr.toLowerCase());

      case 'endswith':
        return actualStr.toLowerCase().endsWith(targetStr.toLowerCase());

      case 'regex':
        try {
          const regex = new RegExp(targetStr, 'i');
          return regex.test(actualStr);
        } catch (e) {
          return actualStr.toLowerCase().includes(targetStr.toLowerCase());
        }

      case 'notempty':
      case 'isnotempty':
        if (Array.isArray(actual)) return actual.length > 0;
        return actualStr.length > 0;

      case 'empty':
      case 'isempty':
        if (Array.isArray(actual)) return actual.length === 0;
        return actualStr.length === 0;

      case '>':
        return Number(actual) > Number(target);

      case '<':
        return Number(actual) < Number(target);

      case '>=':
        return Number(actual) >= Number(target);

      case '<=':
        return Number(actual) <= Number(target);

      default:
        return actualStr.toLowerCase() === targetStr.toLowerCase();
    }
  },

  /**
   * Evaluate whether an advanced logic display config is satisfied
   * Supports DNF: Groups of ANDs connected by OR
   */
  evaluateAdvancedDisplay(displayConfig, formValues) {
    if (!displayConfig || !Array.isArray(displayConfig.groups) || displayConfig.groups.length === 0) {
      return true;
    }

    const validGroups = displayConfig.groups.filter(g => Array.isArray(g.rules) && g.rules.length > 0);
    if (validGroups.length === 0) return true;

    const outerOp = (displayConfig.operator || 'OR').toUpperCase();

    if (outerOp === 'OR') {
      return validGroups.some(group => {
        const innerOp = (group.operator || 'AND').toUpperCase();
        if (innerOp === 'AND') {
          return group.rules.every(r => this.evaluateCondition(r, formValues));
        } else {
          return group.rules.some(r => this.evaluateCondition(r, formValues));
        }
      });
    } else {
      return validGroups.every(group => {
        const innerOp = (group.operator || 'AND').toUpperCase();
        if (innerOp === 'AND') {
          return group.rules.every(r => this.evaluateCondition(r, formValues));
        } else {
          return group.rules.some(r => this.evaluateCondition(r, formValues));
        }
      });
    }
  },

  /**
   * Evaluate direct plain JavaScript code expression
   * `data` and `formValues` are passed into the function scope
   */
  evaluateCustomJs(customJs, formValues) {
    if (!customJs || !customJs.trim()) return true;
    try {
      const data = formValues || {};
      const code = customJs.includes('return') ? customJs : `return (${customJs});`;
      const fn = new Function('data', 'formValues', code);
      return Boolean(fn(data, formValues));
    } catch (e) {
      console.warn('Custom JS rule evaluation error:', e);
      return true; // fail-safe to visible so author is not blocked
    }
  },

  /**
   * Evaluate overall visibility for a field
   * Supports custom plain JavaScript, advancedLogic.display groups, and legacy conditions
   */
  isFieldVisible(field, formValues) {
    if (!field) return true;

    // Check Custom JavaScript mode first
    if (field.advancedLogic?.display?.mode === 'javascript' && field.advancedLogic?.display?.customJs?.trim()) {
      return this.evaluateCustomJs(field.advancedLogic.display.customJs, formValues);
    }

    // Check Advanced Logic display groups next
    if (field.advancedLogic && field.advancedLogic.display && Array.isArray(field.advancedLogic.display.groups) && field.advancedLogic.display.groups.length > 0) {
      return this.evaluateAdvancedDisplay(field.advancedLogic.display, formValues);
    }

    // Fallback to legacy single condition or condition array
    if (!field.condition || field.condition === true) return true;

    if (Array.isArray(field.condition)) {
      if (field.condition.length === 0) return true;
      const type = (field.conditionType || 'AND').toUpperCase();

      if (type === 'OR') {
        return field.condition.some(cond => this.evaluateCondition(cond, formValues));
      } else {
        return field.condition.every(cond => this.evaluateCondition(cond, formValues));
      }
    }

    if (typeof field.condition === 'object') {
      return this.evaluateCondition(field.condition, formValues);
    }

    return true;
  },

  /**
   * Evaluate whether a field is conditionally required via advancedLogic.validation
   */
  isFieldRequired(field, formValues) {
    if (!field) return false;
    if (field.required) return true;

    if (field.advancedLogic?.validation?.requiredIf) {
      const reqIf = field.advancedLogic.validation.requiredIf;
      if (reqIf.enabled && Array.isArray(reqIf.groups) && reqIf.groups.length > 0) {
        return this.evaluateAdvancedDisplay(reqIf, formValues);
      }
    }
    return false;
  },

  /**
   * Evaluate whether a field is conditionally disabled/read-only
   */
  isFieldDisabled(field, formValues) {
    if (!field) return false;
    if (field.disabled) return true;

    if (field.advancedLogic?.editability?.disabledIf) {
      const disIf = field.advancedLogic.editability.disabledIf;
      if (disIf.enabled && Array.isArray(disIf.groups) && disIf.groups.length > 0) {
        return this.evaluateAdvancedDisplay(disIf, formValues);
      }
    }
    return false;
  },

  /**
   * Evaluate dynamic default value if configured in advancedLogic.defaultValue
   */
  resolveDynamicDefault(field, formValues) {
    if (!field?.advancedLogic?.defaultValue?.rules?.length) return undefined;
    for (const rule of field.advancedLogic.defaultValue.rules) {
      if (this.evaluateCondition(rule.condition, formValues)) {
        return rule.value;
      }
    }
    return undefined;
  },

  /**
   * Evaluate overall visibility for a whole section
   */
  isSectionVisible(section, formValues) {
    if (!section || !section.condition) return true;
    if (section.condition === true) return true;

    if (Array.isArray(section.condition)) {
      if (section.condition.length === 0) return true;
      const type = (section.conditionType || 'AND').toUpperCase();
      if (type === 'OR') {
        return section.condition.some(cond => this.evaluateCondition(cond, formValues));
      } else {
        return section.condition.every(cond => this.evaluateCondition(cond, formValues));
      }
    }

    if (typeof section.condition === 'object') {
      return this.evaluateCondition(section.condition, formValues);
    }

    return true;
  },

  /**
   * Reset fields specified in `resets: [...]` or fields that became invisible
   */
  applyResets(changedFieldName, formSchema, formValues) {
    const resetsToRun = [];

    // Find the changed field
    for (const section of formSchema.sections || []) {
      for (const f of section.fields || []) {
        if (f.formData === changedFieldName && Array.isArray(f.resets)) {
          resetsToRun.push(...f.resets);
        }
      }
    }

    // Clear values in formValues
    for (const resetKey of resetsToRun) {
      if (formValues[resetKey] !== undefined) {
        formValues[resetKey] = '';
      }
    }

    return resetsToRun;
  }
};
