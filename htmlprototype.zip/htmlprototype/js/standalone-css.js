window.MOPS_STANDALONE_CSS = `/* ==========================================================================
   MOPS Form Studio - Cisco Enterprise Workstation Design System 2.0
   ========================================================================== */

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {
  /* Cisco Enterprise Blue Palette */
  --cui-primary: #005fb8;            /* Accessible Cisco Blue */
  --cui-primary-hover: #004d96;      /* Deep Blue Hover */
  --cui-primary-dark: #075985;       /* Dark Blue Pressed */
  --cui-primary-light: #e0f2fe;      /* Subtle Blue Tint */
  --cui-primary-tint: #f0f9ff;       /* Very Soft Highlight Tint */
  
  /* Deep Obsidian & Slate Neutrals */
  --cui-navy: #0f172a;               /* Slate 900 */
  --cui-navy-light: #1e293b;         /* Slate 800 */
  --cui-dark: #334155;               /* Slate 700 */
  --cui-body: #1e293b;               /* Primary Text */
  --cui-muted: #64748b;              /* Secondary Muted Text */
  
  /* Modern Surface & Border System */
  --cui-light-border: #e2e8f0;       /* Slate 200 Subtle Borders */
  --cui-border: #cbd5e1;             /* Slate 300 Default Borders */
  --cui-bg: #f8fafc;                 /* Slate 50 Clean Workstation Canvas */
  --cui-card-bg: #ffffff;            /* Pure White Card Surfaces */
  --cui-surface-hover: #f1f5f9;      /* Slate 100 Hover Background */
  
  /* Functional Semantic Statuses */
  --cui-danger: #ef4444;             /* Modern Crisp Red */
  --cui-danger-hover: #dc2626;
  --cui-danger-light: #fef2f2;
  --cui-danger-border: #fecaca;
  --cui-success: #10b981;            /* Emerald 500 */
  --cui-success-light: #ecfdf5;
  --cui-warning: #f59e0b;            /* Amber 500 */
  --cui-warning-light: #fffbeb;
  --cui-purple: #6366f1;             /* Indigo 500 */
  --cui-amber: #d97706;              /* Amber 600 */
  
  /* Elevation Shadows */
  --cui-shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.04);
  --cui-shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.06), 0 2px 4px -2px rgba(0, 0, 0, 0.04);
  --cui-shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.04);
  --cui-radius-sm: 6px;
  --cui-radius-md: 8px;
  --cui-radius-lg: 10px;
  --font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;

  /* Extended spacing scale */
  --sp-1: 4px; --sp-2: 8px; --sp-3: 12px; --sp-4: 16px; --sp-5: 20px; --sp-6: 24px; --sp-8: 32px;

  /* Extended radii */
  --cui-radius-xs: 3px;
  --cui-radius-xl: 12px;
  --cui-radius-2xl: 16px;

  /* Extended shadows */
  --cui-shadow-xl: 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.04);
  --cui-shadow-ring: 0 0 0 3px rgba(0, 95, 184,0.15);

  /* Surface layers */
  --surface-0: #ffffff;
  --surface-1: #f8fafc;
  --surface-2: #f1f5f9;

  /* Layout constants */
  --sidebar-width: 268px;
  --navbar-height: 48px;
  --statusbar-height: 26px;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: var(--font-family);
  background-color: var(--cui-bg);
  color: var(--cui-body);
  font-size: 14px;
  line-height: 1.5;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  -webkit-font-smoothing: antialiased;
}

/* Sidebar Forms Actions row */

.forms-sidebar-actions {
  display: flex;
  align-items: center;
  gap: 7px;
}

/* Gallery button - refined ghost pill style */
.forms-sidebar-gallery-btn {
  background: #ffffff;
  border: 1.5px solid #cbd5e1;
  color: #475569;
  border-radius: 7px;
  padding: 5px 10px;
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.18s ease;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  letter-spacing: 0.1px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  font-family: inherit;
}

.forms-sidebar-gallery-btn:hover {
  background: #f1f5f9;
  color: #1e293b;
  border-color: #94a3b8;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  transform: translateY(-1px);
}

.forms-sidebar-footer {
  padding: 10px 14px;
  border-top: 1px solid var(--cui-light-border);
  background: #f8fafc;
  margin-top: 8px;
}

.forms-sidebar-save-all-btn {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  color: #334155;
  font-size: 12px;
  font-weight: 600;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.forms-sidebar-save-all-btn:hover {
  background: #f0fdf4;
  border-color: #86efac;
  color: #166534;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

/* --------------------------------------------------------------------------
   Buttons
   -------------------------------------------------------------------------- */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 7px 14px;
  font-size: 13px;
  font-weight: 500;
  border-radius: 4px;
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 0.15s ease-in-out;
  outline: none;
  white-space: nowrap;
}

.btn-primary {
  background-color: var(--cui-primary);
  color: #ffffff;
}
.btn-primary:hover {
  background-color: var(--cui-primary-hover);
}

.btn-navy {
  background-color: var(--cui-navy-light);
  color: #ffffff;
  border-color: rgba(255, 255, 255, 0.2);
}
.btn-navy:hover {
  background-color: var(--cui-navy);
  border-color: var(--cui-primary);
}

.btn-outline {
  background-color: transparent;
  border-color: var(--cui-border);
  color: var(--cui-body);
}
.btn-outline:hover {
  background-color: rgba(0, 0, 0, 0.04);
  border-color: var(--cui-muted);
}

.btn-outline-white {
  background: transparent;
  border-color: rgba(255, 255, 255, 0.3);
  color: #ffffff;
}
.btn-outline-white:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: #ffffff;
}

.btn-danger {
  background-color: #fee2e2;
  color: var(--cui-danger);
  border-color: #fca5a5;
}
.btn-danger:hover {
  background-color: var(--cui-danger);
  color: #ffffff;
}

.btn-success {
  background-color: #d1fae5;
  color: #065f46;
  border-color: #6ee7b7;
  font-weight: 600;
}
.btn-success:hover {
  background-color: #059669;
  color: #ffffff;
  border-color: #059669;
}
/* Dirty / unsaved state - pulsing green glow */
.btn-success.is-dirty {
  background-color: #059669;
  color: #ffffff;
  border-color: #047857;
  box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.35);
  animation: pulse-apply 1.6s ease-in-out infinite;
}
@keyframes pulse-apply {
  0%, 100% { box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.35); }
  50%       { box-shadow: 0 0 0 6px rgba(5, 150, 105, 0.15); }
}

.btn-sm {
  padding: 4px 9px;
  font-size: 12px;
}

.btn-xs {
  padding: 3px 8px;
  font-size: 11.5px;
  border-radius: 5px;
}

.btn-icon-only {
  padding: 6px;
  border-radius: 4px;
}

/* --------------------------------------------------------------------------
   App Main Layout
   -------------------------------------------------------------------------- */
.app-container {
  display: flex;
  flex: 1;
  overflow: hidden;
  position: relative;
}

/* --------------------------------------------------------------------------
   Left Sidebar: Palette & Libraries
   -------------------------------------------------------------------------- */
.sidebar-palette {
  width: var(--sidebar-width);
  background-color: #ffffff;
  border-right: 1px solid var(--cui-light-border);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow: hidden;
  z-index: 20;
  transition: transform 0.25s ease;
}

.sidebar-tabs {
  display: flex;
  border-bottom: 1px solid var(--cui-light-border);
  background: #f8fafc;
  overflow-x: auto;
  scrollbar-width: none;
  flex-wrap: nowrap;
}
.sidebar-tabs::-webkit-scrollbar { display: none; }

.sidebar-tab-btn {
  flex: 1 1 auto;
  min-width: 52px;
  padding: 9px 6px 8px;
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  font-size: 11px;
  font-weight: 600;
  color: #94a3b8;
  cursor: pointer;
  text-align: center;
  transition: color 0.12s ease, border-color 0.12s ease, background 0.12s ease;
  white-space: nowrap;
  letter-spacing: 0.1px;
  font-family: inherit;
}

.sidebar-tab-btn:hover:not(.active) {
  color: #475569;
  background: rgba(0,0,0,0.02);
}

.sidebar-tab-btn.active {
  color: #0f172a;
  border-bottom-color: #005fb8;
  background: #ffffff;
  font-weight: 700;
}

.sidebar-tab-content {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.palette-section-title {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--cui-muted);
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.palette-grid {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 20px;
}

/* Draggable Palette Items */
.palette-item {
  background: #ffffff;
  border: 1px solid var(--cui-border);
  border-radius: 6px;
  padding: 10px 12px;
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: grab;
  user-select: none;
  transition: all 0.15s ease;
  box-shadow: var(--cui-shadow-sm);
}

.palette-item:hover {
  border-color: var(--cui-primary);
  box-shadow: 0 2px 6px rgba(0, 95, 184, 0.15);
  transform: translateY(-1px);
}

.palette-item:active {
  cursor: grabbing;
}

.palette-item-icon {
  width: 28px;
  height: 28px;
  border-radius: 4px;
  background: #f0f9ff;
  color: var(--cui-primary-dark);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  flex-shrink: 0;
}

.palette-item-info {
  flex: 1;
}

.palette-item-name {
  font-weight: 600;
  font-size: 13px;
  color: var(--cui-navy);
}

.palette-item-desc {
  font-size: 11px;
  color: var(--cui-muted);
}

/* Reusable Section / Field Card in Palette */
.library-card {
  background: #f8fafc;
  border: 1px solid var(--cui-border);
  border-left: 4px solid var(--cui-primary);
  border-radius: 6px;
  padding: 10px 12px;
  margin-bottom: 8px;
  cursor: grab;
  transition: all 0.15s ease;
}

.library-card:hover {
  border-color: var(--cui-primary);
  box-shadow: var(--cui-shadow-md);
  transform: translateY(-1px);
}

.library-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.library-card-title {
  font-weight: 600;
  font-size: 12.5px;
  color: var(--cui-navy);
}

.library-card-badge {
  font-size: 10px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 4px;
  background: #e0f2fe;
  color: #0369a1;
}

/* --------------------------------------------------------------------------
   Center Canvas (Builder & Review)
   -------------------------------------------------------------------------- */
.main-canvas-area {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  background-color: var(--cui-bg);
  position: relative;
}

.canvas-container {
  max-width: 1040px;
  margin: 0 auto;
}

/* Form Top Meta Banner */
.form-header-card {
  background: #ffffff;
  border: 1px solid var(--cui-border);
  border-top: 4px solid var(--cui-navy);
  border-radius: 6px;
  padding: 20px 24px;
  margin-bottom: 20px;
  box-shadow: var(--cui-shadow-sm);
}

.form-header-card h1 {
  font-size: 20px;
  font-weight: 700;
  color: var(--cui-navy);
  margin-bottom: 6px;
}

.form-header-card p {
  font-size: 13px;
  color: var(--cui-muted);
}

/* Section Container */
.form-section-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-left: 3px solid var(--cui-primary);
  border-radius: 8px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  transition: box-shadow 0.2s ease;
}

.form-section-card.drag-over {
  border-color: var(--cui-primary);
  box-shadow: 0 0 0 2px var(--cui-primary);
}

.section-header {
  padding: 10px 16px;
  background: #f8fafc;
  border-bottom: 1px solid #f1f5f9;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  gap: 8px;
}

.section-title-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
}

.section-drag-handle {
  cursor: grab;
  color: var(--cui-muted);
  padding: 4px;
}
.section-drag-handle:hover {
  color: var(--cui-dark);
}

.section-title-input {
  font-size: 15px;
  font-weight: 700;
  color: var(--cui-navy);
  border: 1px solid transparent;
  border-radius: 4px;
  padding: 4px 8px;
  outline: none;
  background: transparent;
  width: 60%;
}

.section-title-input:hover {
  border-color: var(--cui-light-border);
  background: #f8fafc;
}

.section-title-input:focus {
  border-color: var(--cui-primary);
  background: #ffffff;
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.15);
  outline: none;
}

.section-actions {
  display: flex;
  align-items: center;
  gap: 6px;
}

.section-body {
  padding: 20px;
  min-height: 80px;
}

/* Empty Dropzone in Section */
.section-dropzone-empty {
  border: 1.5px dashed #cbd5e1;
  border-radius: 8px;
  padding: 28px 20px;
  text-align: center;
  color: var(--cui-muted);
  background: #f8fafc;
  transition: all 0.2s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.section-dropzone-empty:hover {
  border-color: #005fb8;
  background: #f0f9ff;
}

.section-dropzone-empty.drag-over {
  border-color: #005fb8;
  background: #e0f2fe;
}

.section-dropzone-empty.drag-over {
  border-color: var(--cui-primary);
  background: #e0f2fe;
  color: var(--cui-primary-dark);
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.15);
}

.dropzone-empty-icon {
  font-size: 28px;
  margin-bottom: 8px;
  opacity: 0.8;
}

.dropzone-empty-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--cui-navy);
  margin-bottom: 4px;
}

.dropzone-empty-desc {
  font-size: 12px;
  color: var(--cui-muted);
  max-width: 420px;
  margin-bottom: 14px;
  line-height: 1.4;
}

.dropzone-quick-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
}

.sidebar-tip-banner {
  background: #e0f2fe;
  border-left: 3px solid var(--cui-primary);
  border-radius: 4px;
  padding: 8px 10px;
  margin-bottom: 12px;
  font-size: 11.5px;
  color: #0369a1;
  line-height: 1.4;
}

/* --------------------------------------------------------------------------
   Sidebar Forms Panel (replaces horizontal form-tab-strip)
   -------------------------------------------------------------------------- */

/* Header row inside the forms tab */
.forms-sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--cui-light-border);
}

.forms-sidebar-title {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--cui-muted);
}

/* + New Form button - premium gradient pill with glow */
.forms-sidebar-new-btn {
  background: #005fb8;
  color: #ffffff;
  border: none;
  border-radius: 6px;
  padding: 5px 11px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  transition: background 0.15s ease;
}

.forms-sidebar-new-btn:hover {
  background: #0369a1;
}

.forms-sidebar-new-btn:active {
  background: #075985;
}

/* Individual form card in the sidebar */
.sidebar-form-card {
  display: flex;
  align-items: center;
  gap: 0;
  border-radius: 8px;
  margin-bottom: 6px;
  background: #f8fafc;
  border: 1.5px solid var(--cui-light-border);
  cursor: pointer;
  transition: border-color 0.15s, box-shadow 0.15s, background 0.15s;
  overflow: hidden;
  position: relative;
}

.sidebar-form-card:hover {
  border-color: #93c5fd;
  background: #f0f9ff;
  box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}

.sidebar-form-card.active {
  border-color: var(--cui-primary);
  background: #f0f9ff;
  box-shadow: inset 3px 0 0 var(--cui-primary);
}

.sfc-main {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  flex: 1;
  min-width: 0;
}

.sfc-icon {
  font-size: 22px;
  line-height: 1;
  flex-shrink: 0;
}

.sfc-info {
  flex: 1;
  min-width: 0;
}

.sfc-name {
  font-size: 13px;
  font-weight: 600;
  color: var(--cui-body);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 1.3;
}

.sidebar-form-card.active .sfc-name {
  color: var(--cui-primary-dark);
}

.sfc-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 3px;
}

.sfc-ver-badge {
  background: var(--cui-primary);
  color: #fff;
  font-size: 9.5px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 20px;
  letter-spacing: 0.3px;
  flex-shrink: 0;
}

.sfc-ver-count {
  font-size: 11px;
  color: var(--cui-muted);
}

/* Active indicator bar on the left */
.sfc-active-indicator {
  width: 4px;
  align-self: stretch;
  background: var(--cui-primary);
  flex-shrink: 0;
  border-radius: 0 2px 2px 0;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
}

/* Empty state inside sidebar forms tab */
.forms-sidebar-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px 16px;
  text-align: center;
  color: var(--cui-muted);
  font-size: 13px;
}

.forms-sidebar-empty-icon {
  font-size: 36px;
  margin-bottom: 10px;
  opacity: 0.5;
}


/* --------------------------------------------------------------------------
   MOPS 12-Column Grid System
   -------------------------------------------------------------------------- */
.mops-grid-row {
  display: flex;
  flex-wrap: wrap;
  margin: -8px;
}

.mops-grid-col {
  padding: 8px;
  box-sizing: border-box;
  position: relative;
  transition: all 0.2s ease;
}

.col-12, .col-lg-12 { width: 100%; }
.col-6, .col-lg-6   { width: 50%; }
.col-4, .col-lg-4   { width: 33.333333%; }
.col-3, .col-lg-3   { width: 25%; }

@media (max-width: 768px) {
  .col-6, .col-lg-6,
  .col-4, .col-lg-4,
  .col-3, .col-lg-3 {
    width: 100%;
  }
}

/* --------------------------------------------------------------------------
   Field Card (Inside Canvas in Builder Mode)
   -------------------------------------------------------------------------- */
.canvas-field-card {
  background: #ffffff;
  border: 1px solid var(--cui-border);
  border-radius: 6px;
  padding: 12px 14px;
  height: 100%;
  position: relative;
  box-shadow: var(--cui-shadow-sm);
  transition: all 0.15s ease;
  cursor: pointer;
}

.canvas-field-card:hover {
  border-color: var(--cui-primary);
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.14);
}

.canvas-field-card.selected {
  border-color: var(--cui-primary);
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.3);
  background: #f0f9ff;
}

/* ============================================================
   Prominent Drag-and-Drop Insertion Indicators & Dropzones
   ============================================================ */

/* --------------------------------------------------------------------------
   Between-Row Drop Strip
   A thin full-width horizontal strip rendered below every row boundary
   so users can clearly drop a field BELOW an existing row (especially
   below full-width fields like Stakeholder Email).
   -------------------------------------------------------------------------- */
.between-row-drop-strip {
  width: 100%;
  height: 6px;
  border-radius: 4px;
  background: transparent;
  transition: all 0.18s ease;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  margin: 1px 0;
  cursor: default;
}

.between-row-drop-strip .between-row-strip-label {
  display: none;
  font-size: 11px;
  font-weight: 600;
  color: #005fb8;
  pointer-events: none;
  white-space: nowrap;
}

.between-row-drop-strip.drag-over {
  height: 44px !important;
  background: #f0f7ff !important;
  border: 2px dashed #005fb8 !important;
  border-radius: 8px !important;
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.14), 0 2px 12px rgba(0, 95, 184, 0.18) !important;
  cursor: copy !important;
}

.between-row-drop-strip.drag-over .between-row-strip-label {
  display: inline-block !important;
}

/* --------------------------------------------------------------------------
   Empty Half-Column Slot Dropzone
   Renders in the right 50% of a row when a half-width field has no pair
   -------------------------------------------------------------------------- */
.grid-empty-slot-col {
  /* mirrors the half-width col; visible at all times in builder */
}

.grid-empty-slot-dropzone {
  min-height: 90px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  border: 2px dashed #cbd5e1;
  border-radius: 8px;
  background: #f8fafc;
  cursor: pointer;
  transition: all 0.18s ease;
  user-select: none;
  box-sizing: border-box;
  position: relative;
}

.grid-empty-slot-dropzone .slot-icon {
  font-size: 20px;
  color: #94a3b8;
  line-height: 1;
  transition: color 0.15s;
}

.grid-empty-slot-dropzone .slot-label {
  font-size: 11.5px;
  font-weight: 600;
  color: #94a3b8;
  transition: color 0.15s;
}

.grid-empty-slot-dropzone .slot-sublabel {
  font-size: 10px;
  color: #b0bec5;
  text-align: center;
  padding: 0 6px;
  transition: color 0.15s;
}

.grid-empty-slot-dropzone:hover,
.grid-empty-slot-dropzone.drag-over {
  border-color: #005fb8 !important;
  background: #f0f7ff !important;
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.14), 0 2px 12px rgba(0, 95, 184, 0.18) !important;
}

.grid-empty-slot-dropzone:hover .slot-icon,
.grid-empty-slot-dropzone.drag-over .slot-icon {
  color: #005fb8;
}

.grid-empty-slot-dropzone:hover .slot-label,
.grid-empty-slot-dropzone.drag-over .slot-label {
  color: #005fb8;
}

.grid-empty-slot-dropzone:hover .slot-sublabel,
.grid-empty-slot-dropzone.drag-over .slot-sublabel {
  color: #3b82f6;
}

.grid-empty-slot-dropzone.drag-over .slot-icon {
  animation: slotPulse 0.6s ease-in-out infinite alternate;
}

@keyframes slotPulse {
  from { transform: scale(1);   opacity: 0.8; }
  to   { transform: scale(1.2); opacity: 1;   }
}

/* Top insertion zone at the very top of each section */
.section-top-insertion-zone {
  width: 100%;
  height: 6px;
  margin: 0 0 6px 0;
  border-radius: 4px;
  transition: all 0.15s ease-in-out;
  position: relative;
  background: transparent;
  box-sizing: border-box;
}
.section-top-insertion-zone.drag-over {
  height: 38px !important;
  background: #f0f9ff !important;
  border: 2px dashed #005fb8 !important;
  border-radius: 6px !important;
  box-shadow: 0 0 12px rgba(0, 95, 184, 0.28) !important;
  margin-bottom: 14px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
}
.section-top-insertion-zone.drag-over::after {
  content: ' Drop here to Insert at Position 1 (Top of Section)';
  color: #005fb8;
  font-weight: 700;
  font-size: 11.5px;
  letter-spacing: 0.2px;
}

/* Card Drag-Target Before (Insert before card / Position N) */
.canvas-field-card.drag-target-before,
.cisco-bld-field-card.drag-target-before {
  position: relative !important;
  border-top: 4px solid #005fb8 !important;
  border-color: #005fb8 !important;
  background: #f0f7ff !important;
  box-shadow: 0 -6px 16px rgba(0, 95, 184, 0.35) !important;
  transform: translateY(2px) !important;
}
.canvas-field-card.drag-target-before::before,
.cisco-bld-field-card.drag-target-before::before {
  content: ' Drop to Insert at Position ' attr(data-pos-before);
  position: absolute;
  top: -15px;
  left: 14px;
  background: #005fb8;
  color: #ffffff;
  font-size: 10.5px;
  font-weight: 700;
  padding: 2px 10px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.5);
  z-index: 100;
  pointer-events: none;
  white-space: nowrap;
  letter-spacing: 0.2px;
}

/* Card Drag-Target After (Insert after card / Position N+1) */
.canvas-field-card.drag-target-after,
.cisco-bld-field-card.drag-target-after {
  position: relative !important;
  border-bottom: 4px solid #005fb8 !important;
  border-color: #005fb8 !important;
  background: #f0f7ff !important;
  box-shadow: 0 6px 16px rgba(0, 95, 184, 0.35) !important;
  transform: translateY(-2px) !important;
}
.canvas-field-card.drag-target-after::after,
.cisco-bld-field-card.drag-target-after::after {
  content: ' Drop to Insert at Position ' attr(data-pos-after);
  position: absolute;
  bottom: -15px;
  left: 14px;
  background: #005fb8;
  color: #ffffff;
  font-size: 10.5px;
  font-weight: 700;
  padding: 2px 10px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.5);
  z-index: 100;
  pointer-events: none;
  white-space: nowrap;
  letter-spacing: 0.2px;
}

.field-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.field-type-pill {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.3px;
  padding: 2px 6px;
  border-radius: 4px;
  background: #f1f5f9;
  color: var(--cui-muted);
}

.field-badges {
  display: flex;
  align-items: center;
  gap: 4px;
}

.badge-rule {
  font-size: 10.5px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 4px;
  background: #fef3c7;
  color: #b45309;
  display: inline-flex;
  align-items: center;
  gap: 3px;
}

.badge-ba-note {
  font-size: 10px;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 4px;
  background: #fef08a;
  color: #854d0e;
  display: inline-flex;
  align-items: center;
  gap: 3px;
}

.badge-width {
  font-size: 10px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 4px;
  background: #e2e8f0;
  color: var(--cui-body);
}

.field-ba-note-callout {
  margin-top: 6px;
  padding: 5px 8px;
  background: #fefce8;
  border: 1px solid #fef08a;
  border-left: 3px solid #eab308;
  border-radius: 4px;
  font-size: 11px;
  color: #713f12;
  line-height: 1.35;
}

.btn-req-active {
  background-color: #fee2e2 !important;
  color: var(--cui-danger) !important;
  border-color: #fca5a5 !important;
  font-weight: 700;
}

.rule-connector-badge {
  display: inline-block;
  font-size: 10.5px;
  font-weight: 800;
  padding: 2px 8px;
  border-radius: 12px;
  background: #e0f2fe;
  color: #0369a1;
  text-align: center;
  margin: 6px 0;
  user-select: none;
}

.field-preview-label {
  font-size: 13px;
  font-weight: 600;
  color: var(--cui-navy);
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.req-star {
  color: var(--cui-danger);
  font-weight: bold;
}

.field-preview-widget {
  pointer-events: none;
  opacity: 0.85;
}

.field-card-footer {
  margin-top: 10px;
  padding-top: 8px;
  border-top: 1px dashed var(--cui-light-border);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.field-key-name {
  font-size: 11px;
  font-family: monospace;
  color: var(--cui-muted);
}

.field-card-actions {
  display: flex;
  gap: 4px;
}

/* --------------------------------------------------------------------------
   MOPS Form Controls (Rendered inputs & preview)
   -------------------------------------------------------------------------- */
.mops-input,
.mops-select,
.mops-textarea {
  width: 100%;
  padding: 8px 12px;
  font-size: 13.5px;
  font-family: inherit;
  color: var(--cui-body);
  background-color: #ffffff;
  border: 1px solid var(--cui-border);
  border-radius: 4px;
  outline: none;
  transition: all 0.15s ease;
}

.mops-input:focus,
.mops-select:focus,
.mops-textarea:focus {
  border-color: var(--cui-primary);
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.12);
  outline: none;
}

.mops-textarea {
  min-height: 70px;
  resize: vertical;
}

.mops-help-tip {
  font-size: 11.5px;
  color: var(--cui-muted);
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.info-icon {
  color: var(--cui-primary);
  font-size: 12px;
}

/* Checkbox & Radio */
.mops-checkbox-item,
.mops-radio-item {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 6px;
  font-size: 13px;
  cursor: pointer;
}

.mops-checkbox-item input,
.mops-radio-item input {
  accent-color: var(--cui-primary);
  width: 16px;
  height: 16px;
}

/* Multi-Select Tag Styling */
.mops-multiselect-box {
  border: 1px solid var(--cui-border);
  border-radius: 4px;
  padding: 6px;
  min-height: 38px;
  background: #ffffff;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.mops-tag {
  background: #e0f2fe;
  color: #0369a1;
  font-size: 12px;
  font-weight: 500;
  padding: 2px 8px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

/* File Upload Simulation */
.mops-file-drop {
  border: 1px dashed var(--cui-border);
  border-radius: 4px;
  padding: 16px;
  text-align: center;
  background: #f8fafc;
  color: var(--cui-muted);
  font-size: 12.5px;
}

/* Add Section Button on Canvas */
.add-section-btn-wrap {
  text-align: center;
  margin: 20px 0 40px;
}

.btn-add-section {
  border: 2px dashed var(--cui-border);
  background: #ffffff;
  color: var(--cui-navy);
  padding: 14px 28px;
  font-weight: 600;
  font-size: 14px;
  border-radius: 8px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s ease;
}

.btn-add-section:hover {
  border-color: var(--cui-primary);
  color: var(--cui-primary-dark);
  background: #f0f9ff;
  box-shadow: var(--cui-shadow-sm);
}

/* --------------------------------------------------------------------------
   Right Slide-out Drawer: Field Settings & Rule Builder
   -------------------------------------------------------------------------- */
.settings-drawer {
  width: 380px;
  background: #ffffff;
  border-left: 1px solid var(--cui-light-border);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  box-shadow: var(--cui-shadow-lg);
  z-index: 30;
  transform: translateX(100%);
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}

.settings-drawer.open {
  transform: translateX(0);
}

.drawer-header {
  padding: 16px 20px;
  border-bottom: 1px solid var(--cui-light-border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #ffffff;
}

.btn-drawer-close {
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  color: #1e293b !important;
  font-size: 14px;
  font-weight: 700;
  border-radius: 6px;
  width: 28px;
  height: 28px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.15s ease;
  line-height: 1;
}

.btn-drawer-close:hover {
  background: #fee2e2;
  border-color: #fca5a5;
  color: #dc2626 !important;
}

.drawer-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--cui-navy);
}

.drawer-tabs {
  display: flex;
  border-bottom: 1px solid var(--cui-light-border);
  background: #f8fafc;
}

.drawer-tab-btn {
  flex: 1;
  padding: 10px;
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--cui-muted);
  cursor: pointer;
  text-align: center;
}

.drawer-tab-btn.active {
  color: var(--cui-primary-dark);
  border-bottom-color: var(--cui-primary);
  background: #ffffff;
}

.drawer-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

.drawer-tab-pane {
  display: none;
}

.drawer-tab-pane.active {
  display: block;
}

/* Drawer Form Group */
.form-group {
  margin-bottom: 16px;
}

.form-label {
  display: block;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--cui-navy);
  margin-bottom: 6px;
}

.form-hint {
  font-size: 11px;
  color: var(--cui-muted);
  margin-top: 4px;
}

/* Width Picker Pills */
.width-picker {
  display: flex;
  gap: 6px;
}

.width-pill {
  flex: 1;
  padding: 8px 4px;
  font-size: 12px;
  font-weight: 600;
  text-align: center;
  border: 1px solid var(--cui-border);
  border-radius: 4px;
  background: #ffffff;
  cursor: pointer;
  transition: all 0.15s ease;
}

.width-pill:hover {
  border-color: var(--cui-primary);
}

.width-pill.active {
  border-color: var(--cui-primary);
  background: var(--cui-primary);
  color: #ffffff;
}

/* Options Editor in Drawer */
.options-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 10px;
}

.option-row {
  display: flex;
  gap: 6px;
  align-items: center;
}

/* Rule Builder Container */
.rule-card {
  background: #f8fafc;
  border: 1px solid var(--cui-border);
  border-left: 3px solid var(--cui-warning);
  border-radius: 6px;
  padding: 12px;
  margin-bottom: 12px;
}

.rule-row {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 8px;
}

.drawer-footer {
  padding: 12px 20px;
  border-top: 1px solid var(--cui-light-border);
  background: #f8fafc;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

/* Primary apply button - full width */
#btnApplyFieldChanges {
  width: 100%;
  padding: 8px 14px;
  font-size: 13px;
  border-radius: 6px;
  transition: all 0.2s ease;
}

/* Secondary row: Save to Library + Delete */
.drawer-footer-secondary {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 8px;
}

/* --------------------------------------------------------------------------
   Live Preview Multi-Variation Toolbar & Viewport
   -------------------------------------------------------------------------- */
.review-mode-banner {
  display: none;
  background: #ffffff;
  color: #1e293b;
  padding: 8px 20px;
  font-size: 12.5px;
  font-weight: 500;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #e2e8f0;
  flex-wrap: wrap;
  gap: 12px;
  z-index: 85;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
}

.review-banner-left {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.review-banner-tag {
  background: #005fb8;
  color: #ffffff;
  padding: 4px 9px;
  border-radius: 4px;
  font-weight: 800;
  font-size: 10.5px;
  letter-spacing: 0.6px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.review-banner-tag::before {
  content: '';
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #22c55e;
  box-shadow: 0 0 6px #22c55e;
}

.review-banner-subtitle {
  font-size: 11.5px;
  color: #94a3b8;
  font-weight: 500;
}

.review-variation-switcher {
  display: inline-flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 6px;
  padding: 3px;
  gap: 3px;
}

.rev-var-btn {
  background: transparent;
  color: #94a3b8;
  border: none;
  padding: 5px 12px;
  font-size: 11.5px;
  font-weight: 600;
  border-radius: 4px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.15s ease;
  font-family: inherit;
  white-space: nowrap;
}

.rev-var-btn:hover {
  background: rgba(255, 255, 255, 0.12);
  color: #ffffff;
}

.rev-var-btn.active {
  background: #005fb8;
  color: #ffffff;
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.3);
}

.rev-var-icon {
  font-size: 13px;
  line-height: 1;
}

.rev-var-label {
  letter-spacing: 0.1px;
}

.review-banner-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Expanded container for Live Preview */
.canvas-container.review-mode-active {
  max-width: 1200px !important;
  width: 100% !important;
}

/* Live Preview Viewport & Iframe */
.live-preview-container {
  width: 100%;
  margin: 0 auto;
}

.live-preview-viewport {
  width: 100%;
  background: #ffffff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.09);
  border: 1px solid #cbd5e1;
}

.live-preview-iframe {
  width: 100%;
  min-height: 850px;
  border: none;
  display: block;
  background: #ffffff;
}

/* Fade-in animation for conditional fields */
@keyframes slideDownFade {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.conditional-show {
  animation: slideDownFade 0.25s ease forwards;
}

.conditional-hidden {
  display: none !important;
}

/* --------------------------------------------------------------------------
   Developer Inspector (Slide-up drawer in Review Mode)
   -------------------------------------------------------------------------- */
.dev-inspector-panel {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: #0f172a;
  color: #f8fafc;
  border-top: 3px solid var(--cui-primary);
  max-height: 45vh;
  display: flex;
  flex-direction: column;
  z-index: 999;
  box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
  transform: translateY(100%);
  transition: transform 0.25s ease;
}

.dev-inspector-panel.open {
  transform: translateY(0);
}

.inspector-header {
  padding: 10px 20px;
  background: #1e293b;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #334155;
}

.inspector-code-wrap {
  flex: 1;
  overflow-y: auto;
  padding: 14px 20px;
  font-family: "Consolas", "Monaco", monospace;
  font-size: 12px;
  line-height: 1.6;
}

/* --------------------------------------------------------------------------
   Modals
   -------------------------------------------------------------------------- */
.mops-modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 14, 52, 0.7);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s ease;
}

.mops-modal-backdrop.open {
  display: flex !important;
  opacity: 1 !important;
  pointer-events: auto !important;
}

.mops-modal-dialog {
  background: #ffffff;
  border-radius: 10px;
  max-width: 640px;
  width: 95%;
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
  overflow: hidden;
  animation: modal-appear 0.2s cubic-bezier(0.16,1,0.3,1);
}

.mops-modal-header {
  padding: 16px 20px;
  border-bottom: 1px solid #f1f5f9;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
  background: #ffffff;
}

.mops-modal-title {
  font-size: 15px;
  font-weight: 700;
  color: #0f172a;
  letter-spacing: -0.2px;
}

.mops-modal-body {
  padding: 24px;
  overflow-y: auto;
  flex: 1;
}

.mops-modal-footer {
  padding: 12px 20px;
  border-top: 1px solid #f1f5f9;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 8px;
  flex-shrink: 0;
  background: #f8fafc;
}

/* Code Display Block */
.code-block {
  background: #0f172a;
  color: #38bdf8;
  font-family: "Consolas", monospace;
  font-size: 12.5px;
  padding: 16px;
  border-radius: 6px;
  overflow-x: auto;
  white-space: pre;
}

/* --------------------------------------------------------------------------
   Print Styles (for Spec Sheet export)
   -------------------------------------------------------------------------- */
@media print {
  body {
    background: #ffffff;
    height: auto;
    overflow: visible;
  }
  .mops-navbar,
  .sidebar-palette,
  .settings-drawer,
  .add-section-btn-wrap,
  .field-card-actions,
  .section-actions,
  .review-mode-banner,
  .dev-inspector-panel {
    display: none !important;
  }
  .app-container {
    display: block;
    height: auto;
  }
  .main-canvas-area {
    padding: 0;
    background: #ffffff;
  }
  .form-section-card {
    box-shadow: none;
    border: 1px solid #000000;
    page-break-inside: avoid;
    margin-bottom: 30px;
  }
}

/* --------------------------------------------------------------------------
   Forms Gallery Modal Styles
   -------------------------------------------------------------------------- */
.gallery-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  gap: 12px;
  flex-wrap: wrap;
}

.gallery-search-input {
  flex: 1;
  min-width: 220px;
  padding: 8px 14px;
  font-size: 13.5px;
  border: 1px solid var(--cui-border);
  border-radius: 4px;
  outline: none;
}

.gallery-search-input:focus {
  border-color: var(--cui-primary);
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.15);
}

.gallery-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
  gap: 16px;
}

.gallery-card {
  background: #ffffff;
  border: 1px solid var(--cui-border);
  border-top: 4px solid var(--cui-navy);
  border-radius: 6px;
  padding: 16px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-shadow: var(--cui-shadow-sm);
  transition: all 0.2s ease;
}

.gallery-card:hover {
  border-color: var(--cui-primary);
  box-shadow: var(--cui-shadow-md);
  transform: translateY(-2px);
}

.gallery-card.current-active {
  border-top-color: var(--cui-primary);
  background: #f8fafc;
}

.gallery-card-top {
  margin-bottom: 12px;
}

.gallery-card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 6px;
}

.gallery-card-title {
  font-size: 14.5px;
  font-weight: 700;
  color: var(--cui-navy);
  line-height: 1.3;
}

.gallery-card-desc {
  font-size: 12px;
  color: var(--cui-muted);
  line-height: 1.4;
  margin-bottom: 12px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.gallery-card-stats {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 14px;
}

.stat-pill {
  font-size: 10.5px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 4px;
  background: #f1f5f9;
  color: var(--cui-body);
}

.stat-pill.rules {
  background: #fef3c7;
  color: #92400e;
}

.gallery-card-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 12px;
  border-top: 1px solid var(--cui-light-border);
  gap: 6px;
}

/* ==========================================================================
   Drawer Improvements
   ========================================================================== */

.drawer-field-key-hint {
  font-size: 10.5px;
  color: var(--cui-muted);
  font-family: 'Courier New', Courier, monospace;
  letter-spacing: 0.3px;
}

.label-required-star {
  color: var(--cui-danger);
  font-weight: 700;
}

.drawer-inline-checks {
  display: flex;
  align-items: center;
  gap: 16px;
}

.check-required {
  background: #fff8f8;
  border: 1px solid #fecaca;
  border-radius: 5px;
  padding: 6px 10px;
}

.check-required input:checked ~ span {
  color: var(--cui-danger);
  font-weight: 600;
}

.drawer-options-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

/* ==========================================================================
   Workfront Mandatory Integration Block
   ========================================================================== */

.wf-integration-block {
  background: #f0f4ff;
  border: 1.5px solid #c7d7fc;
  border-radius: 8px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.wf-integration-header {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 4px;
}

.wf-cisco-icon {
  font-size: 18px;
  flex-shrink: 0;
  margin-top: 1px;
}

.wf-integration-title {
  font-size: 12.5px;
  font-weight: 700;
  color: #1e3a8a;
  margin-bottom: 2px;
}

.wf-integration-desc {
  font-size: 11px;
  color: #3b5bdb;
  line-height: 1.4;
}

/* Red border on empty mandatory WF inputs */
.mops-input.wf-field-missing {
  border-color: #f87171 !important;
  background: #fff5f5 !important;
  box-shadow: 0 0 0 2px rgba(248, 113, 113, 0.2) !important;
}

.mops-input.wf-field-missing::placeholder {
  color: #f87171;
}

/* ==========================================================================
   BA Notes Tab
   ========================================================================== */

.ba-notes-section {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.ba-notes-header {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #fffbeb;
  border: 1px solid #fde68a;
  border-radius: 7px;
  padding: 12px 14px;
}

.ba-notes-icon {
  font-size: 20px;
  flex-shrink: 0;
  margin-top: 1px;
}

.ba-notes-title {
  font-size: 13px;
  font-weight: 700;
  color: #92400e;
  margin-bottom: 3px;
}

.ba-notes-desc {
  font-size: 11.5px;
  color: #b45309;
  line-height: 1.5;
}

.ba-notes-textarea {
  border: 1px solid #fde68a !important;
  background: #fffdf0 !important;
  min-height: 140px;
  font-size: 12.5px;
  line-height: 1.6;
  resize: vertical;
}

.ba-notes-textarea:focus {
  border-color: #f59e0b !important;
  box-shadow: 0 0 0 2px rgba(245,158,11,0.2) !important;
}

/* BA Notes indicator on field card */
.field-ba-note-badge {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 10px;
  background: #fffbeb;
  border: 1px solid #fde68a;
  color: #92400e;
  padding: 1px 5px;
  border-radius: 3px;
  font-weight: 600;
}

/* ==========================================================================
   Display Rules - AND/OR Toggle & Enhanced Cards
   ========================================================================== */

.rules-intro {
  background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
  border: 1px solid #bae6fd;
  border-radius: 7px;
  padding: 12px 14px;
  margin-bottom: 14px;
}

.rules-intro-title {
  font-size: 12.5px;
  font-weight: 700;
  color: var(--cui-primary-dark);
  margin-bottom: 3px;
}

.rules-intro-desc {
  font-size: 11.5px;
  color: #0369a1;
  line-height: 1.5;
}

/* Always shown / no condition state */
.rules-always-shown {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  border-radius: 7px;
  padding: 12px 14px;
  margin-bottom: 12px;
  font-size: 12.5px;
  color: #166534;
}

.rules-always-icon {
  font-size: 18px;
  flex-shrink: 0;
}

.rules-add-first-btn {
  width: 100%;
  justify-content: center;
  padding: 9px;
  font-size: 12.5px;
}

/* AND / OR header toggle */
.rules-andor-header {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  background: #f8fafc;
  border: 1px solid var(--cui-light-border);
  border-radius: 7px;
  padding: 10px 12px;
  margin-bottom: 12px;
}

.rules-andor-label {
  font-size: 11.5px;
  color: var(--cui-muted);
  font-weight: 500;
}

.rules-andor-toggle {
  display: flex;
  gap: 3px;
  background: #e2e8f0;
  border-radius: 5px;
  padding: 2px;
}

.andor-btn {
  background: transparent;
  border: none;
  padding: 3px 10px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
  color: var(--cui-muted);
  cursor: pointer;
  transition: all 0.15s ease;
  letter-spacing: 0.3px;
  font-family: inherit;
}

.andor-btn.active {
  background: #ffffff;
  color: var(--cui-primary-dark);
  box-shadow: 0 1px 3px rgba(0,0,0,0.12);
}

.andor-btn:not(.active):hover {
  color: var(--cui-body);
}

/* Rule card */
.rule-card {
  background: #ffffff;
  border: 1px solid var(--cui-border);
  border-left: 3px solid var(--cui-warning);
  border-radius: 7px;
  padding: 12px 14px;
  margin-bottom: 8px;
  transition: box-shadow 0.15s ease;
}

.rule-card:hover {
  box-shadow: 0 2px 8px rgba(0,0,0,0.07);
}

.rule-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.rule-card-num {
  font-size: 10.5px;
  font-weight: 700;
  color: var(--cui-amber);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.rule-row {
  margin-bottom: 8px;
}

.rule-row-label {
  display: block;
  font-size: 10.5px;
  font-weight: 600;
  color: var(--cui-muted);
  text-transform: uppercase;
  letter-spacing: 0.4px;
  margin-bottom: 4px;
}

/* AND/OR connector between rules */
.rule-connector {
  text-align: center;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 1px;
  color: #ffffff;
  background: var(--cui-primary-dark);
  border-radius: 4px;
  padding: 2px 8px;
  display: inline-block;
  margin: 6px auto 10px;
  display: flex;
  justify-content: center;
}

.rule-no-fields {
  font-size: 12px;
  color: var(--cui-amber);
  background: #fffbeb;
  border: 1px solid #fde68a;
  border-radius: 5px;
  padding: 10px 12px;
}

/* Add more / clear all buttons row */
.rules-add-more {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
  flex-wrap: wrap;
}

.rules-add-more-btn {
  flex: 1;
}

/* Hint badge showing number of options available on a watched picklist field */
.rule-hint-badge {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  font-size: 9.5px;
  font-weight: 600;
  color: #0369a1;
  background: #e0f2fe;
  border: 1px solid #bae6fd;
  border-radius: 3px;
  padding: 1px 5px;
  letter-spacing: 0;
  text-transform: none;
  vertical-align: middle;
  margin-left: 4px;
}

/* Style native datalist inputs in rule cards */
.rule-val-input::-webkit-calendar-picker-indicator {
  opacity: 0.5;
  cursor: pointer;
}

/* BA Notes tab improvements */
.ba-notes-char-counter {
  font-size: 10px;
  color: var(--cui-muted);
  text-align: right;
  margin-top: 4px;
}

/* Save to Library button in drawer footer */
#btnSaveFieldToLib {
  transition: all 0.15s ease;
}
#btnSaveFieldToLib:hover {
  background: #fffbeb;
  border-color: #f59e0b;
  color: #92400e;
}

/* ==========================================================================
   Field Card - Enhanced with BA Notes indicator
   ========================================================================== */

.canvas-field-card .field-badges {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-wrap: wrap;
}

.badge-notes {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  font-size: 9.5px;
  background: #fffbeb;
  border: 1px solid #fde68a;
  color: #92400e;
  padding: 1px 5px;
  border-radius: 3px;
  font-weight: 600;
}

.badge-required {
  display: inline-flex;
  align-items: center;
  font-size: 9.5px;
  background: #fff1f2;
  border: 1px solid #fecdd3;
  color: #be123c;
  padding: 1px 5px;
  border-radius: 3px;
  font-weight: 700;
}

/* ==========================================================================
   Advanced Logic Studio (Matches Enterprise Visual Rule Builder)
   ========================================================================== */

.adv-logic-dialog {
  max-width: 1040px !important;
  width: 95vw !important;
  height: 86vh !important;
  max-height: 860px !important;
  display: flex !important;
  flex-direction: column !important;
  background: #f8fafc !important;
  border-radius: 10px !important;
  overflow: hidden !important;
  box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.35) !important;
}

/* Top Header Bar */
.adv-logic-header {
  padding: 16px 28px;
  background: #ffffff;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
}

.adv-logic-header-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.adv-logic-title-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.adv-logic-title {
  font-size: 20px;
  font-weight: 700;
  color: #0f172a;
  margin: 0;
  letter-spacing: -0.01em;
}

.adv-logic-info-icon {
  font-size: 13px;
  color: #64748b;
  width: 18px;
  height: 18px;
  border: 1px solid #cbd5e1;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: help;
  user-select: none;
}

.adv-logic-meta-strip {
  display: flex;
  align-items: center;
  gap: 28px;
  margin-top: 4px;
}

.adv-meta-item {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.adv-meta-label {
  font-size: 10.5px;
  color: #64748b;
  text-transform: capitalize;
  font-weight: 500;
}

.adv-meta-value {
  font-size: 13px;
  font-weight: 600;
  color: #1e293b;
}

.adv-logic-header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.adv-btn-discard {
  background: transparent !important;
  color: #475569 !important;
  border: 1px solid #cbd5e1 !important;
  border-radius: 20px !important;
  padding: 6px 18px !important;
  font-size: 13px !important;
  font-weight: 600 !important;
  cursor: pointer !important;
  transition: all 0.15s ease !important;
}

.adv-btn-discard:hover {
  background: #f1f5f9 !important;
  color: #0f172a !important;
}

.adv-btn-apply {
  background: #1e40af !important;
  color: #ffffff !important;
  border: 1px solid #1e40af !important;
  border-radius: 20px !important;
  padding: 6px 24px !important;
  font-size: 13px !important;
  font-weight: 600 !important;
  cursor: pointer !important;
  box-shadow: 0 2px 4px rgba(30, 64, 175, 0.25) !important;
  transition: all 0.15s ease !important;
}

.adv-btn-apply:hover {
  background: #1d4ed8 !important;
  border-color: #1d4ed8 !important;
  box-shadow: 0 4px 6px rgba(30, 64, 175, 0.35) !important;
}

/* Modal Body Layout */
.adv-logic-body {
  display: flex;
  flex: 1;
  min-height: 0;
  overflow: hidden;
}

/* Left Vertical Navigation Sidebar */
.adv-logic-sidebar {
  width: 160px;
  background: #ffffff;
  border-right: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
  padding: 16px 0;
  flex-shrink: 0;
}

.adv-sidebar-tab {
  text-align: left;
  padding: 10px 20px;
  font-size: 13px;
  font-weight: 500;
  color: #64748b;
  border: none;
  background: transparent;
  cursor: pointer;
  transition: all 0.15s ease;
  border-left: 3px solid transparent;
  width: 100%;
}

.adv-sidebar-tab:hover {
  color: #0f172a;
  background: #f8fafc;
}

.adv-sidebar-tab.active {
  color: #0f172a;
  font-weight: 700;
  background: #f1f5f9;
  border-left-color: #1e40af;
}

/* Right Content Canvas */
.adv-logic-content {
  flex: 1;
  padding: 24px 32px;
  overflow-y: auto;
  background: #f8fafc;
}

.adv-pane-header-tip {
  font-size: 12.5px;
  color: #475569;
  margin-bottom: 18px;
  line-height: 1.5;
}

.adv-subpane-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
}

/* Form-Scoped Display Logic Notification Banner */
.adv-form-scope-banner {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 6px;
  padding: 10px 14px;
  font-size: 12px;
  color: #1e40af;
  margin-bottom: 16px;
  line-height: 1.45;
}

.adv-form-scope-banner .scope-icon {
  font-size: 15px;
  flex-shrink: 0;
  margin-top: 1px;
}

/* Visual Rule Groups Container */
.adv-groups-tree {
  display: flex;
  flex-direction: column;
  gap: 0;
}

/* Rule Group Card */
.adv-group-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 14px 18px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
  position: relative;
}

.adv-group-body {
  display: flex;
  gap: 14px;
  align-items: stretch;
}

/* Vertical Left Rail with AND badge */
.adv-group-rail {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  width: 38px;
  flex-shrink: 0;
}

.adv-group-rail-line {
  position: absolute;
  top: 6px;
  bottom: 6px;
  left: 50%;
  transform: translateX(-50%);
  width: 2px;
  background: #cbd5e1;
  z-index: 1;
}

.adv-badge-and {
  position: relative;
  z-index: 2;
  background: #1e3a8a;
  color: #ffffff;
  font-size: 10.5px;
  font-weight: 700;
  padding: 2px 8px;
  border-radius: 12px;
  letter-spacing: 0.02em;
  box-shadow: 0 1px 3px rgba(30, 58, 138, 0.3);
  user-select: none;
}

.adv-group-rules-list {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

/* Single Condition Row */
.adv-rule-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 12px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  gap: 10px;
  min-height: 40px;
  transition: all 0.15s ease;
}

.adv-rule-row:hover {
  border-color: #cbd5e1;
  background: #fbfcfe;
}

.adv-rule-content {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

/* Completed condition chips */
.adv-chip-field {
  font-weight: 700;
  color: #0f172a;
  font-size: 13px;
}

.adv-chip-val {
  background: #f1f5f9;
  color: #1e293b;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  border: 1px solid #e2e8f0;
}

.adv-chip-op {
  color: #64748b;
  font-size: 12.5px;
}

/* In-line inputs for editing */
.adv-rule-inputs {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  flex-wrap: wrap;
}

.adv-select-field {
  min-width: 170px;
  max-width: 220px;
  height: 32px;
  font-size: 12px;
  padding: 4px 8px;
  border-radius: 4px;
}

.adv-select-val,
.adv-input-val {
  min-width: 140px;
  max-width: 190px;
  height: 32px;
  font-size: 12px;
  padding: 4px 8px;
  border-radius: 4px;
}

.adv-is-connector {
  font-size: 12px;
  color: #64748b;
  font-style: normal;
  padding: 0 2px;
}

.adv-select-op {
  min-width: 130px;
  max-width: 160px;
  height: 32px;
  font-size: 12px;
  padding: 4px 8px;
  border-radius: 4px;
}

/* Incomplete warning state (Row 2 of Group 2 in user screenshot) */
.adv-rule-warning {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fffbeb;
  border: 1px dashed #f59e0b;
  border-radius: 5px;
  padding: 6px 12px;
  color: #b45309;
  font-size: 12px;
  flex: 1;
}

.adv-warn-icon {
  font-size: 15px;
}

.adv-btn-remove-rule {
  background: transparent;
  border: none;
  color: #94a3b8;
  font-size: 15px;
  cursor: pointer;
  padding: 4px 6px;
  border-radius: 4px;
  line-height: 1;
  transition: all 0.15s ease;
}

.adv-btn-remove-rule:hover {
  color: #ef4444;
  background: #fee2e2;
}

/* Group Action Footer */
.adv-group-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  padding-top: 6px;
  border-top: 1px dashed #e2e8f0;
}

.adv-btn-add-rule {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 600;
  color: #0f172a;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 5px;
  padding: 4px 10px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.adv-btn-add-rule:hover {
  background: #f8fafc;
  border-color: #94a3b8;
}

.adv-btn-delete-group {
  font-size: 11.5px;
  color: #ef4444;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 3px 8px;
}

.adv-btn-delete-group:hover {
  text-decoration: underline;
}

/* OR Connector Between Groups (maroon pill from screenshot) */
.adv-or-connector {
  display: flex;
  align-items: center;
  padding: 10px 0 10px 22px;
  position: relative;
}

.adv-badge-or {
  background: #881337;
  color: #ffffff;
  font-size: 10.5px;
  font-weight: 700;
  padding: 2px 10px;
  border-radius: 12px;
  letter-spacing: 0.02em;
  box-shadow: 0 1px 3px rgba(136, 19, 55, 0.3);
  user-select: none;
}

/* Add Group Button at bottom */
.adv-add-group-row {
  margin-top: 14px;
}

.adv-btn-add-group {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12.5px;
  font-weight: 600;
  color: #0f172a;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 6px 14px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.adv-btn-add-group:hover {
  background: #f8fafc;
  border-color: #64748b;
}

/* Field Card Action Button for Logic */
.btn-logic-trigger {
  font-size: 11px !important;
  font-weight: 600 !important;
  padding: 2px 7px !important;
  color: #1e40af !important;
  border-color: #bfdbfe !important;
  background: #eff6ff !important;
}

.btn-logic-trigger:hover {
  background: #dbeafe !important;
  border-color: #93c5fd !important;
  color: #1d4ed8 !important;
}

/* ==========================================================================
   Canvas Document Header Card
   ========================================================================== */
.canvas-doc-header-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  overflow: hidden;
}

.canvas-doc-header-card:focus-within {
  border-color: #005fb8;
  box-shadow: 0 4px 14px rgba(0, 95, 184, 0.12);
}

/* Form-Level Version Picker in Canvas Header Card */
.form-ver-picker-wrap {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #f8fafc;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 2px 6px 2px 8px;
  transition: all 0.15s ease;
  margin-left: 4px;
}

.form-ver-picker-wrap:hover {
  border-color: #005fb8;
  background: #f0f9ff;
  box-shadow: 0 1px 4px rgba(0, 95, 184, 0.12);
}

.form-ver-label {
  font-size: 10.5px;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  user-select: none;
}

.form-version-select {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  padding: 4px 8px;
  font-size: 12px;
  font-weight: 600;
  color: #1e293b;
  cursor: pointer;
  font-family: inherit;
  outline: none;
  transition: border-color 0.12s ease;
}

.form-version-select:hover {
  border-color: #cbd5e1;
}

.form-version-select:focus {
  border-color: #005fb8;
  box-shadow: 0 0 0 3px rgba(0, 95, 184,0.1);
}

.form-version-select option {
  background: #ffffff;
  color: #0f172a;
  font-size: 12.5px;
  font-weight: 500;
  padding: 4px 8px;
}

.form-ver-history-btn {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  color: #334155;
  border-radius: 4px;
  padding: 2px 6px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s ease;
  line-height: 1.2;
}

.form-ver-history-btn:hover {
  background: #005fb8;
  color: #ffffff;
  border-color: #005fb8;
  transform: scale(1.05);
}

/* ==========================================================================
   Desktop Application Bottom Status Bar
   ========================================================================== */
.desktop-status-bar {
  height: var(--statusbar-height);
  background: #0f172a;
  border-top: 1px solid #1e293b;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  font-size: 11px;
  color: #64748b;
  flex-shrink: 0;
  gap: 8px;
}

.status-left, .status-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.status-indicator-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #22c55e;
  display: inline-block;
  margin-right: 7px;
  box-shadow: 0 0 0 2px rgba(34,197,94,0.25);
  flex-shrink: 0;
}

.status-sep {
  color: #334155;
  margin: 0 7px;
  user-select: none;
}

.status-badge {
  background: #1e293b;
  color: #38bdf8;
  padding: 1px 6px;
  border-radius: 3px;
  font-size: 10.5px;
  font-weight: 600;
}

/* ==========================================================================
   Saved / Reusable Fields Cards in Sidebar Library
   ========================================================================== */
.saved-field-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-left: 4px solid #005fb8;
  border-radius: 6px;
  padding: 10px 12px;
  margin-bottom: 8px;
  cursor: pointer;
  transition: all 0.18s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
}

.saved-field-card:hover {
  border-color: #005fb8;
  box-shadow: 0 3px 8px rgba(0, 95, 184, 0.15);
  transform: translateY(-1px);
}

.saved-field-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}

.saved-field-name {
  font-size: 12.5px;
  font-weight: 600;
  color: #0f172a;
  display: flex;
  align-items: center;
  gap: 6px;
}

.saved-field-key {
  font-size: 11px;
  color: #64748b;
  font-family: 'Courier New', Courier, monospace;
}

.saved-field-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 6px;
  padding-top: 6px;
  border-top: 1px dashed #f1f5f9;
}

.saved-field-badge {
  font-size: 10px;
  font-weight: 600;
  padding: 1px 6px;
  border-radius: 3px;
  background: #e0f2fe;
  color: #005fb8;
}

.saved-field-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.btn-saved-action {
  background: #f8fafc;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  padding: 2px 6px;
  font-size: 11px;
  color: #334155;
  cursor: pointer;
  transition: all 0.12s ease;
}

.btn-saved-action:hover {
  background: #005fb8;
  border-color: #005fb8;
  color: #ffffff;
}

.btn-saved-action.btn-danger-hover:hover {
  background: #ef4444;
  border-color: #ef4444;
  color: #ffffff;
}

/* ==========================================================================
   Advanced Logic: Visual vs JavaScript Code Editor
   ========================================================================== */
.logic-mode-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 7px;
  padding: 6px 12px;
  margin-bottom: 14px;
  flex-wrap: wrap;
  gap: 8px;
}

.logic-mode-pills {
  display: flex;
  gap: 6px;
}

.logic-mode-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 600;
  padding: 5px 12px;
  border-radius: 5px;
  border: 1px solid #cbd5e1;
  background: #ffffff;
  color: #334155;
  cursor: pointer;
  transition: all 0.15s ease;
}

.logic-mode-pill:hover {
  background: #f1f5f9;
  border-color: #94a3b8;
}

.logic-mode-pill.active {
  background: #0f172a;
  border-color: #0f172a;
  color: #ffffff;
  box-shadow: 0 2px 5px rgba(15, 23, 42, 0.2);
}

.logic-mode-hint {
  font-size: 11px;
  color: #64748b;
}

/* JS Code Editor Card */
.js-editor-card {
  background: #0f172a;
  border: 1px solid #1e293b;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.25);
}

.js-editor-header {
  background: #1e293b;
  border-bottom: 1px solid #334155;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 10px;
}

.js-editor-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.js-editor-badge {
  background: #f7df1e;
  color: #000000;
  font-weight: 800;
  font-size: 10.5px;
  padding: 1px 5px;
  border-radius: 3px;
  letter-spacing: 0.5px;
}

.js-snippets-row {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}

.snippet-label {
  font-size: 11px;
  color: #94a3b8;
  font-weight: 600;
}

.btn-snippet {
  background: #334155;
  border: 1px solid #475569;
  color: #f1f5f9;
  border-radius: 4px;
  padding: 3px 8px;
  font-size: 11px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.12s ease;
}

.btn-snippet:hover {
  background: #005fb8;
  border-color: #005fb8;
  color: #ffffff;
}

.js-editor-instruction {
  background: rgba(0, 95, 184, 0.12);
  border-bottom: 1px solid rgba(0, 95, 184, 0.25);
  color: #bae6fd;
  padding: 8px 14px;
  font-size: 12px;
  line-height: 1.4;
}

.js-editor-instruction code {
  background: rgba(0, 0, 0, 0.4);
  color: #38bdf8;
  padding: 1px 5px;
  border-radius: 3px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px;
}

.js-code-box {
  padding: 4px 8px;
  background: #090d16;
}

.js-code-textarea {
  width: 100%;
  background: transparent;
  color: #e2e8f0;
  border: none;
  outline: none;
  font-family: Consolas, 'Fira Code', Menlo, Monaco, 'Courier New', monospace;
  font-size: 13px;
  line-height: 1.6;
  resize: vertical;
  padding: 8px;
  box-sizing: border-box;
}

.js-editor-status-bar {
  background: #131c2b;
  border-top: 1px solid #1e293b;
  padding: 8px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  font-size: 11.5px;
  flex-wrap: wrap;
}

.js-syntax-badge {
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 4px;
}

.js-syntax-badge.valid {
  background: rgba(16, 185, 129, 0.15);
  color: #34d399;
  border: 1px solid rgba(16, 185, 129, 0.3);
}

.js-syntax-badge.error {
  background: rgba(239, 68, 68, 0.15);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.3);
}

.js-test-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.js-test-result {
  font-weight: 700;
  font-size: 11.5px;
}

.js-test-result.visible {
  color: #34d399;
}

.js-test-result.hidden {
  color: #fbbf24;
}

/* ==========================================================================
   Improvised Top Navbar & Form-Level Elements (MOPs FORM Studio)
   ========================================================================== */

.nav-breadcrumb-divider {
  color: #475569;
  font-size: 15px;
  margin: 0 4px;
  user-select: none;
  font-weight: 300;
}

.nav-active-form-pill {
  display: flex;
  align-items: center;
  gap: 6px;
  background: rgba(0, 95, 184, 0.12);
  border: 1px solid rgba(0, 95, 184, 0.32);
  border-radius: 6px;
  padding: 3px 10px;
  font-size: 12px;
  font-weight: 600;
  color: #38bdf8;
  max-width: 280px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.nav-active-icon {
  font-size: 13px;
  line-height: 1;
}

.nav-active-name {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nav-autosave-badge {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 11.5px;
  color: #94a3b8;
  padding: 4px 10px;
  background: rgba(255, 255, 255, 0.04);
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  transition: all 0.2s ease;
}

.save-pulse-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #fbbf24;
  display: none;
  flex-shrink: 0;
}

.save-pulse-dot.saving {
  background: #38bdf8;
  box-shadow: 0 0 8px #38bdf8;
  transform: scale(1.3);
}

.nav-user-chip {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 3px 11px 3px 4px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  cursor: default;
  transition: background 0.15s;
}

.nav-user-chip:hover {
  background: rgba(255, 255, 255, 0.08);
}

.user-avatar-circle {
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: linear-gradient(135deg, #005fb8, #005fb8);
  color: #ffffff;
  font-size: 10px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  letter-spacing: 0.5px;
  box-shadow: 0 1px 4px rgba(0, 95, 184, 0.4);
}

.user-chip-meta {
  display: flex;
  flex-direction: column;
  line-height: 1.15;
}

.user-chip-name {
  font-size: 11px;
  font-weight: 600;
  color: #e2e8f0;
}

.user-chip-role {
  font-size: 9.5px;
  color: #64748b;
}

.tab-actions-divider {
  width: 1px;
  height: 20px;
  background: #243045;
  margin: 0 3px;
  flex-shrink: 0;
}

.doc-config-file-pill {
  font-family: 'Courier New', monospace;
  font-size: 11px;
  color: #005fb8;
  background: #e0f2fe;
  padding: 2px 8px;
  border-radius: 4px;
  border: 1px solid #bae6fd;
  font-weight: 600;
}

/* Shortcuts Grid in Modal */
.shortcuts-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  margin-bottom: 16px;
}

.shortcut-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  font-size: 12.5px;
  color: #334155;
}

.shortcut-item kbd {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-bottom-width: 2px;
  border-radius: 4px;
  padding: 2px 6px;
  font-size: 11px;
  font-weight: 700;
  color: #0f172a;
  font-family: monospace;
}

.studio-tips-box {
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 6px;
  padding: 10px 14px;
  font-size: 12px;
  color: #1e40af;
  line-height: 1.5;
}

/* ==========================================================================
   SPRINT FORM VERSIONING & TIME-MACHINE STYLES
   ========================================================================== */

/* Top Navbar Version Badge */
.nav-version-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: rgba(0, 95, 184, 0.1);
  border: 1px solid rgba(0, 188, 235, 0.35);
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  color: #005fb8;
  cursor: pointer;
  transition: all 0.2s ease;
  user-select: none;
  margin-left: 8px;
}

.nav-version-badge:hover {
  background: rgba(0, 188, 235, 0.22);
  border-color: #005fb8;
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.15);
}

.nav-version-status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #10b981;
  display: inline-block;
}

.nav-version-status-dot.active {
  box-shadow: 0 0 6px #10b981;
}

.nav-version-caret {
  font-size: 10px;
  opacity: 0.7;
}

/* Historical Snapshot Banner */
.version-snapshot-alert {
  background: linear-gradient(90deg, #1e293b 0%, #0f172a 100%);
  border: 1px solid #f59e0b;
  border-left-width: 4px;
  border-radius: 8px;
  padding: 10px 16px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 4px 14px rgba(245, 158, 11, 0.15);
  animation: fadeInAlert 0.3s ease;
}

@keyframes fadeInAlert {
  from { opacity: 0; transform: translateY(-6px); }
  to { opacity: 1; transform: translateY(0); }
}

.vsa-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.vsa-icon {
  font-size: 22px;
}

.vsa-title {
  font-size: 13.5px;
  font-weight: 600;
  color: #fbbf24;
}

.vsa-sub {
  font-size: 12px;
  color: #cbd5e1;
}

.vsa-actions {
  display: flex;
  gap: 8px;
  align-items: center;
}

/* Sprint Save Version Modal Card */
.sprint-snapshot-header-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px 16px;
}

.sprint-snapshot-stats {
  font-size: 12px;
  font-weight: 600;
  color: #0369a1;
  background: #e0f2fe;
  padding: 5px 12px;
  border-radius: 20px;
  border: 1px solid #bae6fd;
}

/* Quick Chips */
.quick-chip-row {
  display: flex;
  gap: 6px;
  margin-top: 6px;
  flex-wrap: wrap;
}

.quick-chip {
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  border-radius: 12px;
  padding: 2px 8px;
  font-size: 11px;
  font-weight: 500;
  color: #475569;
  cursor: pointer;
  transition: all 0.15s;
}

.quick-chip:hover {
  background: #e2e8f0;
  color: #0f172a;
  border-color: #94a3b8;
}

/* Version History Modal Layout */
.vh-subtitle {
  font-size: 12px;
  color: #64748b;
  font-weight: 500;
  margin-left: 8px;
}

.vh-modal-body {
  height: 580px;
}

.vh-sidebar {
  width: 320px;
  flex-shrink: 0;
  border-right: 1px solid #e2e8f0;
  background: #f8fafc;
  display: flex;
  flex-direction: column;
}

.vh-sidebar-header {
  padding: 12px 16px;
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #ffffff;
}

.vh-sidebar-title {
  font-size: 13px;
  font-weight: 700;
  color: #000e34;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.vh-sidebar-badge {
  font-size: 11px;
  font-weight: 600;
  color: #005fb8;
  background: #e0f2fe;
  padding: 2px 8px;
  border-radius: 10px;
}

.vh-version-list {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.vh-card {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  padding: 10px 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
}

.vh-card:hover {
  border-color: #005fb8;
  box-shadow: 0 2px 6px rgba(0, 188, 235, 0.15);
}

.vh-card.active {
  border-color: #005fb8;
  background: #f0f9ff;
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.15);
}

.vh-card.active::before {
  content: '';
  position: absolute;
  left: 0;
  top: 8px;
  bottom: 8px;
  width: 3px;
  background: #005fb8;
  border-radius: 0 2px 2px 0;
}

.vh-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}

.vh-card-tag {
  font-size: 13.5px;
  font-weight: 700;
  color: #000e34;
}

.vh-card-status {
  font-size: 10.5px;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 4px;
  text-transform: uppercase;
}

.vh-card-status.active {
  background: #dcfce7;
  color: #15803d;
}

.vh-card-status.archived {
  background: #f1f5f9;
  color: #64748b;
}

.vh-card-status.review {
  background: #fef3c7;
  color: #b45309;
}

.vh-card-sprint {
  font-size: 12px;
  font-weight: 600;
  color: #005fb8;
  margin-bottom: 4px;
}

.vh-card-date {
  font-size: 11px;
  color: #94a3b8;
  margin-bottom: 6px;
}

.vh-card-stats {
  display: flex;
  gap: 6px;
  font-size: 11px;
  color: #475569;
}

.vh-sidebar-footer {
  padding: 10px;
  border-top: 1px solid #e2e8f0;
  background: #ffffff;
}

/* Main Details Panel */
.vh-main-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: #ffffff;
  overflow: hidden;
}

.vh-panel-top {
  padding: 14px 20px 0 20px;
  border-bottom: 1px solid #e2e8f0;
  background: #ffffff;
}

.vh-detail-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.vh-detail-title-group {
  display: flex;
  align-items: center;
  gap: 10px;
}

.vh-version-title {
  font-size: 20px;
  font-weight: 800;
  color: #000e34;
}

.vh-sprint-badge {
  font-size: 12.5px;
  font-weight: 700;
  background: #e0f2fe;
  color: #0369a1;
  padding: 3px 10px;
  border-radius: 6px;
}

.vh-status-pill {
  font-size: 11px;
  font-weight: 700;
  background: #dcfce7;
  color: #15803d;
  padding: 2px 8px;
  border-radius: 12px;
}

.vh-detail-meta {
  font-size: 12px;
  color: #64748b;
}

.vh-tab-strip {
  display: flex;
  gap: 20px;
}

.vh-tab-btn {
  background: none;
  border: none;
  border-bottom: 3px solid transparent;
  padding: 8px 4px;
  font-size: 13px;
  font-weight: 600;
  color: #64748b;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s ease;
}

.vh-tab-btn:hover {
  color: #000e34;
}

.vh-tab-btn.active {
  color: #005fb8;
  border-bottom-color: #005fb8;
}

.vh-diff-count-badge {
  background: #fef08a;
  color: #854d0e;
  font-size: 10.5px;
  padding: 1px 6px;
  border-radius: 10px;
  font-weight: 700;
}

.vh-panel-content {
  flex: 1;
  overflow-y: auto;
  padding: 16px 20px;
}

.vh-pane {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.vh-card-label {
  font-size: 11px;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 6px;
}

.vh-notes-card {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px 16px;
}

.vh-notes-text {
  font-size: 13.5px;
  line-height: 1.6;
  color: #1e293b;
  white-space: pre-wrap;
}

.vh-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.vh-stat-box {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px;
  text-align: center;
}

.vh-stat-val {
  display: block;
  font-size: 18px;
  font-weight: 800;
  color: #000e34;
}

.vh-stat-lbl {
  font-size: 11.5px;
  color: #64748b;
}

.vh-sections-breakdown {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px 16px;
}

.vh-section-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  margin-right: 8px;
  margin-bottom: 6px;
  color: #334155;
}

/* Visual Diff Engine Styles */
.vh-diff-summary-card {
  display: flex;
  gap: 12px;
  padding: 10px 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  margin-bottom: 12px;
}

.diff-badge-pill {
  font-size: 12px;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.diff-badge-pill.added {
  background: #dcfce7;
  color: #166534;
  border: 1px solid #bbf7d0;
}

.diff-badge-pill.removed {
  background: #fee2e2;
  color: #991b1b;
  border: 1px solid #fecaca;
}

.diff-badge-pill.modified {
  background: #fef3c7;
  color: #92400e;
  border: 1px solid #fde68a;
}

.diff-badge-pill.unchanged {
  background: #f1f5f9;
  color: #475569;
  border: 1px solid #cbd5e1;
}

.vh-diff-item {
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  padding: 10px 12px;
  margin-bottom: 8px;
  background: #ffffff;
}

.vh-diff-item.added {
  border-left: 4px solid #10b981;
  background: #f0fdf4;
}

.vh-diff-item.removed {
  border-left: 4px solid #ef4444;
  background: #fef2f2;
}

.vh-diff-item.modified {
  border-left: 4px solid #f59e0b;
  background: #fffbeb;
}

.diff-change-prop {
  font-size: 11.5px;
  margin-top: 4px;
  color: #475569;
}

.diff-old-val {
  text-decoration: line-through;
  color: #b91c1c;
  background: #fee2e2;
  padding: 1px 4px;
  border-radius: 3px;
}

.diff-new-val {
  font-weight: 600;
  color: #15803d;
  background: #dcfce7;
  padding: 1px 4px;
  border-radius: 3px;
}

.vh-json-viewer {
  background: #0f172a;
  color: #38bdf8;
  padding: 14px;
  border-radius: 6px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  max-height: 380px;
  overflow: auto;
  line-height: 1.5;
}

.vh-panel-footer {
  padding: 12px 20px;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* Save Form Prompt Card Styles */
.save-option-card {
  transition: all 0.2s ease;
}
.save-option-card:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}
.save-option-card.recommended:hover {
  border-color: #0070ba;
  box-shadow: 0 4px 16px rgba(0, 80, 115, 0.12);
}

/* ==========================================================================
   Navbar Version Picker & Quick Switcher Dropdown
   ========================================================================== */
.nav-ver-picker-wrap {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.nav-version-select {
  background: rgba(255, 255, 255, 0.16);
  border: 1px solid rgba(255, 255, 255, 0.35);
  color: #ffffff;
  border-radius: 6px;
  padding: 4px 10px;
  font-size: 12.5px;
  font-weight: 700;
  cursor: pointer;
  outline: none;
  font-family: inherit;
  transition: all 0.2s ease;
}
.nav-version-select:hover, .nav-version-select:focus {
  background: rgba(255, 255, 255, 0.26);
  border-color: #005fb8;
  box-shadow: 0 0 10px rgba(0, 95, 184, 0.4);
}
.nav-version-select option {
  background: #001e38;
  color: #ffffff;
  font-size: 13px;
  font-weight: 500;
  padding: 6px 10px;
}

.nav-ver-picker-btn {
  background: rgba(255, 255, 255, 0.12);
  border: 1px solid rgba(255, 255, 255, 0.25);
  color: #ffffff;
  border-radius: 20px;
  padding: 5px 12px;
  font-size: 12px;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  cursor: pointer;
  transition: all 0.18s ease;
  font-family: inherit;
  outline: none;
}

.nav-ver-picker-btn:hover {
  background: rgba(255, 255, 255, 0.22);
  border-color: rgba(0, 95, 184, 0.8);
  box-shadow: 0 0 12px rgba(0, 95, 184, 0.35);
}

.nav-version-status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 6px #10b981;
}

.nav-ver-switch-hint {
  font-size: 11px;
  opacity: 0.85;
  font-weight: 600;
  background: rgba(0, 0, 0, 0.25);
  padding: 2px 7px;
  border-radius: 10px;
  margin-left: 2px;
}

.nav-ver-dropdown {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  min-width: 330px;
  background: #ffffff;
  color: #1e293b;
  border-radius: 10px;
  border: 1px solid #cbd5e1;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.25);
  z-index: 1050;
  overflow: hidden;
  animation: navVdDrop 0.18s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes navVdDrop {
  from { opacity: 0; transform: translateY(-6px); }
  to { opacity: 1; transform: translateY(0); }
}

.nav-vd-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 14px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #64748b;
}

.nav-vd-count {
  font-size: 10.5px;
  background: #e2e8f0;
  color: #475569;
  padding: 1px 7px;
  border-radius: 10px;
}

.nav-vd-list {
  max-height: 280px;
  overflow-y: auto;
  padding: 6px;
}

.nav-vd-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  border-radius: 7px;
  cursor: pointer;
  transition: all 0.12s ease;
  margin-bottom: 3px;
  border: 1px solid transparent;
}

.nav-vd-item:hover {
  background: #f0f9ff;
  border-color: #bae6fd;
}

.nav-vd-item.active {
  background: #e0f2fe;
  border-color: #7dd3fc;
}

.nav-vd-item-left {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.nav-vd-ver-tag {
  font-weight: 700;
  font-size: 13px;
  color: #0f172a;
  display: flex;
  align-items: center;
  gap: 6px;
}

.nav-vd-active-pill {
  font-size: 10px;
  font-weight: 700;
  background: #dcfce7;
  color: #166534;
  padding: 1px 6px;
  border-radius: 10px;
}

.nav-vd-sprint {
  font-size: 11px;
  color: #64748b;
}

.nav-vd-switch-btn {
  font-size: 11.5px;
  font-weight: 600;
  padding: 4px 10px;
  border-radius: 6px;
  border: 1px solid #cbd5e1;
  background: #ffffff;
  color: #005fb8;
  cursor: pointer;
  transition: all 0.15s ease;
  font-family: inherit;
}

.nav-vd-switch-btn:hover {
  background: #005fb8;
  color: #ffffff;
  border-color: #005fb8;
}

.nav-vd-footer {
  display: flex;
  gap: 6px;
  padding: 8px 12px;
  background: #f8fafc;
  border-top: 1px solid #e2e8f0;
}

.nav-vd-foot-btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px 10px;
  font-size: 11.5px;
  font-weight: 600;
  border-radius: 6px;
  border: 1px solid #cbd5e1;
  background: #ffffff;
  color: #334155;
  cursor: pointer;
  transition: all 0.12s ease;
  font-family: inherit;
}

.nav-vd-foot-btn:hover {
  background: #f1f5f9;
  border-color: #94a3b8;
}

.nav-vd-foot-btn.primary {
  background: #005073;
  color: #ffffff;
  border-color: #005073;
}

.nav-vd-foot-btn.primary:hover {
  background: #005fb8;
  border-color: #005fb8;
}

.vh-card-quick-swap-btn {
  font-size: 10px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 4px;
  background: #005fb8;
  color: #ffffff;
  border: 1px solid #005fb8;
  cursor: pointer;
  transition: all 0.15s ease;
  font-family: inherit;
  line-height: 1.2;
}

.vh-card-quick-swap-btn:hover {
  background: #0369a1;
  border-color: #0369a1;
  box-shadow: 0 2px 6px rgba(0, 95, 184, 0.35);
}

/* ==========================================================================
   Save Confirmation Modals & Pop Messages
   ========================================================================== */
.save-ver-download-option {
  transition: all 0.2s ease;
}
.save-ver-download-option:hover {
  background: #ecfdf5 !important;
  border-color: #10b981 !important;
}

#modalSaveVersionSuccess .mops-modal-dialog,
#modalSaveFormSuccess .mops-modal-dialog {
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.28), 0 0 0 1px rgba(0, 80, 115, 0.15);
  animation: mopsPopScale 0.22s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes mopsPopScale {
  0% {
    transform: scale(0.92);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

/* ==========================================================================
   Date Rules & Picker Constraints Drawer & Badges
   ========================================================================== */
.date-rules-intro {
  margin-bottom: 14px;
  padding: 10px 12px;
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  border-radius: 8px;
}
.date-rules-intro-title {
  font-size: 13px;
  font-weight: 700;
  color: #166534;
  margin-bottom: 3px;
}
.date-rules-intro-desc {
  font-size: 11.5px;
  color: #15803d;
  line-height: 1.4;
}

.date-rule-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}
.date-rule-card:hover {
  border-color: #cbd5e1;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
}
.date-rule-card-header {
  display: flex;
  align-items: center;
  gap: 10px;
}
.date-rule-icon {
  font-size: 18px;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f8fafc;
  border-radius: 6px;
  border: 1px solid #e2e8f0;
}
.date-rule-title-box {
  flex: 1;
  display: flex;
  flex-direction: column;
}
.date-rule-title {
  font-size: 12.5px;
  font-weight: 700;
  color: #0f172a;
}
.date-rule-subtitle {
  font-size: 11px;
  color: #64748b;
}
.date-rule-help {
  font-size: 11px;
  color: #64748b;
  margin-top: 6px;
  line-height: 1.4;
}

/* Modern Toggle Switch */
.mops-toggle-switch {
  position: relative;
  display: inline-block;
  width: 38px;
  height: 22px;
  margin-left: auto;
  flex-shrink: 0;
}
.mops-toggle-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.toggle-slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0; right: 0; bottom: 0;
  background-color: #cbd5e1;
  transition: 0.2s;
  border-radius: 22px;
}
.toggle-slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: 0.2s;
  border-radius: 50%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}
.mops-toggle-switch input:checked + .toggle-slider {
  background-color: #005fb8;
}
.mops-toggle-switch input:checked + .toggle-slider:before {
  transform: translateX(16px);
}

/* Live Rule Summary Card */
.date-rule-summary-card {
  background: #f8fafc;
  border: 1.5px dashed #cbd5e1;
  border-radius: 8px;
  padding: 12px;
  margin-top: 14px;
}
.date-rule-summary-header {
  font-size: 12px;
  font-weight: 700;
  color: #334155;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 6px;
}
.date-rule-summary-content {
  font-size: 11.5px;
  color: #475569;
  line-height: 1.5;
}

/* Badges shown under date fields in canvas */
.date-constraints-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 6px;
}
.date-rule-pill-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 7px;
  background: #e0f2fe;
  color: #0369a1;
  border: 1px solid #bae6fd;
  border-radius: 12px;
  font-size: 10.5px;
  font-weight: 600;
}
.date-input-preview-box {
  display: flex;
  flex-direction: column;
}

/* --------------------------------------------------------------------------
   Builder View Variation Switcher & Multi-Variation Styles
   -------------------------------------------------------------------------- */
.builder-variation-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 14px;
  background: #f8fafc;
  border-top: 1px solid #e2e8f0;
  border-bottom: 1px solid #e2e8f0;
  margin: 10px -20px 14px -20px;
  flex-wrap: wrap;
  gap: 10px;
}

.builder-var-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.builder-var-badge {
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.6px;
  text-transform: uppercase;
  background: #002b49;
  color: #005fb8;
  padding: 3px 8px;
  border-radius: 4px;
}

.builder-var-right {
  display: flex;
  align-items: center;
}

.builder-var-hint {
  font-size: 11.5px;
  color: #475569;
  font-weight: 500;
}

/* --------------------------------------------------------------------------
   Variation 1: MOPS Cisco Brand (Builder Canvas)
   Official flat Cisco enterprise portal layout with red left asterisks
   -------------------------------------------------------------------------- */
.canvas-container.builder-variant-cisco {
  background: #eaedf2;
  transition: background 0.2s ease;
}

.builder-variant-cisco .canvas-inner {
  max-width: 1140px;
}

.cisco-bld-topbar {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 20px 24px 16px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}

.cisco-bld-title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.cisco-bld-title {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 15px;
  font-weight: 700;
  color: #000e34;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.cisco-bld-sub {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 12.5px;
  color: #475569;
  margin-top: 4px;
}

.cisco-bld-divider {
  height: 2px;
  background: #002b49;
  margin-top: 14px;
  border-radius: 1px;
}

/* Flat Cisco Section Blocks */
.cisco-bld-section {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-left: 3px solid #005fb8;
  border-radius: 8px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  overflow: hidden;
  transition: box-shadow 0.2s ease;
}

.cisco-bld-section.drag-over {
  border-color: #005fb8;
  box-shadow: 0 0 0 2px #005fb8;
}

.cisco-bld-sec-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  background: #f8fafc;
  border-bottom: 1px solid #f1f5f9;
  gap: 8px;
}

.cisco-bld-sec-title-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
}

.cisco-bld-sec-title-input {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 14.5px;
  font-weight: 700;
  color: #000e34;
  border: 1px solid transparent;
  border-radius: 3px;
  padding: 4px 8px;
  background: transparent;
  width: 60%;
  outline: none;
  transition: all 0.15s ease;
}

.cisco-bld-sec-title-input:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
}

.cisco-bld-sec-title-input:focus {
  background: #ffffff;
  border-color: #005fb8;
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.15);
}

.cisco-bld-sec-actions {
  display: flex;
  align-items: center;
  gap: 6px;
}

/* Flat Cisco Field Cards */
.cisco-bld-field-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  padding: 12px 14px;
  margin-bottom: 14px;
  position: relative;
  transition: all 0.15s ease;
  cursor: pointer;
}

.cisco-bld-field-card:hover {
  border-color: #005fb8;
  box-shadow: 0 2px 8px rgba(0, 188, 235, 0.15);
}

.cisco-bld-field-card.selected {
  border-color: #005fb8;
  box-shadow: 0 0 0 2px rgba(0, 188, 235, 0.35);
  background: #f8fbff;
}

.cisco-bld-label-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.cisco-bld-label {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 13px;
  font-weight: 600;
  color: #1e293b;
  display: flex;
  align-items: center;
  line-height: 1.3;
}

.cisco-req-star {
  color: #d9381e;
  font-weight: 700;
  font-size: 14px;
  margin-right: 4px;
  line-height: 1;
}

.cisco-bld-tools {
  display: flex;
  align-items: center;
  gap: 4px;
  opacity: 0.85;
  transition: opacity 0.15s ease;
}

.cisco-bld-field-card:hover .cisco-bld-tools {
  opacity: 1;
}

.cisco-tool-btn {
  font-size: 11px;
  padding: 2px 6px;
  border: 1px solid #cbd5e1;
  background: #f8fafc;
  color: #334155;
  border-radius: 3px;
  cursor: pointer;
  font-family: inherit;
  transition: all 0.15s ease;
}

.cisco-tool-btn:hover {
  background: #e0f2fe;
  border-color: #005fb8;
  color: #005fb8;
}

.cisco-tool-del:hover {
  background: #fee2e2;
  border-color: #ef4444;
  color: #dc2626;
}

.cisco-bld-widget {
  margin: 6px 0;
}

.cisco-bld-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: #94a3b8;
  padding-top: 6px;
  border-top: 1px dashed #e2e8f0;
  margin-top: 6px;
}

/* --------------------------------------------------------------------------
   Variation 3: Step Wizard (Builder Canvas)
   Guided multi-step wizard canvas with numbered step tabs
   -------------------------------------------------------------------------- */
.wizard-builder-nav {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 10px 14px;
  margin-bottom: 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.wizard-builder-step-tab {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 14px;
  border-radius: 4px;
  background: #f8fafc;
  border: 1px solid #cbd5e1;
  font-size: 12.5px;
  font-weight: 600;
  color: #334155;
  cursor: pointer;
  transition: all 0.15s ease;
}

.wizard-builder-step-tab:hover {
  background: #e0f2fe;
  border-color: #005fb8;
  color: #005fb8;
}

.wizard-builder-step-tab.active {
  background: #002b49;
  border-color: #002b49;
  color: #ffffff;
}

.wizard-step-circle {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: rgba(0,0,0,0.08);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
}

.wizard-builder-step-tab.active .wizard-step-circle {
  background: #005fb8;
  color: #002b49;
}

.wizard-step-footer-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  padding: 12px 18px;
  margin-top: 20px;
  margin-bottom: 20px;
}

/* ==========================================================================
   ENTERPRISE HEADER & GLOBAL WORKSPACE SHELL (Cisco UI 2.0+ Enhanced)
   ========================================================================== */
.mops-navbar {
  height: var(--navbar-height);
  background: #0f172a;
  border-bottom: 1px solid #1a2740;
  display: flex;
  align-items: center;
  padding: 0 16px;
  gap: 12px;
  flex-shrink: 0;
  z-index: 100;
  position: relative;
}

.mops-brand {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
  min-width: 0;
}

.top-nav-divider, .top-brand-sep {
  width: 1px;
  height: 24px;
  background: rgba(255, 255, 255, 0.12);
  margin: 0 4px;
  flex-shrink: 0;
}

/* Active Form Quick Switcher Pill */
.top-active-form-selector {
  display: flex;
  align-items: center;
  gap: 8px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 8px;
  padding: 4px 10px;
  cursor: pointer;
  transition: all 0.2s ease;
  max-width: 320px;
}
.top-active-form-selector:hover {
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(0, 188, 235, 0.5);
}
.top-form-icon {
  font-size: 15px;
  flex-shrink: 0;
}
.top-form-label {
  font-size: 12.5px;
  font-weight: 600;
  color: #f8fafc;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 180px;
}
.top-form-version-chip {
  font-size: 10px;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(0, 95, 184, 0.12);
  color: #38bdf8;
  letter-spacing: 0.3px;
  border: 1px solid rgba(0, 188, 235, 0.3);
}
.top-form-chevron {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.5);
}

/* Center Section: Command Search & Unified Mode Bar */
.mops-navbar-center {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  justify-content: center;
  max-width: 720px;
}

/* Command Palette Search Trigger Button */
.top-command-search-bar {
  background: #1e293b;
  border: 1px solid #334155;
  border-radius: 8px;
  padding: 6px 12px;
  display: flex;
  align-items: center;
  gap: 8px;
  width: 320px;
  max-width: 100%;
  cursor: pointer;
  transition: border-color 0.15s, box-shadow 0.15s;
  color: #94a3b8;
  font-size: 13px;
  font-family: inherit;
}
.top-command-search-bar:hover {
  border-color: #475569;
  box-shadow: 0 0 0 1px #475569;
}
.top-command-search-bar .cmd-icon {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.5);
}
.top-command-search-bar .cmd-text {
  flex: 1;
  text-align: left;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cmd-kbd {
  background: #0f172a;
  border: 1px solid #334155;
  border-radius: 4px;
  padding: 1px 6px;
  font-size: 10.5px;
  color: #64748b;
  font-family: 'Menlo', 'Monaco', 'Consolas', monospace;
  flex-shrink: 0;
}

/* Segmented Mode Bar in Navbar */
.top-mode-segmented-bar {
  display: flex;
  background: #1e293b;
  border: 1px solid #334155;
  border-radius: 8px;
  padding: 3px;
  gap: 2px;
}
.top-mode-tab {
  background: transparent;
  border: none;
  padding: 4px 12px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: #94a3b8;
  display: flex;
  align-items: center;
  gap: 5px;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
  font-family: inherit;
}
.top-mode-tab:hover {
  color: #ffffff;
  background: rgba(255, 255, 255, 0.08);
}
.top-mode-tab.active {
  background: #0f172a;
  color: #f8fafc;
  box-shadow: 0 1px 3px rgba(0,0,0,0.3);
}
.top-mode-tab .top-mode-icon {
  font-size: 13px;
}

/* Right Actions */
.mops-navbar-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

/* Autosave Sync Badge */
.top-sync-badge {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.6);
  padding: 4px 8px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.08);
  white-space: nowrap;
}
.top-sync-pulse {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 6px rgba(16, 185, 129, 0.8);
}
.top-sync-pulse.unsaved {
  background: #f59e0b;
  box-shadow: 0 0 6px rgba(245, 158, 11, 0.8);
}

/* Top Action Buttons */
.top-action-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px 14px;
  font-size: 12.5px;
  font-weight: 600;
  border-radius: 7px;
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
  font-family: inherit;
}
.top-btn-save {
  background: #005fb8;
  color: #ffffff;
  border-color: #0369a1;
}
.top-btn-save:hover {
  background: #0369a1;
  border-color: #075985;
}
.top-btn-milestone {
  background: rgba(255, 255, 255, 0.08);
  color: rgba(255, 255, 255, 0.9);
  border-color: rgba(255, 255, 255, 0.15);
}
.top-btn-milestone:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
}
.top-btn-share {
  background: rgba(0, 188, 235, 0.15);
  color: #38bdf8;
  border-color: rgba(0, 188, 235, 0.35);
}
.top-btn-share:hover {
  background: rgba(0, 95, 184, 0.15);
  color: #ffffff;
}

/* Dropdown Container & Flyout */
.top-dropdown-container {
  position: relative;
  display: inline-block;
}
.top-dropdown-flyout {
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  background: #1e293b;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 8px;
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.4);
  padding: 6px;
  min-width: 260px;
  z-index: 300;
  display: none;
}
.top-dropdown-flyout.open {
  display: block;
  animation: dropdownFadeIn 0.15s ease;
}
.dropdown-flyout-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  border-radius: 6px;
  text-decoration: none;
  color: #e2e8f0;
  transition: background 0.15s ease;
}
.dropdown-flyout-item:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #ffffff;
}
.flyout-icon {
  font-size: 16px;
  flex-shrink: 0;
}
.flyout-title {
  font-size: 12.5px;
  font-weight: 600;
  color: #f8fafc;
}
.flyout-desc {
  font-size: 10.5px;
  color: #94a3b8;
}
.flyout-divider {
  height: 1px;
  background: rgba(255, 255, 255, 0.1);
  margin: 4px 0;
}

/* Icon button */
.top-icon-btn {
  width: 32px;
  height: 32px;
  background: transparent;
  border: 1px solid #334155;
  border-radius: 7px;
  color: #94a3b8;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.15s ease;
  font-family: inherit;
}
.top-icon-btn:hover {
  background: #1e293b;
  color: #cbd5e1;
  border-color: #475569;
}

/* User Persona Chip */
.top-user-chip {
  display: flex;
  align-items: center;
  gap: 8px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  padding: 3px 10px 3px 4px;
  cursor: default;
}
.top-user-avatar {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  background: linear-gradient(135deg, #005fb8, #8b5cf6);
  color: #ffffff;
  font-size: 11px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}
.top-user-meta {
  display: flex;
  flex-direction: column;
  line-height: 1.1;
}
.top-user-name {
  font-size: 11px;
  font-weight: 600;
  color: #f1f5f9;
}
.top-user-role {
  font-size: 9px;
  color: #38bdf8;
  font-weight: 500;
}

/* ==========================================================================
   COMMAND PALETTE (Spotlight Quick Search)
   ========================================================================== */
.command-palette-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.65);
  backdrop-filter: blur(6px);
  z-index: 1000;
  display: none;
  align-items: flex-start;
  justify-content: center;
  padding-top: 80px;
}
.command-palette-backdrop.open {
  display: flex;
  animation: cpFadeIn 0.15s ease;
}
@keyframes cpFadeIn {
  from { opacity: 0; transform: translateY(-8px); }
  to   { opacity: 1; transform: translateY(0); }
}
.command-palette-modal {
  width: 620px;
  max-width: 92vw;
  background: #0f172a;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.55);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.command-palette-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 18px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  background: rgba(255, 255, 255, 0.03);
}
.cp-input {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: #ffffff;
  font-size: 15px;
  font-family: inherit;
}
.cp-input::placeholder {
  color: rgba(255, 255, 255, 0.4);
}
.cp-results-container {
  max-height: 400px;
  overflow-y: auto;
  padding: 8px;
}
.cp-group-title {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #64748b;
  padding: 8px 10px 4px 10px;
}
.cp-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  border-radius: 6px;
  cursor: pointer;
  color: #cbd5e1;
  transition: all 0.1s ease;
}
.cp-item:hover, .cp-item.selected {
  background: #005fb8;
  color: #ffffff;
}
.cp-item-icon {
  font-size: 16px;
  flex-shrink: 0;
}
.cp-item-label {
  flex: 1;
  font-size: 13px;
  font-weight: 500;
}
.cp-item-badge {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.15);
  color: rgba(255, 255, 255, 0.85);
}
.command-palette-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 18px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  font-size: 11px;
  color: #64748b;
  background: rgba(255, 255, 255, 0.02);
}

/* ==========================================================================
   CANVAS VIEWPORT & GOVERNANCE STATUS DOCK ENHANCEMENTS
   ========================================================================== */
.canvas-vp-segmented {
  display: flex;
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  border-radius: 7px;
  padding: 2px;
  gap: 1px;
}
.canvas-vp-btn {
  background: transparent;
  border: none;
  padding: 3px 9px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 600;
  color: #64748b;
  cursor: pointer;
  transition: all 0.12s ease;
  white-space: nowrap;
  font-family: inherit;
}
.canvas-vp-btn:hover {
  color: #0f172a;
}
.canvas-vp-btn.active {
  background: #ffffff;
  color: #0f172a;
  box-shadow: 0 1px 2px rgba(0,0,0,0.08);
  font-weight: 700;
}

.canvas-config-pill {
  font-family: monospace;
  font-size: 11px;
  color: #005fb8;
  background: #e0f2fe;
  border: 1px solid #bae6fd;
  border-radius: 4px;
  padding: 2px 8px;
  font-weight: 600;
}

.status-health-badge {
  color: #22c55e;
  font-weight: 600;
}
.status-health-badge.info {
  background: rgba(0, 188, 235, 0.15);
  color: #38bdf8;
  border-color: rgba(0, 188, 235, 0.3);
}
.status-storage-info {
  font-size: 11px;
  color: #94a3b8;
}
.status-hotkey-guide {
  font-size: 11px;
  color: #64748b;
}
.status-hotkey-guide kbd {
  background: #1e293b;
  border: 1px solid #334155;
  border-radius: 3px;
  padding: 1px 5px;
  font-size: 10px;
  font-family: 'Menlo', 'Monaco', 'Consolas', monospace;
  color: #94a3b8;
}

/* Streamlined Canvas Workspace Toolbar */
.canvas-workspace-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 14px;
  background: #ffffff;
  border-bottom: 1px solid #f1f5f9;
  gap: 10px;
  border-radius: 8px 8px 0 0;
  min-height: 48px;
}
.cw-toolbar-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}
.cw-toolbar-center {
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 1;
}
.cw-toolbar-right {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}

/* ==========================================================================
   VIEW CONFIG BUTTON (Canvas Toolbar)
   ========================================================================== */
.btn-view-mops-config {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: linear-gradient(135deg, #0f2a4a 0%, #0c3568 100%);
  color: #38bdf8;
  border: 1px solid rgba(56, 189, 248, 0.35);
  border-radius: 6px;
  padding: 4px 11px;
  font-size: 11.5px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.18s ease;
  white-space: nowrap;
  font-family: inherit;
  letter-spacing: 0.2px;
}
.btn-view-mops-config:hover {
  background: linear-gradient(135deg, #005fb8 0%, #0369a1 100%);
  color: #ffffff;
  border-color: #005fb8;
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.35);
  transform: translateY(-1px);
}
.btn-view-mops-config:active {
  transform: translateY(0);
}

/* ==========================================================================
   MOPS CONFIG STUDIO PANEL (Premium Side Slide-in)
   ========================================================================== */

/* Backdrop overlay */
.mops-config-panel-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(10, 18, 35, 0.55);
  backdrop-filter: blur(4px);
  z-index: 900;
  display: none;
  opacity: 0;
  transition: opacity 0.22s ease;
}
.mops-config-panel-backdrop.open {
  display: flex;
  opacity: 1;
}
.mops-config-panel-backdrop.closing {
  opacity: 0;
}

/* Side panel itself */
.mops-config-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 640px;
  max-width: 92vw;
  background: #0b1929;
  display: flex;
  flex-direction: column;
  box-shadow: -8px 0 40px rgba(0, 0, 0, 0.5);
  border-left: 1px solid rgba(56, 189, 248, 0.2);
  transform: translateX(100%);
  transition: transform 0.28s cubic-bezier(0.16, 1, 0.3, 1);
  z-index: 901;
}
.mops-config-panel-backdrop.open .mops-config-panel {
  transform: translateX(0);
}

/* Panel Header */
.dcp-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 22px 14px;
  background: #0f2240;
  border-bottom: 1px solid rgba(56, 189, 248, 0.15);
  flex-shrink: 0;
}
.dcp-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
.dcp-ts-badge {
  background: linear-gradient(135deg, #3178c6, #1e40af);
  color: #ffffff;
  font-size: 11px;
  font-weight: 900;
  width: 36px;
  height: 36px;
  border-radius: 7px;
  display: flex;
  align-items: center;
  justify-content: center;
  letter-spacing: 0.5px;
  box-shadow: 0 2px 6px rgba(49, 120, 198, 0.4);
}
.dcp-title {
  font-family: 'Consolas', 'Fira Code', monospace;
  font-size: 15px;
  font-weight: 700;
  color: #e2e8f0;
  letter-spacing: 0.3px;
}
.dcp-subtitle {
  font-size: 11px;
  color: #64748b;
  margin-top: 2px;
}
.dcp-close-btn {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: rgba(255, 255, 255, 0.6);
  width: 30px;
  height: 30px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.15s ease;
  flex-shrink: 0;
}
.dcp-close-btn:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
}

/* Version Selector Bar */
.dcp-version-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 22px;
  background: #0d1e35;
  border-bottom: 1px solid rgba(255, 255, 255, 0.07);
  flex-shrink: 0;
}
.dcp-version-label {
  font-size: 11.5px;
  font-weight: 600;
  color: #64748b;
  white-space: nowrap;
}
.dcp-version-select {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.14);
  color: #e2e8f0;
  border-radius: 6px;
  padding: 4px 10px;
  font-size: 12.5px;
  font-weight: 700;
  font-family: inherit;
  cursor: pointer;
  outline: none;
  transition: border-color 0.15s ease;
}
.dcp-version-select:focus {
  border-color: #38bdf8;
}
.dcp-version-select option {
  background: #1e293b;
  color: #e2e8f0;
}
.dcp-version-status {
  font-size: 10.5px;
  font-weight: 700;
  padding: 2px 8px;
  border-radius: 10px;
  background: rgba(16, 185, 129, 0.15);
  color: #34d399;
  border: 1px solid rgba(16, 185, 129, 0.3);
}
.dcp-version-status.archived {
  background: rgba(100, 116, 139, 0.15);
  color: #94a3b8;
  border-color: rgba(100, 116, 139, 0.3);
}
.dcp-sprint-chip {
  font-size: 11px;
  font-weight: 600;
  color: #005fb8;
  background: rgba(0, 95, 184, 0.12);
  border: 1px solid rgba(0, 95, 184, 0.25);
  border-radius: 12px;
  padding: 2px 10px;
  white-space: nowrap;
}

/* Meta Info Strip */
.dcp-meta-strip {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 22px;
  background: rgba(255, 255, 255, 0.02);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  flex-shrink: 0;
  flex-wrap: wrap;
}
.dcp-meta-item {
  display: flex;
  align-items: center;
  gap: 5px;
}
.dcp-meta-icon {
  font-size: 12px;
  opacity: 0.7;
}
.dcp-meta-text {
  font-size: 11px;
  color: #64748b;
  font-family: monospace;
}
.dcp-meta-sep {
  color: #1e3a5a;
  font-size: 12px;
}

/* Action Buttons Row */
.dcp-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 22px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
  background: rgba(255, 255, 255, 0.02);
  flex-shrink: 0;
  flex-wrap: wrap;
}
.dcp-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 7px 14px;
  font-size: 12.5px;
  font-weight: 600;
  border-radius: 6px;
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 0.15s ease;
  font-family: inherit;
  white-space: nowrap;
}
.dcp-btn-download {
  background: linear-gradient(135deg, #1d4ed8, #1e40af);
  color: #ffffff;
  border-color: #3b82f6;
  box-shadow: 0 2px 6px rgba(29, 78, 216, 0.3);
}
.dcp-btn-download:hover {
  background: linear-gradient(135deg, #2563eb, #1d4ed8);
  box-shadow: 0 3px 10px rgba(29, 78, 216, 0.45);
  transform: translateY(-1px);
}
.dcp-btn-download:active { transform: translateY(0); }
.dcp-btn-download code {
  font-family: 'Consolas', monospace;
  font-size: 11.5px;
  background: rgba(255,255,255,0.15);
  padding: 1px 5px;
  border-radius: 3px;
}
.dcp-btn-copy {
  background: rgba(56, 189, 248, 0.12);
  color: #38bdf8;
  border-color: rgba(56, 189, 248, 0.3);
}
.dcp-btn-copy:hover {
  background: rgba(56, 189, 248, 0.22);
  color: #ffffff;
  border-color: #38bdf8;
}
.dcp-btn-open {
  background: rgba(255, 255, 255, 0.05);
  color: rgba(255, 255, 255, 0.6);
  border-color: rgba(255, 255, 255, 0.1);
}
.dcp-btn-open:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #ffffff;
}
.dcp-btn.success {
  background: rgba(16, 185, 129, 0.2) !important;
  color: #34d399 !important;
  border-color: rgba(16, 185, 129, 0.4) !important;
}

/* Code Display Container */
.dcp-code-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.dcp-code-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 22px;
  background: #0d1e35;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
  flex-shrink: 0;
}
.dcp-code-lang-pill {
  font-size: 10.5px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #3178c6;
  background: rgba(49, 120, 198, 0.12);
  border: 1px solid rgba(49, 120, 198, 0.3);
  padding: 2px 8px;
  border-radius: 4px;
}
.dcp-code-hint {
  font-size: 11px;
  color: #475569;
}
.dcp-code-hint code {
  font-family: monospace;
  color: #64748b;
  background: rgba(255,255,255,0.05);
  padding: 1px 4px;
  border-radius: 3px;
}
.dcp-code-scroll {
  flex: 1;
  overflow-y: auto;
  overflow-x: auto;
}
.dcp-code-table {
  width: 100%;
  border-collapse: collapse;
  font-family: 'Consolas', 'Fira Code', 'Courier New', monospace;
  font-size: 12.5px;
  line-height: 1.65;
}
.dcp-code-table td {
  padding: 0;
  white-space: pre;
  vertical-align: top;
}
.dcp-line-num {
  color: #334155;
  text-align: right;
  padding: 0 12px 0 14px;
  user-select: none;
  min-width: 38px;
  border-right: 1px solid rgba(255, 255, 255, 0.05);
  font-size: 11px;
  background: #090f1a;
}
.dcp-line-code {
  padding: 0 16px 0 14px;
  color: #e2e8f0;
}
/* Syntax highlight classes */
.dcp-line-code .ts-keyword { color: #c792ea; }
.dcp-line-code .ts-string  { color: #c3e88d; }
.dcp-line-code .ts-comment { color: #546e7a; font-style: italic; }
.dcp-line-code .ts-number  { color: #f78c6c; }
.dcp-line-code .ts-bool    { color: #ff9cac; }
.dcp-line-code .ts-prop    { color: #82aaff; }
.dcp-line-code .ts-type    { color: #ffcb6b; }
tr:hover .dcp-line-num,
tr:hover .dcp-line-code { background: rgba(255, 255, 255, 0.03); }

/* Panel Footer */
.dcp-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 22px;
  border-top: 1px solid rgba(255, 255, 255, 0.06);
  flex-shrink: 0;
  background: #090f1a;
}
.dcp-footer-note {
  font-size: 10.5px;
  color: #334155;
}

/* ==========================================================================
   CANVAS NAMING RULE BAR (Live Project Name Preview Banner)
   ========================================================================== */
.canvas-naming-rule-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 10px;
  padding: 8px 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-left: 3px solid #005fb8;
  border-radius: 6px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
  transition: all 0.2s ease;
}
.canvas-naming-rule-bar:hover {
  background: #ffffff;
  border-color: #cbd5e1;
  border-left-color: #0099c2;
  box-shadow: 0 2px 6px rgba(0, 95, 184, 0.1);
}
.cnrb-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
  overflow: hidden;
}
.cnrb-badge {
  font-size: 11px;
  font-weight: 700;
  color: #0369a1;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  white-space: nowrap;
  flex-shrink: 0;
}
.cnrb-preview {
  display: flex;
  align-items: center;
  gap: 4px;
  overflow-x: auto;
  white-space: nowrap;
  font-family: 'Consolas', 'Fira Code', monospace;
  font-size: 12px;
  color: #1e293b;
  scrollbar-width: none;
}
.cnrb-preview::-webkit-scrollbar {
  display: none;
}
.cnrb-pill {
  padding: 2px 7px;
  background: #e0f2fe;
  color: #0369a1;
  border: 1px solid #bae6fd;
  border-radius: 4px;
  font-weight: 600;
  font-size: 11px;
}
.cnrb-delim {
  color: #94a3b8;
  font-weight: 800;
  font-size: 12px;
}
.cnrb-right {
  display: flex;
  align-items: center;
  flex-shrink: 0;
}
.btn-naming-studio {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  font-size: 11.5px;
  font-weight: 600;
  color: #0f172a;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.15s ease;
  white-space: nowrap;
}
.btn-naming-studio:hover {
  background: #f0f9ff;
  border-color: #005fb8;
  color: #0369a1;
  box-shadow: 0 1px 4px rgba(0, 95, 184, 0.15);
}

/* ==========================================================================
   PROJECT NAMING CONVENTION STUDIO MODAL
   ========================================================================== */
.naming-modal-header-icon {
  font-size: 20px;
  width: 36px;
  height: 36px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.naming-form-badge {
  font-size: 11px;
  font-weight: 700;
  padding: 3px 10px;
  border-radius: 12px;
  background: rgba(0, 95, 184, 0.15);
  color: #38bdf8;
  border: 1px solid rgba(0, 188, 235, 0.4);
}
.naming-hero-card {
  background: linear-gradient(135deg, #0f172a, #1e293b);
  color: #ffffff;
  border-radius: 8px;
  padding: 16px 20px;
  margin-bottom: 16px;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.18);
  border: 1px solid #334155;
}
.naming-hero-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  flex-wrap: wrap;
  gap: 10px;
}
.naming-hero-title {
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #38bdf8;
  display: flex;
  align-items: center;
  gap: 8px;
}
.naming-live-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #4ade80;
  box-shadow: 0 0 8px #4ade80;
  display: inline-block;
}
.naming-hero-controls {
  display: flex;
  align-items: center;
  gap: 10px;
}
.naming-delim-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  color: #94a3b8;
}
.naming-delim-select {
  padding: 3px 8px;
  font-size: 11.5px;
  background: #0b1322;
  color: #f8fafc;
  border: 1px solid #334155;
  border-radius: 4px;
}
.naming-preview-display {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
  background: rgba(0, 0, 0, 0.45);
  padding: 12px 14px;
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  font-family: 'Consolas', 'Fira Code', monospace;
  margin-bottom: 8px;
  min-height: 44px;
}
.naming-eval-pill {
  padding: 3px 9px;
  background: rgba(0, 188, 235, 0.16);
  border: 1px solid rgba(0, 188, 235, 0.4);
  color: #7dd3fc;
  border-radius: 4px;
  font-weight: 600;
  font-size: 12.5px;
}
.naming-eval-delim {
  color: #64748b;
  font-weight: 900;
  font-size: 14px;
}
.naming-formula-display {
  font-size: 11.5px;
  color: #94a3b8;
  font-style: italic;
  padding-left: 2px;
}
.naming-modal-tabs {
  display: flex;
  gap: 6px;
  border-bottom: 1px solid #e2e8f0;
  margin-bottom: 16px;
  background: #ffffff;
  padding: 2px 6px 0;
  border-radius: 6px 6px 0 0;
}
.naming-tab-btn {
  padding: 9px 18px;
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  font-size: 12.5px;
  font-weight: 600;
  color: #64748b;
  cursor: pointer;
  transition: all 0.15s ease;
}
.naming-tab-btn:hover {
  color: #0f172a;
}
.naming-tab-btn.active {
  color: #0369a1;
  border-bottom-color: #005fb8;
  font-weight: 700;
}
.naming-segments-intro {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  font-size: 12px;
  color: #475569;
}
.naming-segments-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}
.naming-segment-row {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  padding: 10px 14px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
.naming-segment-row:hover {
  border-color: #005fb8;
  box-shadow: 0 2px 6px rgba(0, 95, 184, 0.08);
}
.naming-seg-order {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.btn-seg-move {
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  color: #475569;
  border-radius: 3px;
  font-size: 9px;
  width: 22px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  line-height: 1;
}
.btn-seg-move:hover:not(:disabled) {
  background: #005fb8;
  color: #ffffff;
  border-color: #005fb8;
}
.btn-seg-move:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
.naming-seg-badge {
  font-size: 11px;
  font-weight: 700;
  color: #64748b;
  width: 20px;
  text-align: center;
}
.naming-seg-type-select {
  min-width: 175px;
  font-size: 12px;
  padding: 5px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  background: #ffffff;
}
.naming-seg-field-select {
  flex: 1;
  min-width: 150px;
  font-size: 12px;
  padding: 5px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  background: #ffffff;
}
.naming-seg-sample-input {
  width: 150px;
  font-size: 12px;
  padding: 5px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  background: #ffffff;
}
.btn-seg-delete {
  background: #fee2e2;
  border: 1px solid #fecaca;
  color: #ef4444;
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s ease;
}
.btn-seg-delete:hover {
  background: #ef4444;
  color: #ffffff;
  border-color: #ef4444;
}
.naming-ts-code-block {
  background: #090f1a;
  color: #38bdf8;
  font-family: 'Consolas', 'Fira Code', monospace;
  font-size: 12px;
  line-height: 1.6;
  padding: 16px 20px;
  border-radius: 8px;
  overflow-x: auto;
  border: 1px solid #1e293b;
  max-height: 420px;
}


/* ============================================================
   Naming Convention Studio  Segment Cards (added by JS impl)
   ============================================================ */
.naming-segment-card {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px 14px;
  margin-bottom: 8px;
  transition: box-shadow 0.15s ease;
}
.naming-segment-card:hover {
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  border-color: #cbd5e1;
}
.naming-seg-controls {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding-top: 2px;
}
.naming-seg-move {
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  color: #475569;
  border-radius: 3px;
  font-size: 9px;
  width: 22px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.12s ease;
  padding: 0;
  line-height: 1;
}
.naming-seg-move:hover:not(:disabled) {
  background: #005fb8;
  color: #ffffff;
  border-color: #005fb8;
}
.naming-seg-move:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
.naming-seg-num {
  font-size: 10px;
  font-weight: 700;
  color: #94a3b8;
  width: 20px;
  text-align: center;
  line-height: 1;
}
.naming-seg-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 7px;
}
.naming-seg-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.naming-seg-label-text {
  font-size: 11px;
  font-weight: 600;
  color: #64748b;
  min-width: 68px;
  text-align: right;
}
.naming-seg-input {
  flex: 1;
  font-size: 12px;
  padding: 5px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  background: #f8fafc;
  color: #0f172a;
  min-width: 0;
}
.naming-seg-input:focus {
  outline: none;
  border-color: #005fb8;
  background: #ffffff;
}
.naming-seg-select {
  flex: 1;
  font-size: 12px;
  padding: 5px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  background: #f8fafc;
  color: #0f172a;
  min-width: 0;
}
.naming-seg-hint {
  font-size: 10px;
  color: #94a3b8;
  white-space: nowrap;
}
.naming-seg-delete {
  background: #fee2e2;
  border: 1px solid #fecaca;
  color: #ef4444;
  border-radius: 4px;
  padding: 5px 9px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.12s ease;
  align-self: flex-start;
  margin-top: 2px;
}
.naming-seg-delete:hover {
  background: #ef4444;
  color: #ffffff;
  border-color: #dc2626;
}
.naming-empty-state {
  text-align: center;
  padding: 32px 16px;
  color: #94a3b8;
  font-size: 13px;
  border: 2px dashed #e2e8f0;
  border-radius: 8px;
  background: #f8fafc;
}

/* Modal live preview pills */
.naming-preview-pill {
  display: inline-block;
  background: linear-gradient(135deg, #0f172a, #1e3a5f);
  color: #38bdf8;
  font-weight: 700;
  font-size: 13px;
  padding: 5px 12px;
  border-radius: 20px;
  letter-spacing: 0.5px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  animation: pillFadeIn 0.25s ease;
}
.naming-preview-delim {
  display: inline-block;
  color: #64748b;
  font-weight: 900;
  font-size: 16px;
  margin: 0 4px;
  vertical-align: middle;
}
@keyframes pillFadeIn {
  from { opacity: 0; transform: translateY(-4px); }
  to   { opacity: 1; transform: translateY(0); }
}


/* ============================================================
   Field Tooltip Icon (?) - Top-right of label row
   Appears only when field.tooltip is set
   ============================================================ */
.field-tooltip-icon {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  font-size: 13px;
  line-height: 1;
  color: #005fb8;
  cursor: help;
  border-radius: 50%;
  flex-shrink: 0;
  margin-left: 4px;
  transition: color 0.15s ease;
  vertical-align: middle;
}
.field-tooltip-icon:hover {
  color: #005fb8;
}

/* Popup tooltip bubble */
.field-tooltip-popup {
  display: none;
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  z-index: 9999;
  background: #0f172a;
  color: #e2e8f0;
  font-size: 11.5px;
  font-weight: 400;
  line-height: 1.5;
  padding: 8px 12px;
  border-radius: 6px;
  width: 220px;
  white-space: normal;
  box-shadow: 0 6px 20px rgba(0,0,0,0.35);
  pointer-events: none;
  border: 1px solid #1e3a5f;
  font-family: inherit;
}
.field-tooltip-popup::before {
  content: '';
  position: absolute;
  top: -5px;
  right: 5px;
  width: 9px;
  height: 9px;
  background: #0f172a;
  border-top: 1px solid #1e3a5f;
  border-left: 1px solid #1e3a5f;
  transform: rotate(45deg);
}
.field-tooltip-icon:hover .field-tooltip-popup {
  display: block;
}

/* Variant 1 (Cisco Brand): position ? within cisco-bld-tools, float it left of action buttons */
.cisco-bld-tools .field-tooltip-icon {
  font-size: 13px;
  margin-right: 2px;
}

/* Variants 2 & 3: push ? to the far right of the label row via flex */
.field-preview-label {
  display: flex;
  align-items: center;
  gap: 4px;
}
.field-preview-label .field-tooltip-icon {
  margin-left: auto;
}



/* ==========================================================================
   Modern Builder Variation Switcher (MacOS/Linear Segmented Pill Style)
   ========================================================================== */
#builderVariationSwitcher {
  display: inline-flex;
  align-items: center;
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 3px;
  gap: 3px;
}

#builderVariationSwitcher .rev-var-btn {
  background: transparent;
  color: #64748b;
  border: none;
  padding: 5px 12px;
  font-size: 11.5px;
  font-weight: 600;
  border-radius: 6px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.15s ease;
  font-family: inherit;
  white-space: nowrap;
}

#builderVariationSwitcher .rev-var-btn:hover {
  color: #0f172a;
  background: rgba(255, 255, 255, 0.6);
}

#builderVariationSwitcher .rev-var-btn.active {
  background: #ffffff;
  color: #005fb8;
  font-weight: 700;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08), 0 1px 2px rgba(0, 0, 0, 0.04);
}

/* ==========================================================================
   Modern Form Document Header & Editable Inputs (Canvas Topbar)
   ========================================================================== */
.cisco-bld-topbar {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px 16px 12px;
  margin-bottom: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
}

.cisco-bld-title-group {
  position: relative;
  width: 100%;
}

.cisco-bld-title-edit {
  font-family: var(--font-family) !important;
  font-size: 15px !important;
  font-weight: 700 !important;
  color: #0f172a !important;
  letter-spacing: -0.01em !important;
  text-transform: none !important;
  border: 1px solid transparent !important;
  background: transparent !important;
  outline: none !important;
  flex: 1 1 auto !important;
  width: 100% !important;
  padding: 3px 8px !important;
  cursor: text !important;
  transition: all 0.15s ease !important;
  border-radius: 4px !important;
  pointer-events: auto !important;
  user-select: text !important;
  -webkit-user-select: text !important;
  position: relative !important;
  z-index: 5 !important;
}

.cisco-bld-title-edit:hover {
  border-color: #cbd5e1 !important;
  background: #f8fafc !important;
}

.cisco-bld-title-edit:focus {
  border-color: #005fb8 !important;
  background: #ffffff !important;
  box-shadow: 0 0 0 2.5px rgba(0, 95, 184, 0.18) !important;
}

.cisco-bld-edit-pill {
  display: inline-flex !important;
  align-items: center !important;
  gap: 4px !important;
  font-size: 11px !important;
  font-weight: 600 !important;
  color: #64748b !important;
  background: #f1f5f9 !important;
  border: 1px solid #e2e8f0 !important;
  border-radius: 4px !important;
  padding: 3px 8px !important;
  cursor: pointer !important;
  user-select: none !important;
  flex-shrink: 0 !important;
  transition: all 0.15s ease !important;
  line-height: 1 !important;
}

.cisco-bld-edit-pill:hover {
  color: #005fb8 !important;
  background: #eff6ff !important;
  border-color: #bfdbfe !important;
}

.cisco-bld-desc-edit {
  font-family: var(--font-family) !important;
  font-size: 12px !important;
  color: #475569 !important;
  border: 1px solid transparent !important;
  background: transparent !important;
  outline: none !important;
  width: 100% !important;
  padding: 3px 8px !important;
  cursor: text !important;
  transition: all 0.15s ease !important;
  border-radius: 4px !important;
  pointer-events: auto !important;
  user-select: text !important;
  -webkit-user-select: text !important;
  position: relative !important;
  z-index: 5 !important;
}

.cisco-bld-desc-edit:hover {
  border-color: #cbd5e1 !important;
  background: #f8fafc !important;
}

.cisco-bld-desc-edit:focus {
  border-color: #005fb8 !important;
  background: #ffffff !important;
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.12) !important;
}
  background: #f8fafc !important;
}

.cisco-bld-divider {
  height: 1px !important;
  background: #f1f5f9 !important;
  margin-top: 16px !important;
  border-radius: 0 !important;
}

/* ==========================================================================
   Modern Section Cards & Section Headers
   ========================================================================== */
.cisco-bld-section {
  background: #ffffff !important;
  border: 1px solid #e2e8f0 !important;
  border-radius: 10px !important;
  padding: 0 !important;
  margin-bottom: 20px !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
  transition: box-shadow 0.2s ease, border-color 0.2s ease !important;
  overflow: hidden !important;
}

.cisco-bld-sec-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px !important;
  background: #ffffff !important;
  border-bottom: 1px solid #f1f5f9 !important;
  margin-bottom: 0 !important;
}

.cisco-bld-sec-title-input {
  font-family: var(--font-family) !important;
  font-size: 14.5px !important;
  font-weight: 700 !important;
  color: #0f172a !important;
  border: 1px solid transparent !important;
  border-radius: 4px !important;
  padding: 4px 8px !important;
  background: transparent !important;
  width: 55% !important;
  outline: none !important;
  transition: all 0.15s ease !important;
}

.cisco-bld-sec-title-input:hover {
  border-color: #e2e8f0 !important;
  background: #f8fafc !important;
}

.cisco-bld-sec-title-input:focus {
  border-color: #005fb8 !important;
  background: #ffffff !important;
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.15) !important;
}

.cisco-bld-sec-actions {
  display: flex;
  align-items: center;
  gap: 6px;
}

.cisco-bld-sec-actions .btn {
  font-size: 11.5px !important;
  padding: 4px 10px !important;
  border-radius: 6px !important;
  font-weight: 600 !important;
  transition: all 0.15s ease !important;
}

.cisco-bld-sec-actions .btn-outline {
  background: #ffffff !important;
  border: 1px solid #e2e8f0 !important;
  color: #475569 !important;
}

.cisco-bld-sec-actions .btn-outline:hover {
  background: #f8fafc !important;
  color: #0f172a !important;
  border-color: #cbd5e1 !important;
}

.cisco-bld-sec-actions .btn-danger {
  background: transparent !important;
  border: 1px solid transparent !important;
  color: #94a3b8 !important;
  padding: 4px 8px !important;
}

.cisco-bld-sec-actions .btn-danger:hover {
  background: #fef2f2 !important;
  border-color: #fecaca !important;
  color: #ef4444 !important;
}

/* ==========================================================================
   Modern Empty Section Dropzone
   ========================================================================== */
.section-dropzone-empty {
  border: 1.5px dashed #cbd5e1 !important;
  border-radius: 10px !important;
  padding: 36px 20px !important;
  text-align: center !important;
  color: #64748b !important;
  background: #fafbfc !important;
  transition: all 0.2s ease !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: center !important;
  margin: 16px !important;
}

.section-dropzone-empty:hover {
  border-color: #005fb8 !important;
  background: #f0f9ff !important;
}

.section-dropzone-empty.drag-over {
  border-color: #005fb8 !important;
  background: #e0f2fe !important;
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.2) !important;
}

.dropzone-empty-icon {
  width: 44px !important;
  height: 44px !important;
  border-radius: 10px !important;
  background: #f1f5f9 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  font-size: 20px !important;
  margin-bottom: 10px !important;
  color: #005fb8 !important;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04) !important;
}

.dropzone-empty-title {
  font-size: 13.5px !important;
  font-weight: 600 !important;
  color: #0f172a !important;
  margin-bottom: 4px !important;
}

.dropzone-empty-desc {
  font-size: 12px !important;
  color: #64748b !important;
  max-width: 420px !important;
  margin-bottom: 14px !important;
  line-height: 1.4 !important;
}

.dropzone-quick-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
}

.dropzone-quick-actions .btn-primary {
  background: #005fb8 !important;
  color: #ffffff !important;
  border: 1px solid #005fb8 !important;
  border-radius: 6px !important;
  padding: 6px 14px !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  transition: all 0.15s ease !important;
}

.dropzone-quick-actions .btn-primary:hover {
  background: #0369a1 !important;
  border-color: #0369a1 !important;
  box-shadow: 0 2px 6px rgba(0, 95, 184, 0.25) !important;
}

.dropzone-quick-actions .btn-outline {
  background: #ffffff !important;
  color: #334155 !important;
  border: 1px solid #cbd5e1 !important;
  border-radius: 6px !important;
  padding: 6px 14px !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  transition: all 0.15s ease !important;
}

.dropzone-quick-actions .btn-outline:hover {
  background: #f8fafc !important;
  border-color: #94a3b8 !important;
  color: #0f172a !important;
}

/* ==========================================================================
   Modern Add Section Button
   ========================================================================== */
.btn-add-section {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 8px !important;
  width: 100% !important;
  padding: 13px !important;
  background: #ffffff !important;
  border: 1.5px dashed #cbd5e1 !important;
  border-radius: 10px !important;
  color: #475569 !important;
  font-size: 13px !important;
  font-weight: 600 !important;
  cursor: pointer !important;
  transition: all 0.15s ease !important;
  font-family: inherit !important;
}

.btn-add-section:hover {
  background: #f0f9ff !important;
  border-color: #005fb8 !important;
  color: #005fb8 !important;
}

/* ==========================================================================
   Modern Sidebar Form Cards (Selected & Hover)
   ========================================================================== */
.sidebar-form-card {
  display: flex;
  align-items: center;
  gap: 0;
  border-radius: 8px !important;
  margin-bottom: 6px !important;
  background: #ffffff !important;
  border: 1px solid #e2e8f0 !important;
  cursor: pointer;
  transition: all 0.15s ease !important;
  overflow: hidden;
  position: relative;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02) !important;
}

.sidebar-form-card:hover {
  border-color: #cbd5e1 !important;
  background: #f8fafc !important;
  transform: translateY(-1px) !important;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05) !important;
}

.sidebar-form-card.active {
  border-color: #005fb8 !important;
  background: #f0f9ff !important;
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.08) !important;
}

.sidebar-form-card.active .sfc-name {
  color: #005fb8 !important;
  font-weight: 700 !important;
}

.sfc-active-indicator {
  width: 3.5px !important;
  background: #005fb8 !important;
  border-radius: 0 2px 2px 0 !important;
}

.sfc-ver-badge {
  background: #005fb8 !important;
  color: #ffffff !important;
  font-size: 9.5px !important;
  font-weight: 700 !important;
  padding: 1.5px 7px !important;
  border-radius: 12px !important;
  letter-spacing: 0.3px !important;
}

/* ==========================================================================
   Modern Desktop Bottom Status Bar
   ========================================================================== */
.desktop-status-bar {
  height: 30px !important;
  background: #0f172a !important;
  color: #94a3b8 !important;
  border-top: 1px solid rgba(255, 255, 255, 0.08) !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 0 16px !important;
  font-size: 11.5px !important;
  font-weight: 500 !important;
  flex-shrink: 0 !important;
  z-index: 50 !important;
  user-select: none !important;
}

.status-left, .status-right {
  display: flex !important;
  align-items: center !important;
  gap: 10px !important;
}

.status-indicator-dot {
  width: 7px !important;
  height: 7px !important;
  border-radius: 50% !important;
  background: #10b981 !important;
  box-shadow: 0 0 8px rgba(16, 185, 129, 0.6) !important;
}

.status-sep {
  color: rgba(255, 255, 255, 0.15) !important;
  font-weight: 300 !important;
}

.status-health-badge {
  font-size: 10.5px !important;
  font-weight: 600 !important;
  padding: 2px 8px !important;
  border-radius: 4px !important;
  background: rgba(16, 185, 129, 0.12) !important;
  color: #4ade80 !important;
  border: 1px solid rgba(16, 185, 129, 0.25) !important;
}

.status-health-badge.info {
  background: rgba(0, 95, 184, 0.15) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(56, 189, 248, 0.3) !important;
}

.status-hotkey-guide kbd {
  background: rgba(255, 255, 255, 0.08) !important;
  border: 1px solid rgba(255, 255, 255, 0.15) !important;
  padding: 1px 5px !important;
  border-radius: 3px !important;
  color: #cbd5e1 !important;
  font-family: monospace !important;
  font-size: 10px !important;
}


/* ==========================================================================
   Icon & SVG Utilities (Redesign 2.0)
   ========================================================================== */

/* SVG icon wrapper - inline alignment */
.icon-svg {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  line-height: 0;
}

/* Modal icon badge */
.modal-icon-wrap {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  color: #005fb8;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

/* Palette item icons - SVG-ready */
.palette-item-icon {
  width: 30px;
  height: 30px;
  border-radius: 6px;
  background: #f0f9ff;
  color: #0369a1;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 14px;
  line-height: 0;
}

/* Cisco builder section - toolbar btn */
.cisco-bld-sec-actions .btn-xs {
  font-size: 11px;
  padding: 3px 8px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  border-radius: 5px;
}

/* Section tool button in Cisco builder mode */
.cisco-tool-btn {
  background: transparent;
  border: 1px solid #e2e8f0;
  color: #64748b;
  border-radius: 5px;
  padding: 2px 7px;
  font-size: 11px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.12s ease;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  gap: 3px;
}

.cisco-tool-btn:hover {
  background: #f1f5f9;
  border-color: #cbd5e1;
  color: #334155;
}

.cisco-tool-btn.cisco-tool-del {
  color: #ef4444;
}

.cisco-tool-btn.cisco-tool-del:hover {
  background: #fef2f2;
  border-color: #fca5a5;
  color: #dc2626;
}

/* Status bar info text */
.status-storage-info {
  color: #64748b;
  font-size: 10.5px;
}

.status-health-badge.info {
  color: #38bdf8;
  font-weight: 600;
}

/* Toast notification refinements */
.toast-notification {
  border-radius: 8px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.12);
}

/* Drawer body padding refinement */
.drawer-body {
  padding: 16px;
}

/* Wf integration block */
.wf-integration-block {
  background: linear-gradient(135deg, #f0f9ff 0%, #f8fafc 100%);
  border: 1px solid #bae6fd;
  border-left: 3px solid #005fb8;
  border-radius: 8px;
  padding: 14px;
  margin-bottom: 14px;
}

/* Gallery card - for Forms Gallery modal */
.gallery-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 16px;
  cursor: pointer;
  transition: all 0.15s ease;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.gallery-card:hover {
  border-color: #005fb8;
  box-shadow: 0 4px 12px rgba(0, 95, 184, 0.1);
  transform: translateY(-1px);
}

.gallery-card-title {
  font-size: 13.5px;
  font-weight: 700;
  color: #0f172a;
  line-height: 1.3;
}

.gallery-card-meta {
  font-size: 11.5px;
  color: #64748b;
}

.gallery-card-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #f0f9ff;
  color: #0369a1;
  border: 1px solid #bae6fd;
  border-radius: 4px;
  font-size: 10.5px;
  font-weight: 600;
  padding: 2px 7px;
}

/* Version badge - small blue pill on sidebar cards */
.sfc-ver-badge {
  background: #005fb8;
  color: #fff;
  font-size: 9.5px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 20px;
  letter-spacing: 0.3px;
  flex-shrink: 0;
}

/* Sidebar gallery button refinement */
.forms-sidebar-gallery-btn {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  color: #475569;
  border-radius: 6px;
  padding: 4px 9px;
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-family: inherit;
}

.forms-sidebar-gallery-btn:hover {
  background: #f1f5f9;
  color: #1e293b;
  border-color: #cbd5e1;
}

/* Canvas naming rule bar */
.canvas-naming-rule-bar {
  background: #fffbeb;
  border: 1px solid #fde68a;
  border-top: none;
  border-radius: 0 0 8px 8px;
  padding: 6px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 12px;
  gap: 8px;
}

.cnrb-badge {
  background: #fef3c7;
  color: #92400e;
  border: 1px solid #fde68a;
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 10.5px;
  font-weight: 700;
  letter-spacing: 0.3px;
  flex-shrink: 0;
}

.cnrb-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.cnrb-right {
  flex-shrink: 0;
}

.btn-naming-studio {
  background: transparent;
  border: 1px solid #e2e8f0;
  color: #475569;
  border-radius: 6px;
  padding: 3px 10px;
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.12s ease;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.btn-naming-studio:hover {
  background: #f1f5f9;
  border-color: #cbd5e1;
  color: #1e293b;
}

/* View MOPS Config button */
.btn-view-mops-config {
  background: #1e293b;
  color: #38bdf8;
  border: 1px solid #334155;
  border-radius: 6px;
  padding: 5px 11px;
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  transition: all 0.15s ease;
  font-family: inherit;
  white-space: nowrap;
}

.btn-view-mops-config:hover {
  background: #0f172a;
  border-color: #38bdf8;
}

/* Version history button in toolbar */
.form-ver-history-btn {
  background: transparent;
  border: 1px solid #e2e8f0;
  color: #64748b;
  border-radius: 5px;
  padding: 4px 8px;
  font-size: 11px;
  cursor: pointer;
  transition: all 0.12s ease;
  display: inline-flex;
  align-items: center;
  font-family: inherit;
}

.form-ver-history-btn:hover {
  background: #f1f5f9;
  border-color: #cbd5e1;
  color: #334155;
}

/* Canvas config pill */
.canvas-config-pill {
  background: #0f172a;
  color: #38bdf8;
  font-family: 'Menlo', 'Monaco', 'Consolas', monospace;
  font-size: 10.5px;
  padding: 3px 10px;
  border-radius: 5px;
  border: 1px solid #1e293b;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 220px;
}

/* Version label in toolbar */
.form-ver-label {
  font-size: 10px;
  font-weight: 700;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  white-space: nowrap;
}

/* Modal animation */
@keyframes modal-appear {
  from { opacity: 0; transform: scale(0.96) translateY(8px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}

/* Drawer tabs with icons */
.drawer-tab-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}

/* Workfront block header */
.wf-integration-header {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 12px;
}

.wf-cisco-icon {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: #e0f2fe;
  color: #005fb8;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.wf-integration-title {
  font-size: 12.5px;
  font-weight: 700;
  color: #0f172a;
}

.wf-integration-desc {
  font-size: 11px;
  color: #64748b;
  line-height: 1.4;
  margin-top: 2px;
}

/* Library card hover shadow update */
.library-card:hover {
  border-color: var(--cui-primary);
  box-shadow: 0 2px 8px rgba(0, 95, 184, 0.1);
  transform: translateY(-1px);
}

/* Gallery search input */
.gallery-search-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  font-size: 13px;
  font-family: inherit;
  color: #1e293b;
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
}

.gallery-search-input:focus {
  border-color: #005fb8;
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.1);
}



/* ==========================================================================
   ADOBE WORKFRONT THEME & 3-COLUMN STUDIO OVERHAUL
   ========================================================================== */

:root {
  /* Workfront / Spectrum Palette */
  --wf-primary: #005fb8;             /* Workfront / Adobe primary blue */
  --wf-primary-hover: #004d96;       /* Deep blue hover */
  --wf-primary-light: #e5f1fb;       /* Soft blue tint */
  --wf-canvas-bg: #f4f5f8;           /* Neutral soft canvas background */
  --wf-panel-bg: #ffffff;            /* Pure white panels */
  --wf-border: #e0e2e6;              /* Crisp 1px panel borders */
  --wf-input-border: #d1d5db;        /* Workfront input field border */
  --wf-text-dark: #111827;           /* Main dark text */
  --wf-text-body: #374151;           /* Form label & body text */
  --wf-text-muted: #6b7280;          /* Secondary muted text */
  --wf-badge-green: #10b981;         /* Workfront Forms green badge */
  --wf-badge-green-hover: #059669;
}

/* Base Body Layout */
body {
  background-color: var(--wf-canvas-bg) !important;
  color: var(--wf-text-body) !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* --------------------------------------------------------------------------
   Top Global Shell & Navigation (Adobe Workfront Style)
   -------------------------------------------------------------------------- */

/* Top Environment Bar (optional mini-bar for authentic Workfront feel) */
.wf-global-bar {
  height: 28px;
  background: #ffffff;
  border-bottom: 1px solid #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  font-size: 11px;
  color: #6b7280;
  flex-shrink: 0;
}

.wf-global-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.wf-brand-name {
  font-weight: 700;
  color: #111827;
  display: flex;
  align-items: center;
  gap: 6px;
}

.wf-sandbox-tag {
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  color: #475569;
  border-radius: 4px;
  padding: 1px 6px;
  font-size: 10.5px;
  font-weight: 600;
}

.wf-global-right {
  display: flex;
  align-items: center;
  gap: 14px;
}

.wf-env-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-weight: 500;
}

.wf-pulse-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
}

/* Main Navbar (Light, Clean, Elegant) */
.mops-navbar {
  height: 52px !important;
  background: #ffffff !important;
  border-bottom: 1px solid #e2e8f0 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 0 16px !important;
  gap: 12px !important;
  flex-shrink: 0 !important;
  z-index: 100 !important;
  color: #111827 !important;
}

/* Left Brand & Form Title Block */
.mops-brand {
  display: flex;
  align-items: center;
  gap: 10px;
  border-right: none !important;
  padding-right: 0 !important;
  margin-right: 0 !important;
}

.wf-back-btn {
  background: transparent;
  border: 1px solid transparent;
  border-radius: 4px;
  color: #6b7280;
  width: 28px;
  height: 28px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.12s ease;
}

.wf-back-btn:hover {
  background: #f1f5f9;
  color: #111827;
}

/* Green Document Icon Badge (Matches Workfront Forms Icon) */
.wf-form-doc-badge {
  width: 30px;
  height: 30px;
  background: #10b981;
  color: #ffffff;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 1px 2px rgba(16, 185, 129, 0.2);
}

.wf-title-block {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.wf-category-tag {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #6b7280;
  line-height: 1;
}

.wf-form-heading-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 2px;
}

.wf-form-heading {
  font-size: 16px;
  font-weight: 700;
  color: #111827;
  letter-spacing: -0.2px;
  cursor: pointer;
  border: 1px solid transparent;
  border-radius: 4px;
  padding: 1px 4px;
}

.wf-form-heading:hover {
  background: #f8fafc;
  border-color: #e2e8f0;
}

.wf-info-trigger {
  color: #94a3b8;
  cursor: pointer;
  font-size: 13px;
  transition: color 0.12s ease;
}

.wf-info-trigger:hover {
  color: #005fb8;
}

/* Center Search */
.mops-navbar-center {
  flex: 1;
  max-width: 360px;
  margin: 0 12px;
}

.top-command-search-bar {
  background: #f8fafc !important;
  border: 1px solid #e2e8f0 !important;
  color: #64748b !important;
  border-radius: 20px !important;
  padding: 5px 14px !important;
  width: 100% !important;
}

.top-command-search-bar:hover {
  background: #ffffff !important;
  border-color: #cbd5e1 !important;
  box-shadow: 0 1px 4px rgba(0,0,0,0.05) !important;
}

.top-command-search-bar .cmd-kbd {
  background: #ffffff !important;
  border: 1px solid #e2e8f0 !important;
  color: #64748b !important;
}

/* Right Actions (Workfront Style) */
.mops-navbar-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Show Logic Button (fx) */
.btn-wf-logic {
  background: transparent;
  border: 1px solid #d1d5db;
  color: #374151;
  border-radius: 6px;
  padding: 5px 11px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  transition: all 0.15s ease;
  font-family: inherit;
}

.btn-wf-logic:hover {
  background: #f3f4f6;
  border-color: #9ca3af;
  color: #111827;
}

.btn-wf-logic .fx-symbol {
  font-style: italic;
  font-family: serif;
  font-weight: bold;
  font-size: 13px;
  color: #005fb8;
}

/* Active Toggle Switch */
.wf-status-toggle {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 600;
  color: #374151;
  cursor: pointer;
  user-select: none;
  padding: 4px 6px;
}

.wf-status-toggle input[type="checkbox"] {
  accent-color: #10b981;
  width: 15px;
  height: 15px;
}

/* Share Button (Pill) */
.btn-wf-share {
  background: #ffffff;
  border: 1px solid #d1d5db;
  color: #374151;
  border-radius: 20px;
  padding: 5px 14px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  transition: all 0.15s ease;
  font-family: inherit;
}

.btn-wf-share:hover {
  background: #f9fafb;
  border-color: #9ca3af;
}

/* Mode Switcher (Builder vs Simulator) */
.top-mode-segmented-bar {
  background: #f1f5f9 !important;
  border: 1px solid #e2e8f0 !important;
  border-radius: 6px !important;
}

.top-mode-tab {
  color: #64748b !important;
  padding: 4px 10px !important;
  font-size: 11.5px !important;
}

.top-mode-tab.active {
  background: #ffffff !important;
  color: #005fb8 !important;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06) !important;
  font-weight: 600 !important;
}

/* Apply / Save Button (Solid Workfront Blue Pill) */
.top-btn-save {
  background: var(--wf-primary) !important;
  border-color: var(--wf-primary) !important;
  color: #ffffff !important;
  border-radius: 20px !important;
  padding: 6px 18px !important;
  font-size: 12.5px !important;
  font-weight: 600 !important;
  box-shadow: 0 1px 2px rgba(0, 95, 184, 0.2) !important;
}

.top-btn-save:hover {
  background: var(--wf-primary-hover) !important;
  border-color: var(--wf-primary-hover) !important;
}

/* --------------------------------------------------------------------------
   Main 3-Column Studio Layout
   -------------------------------------------------------------------------- */
.app-container {
  display: flex !important;
  flex: 1 !important;
  overflow: hidden !important;
  position: relative !important;
}

/* Column 1: Left Palette & Library (Workfront Clean Single-Line Items) */
.sidebar-palette {
  width: var(--sidebar-left-width, 240px) !important;
  background-color: #ffffff !important;
  border-right: 1px solid #e5e7eb !important;
  display: flex !important;
  flex-direction: column !important;
  flex-shrink: 0 !important;
  overflow: hidden !important;
  z-index: 20 !important;
}

.sidebar-tabs {
  display: flex !important;
  border-bottom: 1px solid #e5e7eb !important;
  background: #ffffff !important;
  padding: 0 4px !important;
}

.sidebar-tab-btn {
  flex: 1 !important;
  padding: 10px 4px 8px !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  color: #6b7280 !important;
  border-bottom: 2px solid transparent !important;
  background: transparent !important;
  transition: all 0.12s ease !important;
  text-align: center !important;
}

.sidebar-tab-btn:hover:not(.active) {
  color: #111827 !important;
}

.sidebar-tab-btn.active {
  color: #005fb8 !important;
  border-bottom-color: #005fb8 !important;
  background: transparent !important;
  font-weight: 700 !important;
}

.sidebar-tab-content {
  padding: 12px !important;
}

/* Clean, Single-Line Palette Items (Workfront Style) */
.palette-grid {
  display: flex !important;
  flex-direction: column !important;
  gap: 2px !important;
}

.palette-item {
  background: #ffffff !important;
  border: 1px solid transparent !important;
  border-radius: 4px !important;
  padding: 7px 10px !important;
  display: flex !important;
  align-items: center !important;
  gap: 10px !important;
  cursor: grab !important;
  user-select: none !important;
  transition: background 0.12s ease, border-color 0.12s ease !important;
  box-shadow: none !important;
  min-height: 34px !important;
}

.palette-item:hover {
  background: #f3f4f6 !important;
  border-color: #e5e7eb !important;
  box-shadow: none !important;
  transform: none !important;
}

.palette-item:active {
  cursor: grabbing !important;
  background: #e5f1fb !important;
}

.palette-item-icon {
  width: 20px !important;
  height: 20px !important;
  background: transparent !important;
  color: #4b5563 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  font-size: 13px !important;
  flex-shrink: 0 !important;
}

.palette-item-info {
  flex: 1 !important;
  min-width: 0 !important;
}

.palette-item-name {
  font-weight: 500 !important;
  font-size: 12.5px !important;
  color: #1f2937 !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}

.palette-item-desc {
  display: none !important; /* Hide long secondary descriptions for compact elegance */
}

/* Column 2: Center Canvas Area */
.main-canvas-area {
  flex: 1 !important;
  overflow-y: auto !important;
  padding: 24px 32px 64px !important;
  background-color: var(--wf-canvas-bg) !important;
  position: relative !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
}

.canvas-container {
  max-width: 820px !important;
  width: 100% !important;
  margin: 0 auto !important;
}

/* Hide the giant distracting workspace card in canvas - keep DOM elements accessible for JS */
.canvas-doc-header-card {
  display: none !important;
}

/* Clean Form Section Sheet (Workfront Style) */
.cisco-bld-section,
.form-section-card {
  background: #ffffff !important;
  border: 1px solid #e5e7eb !important;
  border-left: 1px solid #e5e7eb !important;
  border-radius: 8px !important;
  margin-bottom: 20px !important;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03) !important;
  overflow: hidden !important;
  transition: box-shadow 0.15s ease !important;
}

.cisco-bld-sec-header,
.section-header {
  padding: 16px 20px 8px !important;
  background: #ffffff !important;
  border-bottom: none !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
}

.cisco-bld-sec-title-input,
.section-title-input {
  font-size: 15px !important;
  font-weight: 600 !important;
  color: #111827 !important;
  border: 1px solid transparent !important;
  border-radius: 4px !important;
  padding: 4px 8px !important;
  background: transparent !important;
  width: 70% !important;
}

.cisco-bld-sec-title-input:hover,
.section-title-input:hover {
  background: #f8fafc !important;
  border-color: #e2e8f0 !important;
}

.cisco-bld-sec-title-input:focus,
.section-title-input:focus {
  background: #ffffff !important;
  border-color: #005fb8 !important;
  box-shadow: 0 0 0 2px rgba(0, 95, 184, 0.12) !important;
}

.section-body {
  padding: 8px 20px 20px !important;
}

/* Authentic Form Field Representation on Canvas (Workfront Style) */
.cisco-bld-field-card,
.canvas-field-card {
  background: #ffffff !important;
  border: 1px solid #e5e7eb !important;
  border-radius: 6px !important;
  padding: 10px 14px 12px !important;
  margin-bottom: 12px !important;
  position: relative !important;
  transition: all 0.12s ease !important;
  cursor: pointer !important;
  box-shadow: none !important;
}

.cisco-bld-field-card:hover,
.canvas-field-card:hover {
  border-color: #9ca3af !important;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;
}

/* Crisp Blue Selected State (Identical to Workfront Field Selection) */
.cisco-bld-field-card.selected,
.canvas-field-card.selected {
  border: 2px solid #005fb8 !important;
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.14) !important;
  background: #ffffff !important;
}

.cisco-bld-label,
.field-preview-label {
  font-size: 12.5px !important;
  font-weight: 600 !important;
  color: #374151 !important;
  margin-bottom: 6px !important;
  display: flex !important;
  align-items: center !important;
  gap: 4px !important;
}

.cisco-req-star,
.req-star {
  color: #ef4444 !important;
  font-weight: bold !important;
}

/* Workfront Input Mock Widget */
.cisco-bld-widget input:not([type="checkbox"]):not([type="radio"]),
.cisco-bld-widget select,
.cisco-bld-widget textarea,
.mops-input,
.mops-select,
.mops-textarea {
  background: #ffffff !important;
  border: 1px solid #d1d5db !important;
  border-radius: 4px !important;
  padding: 6px 12px !important;
  font-size: 13px !important;
  color: #374151 !important;
  width: 100% !important;
  height: 36px !important;
  box-sizing: border-box !important;
  pointer-events: none !important; /* Non-interactive in builder view */
}

/* Checkbox & Radio specific handling inside cisco-bld-widget */
.cisco-bld-widget input[type="checkbox"],
.cisco-bld-widget input[type="radio"] {
  width: 17px !important;
  height: 17px !important;
  min-width: 17px !important;
  min-height: 17px !important;
  padding: 0 !important;
  margin: 0 !important;
  accent-color: #005fb8 !important;
  cursor: pointer !important;
  pointer-events: none !important;
  box-sizing: border-box !important;
  flex-shrink: 0 !important;
}

/* Modern Cisco Checkbox Preview Card (for canvas widgets) */
.cisco-checkbox-card-preview {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 36px;
  background: #f8fafc;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  padding: 0 10px;
  box-sizing: border-box;
  transition: all 0.15s ease;
  user-select: none;
  cursor: default;
}

.cisco-checkbox-card-preview.is-checked {
  background: #f0f7ff;
  border-color: #bae6fd;
}

.cisco-cb-left {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  flex: 1;
}

.cisco-cb-box {
  width: 17px;
  height: 17px;
  border-radius: 4px;
  border: 1.5px solid #005fb8;
  background: #005fb8;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  flex-shrink: 0;
  transition: all 0.15s ease;
  box-shadow: 0 1px 2px rgba(0, 95, 184, 0.12);
}

.cisco-cb-box.unchecked {
  border-color: #94a3b8;
  background: #ffffff;
  color: transparent;
  box-shadow: none;
}

.cisco-cb-text {
  font-size: 12.5px;
  font-weight: 500;
  color: #1e293b;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.cisco-cb-status-badge {
  font-size: 10px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 12px;
  background: #e0f2fe;
  color: #0369a1;
  border: 1px solid #bae6fd;
  white-space: nowrap;
  letter-spacing: 0.2px;
  margin-left: 8px;
  flex-shrink: 0;
}

.cisco-cb-status-badge.unchecked {
  background: #f1f5f9;
  color: #64748b;
  border-color: #e2e8f0;
}

.cisco-cb-group-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 12px;
  color: #1e293b;
}

.cisco-cb-group-item.checked {
  background: #f0f7ff;
  border-color: #bae6fd;
}

.cisco-bld-widget textarea,
.mops-textarea {
  height: 64px !important;
}

/* Subtle Toolbar over Field (Appears only on Hover/Selected) */
.cisco-bld-tools {
  opacity: 0.2;
  transition: opacity 0.12s ease;
}

.cisco-bld-field-card:hover .cisco-bld-tools,
.cisco-bld-field-card.selected .cisco-bld-tools {
  opacity: 1;
}

/* Subtle meta at bottom of card */
.cisco-bld-meta {
  margin-top: 6px !important;
  padding-top: 4px !important;
  border-top: 1px dashed #f1f5f9 !important;
  font-size: 10.5px !important;
  color: #94a3b8 !important;
}

/* Empty Dropzone in Section */
.section-dropzone-empty {
  border: 1.5px dashed #d1d5db !important;
  border-radius: 6px !important;
  background: #fafbfc !important;
  padding: 24px 16px !important;
  color: #6b7280 !important;
}

.dropzone-empty-icon {
  margin-bottom: 6px !important;
}

.dropzone-empty-title {
  font-size: 13px !important;
  font-weight: 600 !important;
  color: #374151 !important;
}

.dropzone-empty-desc {
  font-size: 11.5px !important;
  color: #9ca3af !important;
}

/* Add Section Button (Clean Outline Button) */
.btn-add-section {
  background: #ffffff !important;
  border: 1px dashed #cbd5e1 !important;
  color: #4b5563 !important;
  font-size: 13px !important;
  font-weight: 600 !important;
  padding: 10px 20px !important;
  border-radius: 6px !important;
}

.btn-add-section:hover {
  border-color: #005fb8 !important;
  color: #005fb8 !important;
  background: #f0f9ff !important;
}

/* Column 3: Right Inspector Panel (Permanently Docked Workfront Style) */
.settings-drawer {
  width: var(--sidebar-right-width, 320px) !important;
  background: #ffffff !important;
  border-left: 1px solid #e5e7eb !important;
  display: flex !important;
  flex-direction: column !important;
  flex-shrink: 0 !important;
  position: relative !important;
  top: auto !important;
  right: auto !important;
  bottom: auto !important;
  transform: none !important;
  box-shadow: none !important;
  z-index: 20 !important;
  overflow: hidden !important;
}

.drawer-header {
  padding: 14px 18px !important;
  background: #ffffff !important;
  border-bottom: 1px solid #e5e7eb !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
}

.drawer-title {
  font-size: 14px !important;
  font-weight: 700 !important;
  color: #111827 !important;
}

.drawer-field-key-hint {
  font-size: 11px !important;
  color: #6b7280 !important;
  font-family: monospace !important;
}

.drawer-tabs {
  background: #ffffff !important;
  border-bottom: 1px solid #e5e7eb !important;
  padding: 0 8px !important;
}

.drawer-tab-btn {
  padding: 8px 6px !important;
  font-size: 11.5px !important;
  font-weight: 600 !important;
  color: #6b7280 !important;
  border-bottom: 2px solid transparent !important;
}

.drawer-tab-btn.active {
  color: #005fb8 !important;
  border-bottom-color: #005fb8 !important;
}

.drawer-body {
  padding: 16px !important;
  flex: 1 !important;
  overflow-y: auto !important;
}

/* Size Segmented Control (Half / Full) in Inspector */
.width-picker {
  display: flex !important;
  background: #f3f4f6 !important;
  border-radius: 6px !important;
  padding: 3px !important;
  gap: 3px !important;
}

.width-pill {
  flex: 1 !important;
  padding: 6px 4px !important;
  font-size: 11.5px !important;
  font-weight: 600 !important;
  text-align: center !important;
  border: none !important;
  border-radius: 4px !important;
  background: transparent !important;
  color: #4b5563 !important;
  cursor: pointer !important;
}

.width-pill.active {
  background: #ffffff !important;
  color: #111827 !important;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06) !important;
}

/* Workfront Inspector Inputs */
.drawer-body .mops-input,
.drawer-body .mops-select,
.drawer-body .mops-textarea {
  pointer-events: auto !important;
  background: #ffffff !important;
  border: 1px solid #d1d5db !important;
  border-radius: 4px !important;
  padding: 7px 10px !important;
  font-size: 12.5px !important;
  color: #1f2937 !important;
}

.drawer-body .mops-input:focus,
.drawer-body .mops-select:focus,
.drawer-body .mops-textarea:focus {
  border-color: #005fb8 !important;
  box-shadow: 0 0 0 3px rgba(0, 95, 184, 0.12) !important;
  outline: none !important;
}

.form-label {
  font-size: 12px !important;
  font-weight: 600 !important;
  color: #374151 !important;
  margin-bottom: 4px !important;
}

/* Drawer Footer Apply Button */
.drawer-footer {
  padding: 12px 16px !important;
  background: #f9fafb !important;
  border-top: 1px solid #e5e7eb !important;
}

#btnApplyFieldChanges {
  background: #005fb8 !important;
  border-color: #005fb8 !important;
  color: #ffffff !important;
  font-weight: 600 !important;
  border-radius: 6px !important;
}

#btnApplyFieldChanges:hover {
  background: #004d96 !important;
}

/* Inspector Empty State (Shown when no field selected) */
.drawer-empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  padding: 32px 20px;
  text-align: center;
  color: #6b7280;
}

.des-icon {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: #f3f4f6;
  color: #9ca3af;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
}

.des-title {
  font-size: 14px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 6px;
}

.des-text {
  font-size: 12px;
  color: #9ca3af;
  line-height: 1.4;
  max-width: 200px;
}

/* When drawer is NOT open, hide drawer body/footer and show empty state */
.settings-drawer:not(.open) .drawer-tabs,
.settings-drawer:not(.open) .drawer-body,
.settings-drawer:not(.open) .drawer-footer {
  display: none !important;
}

.settings-drawer.open .drawer-empty-state {
  display: none !important;
}

/* --------------------------------------------------------------------------
   Workfront Canvas Footer Bar (- 11/500 fields used | Cancel | Save and Close | Apply)
   -------------------------------------------------------------------------- */
.wf-canvas-footer {
  height: 48px;
  background: #ffffff;
  border-top: 1px solid #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  flex-shrink: 0;
  z-index: 15;
  box-shadow: 0 -1px 3px rgba(0,0,0,0.02);
}

.wf-cf-left {
  font-size: 12px;
  font-weight: 500;
  color: #4b5563;
  display: flex;
  align-items: center;
  gap: 6px;
}

.wf-cf-bullet {
  color: #111827;
  font-size: 16px;
  line-height: 1;
}

.wf-cf-right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.btn-wf-cancel {
  background: transparent;
  border: none;
  color: #4b5563;
  font-size: 13px;
  font-weight: 500;
  padding: 6px 14px;
  cursor: pointer;
  border-radius: 4px;
  font-family: inherit;
}

.btn-wf-cancel:hover {
  background: #f3f4f6;
  color: #111827;
}

.btn-wf-save-close {
  background: #ffffff;
  border: 1px solid #d1d5db;
  color: #374151;
  font-size: 13px;
  font-weight: 600;
  padding: 6px 16px;
  cursor: pointer;
  border-radius: 20px;
  font-family: inherit;
  transition: all 0.12s ease;
}

.btn-wf-save-close:hover {
  background: #f9fafb;
  border-color: #9ca3af;
}

.btn-wf-apply {
  background: #005fb8;
  border: 1px solid #005fb8;
  color: #ffffff;
  font-size: 13px;
  font-weight: 600;
  padding: 6px 22px;
  cursor: pointer;
  border-radius: 20px;
  font-family: inherit;
  box-shadow: 0 1px 2px rgba(0, 95, 184, 0.25);
  transition: all 0.12s ease;
}

.btn-wf-apply:hover {
  background: #004d96;
  border-color: #004d96;
}

/* Hide desktop status bar (replaced by clean Workfront canvas footer) */
.desktop-status-bar {
  display: none !important;
}


/* ==========================================================================
   OFFICIAL CISCO MOPS BRAND STYLES FOR LIGHT NAVBAR
   ========================================================================== */

.cisco-brand-wrap {
  display: flex !important;
  align-items: center !important;
  gap: 15px !important;
  cursor: pointer !important;
  text-decoration: none !important;
  user-select: none !important;
  padding: 4px 8px 4px 4px !important;
  border-radius: 6px !important;
  transition: background 0.12s ease !important;
}

.cisco-brand-wrap:hover {
  background: #f8fafc !important;
}

.cisco-logo-svg {
  width: 62px !important;
  height: 33px !important;
  flex-shrink: 0 !important;
  display: block !important;
}

.cisco-title-block {
  display: flex !important;
  flex-direction: column !important;
  justify-content: center !important;
}

.cisco-app-title {
  font-size: 14.5px !important;
  font-weight: 700 !important;
  color: #0f172a !important;
  letter-spacing: -0.2px !important;
  line-height: 1.2 !important;
}

.cisco-app-tag {
  font-size: 10px !important;
  font-weight: 700 !important;
  color: #0284c7 !important;
  text-transform: uppercase !important;
  letter-spacing: 0.6px !important;
  line-height: 1 !important;
  margin-top: 2px !important;
}

.cisco-nav-sep {
  display: block !important;
  width: 1px !important;
  height: 28px !important;
  background: #cbd5e1 !important;
  margin: 0 18px !important;
  flex-shrink: 0 !important;
}

.wf-active-form-nav-group {
  display: flex !important;
  align-items: center !important;
  gap: 10px !important;
}

.wf-env-pill {
  display: inline-flex; /* no !important - allows JS/inline style="display:none" to hide it */
  align-items: center !important;
  gap: 5px !important;
  background: #f1f5f9 !important;
  border: 1px solid #cbd5e1 !important;
  border-radius: 12px !important;
  padding: 2px 9px !important;
  font-size: 11px !important;
  font-weight: 700 !important;
  color: #005fb8 !important;
  cursor: pointer !important;
  letter-spacing: 0.2px !important;
  transition: all 0.15s ease !important;
}
/* Force-hide when JS sets display:none - overrides any specificity */
.wf-env-pill[style*="display: none"],
.wf-env-pill[style*="display:none"] {
  display: none !important;
}

.wf-env-pill:hover {
  background: #e0f2fe !important;
  border-color: #005fb8 !important;
}


/* ==========================================================================
   CONSISTENT BUTTON TOKENS & SIMULATOR / REVIEW MODE OVERHAUL
   ========================================================================== */

/* Universal Primary & Secondary Button Overrides */
.btn-primary,
.top-action-btn.top-btn-save,
.btn-wf-apply,
#btnExitReviewMode,
.forms-sidebar-new-btn {
  background-color: #005fb8 !important;
  border-color: #005fb8 !important;
  color: #ffffff !important;
}

.btn-primary:hover,
.top-action-btn.top-btn-save:hover,
.btn-wf-apply:hover,
#btnExitReviewMode:hover,
.forms-sidebar-new-btn:hover {
  background-color: #004d96 !important;
  border-color: #004d96 !important;
}

.btn-primary:active,
.top-action-btn.top-btn-save:active,
.btn-wf-apply:active,
#btnExitReviewMode:active,
.forms-sidebar-new-btn:active {
  background-color: #003d78 !important;
  border-color: #003d78 !important;
}

/* Secondary / Outline Button Overrides */
.btn-outline,
.btn-outline-white,
.btn-nav-teal,
.forms-sidebar-gallery-btn,
.btn-wf-share,
.btn-wf-logic,
.btn-wf-save-close,
#btnReviewDownloadPdf,
#btnReviewShareHtml,
#btnOpenDevInspector {
  background-color: #ffffff !important;
  border: 1px solid #d1d5db !important;
  color: #374151 !important;
}

.btn-outline:hover,
.btn-outline-white:hover,
.btn-nav-teal:hover,
.forms-sidebar-gallery-btn:hover,
.btn-wf-share:hover,
.btn-wf-logic:hover,
.btn-wf-save-close:hover,
#btnReviewDownloadPdf:hover,
#btnReviewShareHtml:hover,
#btnOpenDevInspector:hover {
  background-color: #f9fafb !important;
  border-color: #9ca3af !important;
  color: #111827 !important;
}

/* --------------------------------------------------------------------------
   Review Mode / Simulator Banner (Clean Light Enterprise Design)
   -------------------------------------------------------------------------- */
.review-mode-banner {
  display: none !important; /* Hidden in builder mode */
  background: #ffffff !important;
  border-bottom: 1px solid #e2e8f0 !important;
  color: #1e293b !important;
  padding: 8px 20px !important;
  font-size: 12.5px !important;
  font-weight: 500 !important;
  align-items: center !important;
  justify-content: space-between !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03) !important;
  z-index: 50 !important;
  flex-wrap: wrap !important;
  gap: 10px !important;
}

body.mode-review .review-mode-banner,
.app-container.mode-review .review-mode-banner {
  display: flex !important;
}

.review-banner-left {
  display: flex !important;
  align-items: center !important;
  gap: 12px !important;
}

.review-banner-tag {
  background: #ecfdf5 !important;
  color: #059669 !important;
  border: 1px solid #a7f3d0 !important;
  font-size: 11px !important;
  font-weight: 700 !important;
  letter-spacing: 0.4px !important;
  padding: 3px 9px !important;
  border-radius: 12px !important;
  display: inline-flex !important;
  align-items: center !important;
  gap: 6px !important;
}

.review-banner-tag::before {
  content: '' !important;
  width: 6px !important;
  height: 6px !important;
  border-radius: 50% !important;
  background: #10b981 !important;
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.25) !important;
  display: inline-block !important;
}

.review-banner-subtitle {
  font-size: 11.5px !important;
  color: #64748b !important;
  font-weight: 600 !important;
}

/* Review Variation Switcher in Simulator */
.review-variation-switcher {
  display: flex !important;
  background: #f1f5f9 !important;
  border: 1px solid #e2e8f0 !important;
  border-radius: 6px !important;
  padding: 2px !important;
  gap: 2px !important;
}

.review-variation-switcher .rev-var-btn {
  background: transparent !important;
  color: #64748b !important;
  border: none !important;
  padding: 4px 12px !important;
  font-size: 11.5px !important;
  font-weight: 600 !important;
  border-radius: 4px !important;
  cursor: pointer !important;
  display: inline-flex !important;
  align-items: center !important;
  gap: 5px !important;
  transition: all 0.12s ease !important;
}

.review-variation-switcher .rev-var-btn:hover:not(.active) {
  color: #1e293b !important;
  background: rgba(255, 255, 255, 0.6) !important;
}

.review-variation-switcher .rev-var-btn.active {
  background: #ffffff !important;
  color: #005fb8 !important;
  font-weight: 700 !important;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08) !important;
}

.review-banner-right {
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
}

/* --------------------------------------------------------------------------
   Sidebar Forms Tab: Button & Badge Consistency
   -------------------------------------------------------------------------- */
.forms-sidebar-new-btn {
  background: #005fb8 !important;
  border: 1px solid #005fb8 !important;
  color: #ffffff !important;
  border-radius: 6px !important;
  padding: 5px 12px !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  cursor: pointer !important;
  display: inline-flex !important;
  align-items: center !important;
  gap: 4px !important;
  box-shadow: 0 1px 2px rgba(0, 95, 184, 0.2) !important;
  transition: background 0.12s ease !important;
}

.forms-sidebar-new-btn:hover {
  background: #004d96 !important;
  border-color: #004d96 !important;
}

/* Sidebar Form Cards & Badges */
.sidebar-form-card {
  background: #ffffff !important;
  border: 1px solid #e5e7eb !important;
  border-radius: 6px !important;
  margin-bottom: 6px !important;
  transition: all 0.12s ease !important;
}

.sidebar-form-card:hover {
  border-color: #cbd5e1 !important;
  background: #f8fafc !important;
}

.sidebar-form-card.active {
  border-color: #005fb8 !important;
  background: #f0f7ff !important;
  box-shadow: inset 3px 0 0 #005fb8 !important;
}

.sfc-active-indicator {
  background: #005fb8 !important;
}

.sfc-ver-badge {
  background: #e0f2fe !important;
  color: #005fb8 !important;
  border: 1px solid #bae6fd !important;
  font-size: 10px !important;
  font-weight: 700 !important;
  padding: 1px 7px !important;
  border-radius: 12px !important;
  letter-spacing: 0.2px !important;
  flex-shrink: 0 !important;
}

.sidebar-form-card.active .sfc-ver-badge {
  background: #005fb8 !important;
  color: #ffffff !important;
  border-color: #005fb8 !important;
}

/* --------------------------------------------------------------------------
   Settings Drawer: Clean Inspector & Empty State Separation
   -------------------------------------------------------------------------- */
.settings-drawer {
  width: var(--sidebar-right-width, 320px) !important;
  background: #ffffff !important;
  border-left: 1px solid #e5e7eb !important;
  display: flex !important;
  flex-direction: column !important;
  flex-shrink: 0 !important;
  position: relative !important;
  z-index: 20 !important;
  overflow: hidden !important;
}

/* When drawer is closed (no field selected) */
.settings-drawer:not(.open) #drawerActiveContent {
  display: none !important;
}

.settings-drawer:not(.open) #drawerEmptyState {
  display: flex !important;
}

/* When drawer is open (field IS selected) */
.settings-drawer.open #drawerActiveContent {
  display: flex !important;
  flex-direction: column !important;
  flex: 1 !important;
  overflow: hidden !important;
}

.settings-drawer.open #drawerEmptyState {
  display: none !important;
}

.drawer-empty-state {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: center !important;
  height: 100% !important;
  padding: 48px 24px !important;
  text-align: center !important;
  color: #6b7280 !important;
  background: #ffffff !important;
}

.drawer-empty-state .des-icon {
  width: 44px !important;
  height: 44px !important;
  border-radius: 50% !important;
  background: #f3f4f6 !important;
  color: #9ca3af !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin-bottom: 12px !important;
}

.drawer-empty-state .des-title {
  font-size: 14px !important;
  font-weight: 600 !important;
  color: #374151 !important;
  margin-bottom: 6px !important;
}

.drawer-empty-state .des-text {
  font-size: 12px !important;
  color: #9ca3af !important;
  line-height: 1.4 !important;
  max-width: 200px !important;
}

/* Hide inspector in simulator/review mode */
body.mode-review .settings-drawer,
.app-container.mode-review .settings-drawer {
  display: none !important;
}

/* Hide sidebar in simulator mode unless explicitly requested */
body.mode-review .sidebar-palette,
.app-container.mode-review .sidebar-palette {
  display: flex !important;
}


/* ==========================================================================
   SIMULATOR MODE: Canvas and Preview Layout Fixes
   ========================================================================== */

/* In review mode, the sidebar shows only the compact Forms list (not the 
   full drag-and-drop palette) so we shrink sidebar width to save space */
body.mode-review .sidebar-palette {
  width: 200px !important;
  min-width: 200px !important;
}

body.mode-review .sidebar-tabs {
  /* Hide the + New field and Field library tabs in review mode */
}

body.mode-review .sidebar-tab-btn[data-tab-content="tabPanePalette"],
body.mode-review .sidebar-tab-btn[data-tab-content="tabPaneReusableFields"] {
  display: none !important;
}

/* Compact sidebar header label in review mode */
body.mode-review .forms-sidebar-title {
  font-size: 12px !important;
}

/* In review mode, expand canvas to use available width */
body.mode-review .canvas-container {
  max-width: 100% !important;
  width: 100% !important;
}

/* Live preview iframe should use full available height */
body.mode-review .live-preview-iframe {
  min-height: calc(100vh - 110px) !important;
}

/* Main canvas area in review mode: symmetric padding so iframe has equal side gaps */
body.mode-review .main-canvas-area {
  padding: 20px !important;
  box-sizing: border-box !important;
}

/* The live preview viewport gets a polished shadow-card look */
body.mode-review .live-preview-viewport {
  border-radius: 6px !important;
  box-shadow: 0 2px 16px rgba(0, 0, 0, 0.07) !important;
}



/* --------------------------------------------------------------------------
   Sidebar Form Card Status & Quick Actions (Activate, Inactivate, Delete)
   -------------------------------------------------------------------------- */
.sidebar-form-card {
  position: relative !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 6px 8px !important;
}

.sidebar-form-card.form-inactive {
  opacity: 0.72;
  background: #fbfbfb !important;
  border-left: 3px solid #cbd5e1 !important;
}

.sfc-status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  display: inline-block;
  flex-shrink: 0;
}

.sfc-status-dot.status-active {
  background: #10b981;
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.25);
}

.sfc-status-dot.status-inactive {
  background: #94a3b8;
}

.sfc-inactive-pill {
  background: #f1f5f9;
  color: #64748b;
  border: 1px solid #e2e8f0;
  font-size: 9px;
  font-weight: 700;
  padding: 0 5px;
  border-radius: 10px;
  text-transform: uppercase;
}

.sfc-actions {
  display: none;
  align-items: center;
  gap: 3px;
  margin-left: 4px;
  flex-shrink: 0;
}

.sidebar-form-card:hover .sfc-actions {
  display: flex;
}

.sfc-action-btn {
  background: #ffffff;
  border: 1px solid #d1d5db;
  color: #4b5563;
  width: 24px;
  height: 24px;
  border-radius: 4px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  transition: all 0.12s ease;
}

.sfc-action-btn:hover {
  background: #f3f4f6;
  color: #111827;
  border-color: #9ca3af;
}

.sfc-action-btn.sfc-del-btn:hover {
  background: #fef2f2;
  color: #dc2626;
  border-color: #fca5a5;
}

/* Hide builder bottom action bar (Cancel, Save and Close, Apply) in Simulator / Review mode */
body.mode-review .wf-canvas-footer,
body.mode-review #wfCanvasFooter {
  display: none !important;
}


/* ==========================================================================
   RESIZABLE / MOVABLE SIDEBAR SPLITTERS (Workfront Stretchable Dividers)
   ========================================================================== */

:root {
  --sidebar-left-width: 240px;
  --sidebar-right-width: 320px;
}

/* Prevent text selection and force resize cursor while dragging any splitter */
body.is-resizing,
body.is-resizing * {
  cursor: col-resize !important;
  user-select: none !important;
  -webkit-user-select: none !important;
}

/* The vertical draggable splitter divider */
.splitter-gutter {
  width: 8px;
  margin: 0 -4px;
  background: transparent;
  cursor: col-resize;
  position: relative;
  z-index: 35;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  user-select: none;
  touch-action: none;
  transition: background 0.15s ease;
}

/* Vertical guide line on hover or drag */
.splitter-gutter::after {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  left: 3px;
  width: 2px;
  background: transparent;
  transition: background 0.15s ease, box-shadow 0.15s ease;
}

.splitter-gutter:hover::after,
.splitter-gutter.active-drag::after {
  background: #005fb8;
  box-shadow: 0 0 6px rgba(0, 95, 184, 0.4);
}

/* Workfront-style pill handle in the center of the divider */
.splitter-handle-icon {
  width: 5px;
  height: 38px;
  border-radius: 4px;
  background: #cbd5e1;
  position: relative;
  transition: all 0.15s ease;
  pointer-events: none;
}

.splitter-gutter:hover .splitter-handle-icon,
.splitter-gutter.active-drag .splitter-handle-icon {
  background: #005fb8;
  height: 52px;
  width: 6px;
  box-shadow: 0 1px 4px rgba(0, 95, 184, 0.35);
}

/* In Simulator / Review Mode: hide right splitter because drawer is hidden */
body.mode-review .splitter-right,
.app-container.mode-review .splitter-right {
  display: none !important;
}

/* Minimum and maximum constraints */
.sidebar-palette {
  min-width: 170px !important;
  max-width: 520px !important;
}

.settings-drawer {
  min-width: 260px !important;
  max-width: 640px !important;
}


/* ==========================================================================
   MARGIN, OVERLAP, AND PANEL SIZING OVERHAUL
   ========================================================================== */

:root {
  --sidebar-left-width: 260px;
  --sidebar-right-width: 320px;
}

/* Sidebar dimensions & strict min-width to prevent any overlap */
.sidebar-palette {
  width: var(--sidebar-left-width, 260px) !important;
  min-width: 240px !important;
  max-width: 520px !important;
  overflow-x: hidden !important;
  box-sizing: border-box !important;
}

/* Tabs: cleanly spaced, never wrap or overlap */
.sidebar-tabs {
  display: flex !important;
  align-items: center !important;
  border-bottom: 1px solid #e5e7eb !important;
  background: #ffffff !important;
  padding: 0 4px !important;
  gap: 2px !important;
  overflow: hidden !important;
  flex-shrink: 0 !important;
}

.sidebar-tab-btn {
  flex: 1 1 0 !important;
  white-space: nowrap !important;
  padding: 9px 4px 8px !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  text-align: center !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  border-bottom: 2px solid transparent !important;
  box-sizing: border-box !important;
}

.sidebar-tab-btn.active {
  color: #005fb8 !important;
  border-bottom-color: #005fb8 !important;
  font-weight: 700 !important;
}

/* Forms Sidebar Header: 2 stacked rows (Title row, Action button row) */
.forms-sidebar-header {
  display: flex !important;
  flex-direction: column !important;
  gap: 8px !important;
  margin-bottom: 12px !important;
  padding-bottom: 10px !important;
  border-bottom: 1px solid #e5e7eb !important;
}

.forms-sidebar-title-row {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
}

.forms-sidebar-title {
  font-size: 11px !important;
  font-weight: 700 !important;
  text-transform: uppercase !important;
  letter-spacing: 0.5px !important;
  color: #64748b !important;
}

.forms-sidebar-actions {
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  width: 100% !important;
}

.forms-sidebar-gallery-btn,
.forms-sidebar-new-btn {
  flex: 1 !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 6px 10px !important;
  font-size: 12px !important;
  border-radius: 6px !important;
}

/* Form Cards in Sidebar: clean padding and text truncation */
.sidebar-form-card {
  box-sizing: border-box !important;
  width: 100% !important;
  padding: 8px 10px !important;
  margin-bottom: 6px !important;
  border-radius: 6px !important;
}

.sfc-main {
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  flex: 1 !important;
  min-width: 0 !important;
}

.sfc-info {
  flex: 1 !important;
  min-width: 0 !important;
  overflow: hidden !important;
}

.sfc-name {
  font-size: 12.5px !important;
  font-weight: 600 !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  display: block !important;
  max-width: 100% !important;
}

/* Splitter Gutters: zero negative margins, no scrollbar overlap */
.splitter-gutter {
  width: 5px !important;
  margin: 0 !important;
  background: #f1f5f9 !important;
  border-left: 1px solid #e2e8f0 !important;
  cursor: col-resize !important;
  position: relative !important;
  z-index: 25 !important;
  flex-shrink: 0 !important;
  transition: background 0.15s ease !important;
}

.splitter-gutter:hover,
.splitter-gutter.active-drag {
  background: #005fb8 !important;
}

.splitter-handle-icon {
  display: none !important; /* Keep divider clean and flat */
}

/* Main Canvas Area: ensure no overflow clipping */
.main-canvas-area {
  flex: 1 !important;
  min-width: 0 !important;
  overflow-y: auto !important;
  padding: 24px 28px 80px !important;
  box-sizing: border-box !important;
}

.canvas-container {
  max-width: 1080px !important;
  width: 100% !important;
  margin: 0 auto !important;
}


/* ==========================================================================
   Visual Cards Categorized 4-Column Layout
   ========================================================================== */
.visual-cards-subtitle {
  font-size: 13px;
  color: #64748b;
  margin-top: -2px;
  margin-bottom: 12px;
  font-weight: 400;
  line-height: 1.4;
}

.visual-cards-categories-container {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
  margin-top: 6px;
  margin-bottom: 8px;
  width: 100%;
  box-sizing: border-box;
}

@media (max-width: 1200px) {
  .visual-cards-categories-container {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 640px) {
  .visual-cards-categories-container {
    grid-template-columns: 1fr;
  }
}

.visual-cards-column {
  --cat-accent: #00bceb;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.visual-cards-column-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  padding-bottom: 8px;
  border-bottom: 2px solid var(--cat-accent, #00bceb);
}

.visual-cards-column-header .cat-header-title {
  color: var(--cat-accent, #0f172a);
}

.visual-cards-column-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.visual-card-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  background: #ffffff;
  border: 1.5px solid #e2e8f0;
  border-radius: 8px;
  padding: 12px 14px;
  cursor: pointer;
  position: relative;
  transition: all 0.2s ease-in-out;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  user-select: none;
  box-sizing: border-box;
  text-align: left;
  margin: 0;
}

.visual-card-item:hover {
  border-color: var(--cat-accent);
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
  transform: translateY(-1px);
}

.visual-card-item.active,
.visual-card-item:has(input[type="radio"]:checked) {
  border-color: var(--cat-accent) !important;
  background: #f8fafc !important;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.vc-icon-box {
  width: 36px;
  height: 36px;
  min-width: 36px;
  border-radius: 7px;
  background: var(--cat-accent, #005fb8);
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 1px;
}

.vc-icon-box svg {
  width: 18px;
  height: 18px;
  stroke: #ffffff;
  fill: none;
}

.vc-content {
  flex: 1;
  min-width: 0;
}

.vc-label {
  font-size: 13.5px;
  font-weight: 700;
  color: #0f172a;
  line-height: 1.3;
}

.vc-description {
  font-size: 11.5px;
  color: #64748b;
  margin-top: 4px;
  line-height: 1.4;
}

.vc-radio-wrapper {
  margin-top: 3px;
  flex-shrink: 0;
  padding-left: 6px;
}

.vc-radio-circle {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid #cbd5e1;
  background: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease-in-out;
  box-sizing: border-box;
}

.visual-card-item:hover .vc-radio-circle {
  border-color: var(--cat-accent);
}

.vc-radio-circle.checked,
.visual-card-item:has(input[type="radio"]:checked) .vc-radio-circle {
  border-color: var(--cat-accent) !important;
  background: #ffffff !important;
}

.vc-radio-inner {
  display: none;
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: var(--cat-accent);
}

.vc-radio-circle.checked .vc-radio-inner,
.visual-card-item:has(input[type="radio"]:checked) .vc-radio-circle .vc-radio-inner {
  display: block;
}

/* Field highlight animation when added from Palette or Library */
@keyframes fieldHighlightPulse {
  0% { box-shadow: 0 0 0 0 rgba(0, 95, 184, 0.7); border-color: #005fb8; }
  50% { box-shadow: 0 0 0 10px rgba(0, 95, 184, 0.2); border-color: #005fb8; }
  100% { box-shadow: 0 0 0 0 rgba(0, 95, 184, 0); }
}
.field-highlight-pulse {
  animation: fieldHighlightPulse 1.4s ease-out !important;
  border-color: #005fb8 !important;
}

/* Empty canvas card drag-over state */
.canvas-empty-card.drag-over {
  border-color: #005fb8 !important;
  background: #f0f7ff !important;
  box-shadow: 0 4px 16px rgba(0, 95, 184, 0.18) !important;
  transform: scale(1.02);
}

/* Palette items clickable cursor & hover */
.palette-item {
  cursor: pointer !important;
}
.palette-item:hover {
  border-color: #005fb8 !important;
  background: #f0f9ff !important;
}
.saved-field-card {
  cursor: pointer !important;
}
.saved-field-card:hover {
  border-color: #005fb8 !important;
  box-shadow: 0 3px 10px rgba(0, 95, 184, 0.16) !important;
}

`;
window.STANDALONE_REVIEW_CSS = window.MOPS_STANDALONE_CSS;
