/**
 * MOPs FORM Studio - Sample Forms Registry
 * Pre-seeded intake forms representing Cisco MOPS configurations.
 * Only TestForm is active.
 */

window.SAMPLE_FORMS = [
  {
    "id": "test-form",
    "label": "TestForm",
    "icon": "",
    "configFile": "form.test-form.config.ts",
    "activeVersionId": "v3.2",
    "activeSprint": "Sprint 25.2",
    "createdAt": "2026-11-22T14:23:22.981Z",
    "createdBy": "VenkataRamaKrishna Vommi (vevommi)",
    "updatedAt": "2026-11-23T02:16:01+01:00",
    "updatedBy": "VenkataRamaKrishna Vommi (vevommi)",
    "folder": "test-form",
    "totalVersions": 10,
    "schema": {
      "title": "TestForm - Multi-Sprint and Flow Validation Form",
      "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
      "workfrontRouting": {
        "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
        "defaultTemplateLabel": "Standard Web Page Template",
        "defaultCategoryIds": [
          "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
        ],
        "templateRules": [
          {
            "priority": 1,
            "label": "Fast-Track Emergency Template",
            "conditions": [
              {
                "field": "submitterType",
                "comparison": "==",
                "value": "Fast-Track"
              }
            ],
            "conditionOperator": "AND",
            "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
          },
          {
            "priority": 2,
            "label": "Agency Web Page Template",
            "conditions": [
              {
                "field": "submitterType",
                "comparison": "==",
                "value": "Agency"
              },
              {
                "field": "deliverableFormat",
                "comparison": "==",
                "value": "Web Page / Microsite"
              }
            ],
            "conditionOperator": "AND",
            "templateId": "TEMPLATE_DART_AGENCY_WEB"
          },
          {
            "priority": 3,
            "label": "Email Blast Template",
            "conditions": [
              {
                "field": "deliverableFormat",
                "comparison": "==",
                "value": "Email Blast"
              }
            ],
            "conditionOperator": "AND",
            "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
          }
        ],
        "categoryRules": [
          {
            "label": "Agency Financial Details Form",
            "conditions": [
              {
                "field": "submitterType",
                "comparison": "==",
                "value": "Agency"
              }
            ],
            "conditionOperator": "AND",
            "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
          },
          {
            "label": "Fast-Track Escalation Review Form",
            "conditions": [
              {
                "field": "submitterType",
                "comparison": "==",
                "value": "Fast-Track"
              }
            ],
            "conditionOperator": "AND",
            "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
          }
        ]
      },
      "sections": [
        {
          "id": "tf_s1",
          "title": "Project & Stakeholder Details",
          "collapsed": false,
          "fields": [
            {
              "id": "tf_f1",
              "wfId": "61df5582003a92b049cafa45f74e87ac",
              "wfFieldName": "projectName",
              "wfLabel": "Project Name",
              "label": "Project Name",
              "type": "text",
              "col": "col-lg-6",
              "required": true,
              "placeholder": "e.g. Q3 Baseline Security Initiative"
            },
            {
              "id": "tf_f2",
              "wfId": "635040d700147670ca356476308a58f6",
              "wfFieldName": "campaignAlign",
              "wfLabel": "Campaign Alignment",
              "label": "Campaign Alignment",
              "type": "select",
              "col": "col-lg-6",
              "required": true,
              "options": [
                "Accelerate",
                "Foundation",
                "Growth",
                "Security First"
              ]
            },
            {
              "id": "tf_f3",
              "wfId": "65c192830041829928374102938471ac",
              "wfFieldName": "submitterType",
              "wfLabel": "Submitter Type",
              "label": "Submitter Type",
              "type": "select",
              "col": "col-lg-6",
              "required": true,
              "options": [
                "Internal",
                "Agency",
                "Fast-Track"
              ]
            },
            {
              "id": "tf_f4",
              "wfId": "64b192800041289c51239840293812ab",
              "wfFieldName": "stakeholderEmail",
              "wfLabel": "Stakeholder Cisco Email",
              "label": "Stakeholder Email",
              "type": "email",
              "col": "col-lg-12",
              "required": true,
              "placeholder": "submitter@cisco.com",
              "tooltip": "Must be a valid @cisco.com corporate email address."
            }
          ]
        },
        {
          "id": "tf_s2",
          "title": "Agency Information",
          "collapsed": false,
          "fields": [
            {
              "id": "tf_f5",
              "wfId": "66d1928000129384710293847102938d",
              "wfFieldName": "agencyPartnerName",
              "wfLabel": "Agency Partner Name",
              "label": "Agency Partner Name",
              "type": "text",
              "col": "col-lg-6",
              "required": true,
              "placeholder": "e.g. Ogilvy, MediaMonks"
            },
            {
              "id": "tf_f6",
              "wfId": "66e1928000129384710293847102938e",
              "wfFieldName": "agencyPoNumber",
              "wfLabel": "Agency Purchase Order (PO #)",
              "label": "Agency PO #",
              "type": "text",
              "col": "col-lg-6",
              "required": true,
              "placeholder": "e.g. PO-89210-2026"
            }
          ],
          "condition": [
            {
              "field": "submitterType",
              "comparison": "==",
              "value": "Agency"
            }
          ]
        },
        {
          "id": "tf_s3",
          "title": "Emergency / Fast-Track Details",
          "collapsed": false,
          "fields": [
            {
              "id": "tf_f7",
              "wfId": "67c1928000129384710293847102938f",
              "wfFieldName": "escalationSponsor",
              "wfLabel": "Executive Escalation Sponsor",
              "label": "Escalation Sponsor (VP+)",
              "type": "text",
              "col": "col-lg-6",
              "required": true,
              "placeholder": "e.g. Jane Doe (VP Global Mktg)"
            },
            {
              "id": "tf_f8",
              "wfId": "68d1928000129384710293847102938a",
              "wfFieldName": "targetLiveDate",
              "wfLabel": "Target Expedited Live Date",
              "label": "Target Live Date",
              "type": "date",
              "col": "col-lg-6",
              "required": true
            }
          ]
        },
        {
          "id": "tf_s4",
          "title": "Deliverables & Asset Specs",
          "collapsed": false,
          "fields": [
            {
              "id": "tf_f10",
              "wfId": "67a892b100234a9918204910293847aa",
              "wfFieldName": "deliverableFormat",
              "wfLabel": "Deliverable Format",
              "label": "Deliverable Format",
              "type": "select",
              "col": "col-lg-6",
              "required": true,
              "options": [
                "Web Page / Microsite",
                "Email Blast",
                "Digital Media Banner",
                "Executive Video"
              ]
            },
            {
              "id": "tf_f11",
              "wfId": "68b992100034a11229384710293841bb",
              "wfFieldName": "targetRegion",
              "wfLabel": "Target Audience Region",
              "label": "Target Audience Region",
              "type": "select",
              "col": "col-lg-6",
              "required": true,
              "options": [
                "Global",
                "AMER",
                "EMEA",
                "APJC"
              ]
            },
            {
              "id": "tf_f12",
              "wfId": "69c12830004192837410293847102938",
              "wfFieldName": "budgetCode",
              "wfLabel": "Estimated Budget Code",
              "label": "Estimated Budget Code",
              "type": "text",
              "col": "col-lg-12",
              "required": false,
              "placeholder": "e.g. MKTG-2026-US-SEC",
              "baNotes": "Budget code must match standard Cisco cost center naming convention."
            }
          ]
        }
      ],
      "readOnly": false
    },
    "sprints": [
      {
        "sprintId": "sprint-24.8",
        "sprintLabel": "Sprint 24.8",
        "startDate": "2026-08-01",
        "endDate": "2026-08-20",
        "status": "Archived",
        "publishedVersionId": "v1.2",
        "versions": [
          {
            "versionId": "v1.0",
            "versionLabel": "v1.0 (Sprint 24.8)",
            "sprint": "Sprint 24.8",
            "timestamp": "2026-08-05T10:00:00.000Z",
            "author": "MOPs Core Team",
            "status": "Archived",
            "notes": "Initial baseline release for TestForm intake specification with 5 core fields.",
            "stats": {
              "sectionCount": 2,
              "fieldCount": 5,
              "rulesCount": 0
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [],
                "categoryRules": []
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Foundation",
                        "Growth"
                      ]
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": false,
                      "options": [
                        "Global",
                        "AMER"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": false,
                      "placeholder": "e.g. BASE-2026-US"
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v1.1",
            "versionLabel": "v1.1 (Sprint 24.8)",
            "sprint": "Sprint 24.8",
            "timestamp": "2026-08-12T14:30:00.000Z",
            "author": "Alex Rivera",
            "status": "Archived",
            "notes": "Added Stakeholder Email field with corporate domain tooltip and expanded campaign alignments.",
            "stats": {
              "sectionCount": 2,
              "fieldCount": 6,
              "rulesCount": 0
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [],
                "categoryRules": []
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": false,
                      "options": [
                        "Global",
                        "AMER"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": false,
                      "placeholder": "e.g. BASE-2026-US"
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v1.2",
            "versionLabel": "v1.2 (Sprint 24.8 Published)",
            "sprint": "Sprint 24.8",
            "timestamp": "2026-08-20T17:00:00.000Z",
            "author": "Sarah Chen",
            "status": "Published",
            "notes": "Published Sprint 24.8 baseline: Enforced required Target Region and added Budget Code BA spec notes.",
            "stats": {
              "sectionCount": 2,
              "fieldCount": 6,
              "rulesCount": 0
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [],
                "categoryRules": []
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          }
        ]
      },
      {
        "sprintId": "sprint-25.1",
        "sprintLabel": "Sprint 25.1",
        "startDate": "2026-09-01",
        "endDate": "2026-09-25",
        "status": "Archived",
        "publishedVersionId": "v2.3",
        "versions": [
          {
            "versionId": "v2.0",
            "versionLabel": "v2.0 (Sprint 25.1)",
            "sprint": "Sprint 25.1",
            "timestamp": "2026-09-02T09:00:00.000Z",
            "author": "Jane Smith",
            "status": "Archived",
            "notes": "Major release kickoff: Added Submitter Type dropdown (Internal, Agency) and new Deliverable Formats.",
            "stats": {
              "sectionCount": 2,
              "fieldCount": 7,
              "rulesCount": 0
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 2,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency"
                      ]
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v2.1",
            "versionLabel": "v2.1 (Sprint 25.1)",
            "sprint": "Sprint 25.1",
            "timestamp": "2026-09-09T11:30:00.000Z",
            "author": "John Doe",
            "status": "Archived",
            "notes": "Added Fast-Track option to Submitter Type; reordered field layout in Section 1.",
            "stats": {
              "sectionCount": 2,
              "fieldCount": 7,
              "rulesCount": 0
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 2,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency",
                        "Fast-Track"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v2.2",
            "versionLabel": "v2.2 (Sprint 25.1)",
            "sprint": "Sprint 25.1",
            "timestamp": "2026-09-16T15:00:00.000Z",
            "author": "Jane Smith",
            "status": "Archived",
            "notes": "Added Section 2: Agency Information with Agency Partner Name and Agency PO Number.",
            "stats": {
              "sectionCount": 3,
              "fieldCount": 9,
              "rulesCount": 0
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 2,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency",
                        "Fast-Track"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s2",
                  "title": "Agency Information",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f5",
                      "wfId": "66d1928000129384710293847102938d",
                      "wfFieldName": "agencyPartnerName",
                      "wfLabel": "Agency Partner Name",
                      "label": "Agency Partner Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": false,
                      "placeholder": "e.g. Ogilvy, MediaMonks"
                    },
                    {
                      "id": "tf_f6",
                      "wfId": "66e1928000129384710293847102938e",
                      "wfFieldName": "agencyPoNumber",
                      "wfLabel": "Agency Purchase Order (PO #)",
                      "label": "Agency PO #",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": false,
                      "placeholder": "e.g. PO-89210-2026"
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v2.3",
            "versionLabel": "v2.3 (Sprint 25.1 Published)",
            "sprint": "Sprint 25.1",
            "timestamp": "2026-09-25T18:00:00.000Z",
            "author": "Jane Smith",
            "status": "Published",
            "notes": "Published Sprint 25.1 release: Added conditional display rule to Agency Information section.",
            "stats": {
              "sectionCount": 3,
              "fieldCount": 9,
              "rulesCount": 1
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 2,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency",
                        "Fast-Track"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s2",
                  "title": "Agency Information",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f5",
                      "wfId": "66d1928000129384710293847102938d",
                      "wfFieldName": "agencyPartnerName",
                      "wfLabel": "Agency Partner Name",
                      "label": "Agency Partner Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Ogilvy, MediaMonks"
                    },
                    {
                      "id": "tf_f6",
                      "wfId": "66e1928000129384710293847102938e",
                      "wfFieldName": "agencyPoNumber",
                      "wfLabel": "Agency Purchase Order (PO #)",
                      "label": "Agency PO #",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. PO-89210-2026"
                    }
                  ],
                  "condition": [
                    {
                      "field": "submitterType",
                      "comparison": "==",
                      "value": "Agency"
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          }
        ]
      },
      {
        "sprintId": "sprint-25.2",
        "sprintLabel": "Sprint 25.2",
        "startDate": "2026-10-01",
        "endDate": "2026-10-30",
        "status": "Active",
        "publishedVersionId": "v3.2",
        "versions": [
          {
            "versionId": "v3.0",
            "versionLabel": "v3.0 (Sprint 25.2)",
            "sprint": "Sprint 25.2",
            "timestamp": "2026-10-04T10:00:00.000Z",
            "author": "MOPs Core Team",
            "status": "Archived",
            "notes": "Added Emergency / Fast-Track Details section with Escalation Sponsor and Target Live Date.",
            "stats": {
              "sectionCount": 4,
              "fieldCount": 11,
              "rulesCount": 1
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Fast-Track Emergency Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Fast-Track"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
                  },
                  {
                    "priority": 2,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 3,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  },
                  {
                    "label": "Fast-Track Escalation Review Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Fast-Track"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency",
                        "Fast-Track"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s2",
                  "title": "Agency Information",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f5",
                      "wfId": "66d1928000129384710293847102938d",
                      "wfFieldName": "agencyPartnerName",
                      "wfLabel": "Agency Partner Name",
                      "label": "Agency Partner Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Ogilvy, MediaMonks"
                    },
                    {
                      "id": "tf_f6",
                      "wfId": "66e1928000129384710293847102938e",
                      "wfFieldName": "agencyPoNumber",
                      "wfLabel": "Agency Purchase Order (PO #)",
                      "label": "Agency PO #",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. PO-89210-2026"
                    }
                  ],
                  "condition": [
                    {
                      "field": "submitterType",
                      "comparison": "==",
                      "value": "Agency"
                    }
                  ]
                },
                {
                  "id": "tf_s3",
                  "title": "Emergency / Fast-Track Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f7",
                      "wfId": "67c1928000129384710293847102938f",
                      "wfFieldName": "escalationSponsor",
                      "wfLabel": "Executive Escalation Sponsor",
                      "label": "Escalation Sponsor (VP+)",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Jane Doe (VP Global Mktg)"
                    },
                    {
                      "id": "tf_f8",
                      "wfId": "68d1928000129384710293847102938a",
                      "wfFieldName": "targetLiveDate",
                      "wfLabel": "Target Expedited Live Date",
                      "label": "Target Live Date",
                      "type": "date",
                      "col": "col-lg-6",
                      "required": true
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v3.1",
            "versionLabel": "v3.1 (Sprint 25.2)",
            "sprint": "Sprint 25.2",
            "timestamp": "2026-10-12T13:45:00.000Z",
            "author": "Alex Rivera",
            "status": "Archived",
            "notes": "Added Justification for Fast-Track SLA textarea with compliance BA notes.",
            "stats": {
              "sectionCount": 4,
              "fieldCount": 12,
              "rulesCount": 1
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Fast-Track Emergency Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Fast-Track"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
                  },
                  {
                    "priority": 2,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 3,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  },
                  {
                    "label": "Fast-Track Escalation Review Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Fast-Track"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Q3 Baseline Security Initiative"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency",
                        "Fast-Track"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s2",
                  "title": "Agency Information",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f5",
                      "wfId": "66d1928000129384710293847102938d",
                      "wfFieldName": "agencyPartnerName",
                      "wfLabel": "Agency Partner Name",
                      "label": "Agency Partner Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Ogilvy, MediaMonks"
                    },
                    {
                      "id": "tf_f6",
                      "wfId": "66e1928000129384710293847102938e",
                      "wfFieldName": "agencyPoNumber",
                      "wfLabel": "Agency Purchase Order (PO #)",
                      "label": "Agency PO #",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. PO-89210-2026"
                    }
                  ],
                  "condition": [
                    {
                      "field": "submitterType",
                      "comparison": "==",
                      "value": "Agency"
                    }
                  ]
                },
                {
                  "id": "tf_s3",
                  "title": "Emergency / Fast-Track Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f7",
                      "wfId": "67c1928000129384710293847102938f",
                      "wfFieldName": "escalationSponsor",
                      "wfLabel": "Executive Escalation Sponsor",
                      "label": "Escalation Sponsor (VP+)",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Jane Doe (VP Global Mktg)"
                    },
                    {
                      "id": "tf_f8",
                      "wfId": "68d1928000129384710293847102938a",
                      "wfFieldName": "targetLiveDate",
                      "wfLabel": "Target Expedited Live Date",
                      "label": "Target Live Date",
                      "type": "date",
                      "col": "col-lg-6",
                      "required": true
                    },
                    {
                      "id": "tf_f9",
                      "wfId": "69e1928000129384710293847102938b",
                      "wfFieldName": "expeditedJustification",
                      "wfLabel": "Business Escalation Justification",
                      "label": "Justification for Fast-Track SLA",
                      "type": "textarea",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "Describe critical revenue, executive, or event drivers requiring turnaround < standard 10-day SLA...",
                      "baNotes": "Required for compliance audit. Reviewed during intake triaging."
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          },
          {
            "versionId": "v3.2",
            "versionLabel": "v3.2 (Sprint 25.2 Active)",
            "sprint": "Sprint 25.2",
            "timestamp": "2026-10-22T16:30:00.000Z",
            "author": "Sarah Chen",
            "status": "Active",
            "notes": "Current active release: Added conditional rule to Emergency section and updated Project Name placeholder.",
            "stats": {
              "sectionCount": 4,
              "fieldCount": 12,
              "rulesCount": 2
            },
            "schema": {
              "title": "TestForm - Multi-Sprint and Flow Validation Form",
              "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
              "workfrontRouting": {
                "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
                "defaultTemplateLabel": "Standard Web Page Template",
                "defaultCategoryIds": [
                  "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
                ],
                "templateRules": [
                  {
                    "priority": 1,
                    "label": "Fast-Track Emergency Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Fast-Track"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
                  },
                  {
                    "priority": 2,
                    "label": "Agency Web Page Template",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      },
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Web Page / Microsite"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_AGENCY_WEB"
                  },
                  {
                    "priority": 3,
                    "label": "Email Blast Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Email Blast"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
                  },
                  {
                    "priority": 4,
                    "label": "Executive Video Template",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Executive Video"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_VIDEO_EXEC"
                  },
                  {
                    "priority": 5,
                    "label": "Digital Media Banner - APJC Regional",
                    "conditions": [
                      {
                        "field": "deliverableFormat",
                        "comparison": "==",
                        "value": "Digital Media Banner"
                      },
                      {
                        "field": "targetRegion",
                        "comparison": "==",
                        "value": "APJC"
                      }
                    ],
                    "conditionOperator": "AND",
                    "templateId": "TEMPLATE_DART_DIGITAL_MEDIA_APJC"
                  }
                ],
                "categoryRules": [
                  {
                    "label": "Agency Financial Details Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Agency"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
                  },
                  {
                    "label": "Fast-Track Escalation Review Form",
                    "conditions": [
                      {
                        "field": "submitterType",
                        "comparison": "==",
                        "value": "Fast-Track"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
                  },
                  {
                    "label": "APJC Regional Details Form",
                    "conditions": [
                      {
                        "field": "targetRegion",
                        "comparison": "==",
                        "value": "APJC"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_APJC_REGIONAL_DETAILS"
                  },
                  {
                    "label": "EMEA Regional Details Form",
                    "conditions": [
                      {
                        "field": "targetRegion",
                        "comparison": "==",
                        "value": "EMEA"
                      }
                    ],
                    "conditionOperator": "AND",
                    "addCategoryId": "CATEGORY_DART_EMEA_REGIONAL_DETAILS"
                  }
                ]
              },
              "sections": [
                {
                  "id": "tf_s1",
                  "title": "Project & Stakeholder Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f1",
                      "wfId": "61df5582003a92b049cafa45f74e87ac",
                      "wfFieldName": "projectName",
                      "wfLabel": "Project Name",
                      "label": "Project Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. FY27 Cisco Live Core Launch"
                    },
                    {
                      "id": "tf_f2",
                      "wfId": "635040d700147670ca356476308a58f6",
                      "wfFieldName": "campaignAlign",
                      "wfLabel": "Campaign Alignment",
                      "label": "Campaign Alignment",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Accelerate",
                        "Foundation",
                        "Growth",
                        "Security First"
                      ]
                    },
                    {
                      "id": "tf_f3",
                      "wfId": "65c192830041829928374102938471ac",
                      "wfFieldName": "submitterType",
                      "wfLabel": "Submitter Type",
                      "label": "Submitter Type",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Internal",
                        "Agency",
                        "Fast-Track"
                      ]
                    },
                    {
                      "id": "tf_f4",
                      "wfId": "64b192800041289c51239840293812ab",
                      "wfFieldName": "stakeholderEmail",
                      "wfLabel": "Stakeholder Cisco Email",
                      "label": "Stakeholder Email",
                      "type": "email",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "submitter@cisco.com",
                      "tooltip": "Must be a valid @cisco.com corporate email address."
                    }
                  ]
                },
                {
                  "id": "tf_s2",
                  "title": "Agency Information",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f5",
                      "wfId": "66d1928000129384710293847102938d",
                      "wfFieldName": "agencyPartnerName",
                      "wfLabel": "Agency Partner Name",
                      "label": "Agency Partner Name",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Ogilvy, MediaMonks"
                    },
                    {
                      "id": "tf_f6",
                      "wfId": "66e1928000129384710293847102938e",
                      "wfFieldName": "agencyPoNumber",
                      "wfLabel": "Agency Purchase Order (PO #)",
                      "label": "Agency PO #",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. PO-89210-2026"
                    }
                  ],
                  "condition": [
                    {
                      "field": "submitterType",
                      "comparison": "==",
                      "value": "Agency"
                    }
                  ]
                },
                {
                  "id": "tf_s3",
                  "title": "Emergency / Fast-Track Details",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f7",
                      "wfId": "67c1928000129384710293847102938f",
                      "wfFieldName": "escalationSponsor",
                      "wfLabel": "Executive Escalation Sponsor",
                      "label": "Escalation Sponsor (VP+)",
                      "type": "text",
                      "col": "col-lg-6",
                      "required": true,
                      "placeholder": "e.g. Jane Doe (VP Global Mktg)"
                    },
                    {
                      "id": "tf_f8",
                      "wfId": "68d1928000129384710293847102938a",
                      "wfFieldName": "targetLiveDate",
                      "wfLabel": "Target Expedited Live Date",
                      "label": "Target Live Date",
                      "type": "date",
                      "col": "col-lg-6",
                      "required": true
                    },
                    {
                      "id": "tf_f9",
                      "wfId": "69e1928000129384710293847102938b",
                      "wfFieldName": "expeditedJustification",
                      "wfLabel": "Business Escalation Justification",
                      "label": "Justification for Fast-Track SLA",
                      "type": "textarea",
                      "col": "col-lg-12",
                      "required": true,
                      "placeholder": "Describe critical revenue, executive, or event drivers requiring turnaround < standard 10-day SLA...",
                      "baNotes": "Required for compliance audit. Reviewed during intake triaging."
                    }
                  ],
                  "condition": [
                    {
                      "field": "submitterType",
                      "comparison": "==",
                      "value": "Fast-Track"
                    }
                  ]
                },
                {
                  "id": "tf_s4",
                  "title": "Deliverables & Asset Specs",
                  "collapsed": false,
                  "fields": [
                    {
                      "id": "tf_f10",
                      "wfId": "67a892b100234a9918204910293847aa",
                      "wfFieldName": "deliverableFormat",
                      "wfLabel": "Deliverable Format",
                      "label": "Deliverable Format",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Web Page / Microsite",
                        "Email Blast",
                        "Digital Media Banner",
                        "Executive Video"
                      ]
                    },
                    {
                      "id": "tf_f11",
                      "wfId": "68b992100034a11229384710293841bb",
                      "wfFieldName": "targetRegion",
                      "wfLabel": "Target Audience Region",
                      "label": "Target Audience Region",
                      "type": "select",
                      "col": "col-lg-6",
                      "required": true,
                      "options": [
                        "Global",
                        "AMER",
                        "EMEA",
                        "APJC"
                      ]
                    },
                    {
                      "id": "tf_f12",
                      "wfId": "69c12830004192837410293847102938",
                      "wfFieldName": "budgetCode",
                      "wfLabel": "Estimated Budget Code",
                      "label": "Estimated Budget Code",
                      "type": "text",
                      "col": "col-lg-12",
                      "required": false,
                      "placeholder": "e.g. MKTG-2026-US-SEC",
                      "baNotes": "Budget code must match standard Cisco cost center naming convention."
                    }
                  ]
                }
              ]
            }
          }
        ]
      }
    ],
    "versions": [
      {
        "versionId": "v1.0",
        "versionLabel": "v1.0 (Sprint 24.8)",
        "sprint": "Sprint 24.8",
        "timestamp": "2026-08-05T10:00:00.000Z",
        "author": "MOPs Core Team",
        "status": "Archived",
        "notes": "Initial baseline release for TestForm intake specification with 5 core fields.",
        "stats": {
          "sectionCount": 2,
          "fieldCount": 5,
          "rulesCount": 0
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [],
            "categoryRules": []
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Foundation",
                    "Growth"
                  ]
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": false,
                  "options": [
                    "Global",
                    "AMER"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": false,
                  "placeholder": "e.g. BASE-2026-US"
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v1.1",
        "versionLabel": "v1.1 (Sprint 24.8)",
        "sprint": "Sprint 24.8",
        "timestamp": "2026-08-12T14:30:00.000Z",
        "author": "Alex Rivera",
        "status": "Archived",
        "notes": "Added Stakeholder Email field with corporate domain tooltip and expanded campaign alignments.",
        "stats": {
          "sectionCount": 2,
          "fieldCount": 6,
          "rulesCount": 0
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [],
            "categoryRules": []
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": false,
                  "options": [
                    "Global",
                    "AMER"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": false,
                  "placeholder": "e.g. BASE-2026-US"
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v1.2",
        "versionLabel": "v1.2 (Sprint 24.8 Published)",
        "sprint": "Sprint 24.8",
        "timestamp": "2026-08-20T17:00:00.000Z",
        "author": "Sarah Chen",
        "status": "Published",
        "notes": "Published Sprint 24.8 baseline: Enforced required Target Region and added Budget Code BA spec notes.",
        "stats": {
          "sectionCount": 2,
          "fieldCount": 6,
          "rulesCount": 0
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [],
            "categoryRules": []
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v2.0",
        "versionLabel": "v2.0 (Sprint 25.1)",
        "sprint": "Sprint 25.1",
        "timestamp": "2026-09-02T09:00:00.000Z",
        "author": "Jane Smith",
        "status": "Archived",
        "notes": "Major release kickoff: Added Submitter Type dropdown (Internal, Agency) and new Deliverable Formats.",
        "stats": {
          "sectionCount": 2,
          "fieldCount": 7,
          "rulesCount": 0
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 2,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency"
                  ]
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v2.1",
        "versionLabel": "v2.1 (Sprint 25.1)",
        "sprint": "Sprint 25.1",
        "timestamp": "2026-09-09T11:30:00.000Z",
        "author": "John Doe",
        "status": "Archived",
        "notes": "Added Fast-Track option to Submitter Type; reordered field layout in Section 1.",
        "stats": {
          "sectionCount": 2,
          "fieldCount": 7,
          "rulesCount": 0
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 2,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency",
                    "Fast-Track"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v2.2",
        "versionLabel": "v2.2 (Sprint 25.1)",
        "sprint": "Sprint 25.1",
        "timestamp": "2026-09-16T15:00:00.000Z",
        "author": "Jane Smith",
        "status": "Archived",
        "notes": "Added Section 2: Agency Information with Agency Partner Name and Agency PO Number.",
        "stats": {
          "sectionCount": 3,
          "fieldCount": 9,
          "rulesCount": 0
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 2,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency",
                    "Fast-Track"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s2",
              "title": "Agency Information",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f5",
                  "wfId": "66d1928000129384710293847102938d",
                  "wfFieldName": "agencyPartnerName",
                  "wfLabel": "Agency Partner Name",
                  "label": "Agency Partner Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": false,
                  "placeholder": "e.g. Ogilvy, MediaMonks"
                },
                {
                  "id": "tf_f6",
                  "wfId": "66e1928000129384710293847102938e",
                  "wfFieldName": "agencyPoNumber",
                  "wfLabel": "Agency Purchase Order (PO #)",
                  "label": "Agency PO #",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": false,
                  "placeholder": "e.g. PO-89210-2026"
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v2.3",
        "versionLabel": "v2.3 (Sprint 25.1 Published)",
        "sprint": "Sprint 25.1",
        "timestamp": "2026-09-25T18:00:00.000Z",
        "author": "Jane Smith",
        "status": "Published",
        "notes": "Published Sprint 25.1 release: Added conditional display rule to Agency Information section.",
        "stats": {
          "sectionCount": 3,
          "fieldCount": 9,
          "rulesCount": 1
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 2,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency",
                    "Fast-Track"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s2",
              "title": "Agency Information",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f5",
                  "wfId": "66d1928000129384710293847102938d",
                  "wfFieldName": "agencyPartnerName",
                  "wfLabel": "Agency Partner Name",
                  "label": "Agency Partner Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Ogilvy, MediaMonks"
                },
                {
                  "id": "tf_f6",
                  "wfId": "66e1928000129384710293847102938e",
                  "wfFieldName": "agencyPoNumber",
                  "wfLabel": "Agency Purchase Order (PO #)",
                  "label": "Agency PO #",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. PO-89210-2026"
                }
              ],
              "condition": [
                {
                  "field": "submitterType",
                  "comparison": "==",
                  "value": "Agency"
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v3.0",
        "versionLabel": "v3.0 (Sprint 25.2)",
        "sprint": "Sprint 25.2",
        "timestamp": "2026-10-04T10:00:00.000Z",
        "author": "MOPs Core Team",
        "status": "Archived",
        "notes": "Added Emergency / Fast-Track Details section with Escalation Sponsor and Target Live Date.",
        "stats": {
          "sectionCount": 4,
          "fieldCount": 11,
          "rulesCount": 1
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Fast-Track Emergency Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Fast-Track"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
              },
              {
                "priority": 2,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 3,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              },
              {
                "label": "Fast-Track Escalation Review Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Fast-Track"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency",
                    "Fast-Track"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s2",
              "title": "Agency Information",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f5",
                  "wfId": "66d1928000129384710293847102938d",
                  "wfFieldName": "agencyPartnerName",
                  "wfLabel": "Agency Partner Name",
                  "label": "Agency Partner Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Ogilvy, MediaMonks"
                },
                {
                  "id": "tf_f6",
                  "wfId": "66e1928000129384710293847102938e",
                  "wfFieldName": "agencyPoNumber",
                  "wfLabel": "Agency Purchase Order (PO #)",
                  "label": "Agency PO #",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. PO-89210-2026"
                }
              ],
              "condition": [
                {
                  "field": "submitterType",
                  "comparison": "==",
                  "value": "Agency"
                }
              ]
            },
            {
              "id": "tf_s3",
              "title": "Emergency / Fast-Track Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f7",
                  "wfId": "67c1928000129384710293847102938f",
                  "wfFieldName": "escalationSponsor",
                  "wfLabel": "Executive Escalation Sponsor",
                  "label": "Escalation Sponsor (VP+)",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Jane Doe (VP Global Mktg)"
                },
                {
                  "id": "tf_f8",
                  "wfId": "68d1928000129384710293847102938a",
                  "wfFieldName": "targetLiveDate",
                  "wfLabel": "Target Expedited Live Date",
                  "label": "Target Live Date",
                  "type": "date",
                  "col": "col-lg-6",
                  "required": true
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v3.1",
        "versionLabel": "v3.1 (Sprint 25.2)",
        "sprint": "Sprint 25.2",
        "timestamp": "2026-10-12T13:45:00.000Z",
        "author": "Alex Rivera",
        "status": "Archived",
        "notes": "Added Justification for Fast-Track SLA textarea with compliance BA notes.",
        "stats": {
          "sectionCount": 4,
          "fieldCount": 12,
          "rulesCount": 1
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Fast-Track Emergency Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Fast-Track"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
              },
              {
                "priority": 2,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 3,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              },
              {
                "label": "Fast-Track Escalation Review Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Fast-Track"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Q3 Baseline Security Initiative"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency",
                    "Fast-Track"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s2",
              "title": "Agency Information",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f5",
                  "wfId": "66d1928000129384710293847102938d",
                  "wfFieldName": "agencyPartnerName",
                  "wfLabel": "Agency Partner Name",
                  "label": "Agency Partner Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Ogilvy, MediaMonks"
                },
                {
                  "id": "tf_f6",
                  "wfId": "66e1928000129384710293847102938e",
                  "wfFieldName": "agencyPoNumber",
                  "wfLabel": "Agency Purchase Order (PO #)",
                  "label": "Agency PO #",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. PO-89210-2026"
                }
              ],
              "condition": [
                {
                  "field": "submitterType",
                  "comparison": "==",
                  "value": "Agency"
                }
              ]
            },
            {
              "id": "tf_s3",
              "title": "Emergency / Fast-Track Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f7",
                  "wfId": "67c1928000129384710293847102938f",
                  "wfFieldName": "escalationSponsor",
                  "wfLabel": "Executive Escalation Sponsor",
                  "label": "Escalation Sponsor (VP+)",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Jane Doe (VP Global Mktg)"
                },
                {
                  "id": "tf_f8",
                  "wfId": "68d1928000129384710293847102938a",
                  "wfFieldName": "targetLiveDate",
                  "wfLabel": "Target Expedited Live Date",
                  "label": "Target Live Date",
                  "type": "date",
                  "col": "col-lg-6",
                  "required": true
                },
                {
                  "id": "tf_f9",
                  "wfId": "69e1928000129384710293847102938b",
                  "wfFieldName": "expeditedJustification",
                  "wfLabel": "Business Escalation Justification",
                  "label": "Justification for Fast-Track SLA",
                  "type": "textarea",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "Describe critical revenue, executive, or event drivers requiring turnaround < standard 10-day SLA...",
                  "baNotes": "Required for compliance audit. Reviewed during intake triaging."
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      },
      {
        "versionId": "v3.2",
        "versionLabel": "v3.2 (Sprint 25.2 Active)",
        "sprint": "Sprint 25.2",
        "timestamp": "2026-10-22T16:30:00.000Z",
        "author": "Sarah Chen",
        "status": "Active",
        "notes": "Current active release: Added conditional rule to Emergency section and updated Project Name placeholder.",
        "stats": {
          "sectionCount": 4,
          "fieldCount": 12,
          "rulesCount": 2
        },
        "schema": {
          "title": "TestForm - Multi-Sprint and Flow Validation Form",
          "description": "Reference intake form demonstrating multi-sprint versioning and dynamic business process flows.",
          "workfrontRouting": {
            "defaultTemplateId": "TEMPLATE_DART_WEB_PAGE",
            "defaultTemplateLabel": "Standard Web Page Template",
            "defaultCategoryIds": [
              "CATEGORY_DART_GLOBAL_PROJECT_DETAILS"
            ],
            "templateRules": [
              {
                "priority": 1,
                "label": "Fast-Track Emergency Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Fast-Track"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_FASTTRACK_EXPEDITED"
              },
              {
                "priority": 2,
                "label": "Agency Web Page Template",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  },
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Web Page / Microsite"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_AGENCY_WEB"
              },
              {
                "priority": 3,
                "label": "Email Blast Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Email Blast"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_EMAIL_SINGLE"
              },
              {
                "priority": 4,
                "label": "Executive Video Template",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Executive Video"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_VIDEO_EXEC"
              },
              {
                "priority": 5,
                "label": "Digital Media Banner - APJC Regional",
                "conditions": [
                  {
                    "field": "deliverableFormat",
                    "comparison": "==",
                    "value": "Digital Media Banner"
                  },
                  {
                    "field": "targetRegion",
                    "comparison": "==",
                    "value": "APJC"
                  }
                ],
                "conditionOperator": "AND",
                "templateId": "TEMPLATE_DART_DIGITAL_MEDIA_APJC"
              }
            ],
            "categoryRules": [
              {
                "label": "Agency Financial Details Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Agency"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_AGENCY_BILLING"
              },
              {
                "label": "Fast-Track Escalation Review Form",
                "conditions": [
                  {
                    "field": "submitterType",
                    "comparison": "==",
                    "value": "Fast-Track"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_FASTTRACK_ESCALATION"
              },
              {
                "label": "APJC Regional Details Form",
                "conditions": [
                  {
                    "field": "targetRegion",
                    "comparison": "==",
                    "value": "APJC"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_APJC_REGIONAL_DETAILS"
              },
              {
                "label": "EMEA Regional Details Form",
                "conditions": [
                  {
                    "field": "targetRegion",
                    "comparison": "==",
                    "value": "EMEA"
                  }
                ],
                "conditionOperator": "AND",
                "addCategoryId": "CATEGORY_DART_EMEA_REGIONAL_DETAILS"
              }
            ]
          },
          "sections": [
            {
              "id": "tf_s1",
              "title": "Project & Stakeholder Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f1",
                  "wfId": "61df5582003a92b049cafa45f74e87ac",
                  "wfFieldName": "projectName",
                  "wfLabel": "Project Name",
                  "label": "Project Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. FY27 Cisco Live Core Launch"
                },
                {
                  "id": "tf_f2",
                  "wfId": "635040d700147670ca356476308a58f6",
                  "wfFieldName": "campaignAlign",
                  "wfLabel": "Campaign Alignment",
                  "label": "Campaign Alignment",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Accelerate",
                    "Foundation",
                    "Growth",
                    "Security First"
                  ]
                },
                {
                  "id": "tf_f3",
                  "wfId": "65c192830041829928374102938471ac",
                  "wfFieldName": "submitterType",
                  "wfLabel": "Submitter Type",
                  "label": "Submitter Type",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Internal",
                    "Agency",
                    "Fast-Track"
                  ]
                },
                {
                  "id": "tf_f4",
                  "wfId": "64b192800041289c51239840293812ab",
                  "wfFieldName": "stakeholderEmail",
                  "wfLabel": "Stakeholder Cisco Email",
                  "label": "Stakeholder Email",
                  "type": "email",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "submitter@cisco.com",
                  "tooltip": "Must be a valid @cisco.com corporate email address."
                }
              ]
            },
            {
              "id": "tf_s2",
              "title": "Agency Information",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f5",
                  "wfId": "66d1928000129384710293847102938d",
                  "wfFieldName": "agencyPartnerName",
                  "wfLabel": "Agency Partner Name",
                  "label": "Agency Partner Name",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Ogilvy, MediaMonks"
                },
                {
                  "id": "tf_f6",
                  "wfId": "66e1928000129384710293847102938e",
                  "wfFieldName": "agencyPoNumber",
                  "wfLabel": "Agency Purchase Order (PO #)",
                  "label": "Agency PO #",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. PO-89210-2026"
                }
              ],
              "condition": [
                {
                  "field": "submitterType",
                  "comparison": "==",
                  "value": "Agency"
                }
              ]
            },
            {
              "id": "tf_s3",
              "title": "Emergency / Fast-Track Details",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f7",
                  "wfId": "67c1928000129384710293847102938f",
                  "wfFieldName": "escalationSponsor",
                  "wfLabel": "Executive Escalation Sponsor",
                  "label": "Escalation Sponsor (VP+)",
                  "type": "text",
                  "col": "col-lg-6",
                  "required": true,
                  "placeholder": "e.g. Jane Doe (VP Global Mktg)"
                },
                {
                  "id": "tf_f8",
                  "wfId": "68d1928000129384710293847102938a",
                  "wfFieldName": "targetLiveDate",
                  "wfLabel": "Target Expedited Live Date",
                  "label": "Target Live Date",
                  "type": "date",
                  "col": "col-lg-6",
                  "required": true
                },
                {
                  "id": "tf_f9",
                  "wfId": "69e1928000129384710293847102938b",
                  "wfFieldName": "expeditedJustification",
                  "wfLabel": "Business Escalation Justification",
                  "label": "Justification for Fast-Track SLA",
                  "type": "textarea",
                  "col": "col-lg-12",
                  "required": true,
                  "placeholder": "Describe critical revenue, executive, or event drivers requiring turnaround < standard 10-day SLA...",
                  "baNotes": "Required for compliance audit. Reviewed during intake triaging."
                }
              ],
              "condition": [
                {
                  "field": "submitterType",
                  "comparison": "==",
                  "value": "Fast-Track"
                }
              ]
            },
            {
              "id": "tf_s4",
              "title": "Deliverables & Asset Specs",
              "collapsed": false,
              "fields": [
                {
                  "id": "tf_f10",
                  "wfId": "67a892b100234a9918204910293847aa",
                  "wfFieldName": "deliverableFormat",
                  "wfLabel": "Deliverable Format",
                  "label": "Deliverable Format",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Web Page / Microsite",
                    "Email Blast",
                    "Digital Media Banner",
                    "Executive Video"
                  ]
                },
                {
                  "id": "tf_f11",
                  "wfId": "68b992100034a11229384710293841bb",
                  "wfFieldName": "targetRegion",
                  "wfLabel": "Target Audience Region",
                  "label": "Target Audience Region",
                  "type": "select",
                  "col": "col-lg-6",
                  "required": true,
                  "options": [
                    "Global",
                    "AMER",
                    "EMEA",
                    "APJC"
                  ]
                },
                {
                  "id": "tf_f12",
                  "wfId": "69c12830004192837410293847102938",
                  "wfFieldName": "budgetCode",
                  "wfLabel": "Estimated Budget Code",
                  "label": "Estimated Budget Code",
                  "type": "text",
                  "col": "col-lg-12",
                  "required": false,
                  "placeholder": "e.g. MKTG-2026-US-SEC",
                  "baNotes": "Budget code must match standard Cisco cost center naming convention."
                }
              ]
            }
          ]
        }
      }
    ]
  }
];
