/**
 * MOPS Form Mockup & Rule Studio - Drag & Drop Handler
 * Native HTML5 Drag and Drop implementation for:
 * 1. Palette items -> Section dropzone
 * 2. Field reordering within and across sections
 * 3. Section reordering
 * 4. Reusable sections & fields dragging
 */

window.DragDropHandler = {
  activeDragData: null,

  // --- Auto-scroll state ---
  _autoScrollRAF: null,       // requestAnimationFrame handle
  _autoScrollSpeed: 0,        // pixels/frame to scroll (negative = up, positive = down)
  _SCROLL_ZONE: 100,          // px from viewport edge that activates scrolling
  _SCROLL_MAX_SPEED: 18,      // maximum px per animation frame

  /**
   * Start the auto-scroll RAF loop.
   * Called once; runs every frame until _autoScrollSpeed === 0.
   */
  _startAutoScroll() {
    if (this._autoScrollRAF) return; // already running
    const loop = () => {
      if (this._autoScrollSpeed !== 0) {
        // Primary: .main-canvas-area is the overflow-y:auto scroll container for the form canvas
        const scrollEl = document.querySelector('.main-canvas-area') ||
          document.querySelector('.canvas-container') ||
          document.documentElement;
        scrollEl.scrollTop += this._autoScrollSpeed;
        this._autoScrollRAF = requestAnimationFrame(loop);
      } else {
        this._autoScrollRAF = null;
      }
    };
    this._autoScrollRAF = requestAnimationFrame(loop);
  },

  /**
   * Stop the auto-scroll loop immediately.
   */
  _stopAutoScroll() {
    this._autoScrollSpeed = 0;
    if (this._autoScrollRAF) {
      cancelAnimationFrame(this._autoScrollRAF);
      this._autoScrollRAF = null;
    }
  },

  /**
   * Update scroll speed based on cursor Y position in viewport.
   * Called from the global dragover listener on every mouse move during drag.
   */
  _updateAutoScroll(clientY) {
    const zone = this._SCROLL_ZONE;
    const maxSpeed = this._SCROLL_MAX_SPEED;
    const viewH = window.innerHeight;

    if (clientY < zone) {
      // Near top - scroll UP; faster the closer to the edge
      const ratio = 1 - (clientY / zone);
      this._autoScrollSpeed = -Math.round(maxSpeed * ratio);
      this._startAutoScroll();
    } else if (clientY > viewH - zone) {
      // Near bottom - scroll DOWN; faster the closer to the edge
      const ratio = 1 - ((viewH - clientY) / zone);
      this._autoScrollSpeed = Math.round(maxSpeed * ratio);
      this._startAutoScroll();
    } else {
      // In the safe middle zone - stop scrolling
      this._stopAutoScroll();
    }
  },

  init() {
    this.bindPaletteDraggables();

    // --- Global drag-over listener for auto-scroll ---
    // Fires on every mouse-move while a drag is active across the whole page.
    document.addEventListener('dragover', (e) => {
      if (this.activeDragData) {
        this._updateAutoScroll(e.clientY);
      }
    });

    // Stop auto-scroll when the drag ends (drop, cancel, or escape)
    document.addEventListener('dragend', () => {
      this._stopAutoScroll();
      this.clearDropIndicators();
    });
    document.addEventListener('drop', () => {
      this._stopAutoScroll();
      this.clearDropIndicators();
    });

    // Canvas-level fallback drop target for reusable sections dropped on empty canvas space
    const canvasArea = document.querySelector('.main-canvas-area') || document.getElementById('canvasContainer');
    if (canvasArea) {
      canvasArea.addEventListener('dragover', (e) => {
        if (this.activeDragData?.source === 'section-library' && window.App?._userHasOpenedForm) {
          e.preventDefault();
          e.dataTransfer.dropEffect = 'copy';
        }
      });
      canvasArea.addEventListener('drop', (e) => {
        if (this.activeDragData?.source === 'section-library' && this.activeDragData.sectionData && window.App?._userHasOpenedForm) {
          e.preventDefault();
          const secData = this.activeDragData.sectionData;
          this.activeDragData = null;
          this.clearDropIndicators();
          window.App.insertReusableSection(secData);
        }
      });
    }
  },

  /**
   * Set up draggable attributes on palette items and reusable library cards
   */
  bindPaletteDraggables() {
    // 1. Standard Field Palette
    document.querySelectorAll('.palette-item').forEach(item => {
      item.setAttribute('draggable', 'true');
      item.addEventListener('dragstart', (e) => {
        const fieldType = item.getAttribute('data-field-type');
        const paletteDef = (window.DEFAULT_PALETTE_ITEMS || []).find(p => p.type === fieldType);
        const fallbackEmpty = fieldType === 'empty_field'
          ? { label: 'Empty Space', formData: 'emptySpace', col: 'col-lg-6', required: false, type: 'empty_field', condition: null }
          : {};

        this.activeDragData = {
          source: 'palette',
          type: fieldType,
          fieldData: paletteDef ? JSON.parse(JSON.stringify(paletteDef.defaultData)) : fallbackEmpty
        };

        e.dataTransfer.setData('text/plain', JSON.stringify(this.activeDragData));
        e.dataTransfer.effectAllowed = 'copy';
      });

      // Click to add field directly into active form
      item.onclick = (e) => {
        const fieldType = item.getAttribute('data-field-type');
        if (fieldType && window.App?.insertPaletteField) {
          window.App.insertPaletteField(fieldType);
        }
      };

      item.addEventListener('dragend', () => {
        this.activeDragData = null;
        this.clearDropIndicators();
      });
    });

    // 2. Reusable Sections Palette
    document.querySelectorAll('.draggable-section-lib').forEach(card => {
      card.setAttribute('draggable', 'true');
      card.addEventListener('dragstart', (e) => {
        const secId = card.getAttribute('data-section-id');
        const secIdxAttr = card.getAttribute('data-sec-idx');
        const secIdx = secIdxAttr !== null ? parseInt(secIdxAttr, 10) : -1;
        const secDef = (window.App.reusableSections || []).find(s => s.id === secId) ||
          (secIdx >= 0 ? (window.App.reusableSections || [])[secIdx] : null) ||
          (window.BUILTIN_SECTIONS || []).find(s => s.id === secId);

        this.activeDragData = {
          source: 'section-library',
          sectionData: secDef ? JSON.parse(JSON.stringify(secDef.data)) : null
        };

        document.body.classList.add('is-dragging-section');
        e.dataTransfer.setData('text/plain', JSON.stringify(this.activeDragData));
        e.dataTransfer.effectAllowed = 'copy';
      });

      card.addEventListener('dragend', () => {
        this.activeDragData = null;
        this.clearDropIndicators();
      });
    });

    // 3. Reusable Fields Palette
    document.querySelectorAll('.draggable-field-lib').forEach(card => {
      card.setAttribute('draggable', 'true');
      card.addEventListener('dragstart', (e) => {
        const fieldId = card.getAttribute('data-field-lib-id');
        const fieldDef = (window.App.reusableFields || []).find(f => (f.data?.formData || f.label) === fieldId) ||
          (window.BUILTIN_FIELDS || []).find(f => (f.data?.formData || f.label) === fieldId);

        if (fieldDef && fieldDef.status === 'inactive') {
          e.preventDefault();
          window.App?._showToast?.(`"${fieldDef.label}" is Inactive. Reactivate it in WF Field Library to add to forms.`, 'warning');
          return;
        }
        const clonedData = fieldDef ? JSON.parse(JSON.stringify(fieldDef.data)) : null;
        if (clonedData && fieldDef) {
          clonedData.wfLibraryFieldId = fieldDef.id || clonedData.id || clonedData.formData;
          clonedData.wfObject = fieldDef.wfObject || clonedData.wfObject || 'Project';
          clonedData.wfFieldName = clonedData.wfFieldName || clonedData.formData;
          clonedData.wfLabel = clonedData.wfLabel || clonedData.label;
          if (Array.isArray(fieldDef.wfFormIds) && !clonedData.wfFormIds) clonedData.wfFormIds = [...fieldDef.wfFormIds];
          if (Array.isArray(fieldDef.wfFormLabels) && !clonedData.wfFormLabels) clonedData.wfFormLabels = [...fieldDef.wfFormLabels];
        }

        this.activeDragData = {
          source: 'field-library',
          libIdx: parseInt(card.getAttribute('data-lib-idx'), 10),
          fieldData: clonedData
        };

        e.dataTransfer.setData('text/plain', JSON.stringify(this.activeDragData));
        e.dataTransfer.effectAllowed = 'copyMove';
      });

      // Allow vertical drag-and-drop reordering within WF Field Library
      card.addEventListener('dragover', (e) => {
        if (this.activeDragData?.source !== 'field-library') return;
        const fromIdx = this.activeDragData.libIdx;
        const toIdx = parseInt(card.getAttribute('data-lib-idx'), 10);
        if (isNaN(fromIdx) || isNaN(toIdx) || fromIdx === toIdx) return;
        e.preventDefault();
        e.stopPropagation();
        const rect = card.getBoundingClientRect();
        const insertBefore = (e.clientY - rect.top) < (rect.height / 2);
        card.style.borderTop = insertBefore ? '2px solid #005fb8' : '';
        card.style.borderBottom = !insertBefore ? '2px solid #005fb8' : '';
      });

      card.addEventListener('dragleave', () => {
        card.style.borderTop = '';
        card.style.borderBottom = '';
      });

      card.addEventListener('drop', (e) => {
        if (this.activeDragData?.source !== 'field-library') return;
        const fromIdx = this.activeDragData.libIdx;
        const toIdx = parseInt(card.getAttribute('data-lib-idx'), 10);
        card.style.borderTop = '';
        card.style.borderBottom = '';
        if (isNaN(fromIdx) || isNaN(toIdx) || fromIdx === toIdx) return;
        e.preventDefault();
        e.stopPropagation();
        const rect = card.getBoundingClientRect();
        const insertBefore = (e.clientY - rect.top) < (rect.height / 2);
        const list = window.App?.reusableFields;
        if (!Array.isArray(list)) return;
        const [moved] = list.splice(fromIdx, 1);
        let dest = insertBefore ? toIdx : toIdx + 1;
        if (fromIdx < dest) dest--;
        list.splice(dest, 0, moved);
        this.activeDragData = null;
        window.App.saveLibraries?.();
        window.App._refreshSidebarPreserveScroll?.();
      });

      card.addEventListener('dragend', () => {
        document.querySelectorAll('.saved-field-card').forEach(c => {
          c.style.borderTop = '';
          c.style.borderBottom = '';
        });
        this.activeDragData = null;
        this.clearDropIndicators();
      });
    });
  },

  /**
   * Bind drop events onto a specific section element
   */
  bindSectionDropEvents(sectionCardEl, sectionIndex) {
    const dropzone = sectionCardEl.querySelector('.section-body');
    const headerHandle = sectionCardEl.querySelector('.section-drag-handle');

    // Section reordering
    if (headerHandle) {
      headerHandle.setAttribute('draggable', 'true');
      headerHandle.addEventListener('dragstart', (e) => {
        this.activeDragData = {
          source: 'reorder-section',
          sectionIndex: sectionIndex
        };
        document.body.classList.add('is-dragging-section');
        e.dataTransfer.setData('text/plain', JSON.stringify(this.activeDragData));
        e.dataTransfer.effectAllowed = 'move';
        sectionCardEl.style.opacity = '0.5';
      });

      headerHandle.addEventListener('dragend', () => {
        sectionCardEl.style.opacity = '1';
        this.clearDropIndicators();
        this.activeDragData = null;
      });
    }

    // Dropzone for fields or empty sections
    sectionCardEl.addEventListener('dragover', (e) => {
      if (!this.activeDragData) return;

      if (this.activeDragData.source === 'section-library') {
        const targetSec = window.App.formSchema?.sections?.[sectionIndex];
        const isEmptySec = targetSec && (!targetSec.fields || targetSec.fields.length === 0);
        e.stopPropagation();
        if (isEmptySec) {
          e.preventDefault();
          e.dataTransfer.dropEffect = 'copy';
          sectionCardEl.classList.add('drag-over');
          const emptyZone = sectionCardEl.querySelector('.section-dropzone-empty');
          if (emptyZone) emptyZone.classList.add('drag-over');
        } else {
          // Populated section is NOT a droppable zone for another section
          e.dataTransfer.dropEffect = 'none';
        }
        return;
      }

      if (this.activeDragData.source === 'reorder-section') {
        e.preventDefault();
        e.stopPropagation();
        sectionCardEl.classList.add('drag-over');
      } else if (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library') {
        e.preventDefault();
        e.stopPropagation();
        const emptyZone = sectionCardEl.querySelector('.section-dropzone-empty');
        if (emptyZone) emptyZone.classList.add('drag-over');
      }
    });

    sectionCardEl.addEventListener('dragleave', (e) => {
      if (!sectionCardEl.contains(e.relatedTarget)) {
        sectionCardEl.classList.remove('drag-over');
        const emptyZone = sectionCardEl.querySelector('.section-dropzone-empty');
        if (emptyZone) emptyZone.classList.remove('drag-over');
      }
    });

    sectionCardEl.addEventListener('drop', (e) => {
      e.preventDefault();
      e.stopPropagation();
      sectionCardEl.classList.remove('drag-over');
      const emptyZone = sectionCardEl.querySelector('.section-dropzone-empty');
      if (emptyZone) emptyZone.classList.remove('drag-over');
      this.clearDropIndicators();

      if (!this.activeDragData) return;

      // Drop: Section Reorder
      if (this.activeDragData.source === 'reorder-section') {
        const fromIdx = this.activeDragData.sectionIndex;
        const toIdx = sectionIndex;
        this.activeDragData = null;
        if (fromIdx !== toIdx) {
          window.App.reorderSections(fromIdx, toIdx);
        }
        return;
      }

      // Drop: Entire Reusable Section dropped onto section (only allowed on empty sections)
      if (this.activeDragData.source === 'section-library') {
        const secData = this.activeDragData.sectionData;
        this.activeDragData = null;
        if (!secData) return;
        const targetSec = window.App.formSchema.sections[sectionIndex];
        if (targetSec && (!targetSec.fields || targetSec.fields.length === 0)) {
          window.App.populateEmptySectionWithTemplate(sectionIndex, secData);
        }
        return;
      }

      // Drop: New Field into Section Body
      if (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library') {
        const dragSnapshot = this.activeDragData;
        this.activeDragData = null;
        this._dispatchDroppedField(dragSnapshot, sectionIndex, null, false);
        return;
      }
    });

    // 0. Top Insertion Zone (Drop directly at Position 1 / Top of Section)
    const topZone = sectionCardEl.querySelector('.section-top-insertion-zone');
    if (topZone) {
      topZone.addEventListener('dragover', (e) => {
        if (this.activeDragData && (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library' || this.activeDragData.source === 'reorder-field')) {
          e.preventDefault();
          e.stopPropagation();
          topZone.classList.add('drag-over');
        }
      });
      topZone.addEventListener('dragleave', (e) => {
        topZone.classList.remove('drag-over');
      });
      topZone.addEventListener('drop', (e) => {
        if (!this.activeDragData || (this.activeDragData.source !== 'palette' && this.activeDragData.source !== 'field-library' && this.activeDragData.source !== 'reorder-field')) {
          return; // Let section-library / reorder-section bubble to sectionCardEl
        }
        e.preventDefault();
        e.stopPropagation();
        topZone.classList.remove('drag-over');
        this.clearDropIndicators();

        if (this.activeDragData.source === 'reorder-field') {
          window.App.reorderFields(this.activeDragData.sectionIndex, this.activeDragData.fieldIndex, sectionIndex, 0);
        } else if (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library') {
          window.App.insertFieldAt(sectionIndex, 0, this.activeDragData.fieldData);
        }
      });
    }

    // Make field cards inside the section draggable for reordering & precise drop targets
    const fieldCards = sectionCardEl.querySelectorAll('.canvas-field-card');
    fieldCards.forEach((fieldCard, fIdx) => {
      fieldCard.setAttribute('draggable', 'true');

      fieldCard.addEventListener('dragstart', (e) => {
        e.stopPropagation();
        this.activeDragData = {
          source: 'reorder-field',
          sectionIndex: sectionIndex,
          fieldIndex: fIdx
        };
        e.dataTransfer.setData('text/plain', JSON.stringify(this.activeDragData));
        e.dataTransfer.effectAllowed = 'move';
        fieldCard.style.opacity = '0.4';
      });

      fieldCard.addEventListener('dragend', (e) => {
        fieldCard.style.opacity = '1';
        this.clearDropIndicators();
        this.activeDragData = null;
      });

      fieldCard.addEventListener('dragover', (e) => {
        if (fieldCard.classList.contains('canvas-empty-spacer-card') && this.activeDragData && (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library')) {
          e.stopPropagation();
          e.dataTransfer.dropEffect = 'none';
          return;
        }
        if (this.activeDragData && (this.activeDragData.source === 'reorder-field' || this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library')) {
          e.preventDefault();
          e.stopPropagation();
          const rect = fieldCard.getBoundingClientRect();
          const relX = e.clientX - rect.left;
          const relY = e.clientY - rect.top;

          // If the card is in a 2-column or grid layout, upper 40% or left half indicates 'before'
          const isGridCol = fieldCard.closest('.mops-grid-col')?.classList.contains('col-lg-6') || fieldCard.offsetWidth < 550;
          let insertBefore = false;
          if (isGridCol) {
            if (relY < rect.height * 0.4) {
              insertBefore = true;
            } else if (relY > rect.height * 0.6) {
              insertBefore = false;
            } else {
              insertBefore = relX < rect.width * 0.5;
            }
          } else {
            insertBefore = relY < rect.height * 0.5;
          }

          if (insertBefore) {
            fieldCard.classList.add('drag-target-before');
            fieldCard.classList.remove('drag-target-after');
            fieldCard.setAttribute('data-pos-before', fIdx + 1);
          } else {
            fieldCard.classList.add('drag-target-after');
            fieldCard.classList.remove('drag-target-before');
            fieldCard.setAttribute('data-pos-after', fIdx + 2);
          }
        }
      });

      fieldCard.addEventListener('dragleave', (e) => {
        fieldCard.classList.remove('drag-target-before', 'drag-target-after');
      });

      fieldCard.addEventListener('drop', (e) => {
        if (fieldCard.classList.contains('canvas-empty-spacer-card') && this.activeDragData && (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library')) {
          e.preventDefault();
          e.stopPropagation();
          this.clearDropIndicators();
          return;
        }
        if (!this.activeDragData || (this.activeDragData.source !== 'reorder-field' && this.activeDragData.source !== 'palette' && this.activeDragData.source !== 'field-library')) {
          return; // Let section-library / reorder-section bubble to sectionCardEl
        }
        e.preventDefault();
        e.stopPropagation();
        const insertBefore = fieldCard.classList.contains('drag-target-before');
        this.clearDropIndicators();

        if (this.activeDragData.source === 'reorder-field') {
          const fromSec = this.activeDragData.sectionIndex;
          const fromField = this.activeDragData.fieldIndex;
          const toSec = sectionIndex;
          let toField = insertBefore ? fIdx : fIdx + 1;

          window.App.reorderFields(fromSec, fromField, toSec, toField);
        } else if (this.activeDragData && (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library')) {
          const targetFieldIdx = insertBefore ? fIdx : fIdx + 1;
          const dragSnapshot = this.activeDragData;
          this.activeDragData = null;
          this._dispatchDroppedField(dragSnapshot, sectionIndex, targetFieldIdx, false);
        }
      });
    });

    // --- Empty Half-Column Slot Dropzones ---
    // Bind each .grid-empty-slot-dropzone within this section so fields can be
    // dropped precisely into the empty right-half of a row beside a half-width field.
    const emptySlotZones = sectionCardEl.querySelectorAll('.grid-empty-slot-dropzone');
    emptySlotZones.forEach((slotEl) => {
      const slotSec = parseInt(slotEl.getAttribute('data-sec'), 10);
      const insertIdx = parseInt(slotEl.getAttribute('data-insert-idx'), 10);

      slotEl.addEventListener('dragenter', (e) => {
        if (this.activeDragData && (
          this.activeDragData.source === 'palette' ||
          this.activeDragData.source === 'field-library' ||
          this.activeDragData.source === 'reorder-field'
        )) {
          e.preventDefault();
          e.stopPropagation();
          slotEl.classList.add('drag-over');
        }
      });

      slotEl.addEventListener('dragover', (e) => {
        if (this.activeDragData && (
          this.activeDragData.source === 'palette' ||
          this.activeDragData.source === 'field-library' ||
          this.activeDragData.source === 'reorder-field'
        )) {
          e.preventDefault();
          e.stopPropagation();
          e.dataTransfer.dropEffect = 'copy';
          slotEl.classList.add('drag-over');
        }
      });

      slotEl.addEventListener('dragleave', (e) => {
        // Only remove if truly leaving this element (not entering a child)
        if (!slotEl.contains(e.relatedTarget)) {
          slotEl.classList.remove('drag-over');
        }
      });

      slotEl.addEventListener('drop', (e) => {
        if (!this.activeDragData || (
          this.activeDragData.source !== 'palette' &&
          this.activeDragData.source !== 'field-library' &&
          this.activeDragData.source !== 'reorder-field'
        )) {
          return; // Let section-library / reorder-section bubble to sectionCardEl
        }
        e.preventDefault();
        e.stopPropagation();
        slotEl.classList.remove('drag-over');
        this.clearDropIndicators();

        if (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library') {
          const dragSnapshot = this.activeDragData;
          this.activeDragData = null;
          this._dispatchDroppedField(dragSnapshot, slotSec, insertIdx, true);

        } else if (this.activeDragData.source === 'reorder-field') {
          const fromSec = this.activeDragData.sectionIndex;
          const fromField = this.activeDragData.fieldIndex;
          // Force the moved field to half-width so it fits in the slot
          const movedField = window.App.formSchema?.sections?.[fromSec]?.fields?.[fromField];
          if (movedField && (movedField.col === 'col-lg-12' || movedField.col === 'Full')) {
            movedField.col = 'col-lg-6';
          }
          window.App.reorderFields(fromSec, fromField, slotSec, insertIdx);
        }
      });
    });

    // --- Between-Row Insert Strips ---
    // Bind each .between-row-drop-strip - a full-width horizontal strip rendered
    // below every full-width field row so the user can drop directly beneath it.
    const betweenRowStrips = sectionCardEl.querySelectorAll('.between-row-drop-strip');
    betweenRowStrips.forEach((stripEl) => {
      const stripSec = parseInt(stripEl.getAttribute('data-sec'), 10);
      const insertIdx = parseInt(stripEl.getAttribute('data-insert-idx'), 10);

      const activateSources = ['palette', 'field-library', 'reorder-field'];

      stripEl.addEventListener('dragenter', (e) => {
        if (this.activeDragData && activateSources.includes(this.activeDragData.source)) {
          e.preventDefault();
          e.stopPropagation();
          stripEl.classList.add('drag-over');
        }
      });

      stripEl.addEventListener('dragover', (e) => {
        if (this.activeDragData && activateSources.includes(this.activeDragData.source)) {
          e.preventDefault();
          e.stopPropagation();
          e.dataTransfer.dropEffect = 'copy';
          stripEl.classList.add('drag-over');
        }
      });

      stripEl.addEventListener('dragleave', (e) => {
        if (!stripEl.contains(e.relatedTarget)) {
          stripEl.classList.remove('drag-over');
        }
      });

      stripEl.addEventListener('drop', (e) => {
        if (!this.activeDragData || !activateSources.includes(this.activeDragData.source)) {
          return; // Let section-library / reorder-section bubble to sectionCardEl
        }
        e.preventDefault();
        e.stopPropagation();
        stripEl.classList.remove('drag-over');
        this.clearDropIndicators();

        if (this.activeDragData.source === 'palette' || this.activeDragData.source === 'field-library') {
          const dragSnapshot = this.activeDragData;
          this.activeDragData = null;
          this._dispatchDroppedField(dragSnapshot, stripSec, insertIdx, false);

        } else if (this.activeDragData.source === 'reorder-field') {
          const fromSec = this.activeDragData.sectionIndex;
          const fromField = this.activeDragData.fieldIndex;
          window.App.reorderFields(fromSec, fromField, stripSec, insertIdx);
        }
      });
    });
  },

  _dispatchDroppedField(dragData, secIdx, insertIdx, forceHalf) {
    if (!dragData || !window.App) return;
    if (dragData.source === 'palette' && dragData.type !== 'empty_field') {
      window.App.openCreateLibraryFieldModal(dragData.type, {
        secIdx,
        fieldIdx: insertIdx,
        col: forceHalf ? 'col-lg-6' : 'col-lg-6'
      });
      return;
    }
    if (!dragData.fieldData) return;
    const fieldData = JSON.parse(JSON.stringify(dragData.fieldData));
    if (forceHalf && (!fieldData.col || fieldData.col === 'col-lg-12' || fieldData.col === 'Full')) {
      fieldData.col = 'col-lg-6';
    }
    if (insertIdx === null || insertIdx === undefined) {
      window.App.addFieldToSection(secIdx, fieldData);
    } else {
      window.App.insertFieldAt(secIdx, insertIdx, fieldData);
    }
  },

  /**
   * Create a between-section drop strip for inserting reusable sections or reordering sections
   */
  createBetweenSectionStrip(insertIdx) {
    const strip = document.createElement('div');
    strip.className = 'between-section-drop-strip';
    strip.setAttribute('data-insert-idx', insertIdx);
    strip.innerHTML = `<span class="bsds-label">⊕ Drop section here</span>`;

    const isSectionDrag = () =>
      this.activeDragData &&
      (this.activeDragData.source === 'section-library' || this.activeDragData.source === 'reorder-section');

    strip.addEventListener('dragenter', (e) => {
      if (isSectionDrag()) {
        e.preventDefault();
        e.stopPropagation();
        strip.classList.add('drag-over');
      }
    });

    strip.addEventListener('dragover', (e) => {
      if (isSectionDrag()) {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = this.activeDragData.source === 'reorder-section' ? 'move' : 'copy';
        strip.classList.add('drag-over');
      }
    });

    strip.addEventListener('dragleave', (e) => {
      if (!strip.contains(e.relatedTarget)) {
        strip.classList.remove('drag-over');
      }
    });

    strip.addEventListener('drop', (e) => {
      if (!isSectionDrag()) return;
      e.preventDefault();
      e.stopPropagation();
      strip.classList.remove('drag-over');
      this.clearDropIndicators();

      const data = this.activeDragData;
      this.activeDragData = null;
      if (!data) return;

      if (data.source === 'section-library' && data.sectionData) {
        window.App.insertReusableSection(data.sectionData, insertIdx);
      } else if (data.source === 'reorder-section') {
        const fromIdx = data.sectionIndex;
        let toIdx = insertIdx;
        if (fromIdx < toIdx) toIdx -= 1;
        if (fromIdx !== toIdx) {
          window.App.reorderSections(fromIdx, toIdx);
        }
      }
    });

    return strip;
  },

  bindAddSectionDropZone(wrapEl) {
    if (!wrapEl) return;
    const isSectionLibDrag = () => this.activeDragData && this.activeDragData.source === 'section-library';

    wrapEl.addEventListener('dragenter', (e) => {
      if (isSectionLibDrag()) {
        e.preventDefault();
        e.stopPropagation();
        wrapEl.classList.add('drag-over');
      }
    });
    wrapEl.addEventListener('dragover', (e) => {
      if (isSectionLibDrag()) {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = 'copy';
        wrapEl.classList.add('drag-over');
      }
    });
    wrapEl.addEventListener('dragleave', (e) => {
      if (!wrapEl.contains(e.relatedTarget)) {
        wrapEl.classList.remove('drag-over');
      }
    });
    wrapEl.addEventListener('drop', (e) => {
      if (!isSectionLibDrag()) return;
      e.preventDefault();
      e.stopPropagation();
      const secData = this.activeDragData.sectionData;
      this.activeDragData = null;
      this.clearDropIndicators();
      if (secData) {
        window.App.insertReusableSection(secData);
      }
    });
  },

  clearDropIndicators() {
    document.body.classList.remove('is-dragging-section');
    document.querySelectorAll('.drag-target-before, .drag-target-after, .drag-over, .grid-empty-slot-dropzone').forEach(el => {
      el.classList.remove('drag-target-before', 'drag-target-after', 'drag-over');
    });
  }
};
