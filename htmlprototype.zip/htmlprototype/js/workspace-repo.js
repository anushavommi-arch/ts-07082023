/**
 * MOPS Form Studio  Workspace Repository Engine
 * Handles multi-mode persistence:
 *   MODE 1 (PHP Server):   Reads/writes physical JSON files via api.php (Universal Apache/PHP 7.0+)
 *   MODE 2 (Node/PS):      Reads/writes physical JSON files via server.js or server.ps1 (ports 3000/3001)
 *   MODE 3 (Offline):      Falls back to window.MOPS_FORMS_REPOSITORY from forms/forms-manifest.js
 *
 * In all modes, form data is stored as:
 *   forms/<form-id>/form.json                      Current published schema (active sprint)
 *   forms/<form-id>/manifest.json                  Form metadata, activeSprint, activeFlow, flows
 *   forms/<form-id>/flows/<flow-id>/flow.json      Process variant overrides
 *   forms/<form-id>/sprints/<sprint>/sprint.json   Sprint metadata & publishedVersionId pointer
 *   forms/<form-id>/sprints/<sprint>/versions/     Immutable sprint version patches
 *   forms/forms-manifest.json                      Master catalog (auto-rebuilt by api.php/server)
 *   forms/forms-manifest.js                        Static JS bundle (for offline file:/// mode)
 */

window.WorkspaceRepo = {
  _serverUrl: null,
  _mode: 'detecting', // 'php' | 'offline'

  /**
   * Resolve URL to api.php relative to the current page.
   * Works whether the app is at the web root (/htmlprototype/) or in a subfolder (/orderingtool/htmlprototype/).
   */
  _apiUrl() {
    let loc = window.location.href.split('?')[0].split('#')[0];
    if (!loc.endsWith('/') && !loc.endsWith('.html') && !loc.endsWith('.php')) {
      loc += '/';
    }
    return new URL('api.php', loc).href;
  },

  /**
   * Helper to return whether an active server backend is connected
   */
  hasServer() {
    return this._mode === 'php';
  },

  /**
   * Resolve endpoint for an action (all routed through api.php)
   */
  _endpoint(action) {
    return `${this._apiUrl()}?action=${action}`;
  },

  /**
   * Detect backend server. Returns 'php' or 'offline'.
   */
  async detectMode() {
    if (this._mode !== 'detecting') return this._mode;

    // Try PHP api.php (native server persistence)
    try {
      const r = await fetch(this._apiUrl() + '?action=status', {
        method: 'GET'
      });
      if (r.ok) {
        const data = await r.json();
        if (data && data.ok) {
          this._serverUrl = this._apiUrl();
          this._mode = 'php';
          console.log(`[MOPs] OK PHP server mode active via api.php (PHP ${data.php || '7.x'})`);
          return 'php';
        }
      }
    } catch (_) {}

    this._mode = 'offline';
    console.info('[MOPs]  Offline mode  using static forms/forms-manifest.js bundle.');
    return 'offline';
  },

  /**
   * Load the full forms repository (manifest + all forms + sprints + flows).
   * Returns array of form objects compatible with App.allForms.
   */
  async loadRepository() {
    const mode = await this.detectMode();
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('manifest'));
        if (r.ok) {
          const manifest = await r.json();
          return this._normalizeManifest(manifest);
        }
      } catch (e) {
        console.warn('[MOPs] Server manifest fetch failed, falling back to static bundle.', e);
      }
    }
    // Offline: use static pre-built manifest
    if (window.MOPS_FORMS_REPOSITORY && window.MOPS_FORMS_REPOSITORY.forms) {
      return this._normalizeManifest(window.MOPS_FORMS_REPOSITORY);
    }
    // Last resort: seed from SAMPLE_FORMS registry
    return JSON.parse(JSON.stringify(window.SAMPLE_FORMS || []));
  },

  /**
   * Normalize manifest into App.allForms format
   */
  _normalizeManifest(manifest) {
    // PHP api.php handles deletion server-side  no client-side deleted-IDs list needed
    const deletedIds = [];

    return (manifest.forms || [])
      .filter(f => !deletedIds.includes(f.id))
      .map(f => {
        let schema = f.schema || { title: f.label || f.id, sections: [] };

        const allVersions = (f.versions || []).map(v => ({
          versionId: v.versionId,
          versionLabel: v.versionLabel || `${v.versionId} (${v.sprint || ''})`,
          sprint: v.sprint || '',
          timestamp: v.timestamp || new Date().toISOString(),
          author: v.author || 'MOPs Team',
          status: v.status || 'Active',
          notes: v.notes || '',
          schema: v.schema || schema,
          stats: v.stats || {}
        }));

        const validVersions = allVersions.filter(v => v.schema && v.schema.sections && v.schema.sections.length > 0);
        if ((!schema.sections || schema.sections.length === 0) && validVersions.length > 0) {
          schema = JSON.parse(JSON.stringify(validVersions[validVersions.length - 1].schema));
        }

        const sprints = (f.sprints || []).map(sp => {
          let spVers = [];
          if (Array.isArray(sp.versions)) {
            spVers = sp.versions;
          } else if (sp.versions && typeof sp.versions === 'object') {
            spVers = [sp.versions];
          }

          const spNorm = (sp.sprintId || sp.sprintLabel || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          if (spVers.length === 0 && allVersions.length > 0) {
            spVers = allVersions.filter(v => {
              const vSp = (v.sprint || v.sprintId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
              const vId = (v.versionId || '').toLowerCase();
              return (vSp && spNorm && (vSp === spNorm || vSp.includes(spNorm) || spNorm.includes(vSp))) ||
                     (sp.publishedVersionId && vId === sp.publishedVersionId.toLowerCase());
            });
          }

          spVers = spVers.map(v => {
            const full = allVersions.find(av => av.versionId === v.versionId);
            return full ? Object.assign({}, full, v) : v;
          });

          return {
            sprintId: sp.sprintId || '',
            sprintLabel: sp.sprintLabel || sp.sprintId || '',
            startDate: sp.startDate || '',
            endDate: sp.endDate || '',
            status: sp.status || 'Active',
            publishedVersionId: sp.publishedVersionId || (spVers[spVers.length - 1]?.versionId || 'v1.0'),
            versions: spVers
          };
        });

        return {
          id: f.id,
          label: f.label || schema.title || f.id,
          icon: f.icon || '',
          configFile: f.configFile || `form.${f.id}.config.ts`,
          schema: schema,
          activeVersionId: f.activeVersionId || 'v1.0',
          activeSprint: f.activeSprint || 'sprint-25.1',
          createdAt: f.createdAt || schema.createdAt || null,
          createdBy: f.createdBy || schema.createdBy || null,
          updatedAt: f.updatedAt || schema.updatedAt || null,
          updatedBy: f.updatedBy || schema.updatedBy || null,
          readOnly: f.readOnly === true,
          lockedVersions: f.lockedVersions || [],
          sprints: sprints,
          versions: allVersions
        };
      });
  },

  /**
   * Save a form's working schema to disk.
   */
  async saveForm(form, schema) {
    if (!form || !form.id) return { ok: false };
    if ((!schema || !schema.sections || schema.sections.length === 0) && form.versions && form.versions.length > 0) {
      console.warn('[MOPs] Skipped saving empty schema over form with existing versions:', form.id);
      return { ok: false, message: 'Skipped blank schema save' };
    }
    const mode = await this.detectMode();
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('save'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            formId: form.id,
            label: form.label,
            icon: form.icon,
            configFile: form.configFile,
            schema: schema,
            activeSprint: form.activeSprint,
            createdAt: form.createdAt || schema.createdAt,
            createdBy: form.createdBy || schema.createdBy,
            updatedAt: form.updatedAt || schema.updatedAt,
            updatedBy: form.updatedBy || schema.updatedBy
          })
        });
        if (r.ok) {
          const result = await r.json();
          console.log(`[MOPs]  Saved to disk: ${result.filePath}`);
          return result;
        }
      } catch (e) {
        console.warn('[MOPs] Server save failed:', e);
      }
    }
    // Offline fallback: patch static manifest in memory
    if (window.MOPS_FORMS_REPOSITORY) {
      const f = (window.MOPS_FORMS_REPOSITORY.forms || []).find(x => x.id === form.id);
      if (f) f.schema = JSON.parse(JSON.stringify(schema));
    }
    return { ok: false, mode: 'offline', message: 'Saved in memory only.' };
  },

  /**
   * Delete a form folder from disk and update repository.
   */
  async deleteForm(formId) {
    // PHP api.php deletes the form folder server-side  no localStorage tracking needed
    const mode = await this.detectMode();
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('delete'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ formId })
        });
        if (r.ok) {
          const res = await r.json();
          console.log(`[MOPs]  Deleted from disk: ${formId}`);
          return res;
        }
      } catch (e) {
        console.warn('[MOPs] Server delete failed:', e);
      }
    }

    if (window.MOPS_FORMS_REPOSITORY && window.MOPS_FORMS_REPOSITORY.forms) {
      const idx = window.MOPS_FORMS_REPOSITORY.forms.findIndex(x => x.id === formId);
      if (idx >= 0) window.MOPS_FORMS_REPOSITORY.forms.splice(idx, 1);
    }
    return { ok: true, mode };
  },

  /**
   * Save a sprint version snapshot to disk.
   */
  async saveVersion(form, versionRecord) {
    const mode = await this.detectMode();
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('version'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            formId: form.id,
            versionId: versionRecord.versionId,
            sprint: versionRecord.sprint,
            sprintId: versionRecord.sprintId,
            status: versionRecord.status,
            author: versionRecord.author,
            notes: versionRecord.notes,
            schema: versionRecord.schema,
            stats: versionRecord.stats
          })
        });
        if (r.ok) {
          const result = await r.json();
          console.log(`[MOPs]  Version saved to disk: ${result.filePath}`);
          return result;
        }
      } catch (e) {
        console.warn('[MOPs] Server version save failed:', e);
      }
    }
    return { ok: false, mode: 'offline', message: 'Version saved in memory only.' };
  },

  /**
   * Delete a version snapshot from disk and rebuild manifest.
   */
  async deleteVersion(formId, versionId) {
    const mode = await this.detectMode();
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('delete-version'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ formId, versionId })
        });
        if (r.ok) {
          const result = await r.json();
          console.log(`[MOPs]  Version deleted from disk: ${versionId}`);
          return result;
        }
      } catch (e) {
        console.warn('[MOPs] Server version delete failed:', e);
      }
    }
    return { ok: true, mode: 'offline' };
  },

  /**
   * Save a sprint record to disk.
   */
  async saveSprint(form, sprintRecord) {
    if (!form || !form.id) return { ok: false };
    const mode = await this.detectMode();
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('sprint'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            formId: form.id,
            sprintId: sprintRecord.sprintId,
            sprintLabel: sprintRecord.sprintLabel,
            startDate: sprintRecord.startDate,
            endDate: sprintRecord.endDate,
            status: sprintRecord.status,
            publishedVersionId: sprintRecord.publishedVersionId,
            versions: sprintRecord.versions || []
          })
        });
        if (r.ok) {
          const result = await r.json();
          console.log(`[MOPs]  Sprint saved to disk: ${result.filePath}`);
          return result;
        }
      } catch (e) {
        console.warn('[MOPs] Server sprint save failed:', e);
      }
    }
    return { ok: false, mode: 'offline', message: 'Sprint saved in memory only.' };
  },

  /**
   * Rename an existing form
   */
  async renameForm(formId, newLabel) {
    if (!formId || !newLabel) return { ok: false };
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('rename-form'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ formId, newLabel })
        });
        const result = await r.json();
        return result;
      } catch (e) {
        console.warn('[MOPs] Server rename form failed:', e);
      }
    }
    return { ok: true, formId, label: newLabel, mode: 'offline' };
  },

  /**
   * Rename an existing sprint
   */
  async renameSprint(formId, oldSprintId, newSprintId, newSprintLabel) {
    if (!formId || !oldSprintId || !newSprintLabel) return { ok: false };
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('rename-sprint'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ formId, oldSprintId, newSprintId, newSprintLabel })
        });
        const result = await r.json();
        return result;
      } catch (e) {
        console.warn('[MOPs] Server rename sprint failed:', e);
      }
    }
    return { ok: true, formId, sprintId: newSprintId, sprintLabel: newSprintLabel, mode: 'offline' };
  },

  /**
   * Rename an existing version tag
   */
  /**
   * Save only the title field of an existing version's schema (does NOT rename files).
   */
  async saveVersionTitle(formId, sprintId, versionId, newTitle) {
    if (!formId || !versionId || !newTitle) return { ok: false };
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('save-version-title'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ formId, sprintId, versionId, newTitle })
        });
        const result = await r.json();
        return result;
      } catch (e) {
        console.warn('[MOPs] Server save version title failed:', e);
      }
    }
    return { ok: true, mode: 'offline' };
  },

  async renameVersion(formId, oldVersionId, newVersionId) {
    if (!formId || !oldVersionId || !newVersionId) return { ok: false };
    if (this.hasServer()) {
      try {
        const r = await fetch(this._endpoint('rename-version'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ formId, oldVersionId, newVersionId })
        });
        const result = await r.json();
        return result;
      } catch (e) {
        console.warn('[MOPs] Server rename version failed:', e);
      }
    }
    return { ok: true, formId, oldVersionId, newVersionId, mode: 'offline' };
  },

  /**
   * Returns a user-facing storage mode badge string
   */
  getModeBadge() {
    if (this._mode === 'php') return ' PHP Server Saved';
    if (this._mode === 'server') return ' Folder-Saved';
    if (this._mode === 'offline') return ' Memory Only';
    return ' Detecting';
  }
};
