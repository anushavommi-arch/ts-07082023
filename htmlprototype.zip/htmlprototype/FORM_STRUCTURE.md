# DART HTML Prototype — Form Storage Architecture

> **Status:** Proposal for next-generation folder structure  
> **Author:** MOPs Platform Team  
> **Last Updated:** November 2026

---

## Table of Contents

1. [The Problem with Current Structure](#1-the-problem-with-current-structure)
2. [Proposed Structure — Form → Sprints → Versions](#2-proposed-structure--form--sprints--versions)
3. [Flows Folder — Per-Form Business Process Variants](#3-flows-folder--per-form-business-process-variants)
4. [Full Visual Tree](#4-full-visual-tree)
5. [File Specifications](#5-file-specifications)
6. [Sprint Diff — How It Works with New Structure](#6-sprint-diff--how-it-works-with-new-structure)
7. [Migration Plan — Current → New](#7-migration-plan--current--new)
8. [What Needs to Be Built / Changed](#8-what-needs-to-be-built--changed)
9. [Open Questions](#9-open-questions)

---

## 1. The Problem with Current Structure

```
forms/
  web-page/
    form.json          ← live schema (flat)
    manifest.json
    versions/
      v1.0.json        ← sprint info buried inside the file
      v1.1.json        ← no way to group by sprint from folder alone
```

### Pain Points

| # | Problem | Impact |
|---|---------|--------|
| 1 | Versions are numbered sequentially but **sprint grouping is invisible** in the folder | Business team can't navigate "what changed in Sprint 25.1" from file explorer |
| 2 | A sprint can have **multiple patch versions** (v1.1, v1.2, v1.3) — no way to know they belong to the same sprint | Diff picker shows raw version numbers, not sprint names |
| 3 | **No concept of Flows** — some forms have different question paths depending on audience (e.g. Web Page for Agency vs Internal team) | Each flow variation is currently a separate form or manually maintained copy |
| 4 | The `versions/` folder grows unbounded with no sprint boundary | Hard to archive old sprints, hard to see "Sprint 25.1 introduced X" |

---

## 2. Proposed Structure — Form → Sprints → Versions

### Core Idea

```
<form>/
  sprints/
    <sprint-id>/       ← one folder per sprint
      versions/        ← patch versions within that sprint
        v1.0.json
        v1.1.json
      sprint.json      ← sprint metadata + published version pointer
```

### Why Sprint as the Primary Grouping

- **Business team thinks in sprints**, not version numbers
- Sprint = a release boundary → natural "before/after" comparison unit
- Multiple patches within a sprint are internal; only the **published version** is compared cross-sprint
- Retiring / archiving a sprint = moving / zipping one folder

---

## 3. Flows Folder — Per-Form Business Process Variants

Some forms serve **multiple audiences or process paths** with different field sets, section visibility rules, or routing logic. These are **not** separate forms — they are **variants of the same form**.

### Examples

| Form | Flow A | Flow B | Flow C |
|------|--------|--------|--------|
| Web Page | Standard (Internal) | Agency-Submitted | Emergency/Fast-Track |
| Email | Campaign Email | Nurture/Drip | Transactional |
| Event | Virtual Event | In-Person Event | Hybrid Event |
| Collateral | New Asset | Update Existing | Translation Request |

### Flows Folder Structure

```
<form>/
  flows/
    standard/
      flow.json        ← field visibility overrides, routing rules, section order
    agency/
      flow.json
    fast-track/
      flow.json
  sprints/
    ...
```

A `flow.json` **does not duplicate the full schema** — it only declares **overrides** on top of the base form:

```json
{
  "flowId": "agency",
  "flowLabel": "Agency Submitted",
  "description": "Used when the request originates from an external agency partner",
  "audience": ["agency", "partner"],
  "sectionOverrides": [
    { "sectionId": "wp_s_stakeholder", "hidden": true },
    { "sectionId": "wp_s_agency_info", "hidden": false }
  ],
  "fieldOverrides": [
    { "fieldId": "wp_f_submitterType", "defaultValue": "Agency", "locked": true }
  ],
  "routingRules": {
    "approvalChain": "agency-review",
    "notifyGroup": "partner-ops"
  }
}
```

---

## 4. Full Visual Tree

```
htmlprototype/
└── forms/
    ├── forms-manifest.js          ← Global registry of all forms
    │
    ├── web-page/                  ← Form folder (one per form type)
    │   ├── form.json              ← Current live schema (always = active sprint's published version)
    │   ├── manifest.json          ← Form metadata: id, label, icon, activeSprint, activeFlow
    │   │
    │   ├── flows/                 ← Business process variants
    │   │   ├── standard/
    │   │   │   └── flow.json
    │   │   ├── agency/
    │   │   │   └── flow.json
    │   │   └── fast-track/
    │   │       └── flow.json
    │   │
    │   └── sprints/               ← Sprint history
    │       ├── sprint-24.8/       ← Sprint folder (id = sprint label, kebab-case)
    │       │   ├── sprint.json    ← Sprint metadata
    │       │   └── versions/
    │       │       └── v1.0.json  ← Only version in this sprint (= published)
    │       │
    │       ├── sprint-25.1/
    │       │   ├── sprint.json
    │       │   └── versions/
    │       │       ├── v1.1.json  ← First patch
    │       │       ├── v1.2.json  ← Hotfix patch
    │       │       └── v1.3.json  ← Published version for this sprint ✅
    │       │
    │       └── sprint-25.2/       ← Current active sprint
    │           ├── sprint.json
    │           └── versions/
    │               └── v1.4.json  ← Work in progress (draft)
    │
    ├── email/
    │   ├── form.json
    │   ├── manifest.json
    │   ├── flows/
    │   │   ├── campaign/
    │   │   │   └── flow.json
    │   │   └── nurture/
    │   │       └── flow.json
    │   └── sprints/
    │       └── sprint-24.8/
    │           ├── sprint.json
    │           └── versions/
    │               └── v1.0.json
    │
    └── event/
        ├── form.json
        ├── manifest.json
        ├── flows/
        │   ├── virtual/
        │   │   └── flow.json
        │   ├── in-person/
        │   │   └── flow.json
        │   └── hybrid/
        │       └── flow.json
        └── sprints/
            └── sprint-24.8/
                ├── sprint.json
                └── versions/
                    └── v1.0.json
```

---

## 5. File Specifications

### `manifest.json` — Updated Schema

```json
{
  "id": "web-page",
  "label": "Web Page / Web Project Type",
  "icon": "🌐",
  "configFile": "form.web-page.config.ts",
  "activeSprint": "sprint-25.2",
  "activeVersionId": "v1.4",
  "activeFlow": "standard",
  "flows": ["standard", "agency", "fast-track"],
  "updatedAt": "2026-11-06T09:00:00.000Z"
}
```

> [!NOTE]
> `manifest.json` no longer embeds the full version list — that lives in each `sprint.json`. The manifest only points to what's **active right now**.

---

### `sprint.json` — Sprint Metadata

```json
{
  "sprintId": "sprint-25.1",
  "sprintLabel": "Sprint 25.1",
  "startDate": "2026-09-15",
  "endDate": "2026-10-01",
  "status": "Archived",
  "publishedVersionId": "v1.3",
  "versions": [
    {
      "versionId": "v1.1",
      "timestamp": "2026-09-16T10:00:00.000Z",
      "author": "Jane Smith",
      "notes": "Added Support Type field",
      "status": "Superseded"
    },
    {
      "versionId": "v1.2",
      "timestamp": "2026-09-20T14:00:00.000Z",
      "author": "John Doe",
      "notes": "Hotfix: fixed required flag on Web Page Type",
      "status": "Superseded"
    },
    {
      "versionId": "v1.3",
      "timestamp": "2026-09-28T09:00:00.000Z",
      "author": "Jane Smith",
      "notes": "Final published version for Sprint 25.1",
      "status": "Published"
    }
  ]
}
```

---

### `v1.3.json` — Version File (unchanged schema)

```json
{
  "versionId": "v1.3",
  "sprint": "sprint-25.1",
  "timestamp": "2026-09-28T09:00:00.000Z",
  "author": "Jane Smith",
  "status": "Published",
  "notes": "Final published version for Sprint 25.1",
  "stats": {
    "sectionCount": 3,
    "fieldCount": 11,
    "rulesCount": 2
  },
  "schema": {
    "title": "Web Page Intake Form",
    "sections": [ "..." ]
  }
}
```

---

### `flow.json` — Flow Override File

```json
{
  "flowId": "agency",
  "flowLabel": "Agency Submitted",
  "description": "Request originated from an external agency partner",
  "audience": ["agency", "partner"],
  "icon": "🤝",
  "sectionOverrides": [
    { "sectionId": "wp_s1", "hidden": true, "reason": "Agency submitter info replaces internal stakeholder" },
    { "sectionId": "wp_s_agency", "hidden": false }
  ],
  "fieldOverrides": [
    { "fieldId": "wp_f_submitterType", "defaultValue": "Agency", "locked": true },
    { "fieldId": "wp_f_budgetCode", "required": false }
  ],
  "routingRules": {
    "approvalChain": "agency-review",
    "notifyGroup": "partner-ops",
    "slaHours": 48
  }
}
```

---

## 6. Sprint Diff — How It Works with New Structure

### Diff Logic (Updated)

```
Compare:
  sprint-25.2 → publishedVersionId (or latest draft)
    vs
  sprint-25.1 → publishedVersionId

Result: color-coded field cards on canvas
  🟢 Added    🟡 Modified    🔴 Removed    ⚪ Unchanged
```

### Baseline Dropdown (Updated UI)

**Old:**  `v1.0 (Sprint 24.8)`  `v1.1 (Sprint 25.1)`

**New:**  `Sprint 24.8 (v1.0)`  `Sprint 25.1 → v1.3`  `Sprint 25.2 (Draft)`

The dropdown now **groups by sprint** and shows the published version — not individual patch versions. Business team selects sprints, not raw version numbers.

### Flow-Aware Diff

When a flow is active, the diff can optionally **scope to fields visible in that flow** only — hiding irrelevant unchanged fields from other flows.

---

## 7. Migration Plan — Current → New

### Phase 1 — Restructure Existing Files

| Step | Action | Effort |
|------|--------|--------|
| 1 | For each form folder, create `sprints/` and `flows/` directories | Low |
| 2 | For each `versions/vX.Y.json`, read the `sprint` field inside → move to `sprints/<sprint-id>/versions/vX.Y.json` | Medium (Python script) |
| 3 | Create a `sprint.json` per sprint folder from the data already in each version file | Low (Python script) |
| 4 | Create a `flows/standard/flow.json` stub for every form (empty overrides = default behavior) | Low |
| 5 | Update `manifest.json` to remove embedded version list, add `activeSprint` and `activeFlow` | Low |
| 6 | Update `forms-manifest.js` global registry | Medium |

### Phase 2 — Update JS Loaders

| File | Change Needed |
|------|--------------|
| `js/version-manager.js` | Update `getSprintDiff()` to resolve path as `sprints/<id>/versions/<vid>.json` |
| `js/version-manager.js` | Add `loadSprintManifest(formId, sprintId)` → reads `sprint.json` |
| `js/version-manager.js` | Update `ensureFormVersions()` to discover sprints first, then versions within |
| `js/app.js` | Update `updateSprintDiffBarUI()` baseline dropdown to show sprint names |
| `js/app.js` | Add flow switcher UI (flow pill/tab strip on canvas header) |

### Phase 3 — Flow Switcher UI

- Add a **Flow** tab strip on the canvas header (next to the Sprint Diff bar)
- Switching flow applies `sectionOverrides` and `fieldOverrides` from `flow.json` on top of the base schema
- Flow selection persists per form in `localStorage`

---

## 8. What Needs to Be Built / Changed

### 🗂️ File System Changes

- [ ] Python migration script: restructure `versions/` → `sprints/<id>/versions/`
- [ ] Python migration script: generate `sprint.json` per sprint from existing version metadata
- [ ] Create `flows/standard/flow.json` stub for every form
- [ ] Update all `manifest.json` files to new schema

### ⚙️ JavaScript Changes

- [ ] `version-manager.js` — `getSprintDiff()`: new path resolution
- [ ] `version-manager.js` — `loadSprintManifest()`: new function
- [ ] `version-manager.js` — `ensureFormVersions()`: sprint-first discovery
- [ ] `app.js` — `updateSprintDiffBarUI()`: sprint-grouped dropdown
- [ ] `app.js` — `applyFlow(flowId)`: apply overrides from `flow.json`
- [ ] `app.js` — `renderFlowSwitcher()`: UI tab strip for flow selection

### 🎨 CSS Changes

- [ ] Flow switcher tab strip (`.canvas-flow-switcher`)
- [ ] Active flow badge on canvas header
- [ ] Flow-scoped field card dimming (fields hidden in this flow shown as muted)

### 📄 HTML Changes

- [ ] Add `#canvasFlowSwitcher` bar to `index.html` (between sprint diff bar and canvas)

---

## 9. Open Questions

| # | Question | Options | Decision |
|---|----------|---------|----------|
| 1 | **Sprint ID format** — kebab or dot? | `sprint-25.1` vs `sprint_25_1` vs `s25.1` | — |
| 2 | **Who creates sprint folders?** — Manual by BA or auto-created on "Save New Version"? | Manual / Auto | — |
| 3 | **Flow inheritance** — Does a flow override per-sprint or globally? | Per-sprint overrides / Global overrides | — |
| 4 | **Draft versions** — Are WIP patches visible in the diff bar or hidden? | Show as `(Draft)` / Hide until Published | — |
| 5 | **Forms without flows** — Do they still get a `flows/standard/` stub or skip the folder? | Always stub / Optional | — |
| 6 | **Cross-form flows** — If two forms share the same audience flow (e.g. "Agency"), is the flow config centralized or duplicated per form? | Centralized `flows/` at root / Per-form | — |

---

> [!TIP]
> **Recommended first step:** Run the migration script on the `web-page` form only as a dry run, verify the Sprint Change Highlighter still works, then roll out to all forms.

> [!IMPORTANT]
> `form.json` at the root of each form folder should always equal the **published version of the active sprint** — it is the single source of truth for what renders on the canvas. Never edit `form.json` directly; it is auto-generated from the active sprint's published version.

