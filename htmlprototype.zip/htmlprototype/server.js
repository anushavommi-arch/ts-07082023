/**
 * MOPS Form Studio — Local Workspace Folder Server
 * Enables zero-config, native folder-structure persistence.
 * Every form and version is written directly to htmlprototype/forms/<form-id>/
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;
const FORMS_DIR = path.join(ROOT_DIR, 'forms');

// MIME types
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function rebuildMasterManifest() {
  if (!fs.existsSync(FORMS_DIR)) return null;

  const entries = fs.readdirSync(FORMS_DIR, { withFileTypes: true });
  const formFolders = entries.filter(e => e.isDirectory() && e.name !== 'forms_backup_pre_sprints');

  const manifest = {
    repositoryName: 'MOPS Form Mockup & Rule Studio',
    version: '2.0.0',
    updatedAt: new Date().toISOString(),
    forms: []
  };

  formFolders.forEach(dirent => {
    const fDir = path.join(FORMS_DIR, dirent.name);
    const formJsonPath = path.join(fDir, 'form.json');
    const manifestJsonPath = path.join(fDir, 'manifest.json');
    const sprintsDir = path.join(fDir, 'sprints');
    const flowsDir = path.join(fDir, 'flows');
    const versDir = path.join(fDir, 'versions');

    if (!fs.existsSync(formJsonPath)) return;

    const readJsonSafe = (p) => {
      try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); }
      catch (e) { return null; }
    };

    let schema = readJsonSafe(formJsonPath) || {};
    let formMeta = fs.existsSync(manifestJsonPath) ? (readJsonSafe(manifestJsonPath) || {}) : {};

    const sprints = [];
    const versions = [];

    // 1. Scan sprints/ if exists
    if (fs.existsSync(sprintsDir)) {
      const sEntries = fs.readdirSync(sprintsDir, { withFileTypes: true }).filter(e => e.isDirectory());
      sEntries.forEach(se => {
        const sDir = path.join(sprintsDir, se.name);
        const sprintJsonPath = path.join(sDir, 'sprint.json');
        const sVersDir = path.join(sDir, 'versions');

        let sMeta = fs.existsSync(sprintJsonPath) ? (readJsonSafe(sprintJsonPath) || {}) : {};

        const sVersions = [];
        if (fs.existsSync(sVersDir)) {
          const svFiles = fs.readdirSync(sVersDir).filter(f => f.endsWith('.json'));
          svFiles.forEach(svf => {
            const svData = readJsonSafe(path.join(sVersDir, svf));
            if (svData && svData.versionId) {
              sVersions.push(svData);
              versions.push(svData);
            }
          });
        }
        sVersions.sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));

        sprints.push({
          sprintId: sMeta.sprintId || se.name,
          sprintLabel: sMeta.sprintLabel || se.name,
          startDate: sMeta.startDate || '',
          endDate: sMeta.endDate || '',
          status: sMeta.status || 'Active',
          publishedVersionId: sMeta.publishedVersionId || sVersions[sVersions.length - 1]?.versionId || 'v1.0',
          versions: sVersions   // Always use scanned versions from disk, not sprint.json metadata
        });
      });
    } else if (fs.existsSync(versDir)) {
      const vFiles = fs.readdirSync(versDir).filter(f => f.endsWith('.json'));
      vFiles.forEach(vf => {
        const vData = readJsonSafe(path.join(versDir, vf));
        if (vData && vData.versionId) {
          versions.push(vData);
        }
      });
    }

    versions.sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));
    const activeVer = versions[versions.length - 1] || null;

    manifest.forms.push({
      id: formMeta.id || dirent.name,
      label: formMeta.label || schema.title || dirent.name,
      icon: formMeta.icon || '📋',
      configFile: formMeta.configFile || `form.${dirent.name}.config.ts`,
      activeVersionId: formMeta.activeVersionId || activeVer?.versionId || 'v1.0',
      activeSprint: formMeta.activeSprint || activeVer?.sprint || 'sprint-25.1',
      folder: dirent.name,
      totalVersions: versions.length,
      schema: schema,
      sprints: sprints,
      versions: versions
    });
  });

  // Write master forms-manifest.json
  fs.writeFileSync(path.join(FORMS_DIR, 'forms-manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');

  // Write forms-manifest.js for direct file:/// compatibility
  const jsCode = '/** Auto-generated MOPS Folder Repository Manifest **/\n' +
    'window.MOPS_FORMS_REPOSITORY = ' + JSON.stringify(manifest, null, 2) + ';\n';
  fs.writeFileSync(path.join(FORMS_DIR, 'forms-manifest.js'), jsCode, 'utf8');

  return manifest;
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
  });
}

const server = http.createServer(async (req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  // ------------------------------------------------------------------------
  // API Endpoints
  // ------------------------------------------------------------------------
  if (pathname === '/api/status' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'online',
      mode: 'folder-native',
      workspaceDir: ROOT_DIR,
      formsDir: FORMS_DIR,
      timestamp: new Date().toISOString()
    }));
    return;
  }

  if (pathname === '/api/manifest' && req.method === 'GET') {
    const manifest = rebuildMasterManifest();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(manifest));
    return;
  }

  // Save Form schema (Working Draft)
  if (pathname === '/api/forms/save' && req.method === 'POST') {
    try {
      const data = await parseJsonBody(req);
      const formId = data.formId || (data.label || 'form').toLowerCase().replace(/[^a-z0-9]/g, '-');
      const formDir = path.join(FORMS_DIR, formId);

      if (!fs.existsSync(formDir)) fs.mkdirSync(formDir, { recursive: true });

      // Save form.json
      fs.writeFileSync(path.join(formDir, 'form.json'), JSON.stringify(data.schema || {}, null, 2), 'utf8');

      // Update manifest.json
      const manifestPath = path.join(formDir, 'manifest.json');
      let formMeta = {};
      if (fs.existsSync(manifestPath)) {
        try { formMeta = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch (e) {}
      }
      formMeta.id = formId;
      if (data.label) formMeta.label = data.label;
      if (data.icon) formMeta.icon = data.icon;
      if (data.configFile) formMeta.configFile = data.configFile;
      if (data.activeSprint) formMeta.activeSprint = data.activeSprint;
      if (data.activeVersionId) formMeta.activeVersionId = data.activeVersionId;
      formMeta.updatedAt = new Date().toISOString();
      fs.writeFileSync(manifestPath, JSON.stringify(formMeta, null, 2), 'utf8');

      // Rebuild global catalog
      rebuildMasterManifest();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        message: `Saved form to forms/${formId}/form.json`,
        formId,
        filePath: `forms/${formId}/form.json`
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // Delete Form from disk
  if (pathname === '/api/forms/delete' && req.method === 'POST') {
    try {
      const data = await parseJsonBody(req);
      const formId = data.formId;
      if (!formId) throw new Error('Missing formId');

      const formDir = path.join(FORMS_DIR, formId);
      if (fs.existsSync(formDir)) {
        fs.rmSync(formDir, { recursive: true, force: true });
        console.log(`[MOPS] 🗑️ Deleted form folder from disk: forms/${formId}`);
      }

      // Rebuild global catalog
      rebuildMasterManifest();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        message: `Deleted form forms/${formId}`,
        formId
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // Save Sprint Version Snapshot
  if (pathname === '/api/versions/save' && req.method === 'POST') {
    try {
      const data = await parseJsonBody(req);
      const formId = data.formId;
      if (!formId) throw new Error('Missing formId');

      const formDir = path.join(FORMS_DIR, formId);
      const versDir = path.join(formDir, 'versions');
      if (!fs.existsSync(versDir)) fs.mkdirSync(versDir, { recursive: true });

      const versionId = (data.versionId || 'v1.0').toLowerCase();
      const versionFile = path.join(versDir, `${versionId}.json`);

      const versionRecord = {
        versionId: versionId,
        versionLabel: `${versionId} (${data.sprint || 'Sprint'})`,
        sprint: data.sprint || 'Current Sprint',
        timestamp: new Date().toISOString(),
        author: data.author || 'MOPs Team',
        status: data.status || 'Active',
        notes: data.notes || '',
        schema: data.schema || {},
        stats: data.stats || {}
      };

      // Write physical version file
      fs.writeFileSync(versionFile, JSON.stringify(versionRecord, null, 2), 'utf8');

      // Also update working form.json if this is the active release
      if (data.status === 'Active') {
        fs.writeFileSync(path.join(formDir, 'form.json'), JSON.stringify(data.schema || {}, null, 2), 'utf8');
      }

      // Update form manifest
      const manifestPath = path.join(formDir, 'manifest.json');
      let formMeta = {};
      if (fs.existsSync(manifestPath)) {
        try { formMeta = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch (e) {}
      }
      formMeta.id = formId;
      formMeta.activeVersionId = versionId;
      formMeta.activeSprint = data.sprint || 'Current Sprint';
      formMeta.updatedAt = new Date().toISOString();
      fs.writeFileSync(manifestPath, JSON.stringify(formMeta, null, 2), 'utf8');

      // Rebuild global catalog
      rebuildMasterManifest();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        message: `Version snapshot saved to forms/${formId}/versions/${versionId}.json`,
        formId,
        versionId,
        filePath: `forms/${formId}/versions/${versionId}.json`
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // Save Sprint Metadata to disk
  if (pathname === '/api/sprints/save' && req.method === 'POST') {
    try {
      const data = await parseJsonBody(req);
      const formId = data.formId;
      const sprintId = (data.sprintId || 'sprint-25.3').toLowerCase().replace(/[^a-z0-9.]/g, '-');
      if (!formId) throw new Error('Missing formId');

      const formDir = path.join(FORMS_DIR, formId);
      const sprintDir = path.join(formDir, 'sprints', sprintId);
      const versDir = path.join(sprintDir, 'versions');
      if (!fs.existsSync(versDir)) fs.mkdirSync(versDir, { recursive: true });

      const sprintFile = path.join(sprintDir, 'sprint.json');
      const sprintRecord = {
        sprintId: sprintId,
        sprintLabel: data.sprintLabel || sprintId,
        startDate: data.startDate || new Date().toISOString().slice(0, 10),
        endDate: data.endDate || '',
        status: data.status || 'Active',
        publishedVersionId: data.publishedVersionId || 'v1.0',
        versions: (data.versions || []).map(v => ({
          versionId: v.versionId || 'v1.0',
          timestamp: v.timestamp || new Date().toISOString(),
          author: v.author || 'MOPs Business Team',
          notes: v.notes || '',
          status: v.status || 'Active'
        }))
      };

      fs.writeFileSync(sprintFile, JSON.stringify(sprintRecord, null, 2), 'utf8');

      // If versions array is provided, write individual version files
      if (Array.isArray(data.versions)) {
        data.versions.forEach(v => {
          if (v && v.versionId) {
            const vFile = path.join(versDir, `${v.versionId.toLowerCase()}.json`);
            if (!fs.existsSync(vFile)) {
              fs.writeFileSync(vFile, JSON.stringify(v, null, 2), 'utf8');
            }
          }
        });
      }

      // Update form manifest
      const manifestPath = path.join(formDir, 'manifest.json');
      let formMeta = {};
      if (fs.existsSync(manifestPath)) {
        try { formMeta = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch (e) {}
      }
      formMeta.id = formId;
      if (data.status === 'Active') {
        formMeta.activeSprint = sprintId;
        if (data.publishedVersionId) formMeta.activeVersionId = data.publishedVersionId;
      }
      formMeta.updatedAt = new Date().toISOString();
      fs.writeFileSync(manifestPath, JSON.stringify(formMeta, null, 2), 'utf8');

      // Rebuild global catalog
      rebuildMasterManifest();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        message: `Sprint saved to forms/${formId}/sprints/${sprintId}/sprint.json`,
        formId,
        sprintId,
        filePath: `forms/${formId}/sprints/${sprintId}/sprint.json`
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // ------------------------------------------------------------------------
  // Generate & Download PDF Export
  // ------------------------------------------------------------------------
  if (pathname === '/api/export-pdf' && req.method === 'POST') {
    try {
      const data = await parseJsonBody(req);
      const htmlContent = data.html || '';
      const filename = data.filename || 'mops-intake-form.pdf';

      if (!htmlContent) throw new Error('Missing HTML content for PDF generation');

      const tmpHtmlPath = path.join(ROOT_DIR, '.tmp_pdf_source.html');
      const tmpPdfPath = path.join(ROOT_DIR, '.tmp_pdf_output.pdf');

      fs.writeFileSync(tmpHtmlPath, htmlContent, 'utf8');

      // Locate browser executable
      const possibleBrowsers = [
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
      ];
      const browserExe = possibleBrowsers.find(p => fs.existsSync(p));

      if (!browserExe) {
        throw new Error('No compatible headless browser (Edge/Chrome) found for PDF generation');
      }

      const fileUrl = 'http://localhost:' + PORT + '/.tmp_pdf_source.html';
      const cmd = `"${browserExe}" --headless --disable-gpu --run-all-compositor-stages-before-draw --no-pdf-header-footer --print-to-pdf="${tmpPdfPath}" "${fileUrl}"`;

      exec(cmd, { timeout: 15000 }, (error, stdout, stderr) => {
        if (error || !fs.existsSync(tmpPdfPath)) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: error ? error.message : 'PDF generation timed out' }));
          try { if (fs.existsSync(tmpHtmlPath)) fs.unlinkSync(tmpHtmlPath); } catch (e) {}
          return;
        }

        const pdfBuffer = fs.readFileSync(tmpPdfPath);
        res.writeHead(200, {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${filename}"`,
          'Content-Length': pdfBuffer.length
        });
        res.end(pdfBuffer);

        // Cleanup
        try {
          if (fs.existsSync(tmpHtmlPath)) fs.unlinkSync(tmpHtmlPath);
          if (fs.existsSync(tmpPdfPath)) fs.unlinkSync(tmpPdfPath);
        } catch (e) {}
      });
      return;
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
      return;
    }
  }

  // ------------------------------------------------------------------------
  // Static File Serving
  // ------------------------------------------------------------------------
  let reqPath = pathname === '/' ? '/index.html' : pathname;
  // Prevent directory traversal
  const safePath = path.normalize(reqPath).replace(/^(\.\.[\/\\])+/, '');
  const filePath = path.join(ROOT_DIR, safePath);

  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('404 Not Found: ' + reqPath);
  }
});

server.listen(PORT, () => {
  console.log('=====================================================================');
  console.log('  MOPS Form Mockup & Rule Studio — Folder Workspace Server');
  console.log('=====================================================================');
  console.log(`  Local URL:        http://localhost:${PORT}`);
  console.log(`  Workspace Folder: ${ROOT_DIR}`);
  console.log(`  Forms Directory:  ${FORMS_DIR}`);
  console.log('---------------------------------------------------------------------');
  console.log('  * Every form and version saved writes physical JSON files to disk.');
  console.log('  * Ready to zip and share with any team member.');
  console.log('=====================================================================');

  // Auto-open browser
  const startCmd = process.platform === 'win32' ? 'start' : (process.platform === 'darwin' ? 'open' : 'xdg-open');
  exec(`${startCmd} http://localhost:${PORT}`);
});
