# DART Form Studio — Native Windows PowerShell Workspace Server
# Runs 100% natively on any Windows computer without Node.js or any external software installed.

$port = 3000
$root = $PSScriptRoot
$formsDir = Join-Path $root "forms"

Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  DART Form Mockup and Rule Studio - Native Windows Server" -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  URL:              http://localhost:$port" -ForegroundColor Green
Write-Host "  Workspace Folder: $root" -ForegroundColor Yellow
Write-Host "  Forms Directory:  $formsDir" -ForegroundColor Yellow
Write-Host "---------------------------------------------------------------------"
Write-Host "  * All forms and versions are saved directly to folder structure."
Write-Host "  * Press Ctrl+C in this terminal window to stop the server."
Write-Host "====================================================================="

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
} catch {
    Write-Host "[ERROR] Could not bind to port $port. Is another server running?" -ForegroundColor Red
    Write-Host "Trying fallback port 3001..." -ForegroundColor Yellow
    $port = 3001
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$port/")
    $listener.Start()
}

# Open browser
Start-Process "http://localhost:$port"

function Rebuild-Manifest {
    param([string]$formsPath)
    $script = Join-Path (Join-Path $root "scripts") "rebuild_manifest.ps1"
    if (Test-Path $script) {
        & $script
    }
    $manifestPath = Join-Path $formsPath "forms-manifest.json"
    if (Test-Path $manifestPath) {
        return (Get-Content -Raw -Path $manifestPath -Encoding UTF8) | ConvertFrom-Json
    }
    return $null
}

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response

    $response.AddHeader("Access-Control-Allow-Origin", "*")
    $response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    $response.AddHeader("Access-Control-Allow-Headers", "Content-Type")

    if ($request.HttpMethod -eq "OPTIONS") {
        $response.StatusCode = 204
        $response.Close()
        continue
    }

    $path = $request.Url.LocalPath

    if ($path -eq "/api/status" -and $request.HttpMethod -eq "GET") {
        $body = @{ status = "online"; mode = "folder-native-powershell"; workspaceDir = $root; formsDir = $formsDir } | ConvertTo-Json
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
        $response.ContentType = "application/json; charset=utf-8"
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
        $response.Close()
        continue
    }

    if ($path -eq "/api/manifest" -and $request.HttpMethod -eq "GET") {
        $manifestPath = Join-Path $formsDir "forms-manifest.json"
        if (-not (Test-Path $manifestPath)) {
            Rebuild-Manifest -formsPath $formsDir
        }
        $raw = [System.IO.File]::ReadAllText($manifestPath, [System.Text.Encoding]::UTF8)
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw)
        $response.ContentType = "application/json; charset=utf-8"
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
        $response.Close()
        continue
    }

    if ($path -eq "/api/forms/save" -and $request.HttpMethod -eq "POST") {
        $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
        $raw = $reader.ReadToEnd()
        $data = $raw | ConvertFrom-Json

        $formId = if ($data.formId) { $data.formId } else { "form" }
        $formDir = Join-Path $formsDir $formId
        if (-not (Test-Path $formDir)) { New-Item -ItemType Directory -Path $formDir -Force | Out-Null }

        $schemaJson = $data.schema | ConvertTo-Json -Depth 20
        Set-Content -Path (Join-Path $formDir "form.json") -Value $schemaJson -Encoding UTF8

        $manifestPath = Join-Path $formDir "manifest.json"
        $formMeta = @{}
        if (Test-Path $manifestPath) {
            $formMeta = (Get-Content -Raw -Path $manifestPath -Encoding UTF8) | ConvertFrom-Json
        }
        $formMeta.id = $formId
        if ($data.label) { $formMeta.label = $data.label }
        if ($data.icon) { $formMeta.icon = $data.icon }
        if ($data.configFile) { $formMeta.configFile = $data.configFile }
        $formMeta.updatedAt = (Get-Date).ToString("o")

        Set-Content -Path $manifestPath -Value ($formMeta | ConvertTo-Json -Depth 10) -Encoding UTF8
        Rebuild-Manifest -formsPath $formsDir

        $resObj = @{ ok = $true; message = "Saved form to forms/$formId/form.json"; formId = $formId; filePath = "forms/$formId/form.json" } | ConvertTo-Json
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($resObj)
        $response.ContentType = "application/json; charset=utf-8"
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
        $response.Close()
        continue
    }

    if ($path -eq "/api/versions/save" -and $request.HttpMethod -eq "POST") {
        $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
        $raw = $reader.ReadToEnd()
        $data = $raw | ConvertFrom-Json

        $formId = $data.formId
        $formDir = Join-Path $formsDir $formId

        $rawSprint = if ($data.sprint) { $data.sprint } else { "Sprint 25.1" }
        $sprintSlug = if ($data.sprintId) { $data.sprintId } else {
            $s = $rawSprint.ToLower() -replace '[^a-z0-9.]', '-' -replace '-+', '-'
            $s = $s.Trim('-')
            if (-not $s.StartsWith("sprint")) { $s = "sprint-$s" }
            $s
        }
        $sprintDir = Join-Path (Join-Path $formDir "sprints") $sprintSlug
        $sprintVersDir = Join-Path $sprintDir "versions"
        if (-not (Test-Path $sprintVersDir)) { New-Item -ItemType Directory -Path $sprintVersDir -Force | Out-Null }

        $versionId = ($data.versionId).ToLower()
        $versionFile = Join-Path $sprintVersDir "$versionId.json"

        $versionRecord = @{
            versionId = $versionId
            versionLabel = "$versionId ($rawSprint)"
            sprint = $rawSprint
            timestamp = (Get-Date).ToString("o")
            author = if ($data.author) { $data.author } else { "MOPs Team" }
            status = if ($data.status) { $data.status } else { "Active" }
            notes = if ($data.notes) { $data.notes } else { "" }
            schema = $data.schema
            stats = $data.stats
        }

        [System.IO.File]::WriteAllText($versionFile, ($versionRecord | ConvertTo-Json -Depth 20), [System.Text.Encoding]::UTF8)

        # Update or create sprint.json
        $sprintMetaFile = Join-Path $sprintDir "sprint.json"
        $sprintMeta = @{}
        if (Test-Path $sprintMetaFile) {
            try { $sprintMeta = (Get-Content -Raw -Path $sprintMetaFile -Encoding UTF8) | ConvertFrom-Json } catch {}
        }
        $sprintMeta.sprintId = $sprintSlug
        if (-not $sprintMeta.sprintLabel) { $sprintMeta.sprintLabel = $rawSprint }
        if ($data.status -eq "Active" -or $data.status -eq "Published") {
            $sprintMeta.publishedVersionId = $versionId
            $sprintMeta.status = "Active"
        }
        [System.IO.File]::WriteAllText($sprintMetaFile, ($sprintMeta | ConvertTo-Json -Depth 10), [System.Text.Encoding]::UTF8)

        # Also write legacy versions/ for fallback compatibility
        $legacyVersDir = Join-Path $formDir "versions"
        if (Test-Path $legacyVersDir) {
            [System.IO.File]::WriteAllText((Join-Path $legacyVersDir "$versionId.json"), ($versionRecord | ConvertTo-Json -Depth 20), [System.Text.Encoding]::UTF8)
        }

        if ($data.status -eq "Active" -or $data.status -eq "Published") {
            [System.IO.File]::WriteAllText((Join-Path $formDir "form.json"), ($data.schema | ConvertTo-Json -Depth 20), [System.Text.Encoding]::UTF8)
        }

        $manifestPath = Join-Path $formDir "manifest.json"
        $formMeta = @{}
        if (Test-Path $manifestPath) {
            $formMeta = (Get-Content -Raw -Path $manifestPath -Encoding UTF8) | ConvertFrom-Json
        }
        $formMeta.id = $formId
        $formMeta.activeVersionId = $versionId
        $formMeta.activeSprint = $sprintSlug
        $formMeta.updatedAt = (Get-Date).ToString("o")
        [System.IO.File]::WriteAllText($manifestPath, ($formMeta | ConvertTo-Json -Depth 10), [System.Text.Encoding]::UTF8)

        Rebuild-Manifest -formsPath $formsDir

        $resObj = @{ ok = $true; message = "Version saved to forms/$formId/sprints/$sprintSlug/versions/$versionId.json"; formId = $formId; sprintId = $sprintSlug; versionId = $versionId; filePath = "forms/$formId/sprints/$sprintSlug/versions/$versionId.json" } | ConvertTo-Json
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($resObj)
        $response.ContentType = "application/json; charset=utf-8"
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
        $response.Close()
        continue
    }

    # Static file serving
    $rel = $path.TrimStart('/')
    if ([string]::IsNullOrEmpty($rel)) { $rel = "index.html" }
    $localFile = Join-Path $root $rel

    if (Test-Path $localFile -PathType Leaf) {
        $ext = [System.IO.Path]::GetExtension($localFile).ToLower()
        $contentType = "application/octet-stream"
        switch ($ext) {
            ".html" { $contentType = "text/html; charset=utf-8" }
            ".css"  { $contentType = "text/css; charset=utf-8" }
            ".js"   { $contentType = "application/javascript; charset=utf-8" }
            ".json" { $contentType = "application/json; charset=utf-8" }
            ".png"  { $contentType = "image/png" }
            ".jpg"  { $contentType = "image/jpeg" }
            ".svg"  { $contentType = "image/svg+xml" }
            ".ico"  { $contentType = "image/x-icon" }
        }

        $bytes = [System.IO.File]::ReadAllBytes($localFile)
        $response.ContentType = $contentType
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else {
        $response.StatusCode = 404
        $notFoundBytes = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $path")
        $response.OutputStream.Write($notFoundBytes, 0, $notFoundBytes.Length)
    }
    $response.Close()
}
