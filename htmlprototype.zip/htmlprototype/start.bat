@echo off
title DART Form Mockup & Rule Studio (PHP Server)
cd /d "%~dp0"

echo =====================================================================
echo    DART Form Mockup & Rule Studio - PHP Server
echo =====================================================================
echo.

where php >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [INFO] PHP runtime detected.
    echo [INFO] Launching PHP built-in server on http://localhost:3000 ...
    echo [INFO] Direct file persistence via api.php is active!
    echo.
    start "" http://localhost:3000/
    php -S localhost:3000 router.php
    goto end
)

echo [ERROR] PHP was not found in your system PATH!
echo [ERROR] This application requires PHP (7.0+). Node.js and Python are not used.
echo [ERROR] Please install PHP or add PHP to your Windows PATH environment variable.
echo.

:end
pause
